# My Diary – Setup Guide (Flutter + Firebase)

Everything in the `flutter_app/` folder is the project. You will **create a fresh Flutter project, then copy/replace these files into it**.

## 0. What you need
1. Flutter SDK (https://docs.flutter.dev/get-started/install) – run `flutter doctor` until Android toolchain is OK.
2. Android Studio or VS Code.
3. A Google account (for Firebase – free "Spark" plan is enough).
4. Node.js (only for installing the Firebase CLI).

## 1. Create the project
```bash
flutter create --org com.ashif --project-name my_diary --platforms=android,ios,web,windows my_diary
cd my_diary
```

## 2. Copy the files (delete & replace)
Copy from `flutter_app/` into your `my_diary/` folder, replacing existing files:

| From this package | To your project |
|---|---|
| `pubspec.yaml` | `my_diary/pubspec.yaml` (replace) |
| `lib/` (whole folder) | `my_diary/lib/` (delete the old `lib`, paste the new one) |
| `assets/data/medicines.json` | `my_diary/assets/data/medicines.json` |
| **your own icon** | `my_diary/assets/icon.png` (a placeholder icon is included – overwrite it with yours) |
| `android/app/src/main/AndroidManifest.xml` | same path (replace) |
| `firestore.rules` | keep anywhere – you will paste it into the Firebase console |

* Delete `my_diary/test/widget_test.dart` (the default test refers to the old demo app).
* Your folder must be called **`assets`** (with an "s"). If yours is named `asset`, rename it or change the paths in `pubspec.yaml`.

Then:
```bash
flutter pub get
```

## 3. Android settings (one line)
Open `android/app/build.gradle.kts` (or `build.gradle` in older projects) and set:
```kotlin
defaultConfig {
    ...
    minSdk = 23        // (older projects: minSdkVersion 23)
}
```
Firebase needs minSdk 23 or higher.

## 4. Create the Firebase project
1. https://console.firebase.google.com → **Add project** → name `my-diary`.
2. **Build → Authentication → Get started → Sign-in method → Email/Password → Enable.**
3. **Build → Firestore Database → Create database** (production mode, choose a nearby region, e.g. `asia-south1`).
4. **Firestore → Rules** → delete everything, paste the content of `firestore.rules` → **Publish**.
5. In the terminal (inside `my_diary/`):
```bash
npm install -g firebase-tools
dart pub global activate flutterfire_cli
firebase login
flutterfire configure
```
Pick your project and the platforms (android, ios, web, windows). This **overwrites `lib/firebase_options.dart`** and adds `google-services.json` automatically.

## 5. App icon
Put your picture at `assets/icon.png` (1024×1024 PNG recommended), then:
```bash
dart run flutter_launcher_icons
```

## 6. Run
```bash
flutter run
```
**First login:** username `admin`, password `Solution2@` (the app creates this administrator account automatically on the first login, while online).
👉 Immediately open **Drawer → Settings → Change password** and set your own password. Anyone who knows the default password could log in as admin until you change it.

## 7. Build the release APK
```bash
flutter build apk --release        # file: build/app/outputs/flutter-apk/app-release.apk
flutter build appbundle            # for Play Store
flutter build web                  # web version
flutter build windows              # Windows (run on Windows)
```

---

## How the features work

### Users and permissions
* Companies, Medicines, Diseases, P&S are shared – **every user can read all of them**.
* Only the **creator or an administrator** can edit/delete a record (enforced both in the app and in `firestore.rules`).
* **Hisab** (customers, suppliers, cashbook, stock, notes, reports) is private. A user only sees his own data. An admin can switch to any user from the bar at the top of the Hisab tab ("Viewing data of").
* **Private visit fee:** when a disease is saved as *Private*, the fee is stored in the creator's private area (`users/{uid}/diseaseFees`) and automatically added as *Income* in his Cashbook. The disease record itself is public but contains no amount, so only the creator and admin can see the fee.
* **Admin tools** (Drawer → ADMIN): Announcements, Manage Users & Admins (promote/demote or create a new admin account), App Version Control.

### Offline + sync
Firestore keeps a local copy on the phone. You can read and add data with no internet; writes are queued and uploaded automatically when internet returns. (Register / first login need internet once.)

### Announcement dialogs
Drawer → Announcements → New: title, content, Telegram link, Web link, *Cancel allowed*, *how many times shown*. Users see it on app start. If Cancel is not allowed the user must press *Join Telegram* or *Visit Web* to continue.

### New version + force update
1. Build and upload the new APK/AAB (Play Store, website or Google Drive link).
2. Open **Drawer → App Version Control**: set *Latest version* (e.g. `1.0.2`), *Minimum version*, and *Update link*.
3. Users below *Latest* see an "Update available" dialog (can press Later). Users below *Minimum* get a **blocking** "Update required" dialog.
Increase `version:` in `pubspec.yaml` (e.g. `1.0.2+3`) for every release.

### Medicine import
Medicines tab → **Import medicines from local database**. It loads `assets/data/medicines.json` once (marker document `config/seed`), then the button is disabled for everyone.
The bundled list has the 50 veterinary company names and 48 brand/medicine entries collected from **MedEx** and **Arogga** pages (amoxicillin, ivermectin, enrofloxacin, albendazole, oxytetracycline and a few others). Pregnancy safety is imported as *not safe* and pet safety as *unsafe* (except the dog product) – **please verify and edit each one**. Add more by editing `medicines.json` (same format) or from the Add tab.

### Hisab (Tallykhata-like)
* Up to **5 businesses** (switch/rename/add at the top). No limit on entries.
* **Customers / Suppliers:** "You gave" / "You got" entries with running balance, call, SMS/WhatsApp reminder, PDF statement.
* **Group reminder:** select many customers with dues, edit the message (add your bKash/Nagad number or payment link) and send one by one (SMS or WhatsApp) or one group SMS.
* **Cashbook:** Income / Expense / Saving with categories and monthly filter.
* **Stock:** products, stock value, *Stock in*, *Stock out (sell)* asking quantity, buyer name, buyer phone (and optionally adding the sale to income).
* **Notes:** digital notebook.
* **Reports:** customer, supplier, all balances, stock & inventory (entered/sold dates), cost & savings, monthly → on-screen table + **Print / Save PDF** + **Share (WhatsApp / imo)**.

### Honest limitations
* "Free messages" use your phone's SMS / WhatsApp app (free with your SIM plan). A real automatic bulk-SMS gateway (e.g. a Bangladeshi SMS provider) needs a paid account and a server – not included.
* The new-version "notification" is an in-app dialog shown when the app opens. Push notifications while the app is closed would need Firebase Cloud Messaging + Cloud Functions (can be added later).
* The PDF Bangla font is downloaded the first time a PDF is made (internet needed once); offline it falls back to English-only text.
* Passwords are handled by Firebase Authentication (no passwords are stored in the database).
