import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/firebase_options.dart';
import 'package:my_diary/screens/auth_screen.dart';
import 'package:my_diary/screens/home_shell.dart';
import 'package:my_diary/services/startup_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // OFFLINE MODE: data is cached on the device; everything you add while offline is
  // stored locally and uploaded automatically as soon as the internet is back.
  FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true,
    cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
  );

  final app = AppState();
  await app.init();
  runApp(ChangeNotifierProvider.value(value: app, child: const MyDiaryApp()));
}

class MyDiaryApp extends StatelessWidget {
  const MyDiaryApp({super.key});

  ThemeData _theme(Brightness b) {
    return ThemeData(
      useMaterial3: true,
      colorSchemeSeed: const Color(0xFF00796B),
      brightness: b,
      appBarTheme: const AppBarTheme(centerTitle: false),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return MaterialApp(
      title: 'My Diary',
      debugShowCheckedModeBanner: false,
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      themeMode: app.themeMode,
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (!app.authReady) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (app.user == null) return const AuthScreen();
    return const StartupGate(child: HomeShell());
  }
}
