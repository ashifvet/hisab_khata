import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:my_diary/core/utils.dart';
import 'package:my_diary/services/auth_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _form = GlobalKey<FormState>();
  bool _login = true;
  bool _busy = false;
  String? _error;

  final _id = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _phone = TextEditingController();
  final _loc = TextEditingController();

  @override
  void dispose() {
    for (final c in [_id, _pass, _pass2, _first, _last, _phone, _loc]) {
      c.dispose();
    }
    super.dispose();
  }

  String _msg(Object e) {
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'invalid-credential':
        case 'wrong-password':
        case 'user-not-found':
        case 'invalid-login-credentials':
          return 'Wrong e-mail/username or password.';
        case 'email-already-in-use':
          return 'This e-mail is already registered.';
        case 'weak-password':
          return 'Password must be at least 6 characters.';
        case 'invalid-email':
          return 'Invalid e-mail address.';
        case 'network-request-failed':
          return 'No internet connection. Login/registration needs internet the first time.';
        default:
          return e.message ?? e.code;
      }
    }
    return e.toString();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      if (_login) {
        await AuthService.login(_id.text, _pass.text);
      } else {
        await AuthService.register(
          firstName: _first.text,
          lastName: _last.text,
          email: _id.text,
          phone: _phone.text,
          location: _loc.text,
          password: _pass.text,
        );
      }
    } catch (e) {
      if (mounted) setState(() => _error = _msg(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Form(
                key: _form,
                child: Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Image.asset('assets/icon.png',
                          width: 84,
                          height: 84,
                          errorBuilder: (_, __, ___) => Icon(Icons.menu_book,
                              size: 72, color: cs.primary)),
                    ),
                    const SizedBox(height: 10),
                    Text('My Diary',
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(_login ? 'Login to continue' : 'Create your account'),
                    const SizedBox(height: 20),
                    if (!_login) ...[
                      Row(children: [
                        Expanded(child: tf(_first, 'First name', required: true)),
                        const SizedBox(width: 8),
                        Expanded(child: tf(_last, 'Last name')),
                      ]),
                      tf(_phone, 'Phone number', type: TextInputType.phone),
                      tf(_loc, 'Location'),
                    ],
                    TextFormField(
                      controller: _id,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        labelText: _login ? 'Email or username' : 'Email',
                        border: const OutlineInputBorder(),
                        prefixIcon: const Icon(Icons.person_outline),
                      ),
                      validator: (v) {
                        final t = (v ?? '').trim();
                        if (t.isEmpty) return 'Required';
                        if (!_login && !t.contains('@')) return 'Enter a valid e-mail';
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _pass,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Password',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.lock_outline),
                      ),
                      validator: (v) =>
                          (v == null || v.length < 6) ? 'Minimum 6 characters' : null,
                    ),
                    if (!_login) ...[
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _pass2,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'Confirm password',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.lock_outline),
                        ),
                        validator: (v) =>
                            v != _pass.text ? 'Passwords do not match' : null,
                      ),
                    ],
                    if (_error != null) ...[
                      const SizedBox(height: 12),
                      Text(_error!, style: TextStyle(color: cs.error)),
                    ],
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: FilledButton(
                        onPressed: _busy ? null : _submit,
                        child: _busy
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(strokeWidth: 2))
                            : Text(_login ? 'Login' : 'Register'),
                      ),
                    ),
                    TextButton(
                      onPressed: _busy
                          ? null
                          : () => setState(() {
                                _login = !_login;
                                _error = null;
                              }),
                      child: Text(_login
                          ? "Don't have an account? Register"
                          : 'Already have an account? Login'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
