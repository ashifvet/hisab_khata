import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/screens/hisab_books.dart';
import 'package:my_diary/screens/reports.dart';
import 'package:my_diary/services/db.dart';

/// HISAB tab (Tallykhata-like): customers, suppliers, cashbook, stock, notes, reports.
/// Each user sees only his own data. The administrator can open any user's data.
class HisabScreen extends StatefulWidget {
  const HisabScreen({super.key});
  @override
  State<HisabScreen> createState() => _HisabScreenState();
}

class _HisabScreenState extends State<HisabScreen> {
  bool _creating = false;

  void _createMain(String uid) {
    if (_creating) return;
    _creating = true;
    fire(Db.businesses(uid).doc('main').set({
      'name': 'My Business',
      'createdAt': Timestamp.now(),
    }, SetOptions(merge: true)));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final uid = app.dataUid;
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: Db.businesses(uid).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = List<Doc>.of(snap.data!.docs);
        if (docs.isEmpty) {
          if (!snap.data!.metadata.isFromCache) {
            WidgetsBinding.instance.addPostFrameCallback((_) => _createMain(uid));
          }
          return Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const CircularProgressIndicator(),
              const SizedBox(height: 12),
              TextButton(
                  onPressed: () => _createMain(uid),
                  child: const Text('Create my first business')),
            ]),
          );
        }
        docs.sort((a, b) =>
            dt(a.data()['createdAt']).compareTo(dt(b.data()['createdAt'])));
        final cur = docs.any((d) => d.id == app.bizId) ? app.bizId! : docs.first.id;
        final curDoc = docs.firstWhere((d) => d.id == cur);
        final biz = Biz(uid, cur, name: '${curDoc.data()['name'] ?? 'My Business'}');

        return Column(
          children: [
            if (app.isAdmin) _AdminUserPicker(app: app),
            _BizHeader(app: app, docs: docs, cur: cur, uid: uid),
            Expanded(child: _HisabTabs(key: ValueKey('$uid/$cur'), biz: biz)),
          ],
        );
      },
    );
  }
}

class _AdminUserPicker extends StatelessWidget {
  const _AdminUserPicker({required this.app});
  final AppState app;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).colorScheme.tertiaryContainer,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(children: [
        const Icon(Icons.admin_panel_settings, size: 18),
        const SizedBox(width: 8),
        const Text('Viewing data of: '),
        Expanded(
          child: Q(
            query: Db.users,
            builder: (c, docs) {
              final list = List<Doc>.of(docs)
                ..sort((a, b) => '${a.data()['firstName']}'
                    .toLowerCase()
                    .compareTo('${b.data()['firstName']}'.toLowerCase()));
              final value = list.any((d) => d.id == app.dataUid) ? app.dataUid : app.uid;
              return DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: list.any((d) => d.id == value) ? value : null,
                  isExpanded: true,
                  items: [
                    for (final d in list)
                      DropdownMenuItem(
                        value: d.id,
                        child: Text(
                          d.id == app.uid
                              ? 'My own data'
                              : '${d.data()['firstName'] ?? ''} ${d.data()['lastName'] ?? ''} (${d.data()['email'] ?? ''})',
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                  ],
                  onChanged: (v) => app.setViewUid(v == null || v == app.uid ? null : v),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

class _BizHeader extends StatelessWidget {
  const _BizHeader({required this.app, required this.docs, required this.cur, required this.uid});
  final AppState app;
  final List<Doc> docs;
  final String cur;
  final String uid;

  Future<void> _add(BuildContext context) async {
    if (docs.length >= 5) {
      snack(context, 'You can manage up to 5 businesses / accounts.');
      return;
    }
    final r = await formDialog(context, 'New business / account',
        const [FieldSpec('name', 'Business name', required: true)]);
    if (r == null) return;
    final ref = Db.businesses(uid).doc();
    fire(ref.set({'name': r['name'], 'createdAt': Timestamp.now()}));
    app.setBiz(ref.id);
  }

  Future<void> _rename(BuildContext context, String current) async {
    final r = await formDialog(context, 'Rename business',
        [FieldSpec('name', 'Business name', required: true, initial: current)]);
    if (r == null) return;
    fire(Db.businesses(uid).doc(cur).update({'name': r['name']}));
  }

  @override
  Widget build(BuildContext context) {
    final curName = '${docs.firstWhere((d) => d.id == cur).data()['name']}';
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 4, 0),
      child: Row(children: [
        const Icon(Icons.store_mall_directory_outlined),
        const SizedBox(width: 8),
        Expanded(
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: cur,
              isExpanded: true,
              items: [
                for (final d in docs)
                  DropdownMenuItem(
                      value: d.id,
                      child: Text('${d.data()['name']}',
                          style: const TextStyle(fontWeight: FontWeight.bold))),
              ],
              onChanged: (v) => app.setBiz(v!),
            ),
          ),
        ),
        IconButton(
            tooltip: 'Rename',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => _rename(context, curName)),
        IconButton(
            tooltip: 'Add business (max 5)',
            icon: const Icon(Icons.add_business_outlined),
            onPressed: () => _add(context)),
      ]),
    );
  }
}

class _HisabTabs extends StatelessWidget {
  const _HisabTabs({super.key, required this.biz});
  final Biz biz;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return DefaultTabController(
      length: 6,
      child: Column(
        children: [
          TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [
              Tab(text: app.tr('Customers')),
              Tab(text: app.tr('Suppliers')),
              Tab(text: app.tr('Cashbook')),
              Tab(text: app.tr('Stock')),
              Tab(text: app.tr('Notes')),
              Tab(text: app.tr('Reports')),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                PartiesTab(biz: biz, type: 'customer'),
                PartiesTab(biz: biz, type: 'supplier'),
                CashbookTab(biz: biz),
                StockTab(biz: biz),
                NotesTab(biz: biz),
                ReportsTab(biz: biz),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================ PARTIES
class PartyBal {
  const PartyBal(this.id, this.name, this.phone, this.bal);
  final String id;
  final String name;
  final String phone;
  final double bal; // >0 : you will get, <0 : you will give
}

Map<String, double> partyBalances(List<Doc> entries) {
  final m = <String, double>{};
  for (final e in entries) {
    final d = e.data();
    final id = '${d['partyId']}';
    final a = numv(d['amount']);
    m[id] = (m[id] ?? 0) + (d['kind'] == 'gave' ? a : -a);
  }
  return m;
}

class PartiesTab extends StatelessWidget {
  const PartiesTab({super.key, required this.biz, required this.type});
  final Biz biz;
  final String type;

  bool get _isC => type == 'customer';

  Future<void> _add(BuildContext context) async {
    final r = await formDialog(context, _isC ? 'Add customer' : 'Add supplier', const [
      FieldSpec('name', 'Name', required: true),
      FieldSpec('phone', 'Phone', kind: FK.phone),
    ]);
    if (r == null) return;
    fire(biz.col('parties').add({
      'name': r['name'],
      'phone': r['phone'],
      'type': type,
      'createdAt': Timestamp.now(),
    }));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _add(context),
        icon: const Icon(Icons.person_add_alt_1),
        label: Text(app.tr(_isC ? 'Add Customer' : 'Add Supplier')),
      ),
      body: Q(
        query: biz.col('parties'),
        builder: (c, parties) => Q(
          query: biz.col('entries'),
          builder: (c, entries) {
            final bal = partyBalances(entries);
            final list = parties.where((p) => p.data()['type'] == type).toList()
              ..sort((a, b) => '${a.data()['name']}'
                  .toLowerCase()
                  .compareTo('${b.data()['name']}'.toLowerCase()));
            double toGet = 0, toGive = 0;
            for (final p in list) {
              final b = bal[p.id] ?? 0;
              if (b > 0) {
                toGet += b;
              } else {
                toGive += -b;
              }
            }
            final dues = [
              for (final p in list)
                if ((bal[p.id] ?? 0) > 0)
                  PartyBal(p.id, '${p.data()['name']}', '${p.data()['phone'] ?? ''}', bal[p.id]!)
            ];
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                  child: Row(children: [
                    Expanded(child: _Total(app.tr('You will get'), toGet, Colors.green)),
                    const SizedBox(width: 8),
                    Expanded(child: _Total(app.tr('You will give'), toGive, Colors.red)),
                  ]),
                ),
                if (dues.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.notifications_active_outlined),
                        label: Text('${app.tr('Group reminder')} (${dues.length})'),
                        onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => GroupReminderScreen(biz: biz, parties: dues))),
                      ),
                    ),
                  ),
                Expanded(
                  child: list.isEmpty
                      ? EmptyState(
                          _isC ? 'No customers yet.' : 'No suppliers yet.',
                          icon: Icons.people_outline)
                      : ListView.separated(
                          padding: const EdgeInsets.only(bottom: 90),
                          itemCount: list.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (c, i) {
                            final p = list[i];
                            final b = bal[p.id] ?? 0;
                            return ListTile(
                              leading: CircleAvatar(
                                  child: Text('${p.data()['name']}'.isEmpty
                                      ? '?'
                                      : '${p.data()['name']}'[0].toUpperCase())),
                              title: Text('${p.data()['name']}'),
                              subtitle: Text('${p.data()['phone'] ?? ''}'),
                              trailing: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(money(b.abs()),
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: b >= 0 ? Colors.green : Colors.red)),
                                  Text(b == 0
                                      ? 'Settled'
                                      : b > 0
                                          ? 'You will get'
                                          : 'You will give',
                                      style: const TextStyle(fontSize: 10)),
                                ],
                              ),
                              onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => PartyScreen(biz: biz, partyId: p.id))),
                            );
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Total extends StatelessWidget {
  const _Total(this.label, this.value, this.color);
  final String label;
  final double value;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontSize: 12)),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(money(value),
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          ),
        ]),
      ),
    );
  }
}

// ============================================================ PARTY LEDGER
class PartyScreen extends StatelessWidget {
  const PartyScreen({super.key, required this.biz, required this.partyId});
  final Biz biz;
  final String partyId;

  Future<void> _entry(BuildContext context, String kind) async {
    final r = await formDialog(context, kind == 'gave' ? 'You gave' : 'You got', const [
      FieldSpec('amount', 'Amount', kind: FK.number, required: true),
      FieldSpec('note', 'Note (optional)'),
      FieldSpec('date', 'Date', kind: FK.date),
    ]);
    if (r == null) return;
    fire(biz.col('entries').add({
      'partyId': partyId,
      'kind': kind,
      'amount': double.parse(r['amount']!),
      'note': r['note'],
      'date': Timestamp.fromDate(DateTime.tryParse(r['date']!) ?? DateTime.now()),
    }));
  }

  String _msg(String name, double bal) =>
      'Dear $name, your outstanding balance with ${biz.name} is ${moneyPlain(bal)}. Please pay at your earliest convenience. Thank you.';

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: biz.col('parties').doc(partyId).snapshots(),
      builder: (context, ps) {
        if (!ps.hasData) {
          return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        }
        if (!ps.data!.exists) {
          return Scaffold(appBar: AppBar(), body: const EmptyState('Deleted'));
        }
        final p = ps.data!.data() ?? {};
        final name = '${p['name']}';
        final phone = '${p['phone'] ?? ''}';
        return Q(
          query: biz.col('entries').where('partyId', isEqualTo: partyId),
          builder: (context, docs) {
            final list = List<Doc>.of(docs)
              ..sort((a, b) => dt(b.data()['date']).compareTo(dt(a.data()['date'])));
            double bal = 0;
            for (final e in list) {
              final a = numv(e.data()['amount']);
              bal += e.data()['kind'] == 'gave' ? a : -a;
            }
            return Scaffold(
              appBar: AppBar(
                title: Text(name),
                actions: [
                  if (phone.isNotEmpty)
                    IconButton(
                        tooltip: 'Call',
                        icon: const Icon(Icons.call),
                        onPressed: () => openUrl('tel:$phone')),
                  PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'sms') {
                        sendSms([phone], _msg(name, bal));
                      } else if (v == 'wa') {
                        sendWhatsApp(phone, _msg(name, bal));
                      } else if (v == 'pdf') {
                        final data = await Reports.party(biz, partyId);
                        if (context.mounted) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => ReportScreen(data: data, bizName: biz.name)));
                        }
                      } else if (v == 'edit') {
                        final r = await formDialog(context, 'Edit', [
                          FieldSpec('name', 'Name', required: true, initial: name),
                          FieldSpec('phone', 'Phone', kind: FK.phone, initial: phone),
                        ]);
                        if (r != null) {
                          fire(biz.col('parties').doc(partyId).update(
                              {'name': r['name'], 'phone': r['phone']}));
                        }
                      } else if (v == 'del') {
                        if (await confirm(context, 'Delete $name and all entries?')) {
                          final es = await biz.col('entries').where('partyId', isEqualTo: partyId).get();
                          final b = Db.f.batch();
                          for (final d in es.docs) {
                            b.delete(d.reference);
                          }
                          b.delete(biz.col('parties').doc(partyId));
                          fire(b.commit());
                          if (context.mounted) Navigator.pop(context);
                        }
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'sms', child: Text('Remind via SMS')),
                      PopupMenuItem(value: 'wa', child: Text('Remind via WhatsApp')),
                      PopupMenuItem(value: 'pdf', child: Text('Statement (PDF)')),
                      PopupMenuItem(value: 'edit', child: Text('Edit')),
                      PopupMenuItem(value: 'del', child: Text('Delete')),
                    ],
                  ),
                ],
              ),
              body: Column(
                children: [
                  Card(
                    margin: const EdgeInsets.all(12),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(bal == 0
                              ? 'Settled'
                              : bal > 0
                                  ? 'You will get'
                                  : 'You will give'),
                          Text(money(bal.abs()),
                              style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: bal >= 0 ? Colors.green : Colors.red)),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: list.isEmpty
                        ? const EmptyState('No entries yet.', icon: Icons.receipt_long_outlined)
                        : ListView.separated(
                            itemCount: list.length,
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemBuilder: (c, i) {
                              final d = list[i].data();
                              final gave = d['kind'] == 'gave';
                              return ListTile(
                                title: Text(fmtDate(dt(d['date']))),
                                subtitle: Text('${d['note'] ?? ''}'),
                                trailing: Text(
                                  money(numv(d['amount'])),
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: gave ? Colors.red : Colors.green),
                                ),
                                leading: Icon(gave ? Icons.arrow_upward : Icons.arrow_downward,
                                    color: gave ? Colors.red : Colors.green),
                                onLongPress: () async {
                                  if (await confirm(context, 'Delete this entry?')) {
                                    fire(list[i].reference.delete());
                                  }
                                },
                              );
                            },
                          ),
                  ),
                ],
              ),
              bottomNavigationBar: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    Expanded(
                      child: FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: Colors.red),
                        onPressed: () => _entry(context, 'gave'),
                        child: const Text('You gave'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: Colors.green),
                        onPressed: () => _entry(context, 'got'),
                        child: const Text('You got'),
                      ),
                    ),
                  ]),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

// ============================================================ GROUP REMINDER
class GroupReminderScreen extends StatefulWidget {
  const GroupReminderScreen({super.key, required this.biz, required this.parties});
  final Biz biz;
  final List<PartyBal> parties;
  @override
  State<GroupReminderScreen> createState() => _GroupReminderScreenState();
}

class _GroupReminderScreenState extends State<GroupReminderScreen> {
  late final Set<String> _selected = widget.parties.map((e) => e.id).toSet();
  final Set<String> _sent = {};
  late final TextEditingController _tpl = TextEditingController(
      text:
          'Dear {name}, your outstanding balance with {business} is {amount}. Please pay at your earliest convenience. Thank you.');

  @override
  void dispose() {
    _tpl.dispose();
    super.dispose();
  }

  String _build(PartyBal p) => _tpl.text
      .replaceAll('{name}', p.name)
      .replaceAll('{business}', widget.biz.name)
      .replaceAll('{amount}', moneyPlain(p.bal));

  @override
  Widget build(BuildContext context) {
    final chosen = widget.parties.where((p) => _selected.contains(p.id)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Group reminder')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _tpl,
              minLines: 3,
              maxLines: 5,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                labelText: 'Message  ({name}, {business}, {amount})',
                helperText: 'You can add your bKash / Nagad number or payment link here.',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          CheckboxListTile(
            dense: true,
            title: const Text('Select all'),
            value: _selected.length == widget.parties.length,
            onChanged: (v) => setState(() {
              if (v == true) {
                _selected.addAll(widget.parties.map((e) => e.id));
              } else {
                _selected.clear();
              }
            }),
          ),
          Expanded(
            child: ListView(
              children: [
                for (final p in widget.parties)
                  CheckboxListTile(
                    value: _selected.contains(p.id),
                    onChanged: (v) => setState(() {
                      if (v == true) {
                        _selected.add(p.id);
                      } else {
                        _selected.remove(p.id);
                      }
                    }),
                    title: Text(p.name),
                    subtitle: Text('${p.phone.isEmpty ? 'no phone' : p.phone}  •  ${money(p.bal)}'),
                    secondary: Row(mainAxisSize: MainAxisSize.min, children: [
                      if (_sent.contains(p.id)) const Icon(Icons.done_all, color: Colors.green),
                      IconButton(
                        tooltip: 'SMS',
                        icon: const Icon(Icons.sms_outlined),
                        onPressed: p.phone.isEmpty
                            ? null
                            : () {
                                sendSms([p.phone], _build(p));
                                setState(() => _sent.add(p.id));
                              },
                      ),
                      IconButton(
                        tooltip: 'WhatsApp',
                        icon: const Icon(Icons.chat_outlined, color: Colors.green),
                        onPressed: p.phone.isEmpty
                            ? null
                            : () {
                                sendWhatsApp(p.phone, _build(p));
                                setState(() => _sent.add(p.id));
                              },
                      ),
                    ]),
                  ),
              ],
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  icon: const Icon(Icons.send),
                  label: Text('Send one SMS to all selected (${chosen.length})'),
                  onPressed: chosen.isEmpty
                      ? null
                      : () {
                          final msg = _tpl.text
                              .replaceAll('{name}', 'Customer')
                              .replaceAll('{business}', widget.biz.name)
                              .replaceAll('{amount}', 'the due amount');
                          sendSms(chosen.map((e) => e.phone).toList(), msg);
                          setState(() => _sent.addAll(chosen.map((e) => e.id)));
                        },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
