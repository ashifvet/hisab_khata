import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/services/db.dart';

// ====================================================================== CASHBOOK
const _incomeCats = ['Sales', 'Private visit fee', 'Hospital income', 'Other'];
const _expenseCats = [
  'Medicine purchase', 'Rent', 'Salary', 'Transport', 'Food', 'Utilities', 'Other'
];
const _savingCats = ['Bank', 'Cash savings', 'DPS / FDR', 'Other'];

class CashbookTab extends StatefulWidget {
  const CashbookTab({super.key, required this.biz});
  final Biz biz;
  @override
  State<CashbookTab> createState() => _CashbookTabState();
}

class _CashbookTabState extends State<CashbookTab> {
  String _month = 'all';

  Future<void> _add(String type) async {
    final cats = type == 'income'
        ? _incomeCats
        : type == 'expense'
            ? _expenseCats
            : _savingCats;
    final r = await formDialog(
        context,
        type == 'income'
            ? 'Add income'
            : type == 'expense'
                ? 'Add expense'
                : 'Add saving',
        [
          const FieldSpec('amount', 'Amount', kind: FK.number, required: true),
          FieldSpec('category', 'Category', kind: FK.choice, options: cats),
          const FieldSpec('note', 'Note (optional)'),
          const FieldSpec('date', 'Date', kind: FK.date),
        ]);
    if (r == null) return;
    fire(widget.biz.col('cash').add({
      'type': type,
      'amount': double.parse(r['amount']!),
      'category': r['category'],
      'note': r['note'],
      'date': Timestamp.fromDate(DateTime.tryParse(r['date']!) ?? DateTime.now()),
    }));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final now = DateTime.now();
    final months = [for (var i = 0; i < 12; i++) ym(DateTime(now.year, now.month - i))];
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
          child: Row(children: [
            const Icon(Icons.filter_alt_outlined, size: 18),
            const SizedBox(width: 6),
            DropdownButton<String>(
              value: _month,
              underline: const SizedBox.shrink(),
              items: [
                const DropdownMenuItem(value: 'all', child: Text('All time')),
                for (final m in months) DropdownMenuItem(value: m, child: Text(m)),
              ],
              onChanged: (v) => setState(() => _month = v!),
            ),
          ]),
        ),
        Expanded(
          child: Q(
            query: widget.biz.col('cash'),
            builder: (c, docs) {
              final list = docs
                  .where((d) => _month == 'all' || ym(dt(d.data()['date'])) == _month)
                  .toList()
                ..sort((a, b) => dt(b.data()['date']).compareTo(dt(a.data()['date'])));
              double inc = 0, exp = 0, sav = 0;
              for (final d in list) {
                final a = numv(d.data()['amount']);
                switch (d.data()['type']) {
                  case 'income':
                    inc += a;
                    break;
                  case 'expense':
                    exp += a;
                    break;
                  default:
                    sav += a;
                }
              }
              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(children: [
                      _Mini(app.tr('Income'), inc, Colors.green),
                      _Mini(app.tr('Expense'), exp, Colors.red),
                      _Mini(app.tr('Saving'), sav, Colors.blue),
                      _Mini(app.tr('Balance'), inc - exp - sav, Colors.teal),
                    ]),
                  ),
                  Expanded(
                    child: list.isEmpty
                        ? const EmptyState('No cashbook entries.', icon: Icons.menu_book_outlined)
                        : ListView.separated(
                            itemCount: list.length,
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemBuilder: (c, i) {
                              final d = list[i].data();
                              final t = '${d['type']}';
                              final col = t == 'income'
                                  ? Colors.green
                                  : t == 'expense'
                                      ? Colors.red
                                      : Colors.blue;
                              return ListTile(
                                leading: Icon(
                                    t == 'income'
                                        ? Icons.south_west
                                        : t == 'expense'
                                            ? Icons.north_east
                                            : Icons.savings_outlined,
                                    color: col),
                                title: Text('${d['category'] ?? t}'),
                                subtitle: Text(
                                    '${fmtDate(dt(d['date']))}${('${d['note'] ?? ''}').isEmpty ? '' : '  •  ${d['note']}'}'),
                                trailing: Text(
                                    '${t == 'income' ? '+' : '-'}${money(numv(d['amount']))}',
                                    style: TextStyle(
                                        color: col, fontWeight: FontWeight.bold, fontSize: 15)),
                                onLongPress: () async {
                                  if (await confirm(context, 'Delete this entry?')) {
                                    fire(list[i].reference.delete());
                                  }
                                },
                              );
                            },
                          ),
                  ),
                  SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(8, 4, 8, 6),
                      child: Row(children: [
                        Expanded(
                            child: FilledButton(
                                style: FilledButton.styleFrom(backgroundColor: Colors.green),
                                onPressed: () => _add('income'),
                                child: const Text('+ Income'))),
                        const SizedBox(width: 6),
                        Expanded(
                            child: FilledButton(
                                style: FilledButton.styleFrom(backgroundColor: Colors.red),
                                onPressed: () => _add('expense'),
                                child: const Text('+ Expense'))),
                        const SizedBox(width: 6),
                        Expanded(
                            child: FilledButton(
                                style: FilledButton.styleFrom(backgroundColor: Colors.blue),
                                onPressed: () => _add('saving'),
                                child: const Text('+ Saving'))),
                      ]),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}

class _Mini extends StatelessWidget {
  const _Mini(this.label, this.value, this.color);
  final String label;
  final double value;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        margin: const EdgeInsets.all(3),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
          child: Column(children: [
            FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: const TextStyle(fontSize: 11))),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(money(value),
                  style: TextStyle(fontWeight: FontWeight.bold, color: color, fontSize: 14)),
            ),
          ]),
        ),
      ),
    );
  }
}

// ====================================================================== STOCK
const _units = ['pcs', 'vial', 'bottle', 'box', 'packet', 'strip', 'kg', 'litre', 'dose'];

class StockTab extends StatelessWidget {
  const StockTab({super.key, required this.biz});
  final Biz biz;

  Future<void> _addProduct(BuildContext context) async {
    final r = await formDialog(context, 'Add product', const [
      FieldSpec('name', 'Product name', required: true),
      FieldSpec('unit', 'Unit', kind: FK.choice, options: _units),
      FieldSpec('qty', 'Quantity', kind: FK.number, required: true),
      FieldSpec('buy', 'Buying price (per unit)', kind: FK.number, required: true),
      FieldSpec('sell', 'Selling price (per unit)', kind: FK.number),
      FieldSpec('date', 'Date entered', kind: FK.date),
    ]);
    if (r == null) return;
    final qty = double.parse(r['qty']!);
    final buy = double.parse(r['buy']!);
    final date = Timestamp.fromDate(DateTime.tryParse(r['date']!) ?? DateTime.now());
    final ref = biz.col('products').doc();
    final b = Db.f.batch();
    b.set(ref, {
      'name': r['name'],
      'unit': r['unit'],
      'qty': qty,
      'buyPrice': buy,
      'sellPrice': double.tryParse(r['sell'] ?? '') ?? 0,
      'addedAt': date,
      'lastSoldAt': null,
    });
    b.set(biz.col('moves').doc(), {
      'productId': ref.id,
      'productName': r['name'],
      'type': 'in',
      'qty': qty,
      'unitPrice': buy,
      'buyerName': '',
      'buyerPhone': '',
      'date': date,
    });
    fire(b.commit());
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addProduct(context),
        icon: const Icon(Icons.add_box_outlined),
        label: Text(app.tr('Add product')),
      ),
      body: Q(
        query: biz.col('products'),
        builder: (c, docs) {
          final list = List<Doc>.of(docs)
            ..sort((a, b) => '${a.data()['name']}'
                .toLowerCase()
                .compareTo('${b.data()['name']}'.toLowerCase()));
          double value = 0;
          for (final d in list) {
            value += numv(d.data()['qty']) * numv(d.data()['buyPrice']);
          }
          return Column(
            children: [
              Card(
                margin: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(app.tr('Stock value'), style: const TextStyle(fontSize: 12)),
                        Text(money(value),
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                      ]),
                      Text('${list.length} products'),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? const EmptyState('No products yet.', icon: Icons.inventory_2_outlined)
                    : ListView.separated(
                        padding: const EdgeInsets.only(bottom: 90),
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (c, i) {
                          final d = list[i].data();
                          final qty = numv(d['qty']);
                          return ListTile(
                            title: Text('${d['name']}'),
                            subtitle: Text(
                                'Buy ${money(numv(d['buyPrice']))}  •  Sell ${money(numv(d['sellPrice']))}'),
                            trailing: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text('${fmtNum(qty)} ${d['unit'] ?? ''}',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: qty <= 0 ? Colors.red : null)),
                                Text(money(qty * numv(d['buyPrice'])),
                                    style: const TextStyle(fontSize: 11)),
                              ],
                            ),
                            onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => ProductScreen(biz: biz, productId: list[i].id))),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class ProductScreen extends StatelessWidget {
  const ProductScreen({super.key, required this.biz, required this.productId});
  final Biz biz;
  final String productId;

  DocumentReference<Map<String, dynamic>> get _ref => biz.col('products').doc(productId);

  Future<void> _in(BuildContext context, Map<String, dynamic> p) async {
    final r = await formDialog(context, 'Stock in', [
      const FieldSpec('qty', 'Quantity', kind: FK.number, required: true),
      FieldSpec('buy', 'Buying price (per unit)',
          kind: FK.number, required: true, initial: fmtNum(numv(p['buyPrice'])).replaceAll(',', '')),
      const FieldSpec('date', 'Date', kind: FK.date),
    ]);
    if (r == null) return;
    final qty = double.parse(r['qty']!);
    final buy = double.parse(r['buy']!);
    final b = Db.f.batch();
    b.update(_ref, {'qty': FieldValue.increment(qty), 'buyPrice': buy});
    b.set(biz.col('moves').doc(), {
      'productId': productId,
      'productName': p['name'],
      'type': 'in',
      'qty': qty,
      'unitPrice': buy,
      'buyerName': '',
      'buyerPhone': '',
      'date': Timestamp.fromDate(DateTime.tryParse(r['date']!) ?? DateTime.now()),
    });
    fire(b.commit());
  }

  Future<void> _out(BuildContext context, Map<String, dynamic> p) async {
    final r = await formDialog(context, 'Stock out (sell)', [
      const FieldSpec('qty', 'Quantity', kind: FK.number, required: true),
      const FieldSpec('buyer', 'Sold to (buyer name)', required: true),
      const FieldSpec('phone', 'Buyer phone number', kind: FK.phone),
      FieldSpec('price', 'Selling price (per unit)',
          kind: FK.number, required: true, initial: fmtNum(numv(p['sellPrice'])).replaceAll(',', '')),
      const FieldSpec('date', 'Date', kind: FK.date),
      const FieldSpec('cash', 'Add the sale to Cashbook income?',
          kind: FK.choice, options: ['Yes', 'No']),
    ]);
    if (r == null || !context.mounted) return;
    final qty = double.parse(r['qty']!);
    final price = double.parse(r['price']!);
    if (qty <= 0) {
      snack(context, 'Quantity must be greater than 0');
      return;
    }
    if (qty > numv(p['qty'])) {
      snack(context, 'Not enough stock. Available: ${fmtNum(numv(p['qty']))}');
      return;
    }
    final date = Timestamp.fromDate(DateTime.tryParse(r['date']!) ?? DateTime.now());
    final b = Db.f.batch();
    b.update(_ref, {'qty': FieldValue.increment(-qty), 'lastSoldAt': date});
    b.set(biz.col('moves').doc(), {
      'productId': productId,
      'productName': p['name'],
      'type': 'out',
      'qty': qty,
      'unitPrice': price,
      'buyerName': r['buyer'],
      'buyerPhone': r['phone'],
      'date': date,
    });
    if (r['cash'] == 'Yes') {
      b.set(biz.col('cash').doc(), {
        'type': 'income',
        'amount': qty * price,
        'category': 'Sales',
        'note': '${p['name']} x ${fmtNum(qty)} to ${r['buyer']}',
        'date': date,
      });
    }
    fire(b.commit());
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _ref.snapshots(),
      builder: (context, ps) {
        if (!ps.hasData) {
          return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        }
        if (!ps.data!.exists) {
          return Scaffold(appBar: AppBar(), body: const EmptyState('Product deleted'));
        }
        final p = ps.data!.data() ?? {};
        return Scaffold(
          appBar: AppBar(
            title: Text('${p['name']}'),
            actions: [
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  if (await confirm(context, 'Delete this product and its history?')) {
                    final ms = await biz.col('moves').where('productId', isEqualTo: productId).get();
                    final b = Db.f.batch();
                    for (final d in ms.docs) {
                      b.delete(d.reference);
                    }
                    b.delete(_ref);
                    fire(b.commit());
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
            ],
          ),
          body: Column(
            children: [
              Card(
                margin: const EdgeInsets.all(12),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('In stock'),
                      Text('${fmtNum(numv(p['qty']))} ${p['unit'] ?? ''}',
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    ]),
                    const SizedBox(height: 4),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text('Buy ${money(numv(p['buyPrice']))}'),
                      Text('Sell ${money(numv(p['sellPrice']))}'),
                      Text('Value ${money(numv(p['qty']) * numv(p['buyPrice']))}'),
                    ]),
                    const SizedBox(height: 4),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text('Entered: ${fmtDate(dt(p['addedAt']))}',
                          style: const TextStyle(fontSize: 12)),
                      Text(
                          'Last sold: ${p['lastSoldAt'] == null ? '-' : fmtDate(dt(p['lastSoldAt']))}',
                          style: const TextStyle(fontSize: 12)),
                    ]),
                  ]),
                ),
              ),
              Expanded(
                child: Q(
                  query: biz.col('moves').where('productId', isEqualTo: productId),
                  builder: (c, docs) {
                    final list = List<Doc>.of(docs)
                      ..sort((a, b) => dt(b.data()['date']).compareTo(dt(a.data()['date'])));
                    return ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final d = list[i].data();
                        final out = d['type'] == 'out';
                        return ListTile(
                          leading: Icon(out ? Icons.north_east : Icons.south_west,
                              color: out ? Colors.red : Colors.green),
                          title: Text(out
                              ? 'Sold ${fmtNum(numv(d['qty']))} to ${d['buyerName']}'
                              : 'Stock in ${fmtNum(numv(d['qty']))}'),
                          subtitle: Text(
                              '${fmtDate(dt(d['date']))}${'${d['buyerPhone'] ?? ''}'.isEmpty ? '' : '  •  ${d['buyerPhone']}'}'),
                          trailing: Text('@ ${money(numv(d['unitPrice']))}'),
                          onTap: out && '${d['buyerPhone'] ?? ''}'.isNotEmpty
                              ? () => openUrl('tel:${d['buyerPhone']}')
                              : null,
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
          bottomNavigationBar: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(
                    child: FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: Colors.green),
                        onPressed: () => _in(context, p),
                        icon: const Icon(Icons.add),
                        label: const Text('Stock in'))),
                const SizedBox(width: 12),
                Expanded(
                    child: FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: Colors.red),
                        onPressed: () => _out(context, p),
                        icon: const Icon(Icons.sell_outlined),
                        label: const Text('Stock out (sell)'))),
              ]),
            ),
          ),
        );
      },
    );
  }
}

// ====================================================================== NOTES
class NotesTab extends StatelessWidget {
  const NotesTab({super.key, required this.biz});
  final Biz biz;

  Future<void> _edit(BuildContext context, {Doc? doc}) async {
    final d = doc?.data();
    final r = await formDialog(context, doc == null ? 'New note' : 'Edit note', [
      FieldSpec('title', 'Title', required: true, initial: d?['title']?.toString()),
      FieldSpec('body', 'Note', kind: FK.multiline, initial: d?['body']?.toString()),
    ]);
    if (r == null) return;
    final data = {'title': r['title'], 'body': r['body'], 'updatedAt': Timestamp.now()};
    if (doc == null) {
      fire(biz.col('notes').add(data));
    } else {
      fire(doc.reference.update(data));
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context),
        icon: const Icon(Icons.note_add_outlined),
        label: Text(app.tr('Add note')),
      ),
      body: Q(
        query: biz.col('notes'),
        builder: (c, docs) {
          final list = List<Doc>.of(docs)
            ..sort((a, b) => dt(b.data()['updatedAt']).compareTo(dt(a.data()['updatedAt'])));
          if (list.isEmpty) {
            return const EmptyState('No notes yet. Use notes instead of a paper notebook.',
                icon: Icons.sticky_note_2_outlined);
          }
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            itemBuilder: (c, i) {
              final d = list[i].data();
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                child: ListTile(
                  title: Text('${d['title']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${d['body'] ?? ''}', maxLines: 3, overflow: TextOverflow.ellipsis),
                  onTap: () => _edit(context, doc: list[i]),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      if (await confirm(context, 'Delete this note?')) {
                        fire(list[i].reference.delete());
                      }
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
