import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/services/db.dart';

/// Wraps a form in a page (used for editing existing records).
class EditPage extends StatelessWidget {
  const EditPage({super.key, required this.title, required this.builder});
  final String title;
  final Widget Function(VoidCallback done) builder;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: builder(() => Navigator.pop(context)),
    );
  }
}

/// The "Add" tab: Company | Medicine | Disease | Problems & Solutions
class AddScreen extends StatefulWidget {
  const AddScreen({super.key});
  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  int _gen = 0; // changing it resets the forms after saving

  void _done() {
    setState(() => _gen++);
    snack(context, 'Saved ✓');
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return DefaultTabController(
      length: 4,
      child: Column(
        children: [
          TabBar(
            tabs: [
              Tab(icon: const Icon(Icons.business, size: 20), text: app.tr('Company')),
              Tab(icon: const Icon(Icons.medication, size: 20), text: app.tr('Medicine')),
              Tab(icon: const Icon(Icons.healing, size: 20), text: app.tr('Disease')),
              Tab(icon: const Icon(Icons.lightbulb_outline, size: 20), text: app.tr('P&S')),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                CompanyForm(key: ValueKey('c$_gen'), onDone: _done),
                MedicineForm(key: ValueKey('m$_gen'), onDone: _done),
                DiseaseForm(key: ValueKey('d$_gen'), onDone: _done),
                ProblemForm(key: ValueKey('p$_gen'), onDone: _done),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ======================================================================= COMPANY
class CompanyForm extends StatefulWidget {
  const CompanyForm({super.key, this.existing, required this.onDone});
  final Rec? existing;
  final VoidCallback onDone;
  @override
  State<CompanyForm> createState() => _CompanyFormState();
}

class _CompanyFormState extends State<CompanyForm> with AutomaticKeepAliveClientMixin {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name, _phone, _web, _addr, _notes;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.s('name') ?? '');
    _phone = TextEditingController(text: e?.s('phone') ?? '');
    _web = TextEditingController(text: e?.s('website') ?? '');
    _addr = TextEditingController(text: e?.s('address') ?? '');
    _notes = TextEditingController(text: e?.s('notes') ?? '');
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _web, _addr, _notes]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    final data = {
      'name': _name.text.trim(),
      'nameLower': _name.text.trim().toLowerCase(),
      'phone': _phone.text.trim(),
      'website': _web.text.trim(),
      'address': _addr.text.trim(),
      'notes': _notes.text.trim(),
    };
    if (widget.existing == null) {
      fire(Db.companies.add({...data, ...stamp(app)}));
    } else {
      fire(Db.companies.doc(widget.existing!.id).update(data));
    }
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          tf(_name, 'Company name', required: true),
          tf(_phone, 'Phone / Representative number', type: TextInputType.phone),
          tf(_web, 'Website', type: TextInputType.url),
          tf(_addr, 'Address'),
          tf(_notes, 'Notes', lines: 3),
          FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(widget.existing == null ? 'Add company' : 'Save changes')),
        ],
      ),
    );
  }
}

// ======================================================================= MEDICINE
class MedicineForm extends StatefulWidget {
  const MedicineForm({super.key, this.existing, required this.onDone});
  final Rec? existing;
  final VoidCallback onDone;
  @override
  State<MedicineForm> createState() => _MedicineFormState();
}

class _MedicineFormState extends State<MedicineForm> with AutomaticKeepAliveClientMixin {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name, _comp, _when, _dose, _details;
  String? _companyId;
  Map<String, String> _companies = {};
  String _preg = 'unsafe';
  String _pet = 'unsafe';

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.s('name') ?? '');
    _comp = TextEditingController(text: e?.s('components') ?? '');
    _when = TextEditingController(text: e?.s('whenToUse') ?? '');
    _dose = TextEditingController(text: e?.s('dose') ?? '');
    _details = TextEditingController(text: e?.s('details') ?? '');
    if (e != null) {
      _companyId = e.s('companyId');
      _preg = e.b('pregnancySafe') ? 'safe' : 'unsafe';
      _pet = e.b('petSafe') ? 'safe' : 'unsafe';
    }
  }

  @override
  void dispose() {
    for (final c in [_name, _comp, _when, _dose, _details]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    final data = {
      'name': _name.text.trim(),
      'nameLower': _name.text.trim().toLowerCase(),
      'companyId': _companyId,
      'companyName': _companies[_companyId] ?? '',
      'components': _comp.text.trim(),
      'whenToUse': _when.text.trim(),
      'dose': _dose.text.trim(),
      'pregnancySafe': _preg == 'safe',
      'petSafe': _pet == 'safe',
      'details': _details.text.trim(),
    };
    if (widget.existing == null) {
      fire(Db.medicines.add({...data, ...stamp(app)}));
    } else {
      fire(Db.medicines.doc(widget.existing!.id).update(data));
    }
    widget.onDone();
  }

  Widget _seg(String label, String value, ValueChanged<String> on) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'safe', label: Text('Safe'), icon: Icon(Icons.check_circle_outline)),
              ButtonSegment(value: 'unsafe', label: Text('Unsafe'), icon: Icon(Icons.cancel_outlined)),
            ],
            selected: {value},
            onSelectionChanged: (s) => on(s.first),
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          tf(_name, 'Medicine name', required: true),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: Db.companies.snapshots(),
            builder: (c, s) {
              final docs = List<Doc>.of(s.data?.docs ?? [])
                ..sort((a, b) => '${a.data()['name']}'
                    .toLowerCase()
                    .compareTo('${b.data()['name']}'.toLowerCase()));
              _companies = {for (final d in docs) d.id: '${d.data()['name']}'};
              if (docs.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: Text('⚠ Add a company first (Company tab), then choose it here.'),
                );
              }
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: DropdownButtonFormField<String>(
                  value: _companies.containsKey(_companyId) ? _companyId : null,
                  isExpanded: true,
                  decoration: const InputDecoration(
                      labelText: 'Company', border: OutlineInputBorder()),
                  items: [
                    for (final d in docs)
                      DropdownMenuItem(value: d.id, child: Text('${d.data()['name']}'))
                  ],
                  onChanged: (v) => setState(() => _companyId = v),
                  validator: (v) => v == null ? 'Select a company' : null,
                ),
              );
            },
          ),
          tf(_comp, 'Components (generic / composition)', lines: 2),
          tf(_when, 'When to use', lines: 3),
          tf(_dose, 'Dose', lines: 3),
          _seg('Pregnancy indication', _preg, (v) => setState(() => _preg = v)),
          _seg('Pet safety', _pet, (v) => setState(() => _pet = v)),
          tf(_details, 'Any other details', lines: 4),
          FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(widget.existing == null ? 'Add medicine' : 'Save changes')),
        ],
      ),
    );
  }
}

// ======================================================================= DISEASE
class DiseaseForm extends StatefulWidget {
  const DiseaseForm({super.key, this.existing, required this.onDone});
  final Rec? existing;
  final VoidCallback onDone;
  @override
  State<DiseaseForm> createState() => _DiseaseFormState();
}

class _DiseaseFormState extends State<DiseaseForm> with AutomaticKeepAliveClientMixin {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _owner, _phone, _loc, _fee, _title, _temp, _sym, _clin, _treat;
  String _visit = 'hospital';
  String _skin = 'absent';
  String _prog = 'good';
  String? _feeBizId; // business where the fee income was recorded

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _owner = TextEditingController(text: e?.s('ownerName') ?? '');
    _phone = TextEditingController(text: e?.s('phone') ?? '');
    _loc = TextEditingController(text: e?.s('location') ?? '');
    _fee = TextEditingController();
    _title = TextEditingController(text: e?.s('title') ?? '');
    _temp = TextEditingController(text: e?.s('temperature') ?? '');
    _sym = TextEditingController(text: e?.s('symptoms') ?? '');
    _clin = TextEditingController(text: e?.s('clinicalFindings') ?? '');
    _treat = TextEditingController(text: e?.s('treatment') ?? '');
    if (e != null) {
      _visit = e.s('visitType') == 'private' ? 'private' : 'hospital';
      _skin = e.s('skinParasite') == 'present' ? 'present' : 'absent';
      _prog = e.s('prognosis') == 'poor' ? 'poor' : 'good';
      if (_visit == 'private') _loadFee(e);
    }
  }

  Future<void> _loadFee(Rec e) async {
    try {
      final s = await Db.users
          .doc(e.s('createdBy'))
          .collection('diseaseFees')
          .doc(e.id)
          .get();
      final d = s.data();
      if (d != null && mounted) {
        _fee.text = fmtNum(numv(d['amount'])).replaceAll(',', '');
        _feeBizId = d['bizId']?.toString();
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    for (final c in [_owner, _phone, _loc, _fee, _title, _temp, _sym, _clin, _treat]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    final e = widget.existing;
    final ref = e == null ? Db.diseases.doc() : Db.diseases.doc(e.id);
    final ownerUid = e?.s('createdBy').isNotEmpty == true ? e!.s('createdBy') : app.uid;
    final isPrivate = _visit == 'private';

    final data = <String, dynamic>{
      'ownerName': _owner.text.trim(),
      'phone': _phone.text.trim(),
      'location': _loc.text.trim(),
      'visitType': _visit, // NOTE: the fee amount is NOT stored here (this doc is public)
      'title': _title.text.trim(),
      'temperature': _temp.text.trim(),
      'symptoms': _sym.text.trim(),
      'clinicalFindings': _clin.text.trim(),
      'skinParasite': _skin,
      'treatment': _treat.text.trim(),
      'prognosis': _prog,
    };

    final batch = Db.f.batch();
    if (e == null) {
      batch.set(ref, {...data, ...stamp(app)});
    } else {
      batch.update(ref, data);
    }

    final feeRef = Db.users.doc(ownerUid).collection('diseaseFees').doc(ref.id);
    final amount = double.tryParse(_fee.text.trim()) ?? 0;
    final bizId = _feeBizId ?? ((app.viewUid == null ? app.bizId : null) ?? 'main');
    final cashRef = Db.sub(ownerUid, bizId, 'cash').doc('fee_${ref.id}');
    if (isPrivate && amount > 0) {
      // private fee -> stored in the creator's private area and added to the cashbook income
      batch.set(feeRef, {'amount': amount, 'bizId': bizId, 'date': Timestamp.now()});
      batch.set(
        cashRef,
        {
          'type': 'income',
          'amount': amount,
          'category': 'Private visit fee',
          'note': '${_title.text.trim()} - ${_owner.text.trim()}',
          'date': Timestamp.fromDate(e == null ? DateTime.now() : dt(e.data['createdAt'])),
          'auto': true,
        },
        SetOptions(merge: true),
      );
    } else if (e != null) {
      batch.delete(feeRef);
      batch.delete(cashRef);
    }
    fire(batch.commit());
    widget.onDone();
  }

  Widget _seg(String label, String value, List<ButtonSegment<String>> segs,
      ValueChanged<String> on) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<String>(
            segments: segs,
            selected: {value},
            onSelectionChanged: (s) => on(s.first),
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          tf(_owner, 'Name of the owner', required: true),
          tf(_phone, 'Phone number', type: TextInputType.phone),
          _seg(
            'Location',
            _visit,
            const [
              ButtonSegment(value: 'hospital', label: Text('Hospital'), icon: Icon(Icons.local_hospital_outlined)),
              ButtonSegment(value: 'private', label: Text('Private'), icon: Icon(Icons.home_work_outlined)),
            ],
            (v) => setState(() => _visit = v),
          ),
          if (_visit == 'private') ...[
            tf(_fee, 'Fee taken (৳)', type: const TextInputType.numberWithOptions(decimal: true)),
            const Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Text(
                '🔒 Only you and the administrator can see this amount. It is added to your Cashbook income automatically.',
                style: TextStyle(fontSize: 12),
              ),
            ),
          ],
          tf(_loc, 'Address / place of the animal'),
          tf(_title, 'Title of the disease', required: true),
          tf(_temp, 'Temperature (e.g. 103.5 °F)'),
          tf(_sym, 'Sign & symptoms told by the owner', lines: 4),
          tf(_clin, 'Clinical findings', lines: 4),
          _seg(
            'Skin parasite',
            _skin,
            const [
              ButtonSegment(value: 'present', label: Text('Present')),
              ButtonSegment(value: 'absent', label: Text('Absent')),
            ],
            (v) => setState(() => _skin = v),
          ),
          WordField(controller: _treat, label: 'Treatment', maxWords: 1000, minLines: 6, required: true),
          _seg(
            'Prognosis after 10 days of treatment',
            _prog,
            const [
              ButtonSegment(value: 'good', label: Text('Good'), icon: Icon(Icons.thumb_up_alt_outlined)),
              ButtonSegment(value: 'poor', label: Text('Poor'), icon: Icon(Icons.thumb_down_alt_outlined)),
            ],
            (v) => setState(() => _prog = v),
          ),
          FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(widget.existing == null ? 'Add disease' : 'Save changes')),
        ],
      ),
    );
  }
}

// ======================================================================= PROBLEM & SOLUTION
class ProblemForm extends StatefulWidget {
  const ProblemForm({super.key, this.existing, required this.onDone});
  final Rec? existing;
  final VoidCallback onDone;
  @override
  State<ProblemForm> createState() => _ProblemFormState();
}

class _ProblemFormState extends State<ProblemForm> with AutomaticKeepAliveClientMixin {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _title, _problem, _solution, _prog;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _title = TextEditingController(text: e?.s('title') ?? '');
    _problem = TextEditingController(text: e?.s('problem') ?? '');
    _solution = TextEditingController(text: e?.s('solution') ?? '');
    _prog = TextEditingController(text: e?.s('prognosis') ?? '');
  }

  @override
  void dispose() {
    for (final c in [_title, _problem, _solution, _prog]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    final data = {
      'title': _title.text.trim(),
      'problem': _problem.text.trim(),
      'solution': _solution.text.trim(),
      'prognosis': _prog.text.trim(),
    };
    if (widget.existing == null) {
      fire(Db.problems.add({...data, ...stamp(app)}));
    } else {
      fire(Db.problems.doc(widget.existing!.id).update(data));
    }
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          tf(_title, 'Title', required: true),
          WordField(controller: _problem, label: 'Problems', maxWords: 1000, minLines: 5, required: true),
          WordField(controller: _solution, label: 'Solutions', maxWords: 2000, minLines: 6, required: true),
          WordField(controller: _prog, label: 'Prognosis', maxWords: 300, minLines: 3),
          FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(widget.existing == null ? 'Add' : 'Save changes')),
        ],
      ),
    );
  }
}
