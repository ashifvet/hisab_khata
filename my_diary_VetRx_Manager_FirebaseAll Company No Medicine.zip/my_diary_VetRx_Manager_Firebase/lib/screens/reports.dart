import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import 'package:my_diary/core/utils.dart';
import 'package:my_diary/services/db.dart';

class ReportSection {
  const ReportSection(this.title, this.headers, this.rows);
  final String title;
  final List<String> headers;
  final List<List<String>> rows;
}

class ReportData {
  const ReportData({
    required this.title,
    required this.subtitle,
    this.summary = const [],
    this.sections = const [],
  });
  final String title;
  final String subtitle;
  final List<MapEntry<String, String>> summary;
  final List<ReportSection> sections;
}

/// Builds all the reports from the Firestore data (works offline from the local cache).
class Reports {
  static Future<List<Doc>> _all(MQuery q) async => List<Doc>.of((await q.get()).docs);

  static int _byDate(Doc a, Doc b) =>
      dt(a.data()['date']).compareTo(dt(b.data()['date']));

  // ---------- one customer / supplier ----------
  static Future<ReportData> party(Biz b, String partyId) async {
    final pd = await b.col('parties').doc(partyId).get();
    final p = pd.data() ?? {};
    final es = await _all(b.col('entries').where('partyId', isEqualTo: partyId));
    es.sort(_byDate);
    double run = 0, gave = 0, got = 0;
    final rows = <List<String>>[];
    for (final e in es) {
      final d = e.data();
      final a = numv(d['amount']);
      final isGave = d['kind'] == 'gave';
      if (isGave) {
        gave += a;
        run += a;
      } else {
        got += a;
        run -= a;
      }
      rows.add([
        fmtDate(dt(d['date'])),
        '${d['note'] ?? ''}',
        isGave ? fmtNum(a) : '',
        isGave ? '' : fmtNum(a),
        '${fmtNum(run.abs())} ${run >= 0 ? '(get)' : '(give)'}',
      ]);
    }
    return ReportData(
      title: '${p['type'] == 'supplier' ? 'Supplier' : 'Customer'} statement: ${p['name']}',
      subtitle: 'Phone: ${p['phone'] ?? ''}   |   Generated: ${fmtDate(DateTime.now())}',
      summary: [
        MapEntry('You gave', moneyPlain(gave)),
        MapEntry('You got', moneyPlain(got)),
        MapEntry(run >= 0 ? 'You will get' : 'You will give', moneyPlain(run.abs())),
      ],
      sections: [
        ReportSection('Transactions', ['Date', 'Note', 'You gave', 'You got', 'Balance'], rows),
      ],
    );
  }

  // ---------- all customers + suppliers ----------
  static Future<ReportData> partiesSummary(Biz b) async {
    final ps = await _all(b.col('parties'));
    final es = await _all(b.col('entries'));
    final bal = <String, double>{};
    for (final e in es) {
      final d = e.data();
      final a = numv(d['amount']);
      final id = '${d['partyId']}';
      bal[id] = (bal[id] ?? 0) + (d['kind'] == 'gave' ? a : -a);
    }
    ps.sort((a, c) => '${a.data()['name']}'.toLowerCase().compareTo('${c.data()['name']}'.toLowerCase()));
    double toGet = 0, toGive = 0;
    final rows = <List<String>>[];
    for (final p in ps) {
      final v = bal[p.id] ?? 0;
      if (v > 0) {
        toGet += v;
      } else {
        toGive += -v;
      }
      rows.add([
        '${p.data()['name']}',
        p.data()['type'] == 'supplier' ? 'Supplier' : 'Customer',
        '${p.data()['phone'] ?? ''}',
        fmtNum(v.abs()),
        v == 0 ? 'Settled' : v > 0 ? 'You will get' : 'You will give',
      ]);
    }
    return ReportData(
      title: 'Customers & Suppliers balance',
      subtitle: 'Generated: ${fmtDate(DateTime.now())}',
      summary: [
        MapEntry('You will get', moneyPlain(toGet)),
        MapEntry('You will give', moneyPlain(toGive)),
      ],
      sections: [
        ReportSection('Balances', ['Name', 'Type', 'Phone', 'Amount', 'Status'], rows),
      ],
    );
  }

  // ---------- stock & inventory ----------
  static Future<ReportData> stock(Biz b) async {
    final ps = await _all(b.col('products'));
    final ms = await _all(b.col('moves'));
    ps.sort((a, c) => '${a.data()['name']}'.toLowerCase().compareTo('${c.data()['name']}'.toLowerCase()));
    ms.sort(_byDate);
    double value = 0, soldQty = 0, soldValue = 0;
    final prodRows = <List<String>>[];
    for (final p in ps) {
      final d = p.data();
      final qty = numv(d['qty']);
      final v = qty * numv(d['buyPrice']);
      value += v;
      prodRows.add([
        '${d['name']}',
        '${d['unit'] ?? ''}',
        fmtDate(dt(d['addedAt'])),
        fmtNum(qty),
        fmtNum(numv(d['buyPrice'])),
        fmtNum(numv(d['sellPrice'])),
        fmtNum(v),
        d['lastSoldAt'] == null ? '-' : fmtDate(dt(d['lastSoldAt'])),
      ]);
    }
    final moveRows = <List<String>>[];
    for (final m in ms) {
      final d = m.data();
      final out = d['type'] == 'out';
      if (out) {
        soldQty += numv(d['qty']);
        soldValue += numv(d['qty']) * numv(d['unitPrice']);
      }
      moveRows.add([
        fmtDate(dt(d['date'])),
        '${d['productName']}',
        out ? 'SOLD' : 'IN',
        fmtNum(numv(d['qty'])),
        fmtNum(numv(d['unitPrice'])),
        '${d['buyerName'] ?? ''}',
        '${d['buyerPhone'] ?? ''}',
      ]);
    }
    return ReportData(
      title: 'Stock & Inventory report',
      subtitle: 'Generated: ${fmtDate(DateTime.now())}',
      summary: [
        MapEntry('Products', '${ps.length}'),
        MapEntry('Stock value', moneyPlain(value)),
        MapEntry('Total sold qty', fmtNum(soldQty)),
        MapEntry('Total sales', moneyPlain(soldValue)),
      ],
      sections: [
        ReportSection('Current stock',
            ['Product', 'Unit', 'Date entered', 'Qty', 'Buy price', 'Sell price', 'Value', 'Last sold'], prodRows),
        ReportSection('Stock movements (entered / sold)',
            ['Date', 'Product', 'Type', 'Qty', 'Price', 'Buyer', 'Phone'], moveRows),
      ],
    );
  }

  // ---------- cost & savings ----------
  static Future<ReportData> costSavings(Biz b, String month) async {
    final cs = await _all(b.col('cash'));
    cs.sort(_byDate);
    bool inRange(Doc d) => month == 'all' || ym(dt(d.data()['date'])) == month;
    final list = cs.where(inRange).toList();
    double inc = 0, exp = 0, sav = 0;
    final byCat = <String, double>{};
    final expRows = <List<String>>[];
    final savRows = <List<String>>[];
    for (final d in list) {
      final m = d.data();
      final a = numv(m['amount']);
      final row = [fmtDate(dt(m['date'])), '${m['category'] ?? ''}', '${m['note'] ?? ''}', fmtNum(a)];
      if (m['type'] == 'income') {
        inc += a;
      } else if (m['type'] == 'expense') {
        exp += a;
        byCat['${m['category']}'] = (byCat['${m['category']}'] ?? 0) + a;
        expRows.add(row);
      } else {
        sav += a;
        savRows.add(row);
      }
    }
    final catRows = byCat.entries.toList()..sort((a, c) => c.value.compareTo(a.value));
    return ReportData(
      title: 'Cost & Savings report',
      subtitle: 'Period: ${month == 'all' ? 'All time' : month}   |   Generated: ${fmtDate(DateTime.now())}',
      summary: [
        MapEntry('Income', moneyPlain(inc)),
        MapEntry('Total cost', moneyPlain(exp)),
        MapEntry('Total savings', moneyPlain(sav)),
        MapEntry('Net (income - cost - savings)', moneyPlain(inc - exp - sav)),
      ],
      sections: [
        ReportSection('Cost by category', ['Category', 'Amount'],
            [for (final e in catRows) [e.key, fmtNum(e.value)]]),
        ReportSection('Cost details', ['Date', 'Category', 'Note', 'Amount'], expRows),
        ReportSection('Savings', ['Date', 'Category', 'Note', 'Amount'], savRows),
      ],
    );
  }

  // ---------- monthly ----------
  static Future<ReportData> monthly(Biz b, String month) async {
    final cs = (await _all(b.col('cash'))).where((d) => ym(dt(d.data()['date'])) == month).toList()
      ..sort(_byDate);
    final es = (await _all(b.col('entries'))).where((d) => ym(dt(d.data()['date'])) == month).toList()
      ..sort(_byDate);
    final ms = (await _all(b.col('moves')))
        .where((d) => ym(dt(d.data()['date'])) == month && d.data()['type'] == 'out')
        .toList()
      ..sort(_byDate);
    final parties = <String, String>{};
    for (final p in await _all(b.col('parties'))) {
      parties[p.id] = '${p.data()['name']}';
    }

    double inc = 0, exp = 0, sav = 0, gave = 0, got = 0, sales = 0;
    final cashRows = <List<String>>[];
    for (final d in cs) {
      final m = d.data();
      final a = numv(m['amount']);
      final t = '${m['type']}';
      if (t == 'income') {
        inc += a;
      } else if (t == 'expense') {
        exp += a;
      } else {
        sav += a;
      }
      cashRows.add([
        fmtDate(dt(m['date'])),
        t[0].toUpperCase() + t.substring(1),
        '${m['category'] ?? ''}',
        '${m['note'] ?? ''}',
        fmtNum(a),
      ]);
    }
    final partyRows = <List<String>>[];
    for (final d in es) {
      final m = d.data();
      final a = numv(m['amount']);
      final isGave = m['kind'] == 'gave';
      if (isGave) {
        gave += a;
      } else {
        got += a;
      }
      partyRows.add([
        fmtDate(dt(m['date'])),
        parties['${m['partyId']}'] ?? '-',
        isGave ? fmtNum(a) : '',
        isGave ? '' : fmtNum(a),
        '${m['note'] ?? ''}',
      ]);
    }
    final saleRows = <List<String>>[];
    for (final d in ms) {
      final m = d.data();
      final v = numv(m['qty']) * numv(m['unitPrice']);
      sales += v;
      saleRows.add([
        fmtDate(dt(m['date'])),
        '${m['productName']}',
        fmtNum(numv(m['qty'])),
        fmtNum(v),
        '${m['buyerName'] ?? ''} ${m['buyerPhone'] ?? ''}'.trim(),
      ]);
    }
    return ReportData(
      title: 'Monthly report - $month',
      subtitle: 'Generated: ${fmtDate(DateTime.now())}',
      summary: [
        MapEntry('Income', moneyPlain(inc)),
        MapEntry('Expense', moneyPlain(exp)),
        MapEntry('Savings', moneyPlain(sav)),
        MapEntry('Net', moneyPlain(inc - exp - sav)),
        MapEntry('Credit given', moneyPlain(gave)),
        MapEntry('Payments received', moneyPlain(got)),
        MapEntry('Stock sales', moneyPlain(sales)),
      ],
      sections: [
        ReportSection('Cashbook', ['Date', 'Type', 'Category', 'Note', 'Amount'], cashRows),
        ReportSection('Customer / Supplier entries',
            ['Date', 'Party', 'You gave', 'You got', 'Note'], partyRows),
        ReportSection('Stock sold', ['Date', 'Product', 'Qty', 'Amount', 'Buyer'], saleRows),
      ],
    );
  }
}

// ====================================================================== REPORTS TAB
class ReportsTab extends StatelessWidget {
  const ReportsTab({super.key, required this.biz});
  final Biz biz;

  void _open(BuildContext context, ReportData d) {
    Navigator.push(context,
        MaterialPageRoute(builder: (_) => ReportScreen(data: d, bizName: biz.name)));
  }

  Future<String?> _pickParty(BuildContext context, String type) async {
    final ps = (await _all(type)).toList();
    if (!context.mounted) return null;
    if (ps.isEmpty) {
      snack(context, 'No ${type}s added yet');
      return null;
    }
    return showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Text('Select $type', style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
            for (final p in ps)
              ListTile(
                title: Text('${p.data()['name']}'),
                subtitle: Text('${p.data()['phone'] ?? ''}'),
                onTap: () => Navigator.pop(c, p.id),
              ),
          ],
        ),
      ),
    );
  }

  Future<List<Doc>> _all(String type) async {
    final s = await biz.col('parties').where('type', isEqualTo: type).get();
    final l = List<Doc>.of(s.docs)
      ..sort((a, b) => '${a.data()['name']}'.toLowerCase().compareTo('${b.data()['name']}'.toLowerCase()));
    return l;
  }

  Future<String?> _pickMonth(BuildContext context, String title, {bool withAll = false}) async {
    final now = DateTime.now();
    final months = [for (var i = 0; i < 24; i++) ym(DateTime(now.year, now.month - i))];
    final r = await formDialog(context, title, [
      FieldSpec('m', 'Month', kind: FK.choice, options: [if (withAll) 'all', ...months]),
    ]);
    return r?['m'];
  }

  Widget _tile(BuildContext context, IconData icon, String title, String sub, VoidCallback on) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right),
        onTap: on,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(top: 8, bottom: 24),
      children: [
        _tile(context, Icons.person_outline, 'Customer report', 'Statement of one customer', () async {
          final id = await _pickParty(context, 'customer');
          if (id != null && context.mounted) _open(context, await Reports.party(biz, id));
        }),
        _tile(context, Icons.local_shipping_outlined, 'Supplier report', 'Statement of one supplier', () async {
          final id = await _pickParty(context, 'supplier');
          if (id != null && context.mounted) _open(context, await Reports.party(biz, id));
        }),
        _tile(context, Icons.people_alt_outlined, 'All balances', 'Everyone you will get from / give to', () async {
          _open(context, await Reports.partiesSummary(biz));
        }),
        _tile(context, Icons.inventory_2_outlined, 'Stock & Inventory report',
            'Every product: date entered, date sold, buyers', () async {
          _open(context, await Reports.stock(biz));
        }),
        _tile(context, Icons.savings_outlined, 'My cost & savings', 'Where the money went, what you saved', () async {
          final m = await _pickMonth(context, 'Cost & savings period', withAll: true);
          if (m != null && context.mounted) _open(context, await Reports.costSavings(biz, m));
        }),
        _tile(context, Icons.calendar_month_outlined, 'Monthly report', 'Income, expense, credit, stock sales', () async {
          final m = await _pickMonth(context, 'Select month');
          if (m != null && context.mounted) _open(context, await Reports.monthly(biz, m));
        }),
      ],
    );
  }
}

// ====================================================================== REPORT VIEWER
class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key, required this.data, required this.bizName});
  final ReportData data;
  final String bizName;
  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  bool _busy = false;

  String get _fileName =>
      '${widget.data.title.replaceAll(RegExp(r'[^A-Za-z0-9]+'), '_')}.pdf';

  Future<void> _run(Future<void> Function(Uint8List bytes) action) async {
    setState(() => _busy = true);
    try {
      final bytes = await buildPdf(widget.data, widget.bizName);
      await action(bytes);
    } catch (e) {
      if (mounted) snack(context, 'PDF error: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.data;
    return Scaffold(
      appBar: AppBar(title: Text(d.title, style: const TextStyle(fontSize: 16))),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Text(d.subtitle, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 8),
          if (d.summary.isNotEmpty)
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final s in d.summary)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(s.key, style: const TextStyle(fontSize: 11)),
                      Text(s.value,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ]),
                  ),
                ),
            ]),
          for (final sec in d.sections) ...[
            Padding(
              padding: const EdgeInsets.only(top: 14, bottom: 6),
              child: Text(sec.title,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            ),
            if (sec.rows.isEmpty)
              const Text('No data')
            else
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columnSpacing: 18,
                  headingRowHeight: 36,
                  dataRowMinHeight: 32,
                  dataRowMaxHeight: 60,
                  columns: [for (final h in sec.headers) DataColumn(label: Text(h))],
                  rows: [
                    for (final r in sec.rows)
                      DataRow(cells: [for (final c in r) DataCell(Text(c))]),
                  ],
                ),
              ),
          ],
          const SizedBox(height: 90),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: _busy
              ? const LinearProgressIndicator()
              : Row(children: [
                  Expanded(
                    child: FilledButton.icon(
                      icon: const Icon(Icons.print_outlined),
                      label: const Text('Print / Save PDF'),
                      onPressed: () => _run((bytes) async {
                        await Printing.layoutPdf(
                            onLayout: (format) async => bytes, name: _fileName);
                      }),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.tonalIcon(
                      icon: const Icon(Icons.share),
                      label: const Text('Share (WhatsApp / imo)'),
                      onPressed: () => _run((bytes) async {
                        await Printing.sharePdf(bytes: bytes, filename: _fileName);
                      }),
                    ),
                  ),
                ]),
        ),
      ),
    );
  }
}

/// Creates the PDF. The Bangla font is downloaded once (needs internet);
/// offline it falls back to the default font (English text only).
Future<Uint8List> buildPdf(ReportData r, String bizName) async {
  pw.ThemeData theme;
  try {
    final base = await PdfGoogleFonts.notoSansBengaliRegular();
    final bold = await PdfGoogleFonts.notoSansBengaliBold();
    theme = pw.ThemeData.withFont(base: base, bold: bold);
  } catch (_) {
    theme = pw.ThemeData.base();
  }
  final doc = pw.Document(theme: theme);
  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      footer: (ctx) => pw.Align(
        alignment: pw.Alignment.centerRight,
        child: pw.Text('Page ${ctx.pageNumber}/${ctx.pagesCount}',
            style: const pw.TextStyle(fontSize: 8)),
      ),
      build: (ctx) => [
        pw.Text('My Diary  |  $bizName',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
        pw.SizedBox(height: 4),
        pw.Text(r.title, style: pw.TextStyle(fontSize: 19, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 2),
        pw.Text(r.subtitle, style: const pw.TextStyle(fontSize: 9)),
        pw.SizedBox(height: 10),
        if (r.summary.isNotEmpty)
          pw.Wrap(spacing: 8, runSpacing: 8, children: [
            for (final s in r.summary)
              pw.Container(
                padding: const pw.EdgeInsets.all(7),
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.grey500, width: 0.6),
                  borderRadius: pw.BorderRadius.circular(4),
                ),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                  pw.Text(s.key, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                  pw.Text(s.value,
                      style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
                ]),
              ),
          ]),
        for (final sec in r.sections) ...[
          pw.SizedBox(height: 14),
          pw.Text(sec.title, style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          if (sec.rows.isEmpty)
            pw.Text('No data', style: const pw.TextStyle(fontSize: 9))
          else
            pw.TableHelper.fromTextArray(
              headers: sec.headers,
              data: sec.rows,
              headerStyle: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold),
              headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
              cellStyle: const pw.TextStyle(fontSize: 8.5),
              cellAlignment: pw.Alignment.centerLeft,
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
            ),
        ],
      ],
    ),
  );
  return doc.save();
}
