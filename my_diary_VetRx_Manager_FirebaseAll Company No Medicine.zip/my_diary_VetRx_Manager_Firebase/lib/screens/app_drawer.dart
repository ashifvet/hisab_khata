import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/screens/drawer_screens.dart';
import 'package:my_diary/services/auth_service.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  void _go(BuildContext context, Widget page) {
    Navigator.pop(context); // close drawer
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    return Drawer(
      child: Column(
        children: [
          // ---- greeting header ----
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(
                16, MediaQuery.of(context).padding.top + 20, 16, 18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [cs.primary, cs.tertiary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: cs.onPrimary,
                  child: Text(
                    app.fullName.isEmpty ? '?' : app.fullName[0].toUpperCase(),
                    style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: cs.primary),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  greetingFor(app),
                  style: TextStyle(
                      color: cs.onPrimary,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 2),
                Text(app.user?.email ?? '',
                    style: TextStyle(color: cs.onPrimary.withAlpha(220), fontSize: 12)),
                if (app.isAdmin)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Pill('ADMINISTRATOR', cs.onPrimary.withAlpha(60)),
                  ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                  leading: const Icon(Icons.person_outline),
                  title: Text(app.tr('Edit Profile')),
                  onTap: () => _go(context, const ProfileScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.settings_outlined),
                  title: Text(app.tr('Settings')),
                  onTap: () => _go(context, const SettingsScreen()),
                ),
                if (app.isAdmin) ...[
                  const Divider(),
                  Padding(
                    padding: const EdgeInsets.only(left: 16, top: 4),
                    child: Text('ADMIN',
                        style: TextStyle(
                            fontSize: 11,
                            color: cs.primary,
                            fontWeight: FontWeight.bold)),
                  ),
                  ListTile(
                    leading: const Icon(Icons.campaign_outlined),
                    title: Text(app.tr('Announcements')),
                    onTap: () => _go(context, const AnnouncementsAdminScreen()),
                  ),
                  ListTile(
                    leading: const Icon(Icons.admin_panel_settings_outlined),
                    title: Text(app.tr('Manage Users & Admins')),
                    onTap: () => _go(context, const UsersAdminScreen()),
                  ),
                  ListTile(
                    leading: const Icon(Icons.system_update_outlined),
                    title: Text(app.tr('App Version Control')),
                    onTap: () => _go(context, const VersionAdminScreen()),
                  ),
                  const Divider(),
                ],
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(app.tr('About Developer')),
                  onTap: () => _go(context, const AboutScreen()),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          FutureBuilder<PackageInfo>(
            future: PackageInfo.fromPlatform(),
            builder: (c, s) => Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                '${app.tr('Version')} ${s.data?.version ?? ''}',
                style: TextStyle(color: cs.outline, fontSize: 12),
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.logout, color: cs.error),
            title: Text(app.tr('Logout'), style: TextStyle(color: cs.error)),
            onTap: () async {
              final ok = await confirm(context, 'Logout from My Diary?');
              if (ok) {
                if (context.mounted) Navigator.pop(context);
                await AuthService.logout();
              }
            },
          ),
          SizedBox(height: MediaQuery.of(context).padding.bottom),
        ],
      ),
    );
  }
}
