import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/screens/add_screen.dart';
import 'package:my_diary/services/db.dart';

class DiseasesScreen extends StatefulWidget {
  const DiseasesScreen({super.key});
  @override
  State<DiseasesScreen> createState() => _DiseasesScreenState();
}

class _DiseasesScreenState extends State<DiseasesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase()), hint: app.tr('Search')),
          TabBar(tabs: [
            Tab(text: app.tr('All')),
            Tab(text: app.tr('Good Prognosis')),
            Tab(text: app.tr('Poor Prognosis')),
          ]),
          Expanded(
            child: TabBarView(children: [
              _DiseaseList(q: _q, prognosis: null),
              _DiseaseList(q: _q, prognosis: 'good'),
              _DiseaseList(q: _q, prognosis: 'poor'),
            ]),
          ),
        ],
      ),
    );
  }
}

class _DiseaseList extends StatelessWidget {
  const _DiseaseList({required this.q, required this.prognosis});
  final String q;
  final String? prognosis;

  @override
  Widget build(BuildContext context) {
    return Q(
      query: Db.diseases,
      builder: (c, docs) {
        final list = docs.where((d) {
          final m = d.data();
          if (prognosis != null && m['prognosis'] != prognosis) return false;
          if (q.isEmpty) return true;
          return '${m['title']} ${m['ownerName']} ${m['phone']}'.toLowerCase().contains(q);
        }).toList()
          ..sort((a, b) =>
              dt(b.data()['createdAt']).compareTo(dt(a.data()['createdAt'])));
        if (list.isEmpty) {
          return const EmptyState('No diseases found.', icon: Icons.healing_outlined);
        }
        return ListView.separated(
          itemCount: list.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (c, i) {
            final m = list[i].data();
            return ListTile(
              title: Text('${m['title']}', style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('${m['ownerName'] ?? ''}  •  ${m['phone'] ?? ''}',
                  style: const TextStyle(fontSize: 11)),
              trailing: Pill(m['prognosis'] == 'good' ? 'Good' : 'Poor',
                  m['prognosis'] == 'good' ? Colors.green : Colors.red),
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => DiseaseDetailScreen(id: list[i].id))),
            );
          },
        );
      },
    );
  }
}

class DiseaseDetailScreen extends StatelessWidget {
  const DiseaseDetailScreen({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: Db.diseases.doc(id).snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        }
        if (!snap.data!.exists) {
          return Scaffold(appBar: AppBar(), body: const EmptyState('Disease record deleted'));
        }
        final r = Rec(id, snap.data!.data() ?? {});
        final editable = canEdit(app, r.data);
        final private = r.s('visitType') == 'private';
        return Scaffold(
          appBar: AppBar(
            title: Text(r.s('title')),
            actions: [
              if (editable)
                IconButton(
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => EditPage(
                              title: 'Edit disease',
                              builder: (done) => DiseaseForm(existing: r, onDone: done)))),
                ),
              if (editable)
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await confirm(context, 'Delete this disease record?')) {
                      final owner = r.s('createdBy');
                      final batch = Db.f.batch();
                      batch.delete(Db.diseases.doc(id));
                      if (owner.isNotEmpty) {
                        batch.delete(Db.users.doc(owner).collection('diseaseFees').doc(id));
                      }
                      fire(batch.commit());
                      if (context.mounted) Navigator.pop(context);
                    }
                  },
                ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Wrap(spacing: 8, runSpacing: 6, children: [
                Pill(r.s('prognosis') == 'good' ? 'Prognosis: GOOD' : 'Prognosis: POOR',
                    r.s('prognosis') == 'good' ? Colors.green : Colors.red),
                Pill(private ? 'Private call/visit' : 'Hospital', Colors.indigo),
                Pill(r.s('skinParasite') == 'present' ? 'Skin parasite: PRESENT' : 'Skin parasite: ABSENT',
                    Colors.brown),
              ]),
              const SizedBox(height: 6),
              Card(
                child: Column(children: [
                  ListTile(
                    leading: const Icon(Icons.person_outline),
                    title: Text(r.s('ownerName')),
                    subtitle: const Text('Owner'),
                  ),
                  ListTile(
                    leading: const Icon(Icons.phone),
                    title: Text(r.s('phone')),
                    subtitle: const Text('Phone'),
                    onTap: r.s('phone').isEmpty ? null : () => openUrl('tel:${r.s('phone')}'),
                  ),
                  if (r.s('location').isNotEmpty)
                    ListTile(
                      leading: const Icon(Icons.location_on_outlined),
                      title: Text(r.s('location')),
                      subtitle: const Text('Location'),
                    ),
                ]),
              ),
              // The fee is private: only the creator and the administrator can read it.
              if (private && editable)
                StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                  stream: Db.users
                      .doc(r.s('createdBy'))
                      .collection('diseaseFees')
                      .doc(id)
                      .snapshots(),
                  builder: (c, s) {
                    final amount = s.data?.data()?['amount'];
                    if (amount == null) return const SizedBox.shrink();
                    return Card(
                      color: Theme.of(context).colorScheme.tertiaryContainer,
                      child: ListTile(
                        leading: const Icon(Icons.lock_outline),
                        title: Text('Fee taken: ${money(numv(amount))}'),
                        subtitle: const Text('Visible only to you and the administrator'),
                      ),
                    );
                  },
                ),
              InfoBlock('Temperature', r.s('temperature'), icon: Icons.thermostat),
              InfoBlock('Sign & symptoms told by the owner', r.s('symptoms'), icon: Icons.record_voice_over_outlined),
              InfoBlock('Clinical findings', r.s('clinicalFindings'), icon: Icons.search),
              InfoBlock('Treatment', r.s('treatment'), icon: Icons.medical_services_outlined),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Text(
                    'Added by: ${r.s('createdByName')} • ${fmtDate(dt(r.data['createdAt']))}',
                    style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12)),
              ),
            ],
          ),
        );
      },
    );
  }
}
