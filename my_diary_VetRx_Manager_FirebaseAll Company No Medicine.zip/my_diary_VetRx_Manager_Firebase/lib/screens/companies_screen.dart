import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/screens/add_screen.dart';
import 'package:my_diary/screens/medicines_screen.dart';
import 'package:my_diary/services/db.dart';

class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});
  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Column(
      children: [
        SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase()), hint: app.tr('Search')),
        Expanded(
          child: Q(
            query: Db.companies,
            builder: (c, companies) => Q(
              query: Db.medicines,
              builder: (c, meds) {
                final counts = <String, int>{};
                for (final m in meds) {
                  final id = '${m.data()['companyId']}';
                  counts[id] = (counts[id] ?? 0) + 1;
                }
                final list = companies
                    .where((d) => '${d.data()['name']}'.toLowerCase().contains(_q))
                    .toList()
                  ..sort((a, b) => '${a.data()['name']}'
                      .toLowerCase()
                      .compareTo('${b.data()['name']}'.toLowerCase()));
                if (list.isEmpty) {
                  return const EmptyState(
                      'No companies yet.\nAdd one from the "Add" tab.',
                      icon: Icons.business_outlined);
                }
                return ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (c, i) {
                    final d = list[i];
                    final n = counts[d.id] ?? 0;
                    return ListTile(
                      leading: CircleAvatar(
                          child: Text('${d.data()['name']}'.isEmpty
                              ? '?'
                              : '${d.data()['name']}'[0].toUpperCase())),
                      title: Text('${d.data()['name']}'),
                      subtitle: Text('$n medicine${n == 1 ? '' : 's'}'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => CompanyDetailScreen(id: d.id))),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

class CompanyDetailScreen extends StatelessWidget {
  const CompanyDetailScreen({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: Db.companies.doc(id).snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return Scaffold(
              appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        }
        if (!snap.data!.exists) {
          return Scaffold(appBar: AppBar(), body: const EmptyState('Company deleted'));
        }
        final r = Rec(id, snap.data!.data() ?? {});
        final editable = canEdit(app, r.data);
        return Scaffold(
          appBar: AppBar(
            title: Text(r.s('name')),
            actions: [
              if (editable)
                IconButton(
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => EditPage(
                              title: 'Edit company',
                              builder: (done) => CompanyForm(existing: r, onDone: done)))),
                ),
              if (editable)
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await confirm(context,
                        'Delete this company? Its medicines will stay in the Medicines list.')) {
                      fire(Db.companies.doc(id).delete());
                      if (context.mounted) Navigator.pop(context);
                    }
                  },
                ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(12),
            children: [
              InfoBlock('Phone', r.s('phone'), icon: Icons.phone),
              InfoBlock('Website', r.s('website'), icon: Icons.public),
              InfoBlock('Address', r.s('address'), icon: Icons.location_on_outlined),
              InfoBlock('Notes', r.s('notes'), icon: Icons.notes),
              const Padding(
                padding: EdgeInsets.fromLTRB(4, 14, 4, 4),
                child: Text('Medicines of this company',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
              Q(
                query: Db.medicines.where('companyId', isEqualTo: id),
                builder: (c, docs) {
                  final list = List<Doc>.of(docs)
                    ..sort((a, b) => '${a.data()['name']}'
                        .toLowerCase()
                        .compareTo('${b.data()['name']}'.toLowerCase()));
                  if (list.isEmpty) {
                    return const Padding(
                        padding: EdgeInsets.all(20),
                        child: Text('No medicine added for this company yet.'));
                  }
                  return Column(
                    children: [
                      for (final d in list) MedicineTile(rec: Rec.of(d), showCompany: false)
                    ],
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
