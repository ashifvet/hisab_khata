import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/screens/add_screen.dart';
import 'package:my_diary/screens/app_drawer.dart';
import 'package:my_diary/screens/companies_screen.dart';
import 'package:my_diary/screens/diseases_screen.dart';
import 'package:my_diary/screens/hisab_screen.dart';
import 'package:my_diary/screens/medicines_screen.dart';
import 'package:my_diary/screens/ps_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  // Order (left -> right): Hisab > Companies > Medicines > Diseases > P&S > Add
  static const _labels = ['Hisab', 'Companies', 'Medicines', 'Diseases', 'P&S', 'Add'];
  static const _icons = [
    Icons.account_balance_wallet_outlined,
    Icons.business_outlined,
    Icons.medication_outlined,
    Icons.healing_outlined,
    Icons.lightbulb_outline,
    Icons.add_circle_outline,
  ];
  static const _iconsOn = [
    Icons.account_balance_wallet,
    Icons.business,
    Icons.medication,
    Icons.healing,
    Icons.lightbulb,
    Icons.add_circle,
  ];

  final _pages = const <Widget>[
    HisabScreen(),
    CompaniesScreen(),
    MedicinesScreen(),
    DiseasesScreen(),
    PsScreen(),
    AddScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: Text(app.tr(_labels[_i])),
      ),
      drawer: const AppDrawer(),
      body: IndexedStack(index: _i, children: _pages),
      bottomNavigationBar: _ResponsiveNavBar(
        index: _i,
        labels: [for (final l in _labels) app.tr(l)],
        icons: _icons,
        iconsOn: _iconsOn,
        onTap: (v) => setState(() => _i = v),
      ),
    );
  }
}

/// Bottom bar that scales icons/text with the screen width, so all 6 tabs always fit
/// (small phones => smaller, tablets/desktop => bigger).
class _ResponsiveNavBar extends StatelessWidget {
  const _ResponsiveNavBar({
    required this.index,
    required this.labels,
    required this.icons,
    required this.iconsOn,
    required this.onTap,
  });
  final int index;
  final List<String> labels;
  final List<IconData> icons;
  final List<IconData> iconsOn;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      elevation: 10,
      color: cs.surface,
      child: SafeArea(
        top: false,
        child: LayoutBuilder(builder: (context, c) {
          final itemW = c.maxWidth / labels.length;
          final iconSize = (itemW * 0.36).clamp(18.0, 36.0).toDouble();
          final font = (itemW * 0.16).clamp(9.0, 15.0).toDouble();
          final height = (itemW * 0.78).clamp(56.0, 88.0).toDouble();
          return SizedBox(
            height: height,
            child: Row(
              children: [
                for (var i = 0; i < labels.length; i++)
                  Expanded(
                    child: InkWell(
                      onTap: () => onTap(i),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: EdgeInsets.symmetric(
                                horizontal: itemW * 0.16, vertical: 2),
                            decoration: BoxDecoration(
                              color: i == index
                                  ? cs.secondaryContainer
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Icon(
                              i == index ? iconsOn[i] : icons[i],
                              size: iconSize,
                              color: i == index ? cs.primary : cs.onSurfaceVariant,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Text(
                                labels[i],
                                maxLines: 1,
                                style: TextStyle(
                                  fontSize: font,
                                  fontWeight:
                                      i == index ? FontWeight.bold : FontWeight.normal,
                                  color: i == index
                                      ? cs.primary
                                      : cs.onSurfaceVariant,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }
}
