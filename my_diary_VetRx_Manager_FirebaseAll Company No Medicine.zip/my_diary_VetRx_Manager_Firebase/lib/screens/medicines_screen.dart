import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/screens/add_screen.dart';
import 'package:my_diary/screens/companies_screen.dart';
import 'package:my_diary/services/db.dart';

class MedicinesScreen extends StatefulWidget {
  const MedicinesScreen({super.key});
  @override
  State<MedicinesScreen> createState() => _MedicinesScreenState();
}

class _MedicinesScreenState extends State<MedicinesScreen> {
  String _q = '';
  bool _importing = false;

  String _slug(String s) => s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_');

  /// One-time import of the bundled medicine database (assets/data/medicines.json).
  Future<void> _import() async {
    final app = context.read<AppState>();
    final ok = await confirm(context,
        'Import the bundled list of veterinary companies and medicines (Medex / Arogga based)?\n\nThis can be done only once.');
    if (!ok) return;
    setState(() => _importing = true);
    try {
      final raw = await rootBundle.loadString('assets/data/medicines.json');
      final json = jsonDecode(raw) as Map<String, dynamic>;
      final companies = (json['companies'] as List).cast<String>();
      final meds = (json['medicines'] as List).cast<Map<String, dynamic>>();

      // reuse already existing companies (same name)
      final existing = <String, String>{}; // lower name -> id
      final cs = await Db.companies.get();
      for (final d in cs.docs) {
        existing['${d.data()['name']}'.toLowerCase()] = d.id;
      }

      final ops = <void Function(WriteBatch)>[];
      final idOf = <String, String>{};
      for (final name in companies) {
        final id = existing[name.toLowerCase()] ?? 'seed_${_slug(name)}';
        idOf[name] = id;
        if (!existing.containsKey(name.toLowerCase())) {
          ops.add((b) => b.set(Db.companies.doc(id), {
                'name': name,
                'phone': '',
                'website': '',
                'address': '',
                'notes': 'Imported from local database',
                'createdBy': 'system',
                'createdByName': 'Local database',
                'createdAt': Timestamp.now(),
              }));
        }
      }
      for (final m in meds) {
        final cname = '${m['c']}';
        final cid = idOf[cname] ?? 'seed_${_slug(cname)}';
        final mid = 'seed_${_slug('${m['n']}_$cname')}';
        ops.add((b) => b.set(Db.medicines.doc(mid), {
              'name': '${m['n']}',
              'nameLower': '${m['n']}'.toLowerCase(),
              'companyId': cid,
              'companyName': cname,
              'components': '${m['g']}',
              'whenToUse': '${m['u']}',
              'dose': '${m['d']}',
              'pregnancySafe': false,
              'petSafe': m['p'] == true,
              'details':
                  'Form: ${m['f']}\nStrength: ${m['s']}\n${m['x']}\n\n(Imported - please verify details and edit pregnancy / pet safety before relying on them.)',
              'source': 'local-db',
              'createdBy': 'system',
              'createdByName': 'Local database',
              'createdAt': Timestamp.now(),
            }));
      }
      ops.add((b) => b.set(Db.config.doc('seed'), {
            'done': true,
            'by': app.uid,
            'at': Timestamp.now(),
          }));

      // commit in chunks of 400 (Firestore limit is 500)
      for (var i = 0; i < ops.length; i += 400) {
        final batch = Db.f.batch();
        for (final op in ops.sublist(i, i + 400 > ops.length ? ops.length : i + 400)) {
          op(batch);
        }
        // not awaited indefinitely: when offline the commit finishes after sync
        await batch.commit().timeout(const Duration(seconds: 20), onTimeout: () {});
      }
      if (mounted) snack(context, 'Import done: ${companies.length} companies, ${meds.length} medicines');
    } catch (e) {
      if (mounted) snack(context, 'Import failed: $e');
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase()), hint: app.tr('Search')),
          // ---- import button (disabled after import) ----
          StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: Db.config.doc('seed').snapshots(),
            builder: (c, s) {
              final done = s.data?.exists == true;
              return Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: (done || _importing || !s.hasData) ? null : _import,
                    icon: _importing
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Icon(done ? Icons.check_circle : Icons.download),
                    label: Text(done
                        ? app.tr('Medicines imported')
                        : app.tr('Import medicines from local database')),
                  ),
                ),
              );
            },
          ),
          TabBar(
            tabs: [
              Tab(text: app.tr('All Medicines')),
              Tab(text: app.tr('Pregnancy Safe')),
              Tab(text: app.tr('Pet Medicines')),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                _MedList(q: _q, filter: (d) => true),
                _MedList(q: _q, filter: (d) => d['pregnancySafe'] == true),
                _MedList(q: _q, filter: (d) => d['petSafe'] == true),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MedList extends StatelessWidget {
  const _MedList({required this.q, required this.filter});
  final String q;
  final bool Function(Map<String, dynamic>) filter;

  @override
  Widget build(BuildContext context) {
    return Q(
      query: Db.medicines,
      builder: (c, docs) {
        final list = docs.where((d) {
          final m = d.data();
          if (!filter(m)) return false;
          if (q.isEmpty) return true;
          return '${m['name']} ${m['companyName']} ${m['components']}'
              .toLowerCase()
              .contains(q);
        }).toList()
          ..sort((a, b) => '${a.data()['name']}'
              .toLowerCase()
              .compareTo('${b.data()['name']}'.toLowerCase()));
        if (list.isEmpty) {
          return const EmptyState('No medicines found.', icon: Icons.medication_outlined);
        }
        return ListView.separated(
          itemCount: list.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (c, i) => MedicineTile(rec: Rec.of(list[i])),
        );
      },
    );
  }
}

class MedicineTile extends StatelessWidget {
  const MedicineTile({super.key, required this.rec, this.showCompany = true});
  final Rec rec;
  final bool showCompany;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(rec.s('name'), style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(
        [
          if (showCompany) rec.s('companyName'),
          rec.s('components'),
        ].where((e) => e.isNotEmpty).join(' • '),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        if (rec.b('pregnancySafe')) const Icon(Icons.pregnant_woman, size: 18, color: Colors.pink),
        const SizedBox(width: 4),
        Icon(rec.b('petSafe') ? Icons.pets : Icons.warning_amber_rounded,
            size: 18, color: rec.b('petSafe') ? Colors.green : Colors.orange),
      ]),
      onTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => MedicineDetailScreen(id: rec.id))),
    );
  }
}

class MedicineDetailScreen extends StatelessWidget {
  const MedicineDetailScreen({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: Db.medicines.doc(id).snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        }
        if (!snap.data!.exists) {
          return Scaffold(appBar: AppBar(), body: const EmptyState('Medicine deleted'));
        }
        final r = Rec(id, snap.data!.data() ?? {});
        final editable = canEdit(app, r.data);
        return Scaffold(
          appBar: AppBar(
            title: Text(r.s('name')),
            actions: [
              if (editable)
                IconButton(
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => EditPage(
                              title: 'Edit medicine',
                              builder: (done) => MedicineForm(existing: r, onDone: done)))),
                ),
              if (editable)
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await confirm(context, 'Delete this medicine?')) {
                      fire(Db.medicines.doc(id).delete());
                      if (context.mounted) Navigator.pop(context);
                    }
                  },
                ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Wrap(spacing: 8, runSpacing: 6, children: [
                Pill(r.b('petSafe') ? 'Pet: SAFE' : 'Pet: UNSAFE',
                    r.b('petSafe') ? Colors.green : Colors.red),
                Pill(r.b('pregnancySafe') ? 'Pregnancy: SAFE' : 'Pregnancy: NOT SAFE',
                    r.b('pregnancySafe') ? Colors.teal : Colors.deepOrange),
              ]),
              const SizedBox(height: 8),
              if (r.s('companyId').isNotEmpty)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.business),
                    title: Text(r.s('companyName')),
                    subtitle: const Text('Company'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => CompanyDetailScreen(id: r.s('companyId')))),
                  ),
                ),
              InfoBlock('Components', r.s('components'), icon: Icons.science_outlined),
              InfoBlock('When to use', r.s('whenToUse'), icon: Icons.help_outline),
              InfoBlock('Dose', r.s('dose'), icon: Icons.colorize),
              InfoBlock('Other details', r.s('details'), icon: Icons.notes),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Text('Added by: ${r.s('createdByName')}',
                    style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12)),
              ),
            ],
          ),
        );
      },
    );
  }
}
