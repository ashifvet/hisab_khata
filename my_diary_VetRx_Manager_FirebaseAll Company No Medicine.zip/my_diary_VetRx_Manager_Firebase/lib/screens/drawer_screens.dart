import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/services/auth_service.dart';
import 'package:my_diary/services/db.dart';

// =============================================================== PROFILE
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _first, _last, _phone, _loc, _extra;

  @override
  void initState() {
    super.initState();
    final p = context.read<AppState>().profile;
    _first = TextEditingController(text: '${p['firstName'] ?? ''}');
    _last = TextEditingController(text: '${p['lastName'] ?? ''}');
    _phone = TextEditingController(text: '${p['phone'] ?? ''}');
    _loc = TextEditingController(text: '${p['location'] ?? ''}');
    _extra = TextEditingController(text: '${p['about'] ?? ''}');
  }

  @override
  void dispose() {
    for (final c in [_first, _last, _phone, _loc, _extra]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    fire(Db.users.doc(app.uid).set({
      'firstName': _first.text.trim(),
      'lastName': _last.text.trim(),
      'phone': _phone.text.trim(),
      'location': _loc.text.trim(),
      'about': _extra.text.trim(),
    }, SetOptions(merge: true)));
    snack(context, 'Profile saved');
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.tr('Edit Profile'))),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            tf(_first, 'First name', required: true),
            tf(_last, 'Last name'),
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TextFormField(
                initialValue: app.user?.email ?? '',
                enabled: false,
                decoration: const InputDecoration(
                    labelText: 'Email', border: OutlineInputBorder()),
              ),
            ),
            tf(_phone, 'Phone number', type: TextInputType.phone),
            tf(_loc, 'Location'),
            tf(_extra, 'About / Designation', lines: 2),
            FilledButton.icon(
                onPressed: _save, icon: const Icon(Icons.save), label: const Text('Save')),
          ],
        ),
      ),
    );
  }
}

// =============================================================== SETTINGS
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _changePassword(BuildContext context) async {
    final r = await formDialog(context, 'Change password', const [
      FieldSpec('cur', 'Current password', kind: FK.password, required: true),
      FieldSpec('new', 'New password (min 6)', kind: FK.password, required: true),
      FieldSpec('new2', 'Confirm new password', kind: FK.password, required: true),
    ]);
    if (r == null || !context.mounted) return;
    if (r['new']!.length < 6) {
      snack(context, 'Password must be at least 6 characters');
      return;
    }
    if (r['new'] != r['new2']) {
      snack(context, 'Passwords do not match');
      return;
    }
    try {
      await AuthService.changePassword(r['cur']!, r['new']!);
      if (context.mounted) snack(context, 'Password changed');
    } catch (e) {
      if (context.mounted) snack(context, 'Could not change password: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.tr('Settings'))),
      body: ListView(
        children: [
          SwitchListTile(
            secondary: const Icon(Icons.dark_mode_outlined),
            title: Text(app.tr('Dark mode')),
            value: app.themeMode == ThemeMode.dark,
            onChanged: app.setDark,
          ),
          ListTile(
            leading: const Icon(Icons.lock_reset),
            title: Text(app.tr('Change password')),
            onTap: () => _changePassword(context),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Text(app.tr('App language'),
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          RadioListTile<String>(
            value: 'en',
            groupValue: app.lang,
            title: const Text('English'),
            onChanged: (v) => app.setLang(v!),
          ),
          RadioListTile<String>(
            value: 'bn',
            groupValue: app.lang,
            title: const Text('বাংলা (Bangla)'),
            onChanged: (v) => app.setLang(v!),
          ),
        ],
      ),
    );
  }
}

// =============================================================== ABOUT
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Widget _row(IconData i, String k, String v, {VoidCallback? onTap}) => ListTile(
        leading: Icon(i),
        title: Text(k, style: const TextStyle(fontSize: 12)),
        subtitle: Text(v, style: const TextStyle(fontSize: 16)),
        onTap: onTap,
      );

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(app.tr('About Developer'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 44,
              backgroundColor: cs.primaryContainer,
              child: Icon(Icons.medical_services, size: 44, color: cs.primary),
            ),
          ),
          const SizedBox(height: 12),
          const Center(
            child: Text('Dr. MD. ASHIF IQBAL',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          ),
          const Center(child: Text('DVM, MSc, BCS')),
          const SizedBox(height: 12),
          Card(
            child: Column(children: [
              _row(Icons.work_outline, 'Designation', 'Veterinary Surgeon, Maheshpur'),
              _row(Icons.phone, 'Phone', '01711989236',
                  onTap: () => openUrl('tel:01711989236')),
              _row(Icons.home_outlined, 'Hometown', 'Kushtia'),
              FutureBuilder<PackageInfo>(
                future: PackageInfo.fromPlatform(),
                builder: (c, s) => _row(Icons.tag, 'Version Name',
                    '${s.data?.version ?? ''} (build ${s.data?.buildNumber ?? ''})'),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

// =============================================================== ANNOUNCEMENTS (admin)
class AnnouncementsAdminScreen extends StatelessWidget {
  const AnnouncementsAdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.tr('Announcements'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('New'),
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const _AnnouncementForm())),
      ),
      body: Q(
        query: Db.announcements,
        builder: (c, docs) {
          final list = List<Doc>.of(docs)
            ..sort((a, b) =>
                dt(b.data()['createdAt']).compareTo(dt(a.data()['createdAt'])));
          if (list.isEmpty) {
            return const EmptyState('No announcements yet.\nTap "New" to create one.',
                icon: Icons.campaign_outlined);
          }
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            itemBuilder: (c, i) {
              final d = list[i].data();
              final active = d['active'] == true;
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                child: ListTile(
                  title: Text('${d['title'] ?? ''}'),
                  subtitle: Text(
                      '${d['content'] ?? ''}\nShow ${d['showTimes'] ?? 1}x • Cancel: ${d['cancelAllowed'] == true ? 'Yes' : 'No'}',
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis),
                  isThreeLine: true,
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => _AnnouncementForm(existing: Rec.of(list[i])))),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Switch(
                      value: active,
                      onChanged: (v) =>
                          fire(Db.announcements.doc(list[i].id).update({'active': v})),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        if (await confirm(context, 'Delete this announcement?')) {
                          fire(Db.announcements.doc(list[i].id).delete());
                        }
                      },
                    ),
                  ]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _AnnouncementForm extends StatefulWidget {
  const _AnnouncementForm({this.existing});
  final Rec? existing;
  @override
  State<_AnnouncementForm> createState() => _AnnouncementFormState();
}

class _AnnouncementFormState extends State<_AnnouncementForm> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _title, _content, _tg, _web, _times;
  bool _cancel = true;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _title = TextEditingController(text: e?.s('title') ?? '');
    _content = TextEditingController(text: e?.s('content') ?? '');
    _tg = TextEditingController(text: e?.s('telegramLink') ?? '');
    _web = TextEditingController(text: e?.s('webLink') ?? '');
    _times = TextEditingController(text: e == null ? '1' : e.s('showTimes'));
    _cancel = e == null ? true : e.b('cancelAllowed');
  }

  @override
  void dispose() {
    for (final c in [_title, _content, _tg, _web, _times]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final data = {
      'title': _title.text.trim(),
      'content': _content.text.trim(),
      'telegramLink': _tg.text.trim(),
      'webLink': _web.text.trim(),
      'cancelAllowed': _cancel,
      'showTimes': int.tryParse(_times.text.trim()) ?? 1,
      'active': true,
      'updatedAt': Timestamp.now(),
    };
    if (widget.existing == null) {
      fire(Db.announcements.add({...data, 'createdAt': Timestamp.now()}));
    } else {
      fire(Db.announcements.doc(widget.existing!.id).update(data));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'New announcement' : 'Edit announcement')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            tf(_title, 'Title of the dialog box', required: true),
            tf(_content, 'Content of the dialog box', required: true, lines: 5),
            tf(_tg, 'Telegram link', type: TextInputType.url),
            tf(_web, 'Website link', type: TextInputType.url),
            tf(_times, 'How many times will the user see it?',
                required: true, type: TextInputType.number),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Cancel allowed'),
              subtitle: Text(_cancel
                  ? 'Yes - user can close the dialog'
                  : 'No - user must click Join Telegram or Visit Web'),
              value: _cancel,
              onChanged: (v) => setState(() => _cancel = v),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
                onPressed: _save, icon: const Icon(Icons.send), label: const Text('Publish')),
          ],
        ),
      ),
    );
  }
}

// =============================================================== USERS (admin)
class UsersAdminScreen extends StatelessWidget {
  const UsersAdminScreen({super.key});

  Future<void> _addAccount(BuildContext context) async {
    final r = await formDialog(context, 'Add new account', const [
      FieldSpec('name', 'Name', required: true),
      FieldSpec('email', 'E-mail or username', required: true),
      FieldSpec('pass', 'Password (min 6)', kind: FK.password, required: true),
      FieldSpec('role', 'Role', kind: FK.choice, options: ['Admin', 'User']),
    ]);
    if (r == null || !context.mounted) return;
    if (r['pass']!.length < 6) {
      snack(context, 'Password must be at least 6 characters');
      return;
    }
    try {
      await AuthService.createAccount(
        firstName: r['name']!,
        email: r['email']!,
        password: r['pass']!,
        admin: r['role'] == 'Admin',
      );
      if (context.mounted) snack(context, 'Account created');
    } catch (e) {
      if (context.mounted) snack(context, 'Failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.tr('Manage Users & Admins'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.person_add),
        label: const Text('Add account'),
        onPressed: () => _addAccount(context),
      ),
      body: Q(
        query: Db.users,
        builder: (c, docs) {
          final list = List<Doc>.of(docs)
            ..sort((a, b) => '${a.data()['firstName']}'
                .toLowerCase()
                .compareTo('${b.data()['firstName']}'.toLowerCase()));
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            itemBuilder: (c, i) {
              final d = list[i].data();
              final isAdmin = d['role'] == 'admin';
              final self = list[i].id == app.uid;
              return ListTile(
                leading: CircleAvatar(
                    child: Text('${d['firstName'] ?? '?'}'.isEmpty
                        ? '?'
                        : '${d['firstName']}'[0].toUpperCase())),
                title: Text('${d['firstName'] ?? ''} ${d['lastName'] ?? ''}'.trim()),
                subtitle: Text('${d['email'] ?? ''}\n${d['phone'] ?? ''}'),
                isThreeLine: true,
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(isAdmin ? 'Admin' : 'User',
                        style: const TextStyle(fontSize: 11)),
                    Switch(
                      value: isAdmin,
                      onChanged: self
                          ? null
                          : (v) => fire(Db.users
                              .doc(list[i].id)
                              .update({'role': v ? 'admin' : 'user'})),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// =============================================================== VERSION CONTROL (admin)
class VersionAdminScreen extends StatefulWidget {
  const VersionAdminScreen({super.key});
  @override
  State<VersionAdminScreen> createState() => _VersionAdminScreenState();
}

class _VersionAdminScreenState extends State<VersionAdminScreen> {
  final _latest = TextEditingController();
  final _min = TextEditingController();
  final _url = TextEditingController();
  final _msg = TextEditingController();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    Db.config.doc('app').get().then((s) {
      final d = s.data() ?? {};
      _latest.text = '${d['latestVersion'] ?? ''}';
      _min.text = '${d['minVersion'] ?? ''}';
      _url.text = '${d['updateUrl'] ?? ''}';
      _msg.text = '${d['message'] ?? ''}';
      if (mounted) setState(() => _loaded = true);
    }).catchError((Object e) {
      if (mounted) setState(() => _loaded = true);
    });
  }

  @override
  void dispose() {
    for (final c in [_latest, _min, _url, _msg]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.tr('App Version Control'))),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                    'Users with a version lower than "Minimum version" are forced to update '
                    '(they cannot continue). Users lower than "Latest version" see an optional update dialog.'),
                const SizedBox(height: 14),
                tf(_latest, 'Latest version (e.g. 1.0.3)'),
                tf(_min, 'Minimum version (force update below this)'),
                tf(_url, 'Update link (Play Store / website / Drive)',
                    type: TextInputType.url),
                tf(_msg, 'Update message', lines: 3),
                FilledButton.icon(
                  icon: const Icon(Icons.cloud_upload),
                  label: const Text('Publish'),
                  onPressed: () {
                    fire(Db.config.doc('app').set({
                      'latestVersion': _latest.text.trim(),
                      'minVersion': _min.text.trim(),
                      'updateUrl': _url.text.trim(),
                      'message': _msg.text.trim(),
                      'updatedAt': Timestamp.now(),
                    }));
                    snack(context, 'Published');
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
    );
  }
}
