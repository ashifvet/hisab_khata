import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/screens/add_screen.dart';
import 'package:my_diary/services/db.dart';

/// "Problem based Solutions" list
class PsScreen extends StatefulWidget {
  const PsScreen({super.key});
  @override
  State<PsScreen> createState() => _PsScreenState();
}

class _PsScreenState extends State<PsScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Column(
      children: [
        SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase()), hint: app.tr('Search')),
        Expanded(
          child: Q(
            query: Db.problems,
            builder: (c, docs) {
              final list = docs
                  .where((d) => '${d.data()['title']} ${d.data()['problem']}'
                      .toLowerCase()
                      .contains(_q))
                  .toList()
                ..sort((a, b) =>
                    dt(b.data()['createdAt']).compareTo(dt(a.data()['createdAt'])));
              if (list.isEmpty) {
                return const EmptyState(
                    'No problems & solutions yet.\nAdd one from the "Add" tab.',
                    icon: Icons.lightbulb_outline);
              }
              return ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (c, i) {
                  final m = list[i].data();
                  return ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.lightbulb_outline)),
                    title: Text('${m['title']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text('${m['problem'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => PsDetailScreen(id: list[i].id))),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class PsDetailScreen extends StatelessWidget {
  const PsDetailScreen({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: Db.problems.doc(id).snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        }
        if (!snap.data!.exists) {
          return Scaffold(appBar: AppBar(), body: const EmptyState('Deleted'));
        }
        final r = Rec(id, snap.data!.data() ?? {});
        final editable = canEdit(app, r.data);
        return Scaffold(
          appBar: AppBar(
            title: Text(r.s('title')),
            actions: [
              if (editable)
                IconButton(
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => EditPage(
                              title: 'Edit problem & solution',
                              builder: (done) => ProblemForm(existing: r, onDone: done)))),
                ),
              if (editable)
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await confirm(context, 'Delete this item?')) {
                      fire(Db.problems.doc(id).delete());
                      if (context.mounted) Navigator.pop(context);
                    }
                  },
                ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(12),
            children: [
              InfoBlock('Problem', r.s('problem'), icon: Icons.error_outline),
              InfoBlock('Solution', r.s('solution'), icon: Icons.check_circle_outline),
              InfoBlock('Prognosis', r.s('prognosis'), icon: Icons.trending_up),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Text('Added by: ${r.s('createdByName')}',
                    style: TextStyle(color: Theme.of(context).colorScheme.outline, fontSize: 12)),
              ),
            ],
          ),
        );
      },
    );
  }
}
