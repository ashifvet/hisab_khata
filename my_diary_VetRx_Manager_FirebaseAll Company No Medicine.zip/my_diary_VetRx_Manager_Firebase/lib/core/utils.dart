import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:my_diary/core/app_state.dart';

typedef Doc = QueryDocumentSnapshot<Map<String, dynamic>>;
typedef MQuery = Query<Map<String, dynamic>>;

/// A light wrapper for "id + data" of a Firestore document.
class Rec {
  const Rec(this.id, this.data);
  final String id;
  final Map<String, dynamic> data;
  factory Rec.of(Doc d) => Rec(d.id, d.data());
  String s(String k) => (data[k] ?? '').toString();
  bool b(String k) => data[k] == true;
}

// ---------------------------------------------------------------- helpers
int wordCount(String s) =>
    s.trim().isEmpty ? 0 : s.trim().split(RegExp(r'\s+')).length;

/// Fire-and-forget for Firestore writes. Offline, Firestore queues the write and
/// syncs later; awaiting would block the UI until the server answers.
void fire(Future<dynamic> f) {
  f.catchError((Object e) {
    debugPrint('Firestore error: $e');
    return null;
  });
}

DateTime dt(dynamic v) => v is Timestamp ? v.toDate() : DateTime.now();
double numv(dynamic v) => v is num ? v.toDouble() : (double.tryParse('$v') ?? 0);

String fmtNum(double v) {
  final neg = v < 0;
  final a = v.abs();
  final s = a.toStringAsFixed(a == a.roundToDouble() ? 0 : 2);
  final parts = s.split('.');
  parts[0] = parts[0]
      .replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return '${neg ? '-' : ''}${parts.join('.')}';
}

String money(double v) => '৳${fmtNum(v)}';
String moneyPlain(double v) => 'Tk ${fmtNum(v)}';

const _months = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

String fmtDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')} ${_months[d.month - 1]} ${d.year}';
String ymd(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String ym(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}';

String greetingFor(AppState app) {
  final h = DateTime.now().hour;
  final k = h < 5
      ? 'Good night'
      : h < 12
          ? 'Good morning'
          : h < 17
              ? 'Good afternoon'
              : h < 20
                  ? 'Good evening'
                  : 'Good night';
  return '${app.tr(k)}, ${app.fullName}';
}

bool canEdit(AppState app, Map<String, dynamic> data) =>
    app.isAdmin || (data['createdBy'] != null && data['createdBy'] == app.uid);

Map<String, dynamic> stamp(AppState app) => {
      'createdBy': app.uid,
      'createdByName': app.fullName,
      'createdAt': Timestamp.now(),
    };

void snack(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<bool> confirm(BuildContext context, String msg) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Yes')),
      ],
    ),
  );
  return r ?? false;
}

// ---------------------------------------------------------------- launching
Future<void> openUrl(String url) async {
  var u = url.trim();
  if (u.isEmpty) return;
  if (!u.startsWith('http') && !u.startsWith('tel:') && !u.startsWith('sms:')) {
    u = 'https://$u';
  }
  try {
    await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
  } catch (e) {
    debugPrint('launch error $e');
  }
}

/// Bangladeshi number -> 8801XXXXXXXXX
String normalizeBd(String p) {
  final d = p.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('880')) return d;
  if (d.startsWith('0')) return '88$d';
  return d;
}

Future<void> sendSms(List<String> phones, String msg) async {
  final nums = phones.where((e) => e.trim().isNotEmpty).join(',');
  await openUrl('sms:$nums?body=${Uri.encodeComponent(msg)}');
}

Future<void> sendWhatsApp(String phone, String msg) async {
  await openUrl('https://wa.me/${normalizeBd(phone)}?text=${Uri.encodeComponent(msg)}');
}

// ---------------------------------------------------------------- widgets
/// StreamBuilder for a Firestore query.
class Q extends StatelessWidget {
  const Q({super.key, required this.query, required this.builder});
  final MQuery query;
  final Widget Function(BuildContext, List<Doc>) builder;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: query.snapshots(),
      builder: (c, s) {
        if (s.hasError) {
          return Center(
              child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text('Error: ${s.error}')));
        }
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        return builder(c, s.data!.docs);
      },
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState(this.text, {super.key, this.icon = Icons.inbox_outlined});
  final String text;
  final IconData icon;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 8),
          Text(text, textAlign: TextAlign.center),
        ]),
      ),
    );
  }
}

class SearchBox extends StatelessWidget {
  const SearchBox({super.key, required this.onChanged, this.hint = 'Search'});
  final ValueChanged<String> onChanged;
  final String hint;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
      child: TextField(
        onChanged: onChanged,
        decoration: InputDecoration(
          hintText: hint,
          prefixIcon: const Icon(Icons.search),
          isDense: true,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(28)),
        ),
      ),
    );
  }
}

/// Detail block: title + text (only shown when text is not empty)
class InfoBlock extends StatelessWidget {
  const InfoBlock(this.title, this.text, {super.key, this.icon});
  final String title;
  final String text;
  final IconData? icon;
  @override
  Widget build(BuildContext context) {
    if (text.trim().isEmpty) return const SizedBox.shrink();
    final cs = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            if (icon != null) ...[Icon(icon, size: 18, color: cs.primary), const SizedBox(width: 6)],
            Text(title,
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: cs.primary, fontSize: 13)),
          ]),
          const SizedBox(height: 6),
          SelectableText(text, style: const TextStyle(fontSize: 15, height: 1.35)),
        ]),
      ),
    );
  }
}

class Pill extends StatelessWidget {
  const Pill(this.text, this.color, {super.key});
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(text,
          style: const TextStyle(
              color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
    );
  }
}

/// Multi-line field with live "words used / max" counter and a hard limit.
class WordField extends StatefulWidget {
  const WordField({
    super.key,
    required this.controller,
    required this.label,
    required this.maxWords,
    this.minLines = 4,
    this.required = false,
  });
  final TextEditingController controller;
  final String label;
  final int maxWords;
  final int minLines;
  final bool required;
  @override
  State<WordField> createState() => _WordFieldState();
}

class _WordFieldState extends State<WordField> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_r);
  }

  void _r() => setState(() {});

  @override
  void dispose() {
    widget.controller.removeListener(_r);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final n = wordCount(widget.controller.text);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: widget.controller,
        minLines: widget.minLines,
        maxLines: widget.minLines + 10,
        keyboardType: TextInputType.multiline,
        decoration: InputDecoration(
          labelText: widget.label,
          alignLabelWithHint: true,
          border: const OutlineInputBorder(),
          helperText: '$n / ${widget.maxWords} words',
          helperStyle: TextStyle(color: n > widget.maxWords ? Colors.red : null),
        ),
        validator: (v) {
          final c = wordCount(v ?? '');
          if (widget.required && c == 0) return 'Required';
          if (c > widget.maxWords) return 'Maximum ${widget.maxWords} words allowed';
          return null;
        },
      ),
    );
  }
}

/// Standard text field used in forms
Widget tf(TextEditingController c, String label,
    {bool required = false,
    TextInputType? type,
    int lines = 1,
    bool obscure = false}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextFormField(
      controller: c,
      keyboardType: type,
      minLines: lines,
      maxLines: lines,
      obscureText: obscure,
      decoration:
          InputDecoration(labelText: label, border: const OutlineInputBorder()),
      validator: required
          ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null
          : null,
    ),
  );
}

// ---------------------------------------------------------------- form dialog
enum FK { text, number, phone, multiline, date, choice, password }

class FieldSpec {
  const FieldSpec(this.key, this.label,
      {this.kind = FK.text,
      this.required = false,
      this.initial,
      this.options = const []});
  final String key;
  final String label;
  final FK kind;
  final bool required;
  final String? initial;
  final List<String> options;
}

/// Shows a dialog with the given fields. Returns a map key->text or null.
Future<Map<String, String>?> formDialog(
    BuildContext context, String title, List<FieldSpec> specs) {
  return showDialog<Map<String, String>>(
    context: context,
    builder: (_) => _FormDialog(title: title, specs: specs),
  );
}

class _FormDialog extends StatefulWidget {
  const _FormDialog({required this.title, required this.specs});
  final String title;
  final List<FieldSpec> specs;
  @override
  State<_FormDialog> createState() => _FormDialogState();
}

class _FormDialogState extends State<_FormDialog> {
  final _form = GlobalKey<FormState>();
  final Map<String, TextEditingController> _c = {};

  @override
  void initState() {
    super.initState();
    for (final s in widget.specs) {
      String init = s.initial ?? '';
      if (s.initial == null) {
        if (s.kind == FK.date) init = ymd(DateTime.now());
        if (s.kind == FK.choice && s.options.isNotEmpty) init = s.options.first;
      }
      _c[s.key] = TextEditingController(text: init);
    }
  }

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  Widget _field(FieldSpec s) {
    final c = _c[s.key]!;
    const border = OutlineInputBorder();
    Widget w;
    switch (s.kind) {
      case FK.choice:
        w = DropdownButtonFormField<String>(
          value: s.options.contains(c.text) ? c.text : null,
          isExpanded: true,
          decoration: InputDecoration(labelText: s.label, border: border),
          items: [
            for (final o in s.options) DropdownMenuItem(value: o, child: Text(o))
          ],
          onChanged: (v) => setState(() => c.text = v ?? ''),
        );
        break;
      case FK.date:
        w = TextFormField(
          controller: c,
          readOnly: true,
          decoration: InputDecoration(
              labelText: s.label,
              border: border,
              suffixIcon: const Icon(Icons.calendar_today)),
          onTap: () async {
            final d = await showDatePicker(
              context: context,
              initialDate: DateTime.tryParse(c.text) ?? DateTime.now(),
              firstDate: DateTime(2000),
              lastDate: DateTime(2100),
            );
            if (d != null) setState(() => c.text = ymd(d));
          },
        );
        break;
      default:
        w = TextFormField(
          controller: c,
          obscureText: s.kind == FK.password,
          keyboardType: s.kind == FK.number
              ? const TextInputType.numberWithOptions(decimal: true)
              : s.kind == FK.phone
                  ? TextInputType.phone
                  : s.kind == FK.multiline
                      ? TextInputType.multiline
                      : TextInputType.text,
          minLines: s.kind == FK.multiline ? 4 : 1,
          maxLines: s.kind == FK.multiline ? 8 : 1,
          decoration: InputDecoration(labelText: s.label, border: border),
          validator: (v) {
            final t = (v ?? '').trim();
            if (s.required && t.isEmpty) return 'Required';
            if (s.kind == FK.number && t.isNotEmpty && double.tryParse(t) == null) {
              return 'Enter a valid number';
            }
            return null;
          },
        );
    }
    return Padding(padding: const EdgeInsets.only(bottom: 12), child: w);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Form(
            key: _form,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [for (final s in widget.specs) _field(s)],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: () {
            if (_form.currentState!.validate()) {
              Navigator.pop(context, {
                for (final e in _c.entries) e.key: e.value.text.trim()
              });
            }
          },
          child: const Text('Save'),
        ),
      ],
    );
  }
}
