import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:my_diary/core/strings.dart';
import 'package:my_diary/services/db.dart';

/// Global app state: theme, language, logged-in user + profile, selected business.
class AppState extends ChangeNotifier {
  late SharedPreferences prefs;

  ThemeMode themeMode = ThemeMode.light;
  String lang = 'en';

  bool authReady = false;
  User? user;
  Map<String, dynamic> profile = {};

  /// currently selected business (Hisab)
  String? bizId;

  /// admin only: whose Hisab data is being viewed (null = my own)
  String? viewUid;

  StreamSubscription<User?>? _authSub;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _profSub;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    themeMode =
        (prefs.getBool('dark') ?? false) ? ThemeMode.dark : ThemeMode.light;
    lang = prefs.getString('lang') ?? 'en';
    _authSub = FirebaseAuth.instance.authStateChanges().listen(_onAuth);
  }

  void _onAuth(User? u) {
    user = u;
    _profSub?.cancel();
    profile = {};
    viewUid = null;
    bizId = null;
    if (u == null) {
      authReady = true;
      notifyListeners();
      return;
    }
    bizId = prefs.getString('biz_${u.uid}');
    _profSub = Db.users.doc(u.uid).snapshots().listen((s) {
      if (s.exists) {
        profile = s.data() ?? {};
        authReady = true;
        notifyListeners();
      } else if (!s.metadata.isFromCache) {
        // profile document missing on the server -> create a minimal one
        final isAdminMail = (u.email ?? '') == 'admin@mydiary.app';
        Db.users.doc(u.uid).set({
          'email': u.email ?? '',
          'role': isAdminMail ? 'admin' : 'user',
        }, SetOptions(merge: true)).catchError((Object e) => debugPrint('$e'));
      } else {
        // offline and nothing cached yet: let the user in with empty profile
        authReady = true;
        notifyListeners();
      }
    });
  }

  // ---------- getters ----------
  bool get isAdmin => profile['role'] == 'admin';
  String get uid => user?.uid ?? '';
  String get dataUid => viewUid ?? uid;

  String get fullName {
    final n =
        '${profile['firstName'] ?? ''} ${profile['lastName'] ?? ''}'.trim();
    if (n.isNotEmpty) return n;
    final mail = user?.email ?? '';
    return mail.contains('@') ? mail.split('@').first : mail;
  }

  /// translate (English text is the key)
  String tr(String s) => lang == 'bn' ? (bnStrings[s] ?? s) : s;

  // ---------- setters ----------
  void setDark(bool v) {
    themeMode = v ? ThemeMode.dark : ThemeMode.light;
    prefs.setBool('dark', v);
    notifyListeners();
  }

  void setLang(String l) {
    lang = l;
    prefs.setString('lang', l);
    notifyListeners();
  }

  void setBiz(String id) {
    bizId = id;
    prefs.setString('biz_$dataUid', id);
    notifyListeners();
  }

  void setViewUid(String? id) {
    viewUid = id;
    bizId = id == null ? prefs.getString('biz_$uid') : prefs.getString('biz_$id');
    notifyListeners();
  }

  @override
  void dispose() {
    _authSub?.cancel();
    _profSub?.cancel();
    super.dispose();
  }
}
