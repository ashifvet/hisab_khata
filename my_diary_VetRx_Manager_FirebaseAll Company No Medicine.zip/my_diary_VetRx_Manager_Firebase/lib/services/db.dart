import 'package:cloud_firestore/cloud_firestore.dart';

/// Central place for all Firestore collection references.
class Db {
  static FirebaseFirestore get f => FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> c(String name) =>
      f.collection(name);

  // ---- shared (visible to every user) ----
  static CollectionReference<Map<String, dynamic>> get companies =>
      c('companies');
  static CollectionReference<Map<String, dynamic>> get medicines =>
      c('medicines');
  static CollectionReference<Map<String, dynamic>> get diseases =>
      c('diseases');
  static CollectionReference<Map<String, dynamic>> get problems =>
      c('problems');
  static CollectionReference<Map<String, dynamic>> get announcements =>
      c('announcements');
  static CollectionReference<Map<String, dynamic>> get config => c('config');

  // ---- users + private Hisab data ----
  static CollectionReference<Map<String, dynamic>> get users => c('users');

  static CollectionReference<Map<String, dynamic>> businesses(String uid) =>
      users.doc(uid).collection('businesses');

  static CollectionReference<Map<String, dynamic>> sub(
          String uid, String bid, String name) =>
      businesses(uid).doc(bid).collection(name);
}

/// One business (account book) of one user.
class Biz {
  const Biz(this.uid, this.id, {this.name = ''});
  final String uid;
  final String id;
  final String name;

  CollectionReference<Map<String, dynamic>> col(String n) =>
      Db.sub(uid, id, n);
}
