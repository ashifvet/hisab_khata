import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/utils.dart';
import 'package:my_diary/services/db.dart';

/// Wraps the home screen. After login it:
///  1) checks Firestore doc  config/app  for a new version (force update / optional update)
///  2) shows admin announcements (dialog boxes) as many times as the admin allowed
class StartupGate extends StatefulWidget {
  const StartupGate({super.key, required this.child});
  final Widget child;
  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  bool _started = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  int _cmp(String a, String b) {
    final x = a.split('.').map((e) => int.tryParse(e.trim()) ?? 0).toList();
    final y = b.split('.').map((e) => int.tryParse(e.trim()) ?? 0).toList();
    for (var i = 0; i < 4; i++) {
      final p = i < x.length ? x[i] : 0;
      final q = i < y.length ? y[i] : 0;
      if (p != q) return p.compareTo(q);
    }
    return 0;
  }

  Future<void> _run() async {
    if (_started) return;
    _started = true;
    await _checkVersion();
    if (!mounted) return;
    await _showAnnouncements();
  }

  Future<void> _checkVersion() async {
    try {
      final snap = await Db.config
          .doc('app')
          .get()
          .timeout(const Duration(seconds: 6));
      if (!snap.exists || !mounted) return;
      final d = snap.data() ?? {};
      final info = await PackageInfo.fromPlatform();
      final current = info.version;
      final latest = (d['latestVersion'] ?? '').toString();
      final minV = (d['minVersion'] ?? '').toString();
      final url = (d['updateUrl'] ?? '').toString();
      final msg = (d['message'] ?? 'A new version of My Diary is available.').toString();

      final force = minV.isNotEmpty && _cmp(current, minV) < 0;
      final optional = latest.isNotEmpty && _cmp(current, latest) < 0;
      if (!force && !optional) return;
      if (!mounted) return;

      await showDialog<void>(
        context: context,
        barrierDismissible: !force,
        builder: (c) => PopScope(
          canPop: !force,
          child: AlertDialog(
            title: Text(force ? 'Update required' : 'Update available'),
            content: Text('$msg\n\nYour version: $current\nLatest version: $latest'),
            actions: [
              if (!force)
                TextButton(
                    onPressed: () => Navigator.pop(c), child: const Text('Later')),
              FilledButton(
                onPressed: () => openUrl(url), // stays open when force update
                child: const Text('Update now'),
              ),
            ],
          ),
        ),
      );
    } catch (_) {
      // offline / no config yet -> ignore
    }
  }

  Future<void> _showAnnouncements() async {
    try {
      final app = context.read<AppState>();
      final snap = await Db.announcements
          .where('active', isEqualTo: true)
          .get()
          .timeout(const Duration(seconds: 6));
      final docs = List<Doc>.of(snap.docs)
        ..sort((a, b) =>
            dt(a.data()['createdAt']).compareTo(dt(b.data()['createdAt'])));

      for (final d in docs) {
        if (!mounted) return;
        final data = d.data();
        final times = (data['showTimes'] as num?)?.toInt() ?? 1;
        final rev = dt(data['updatedAt'] ?? data['createdAt']).millisecondsSinceEpoch;
        final key = 'ann_${d.id}_$rev';
        final seen = app.prefs.getInt(key) ?? 0;
        if (seen >= times) continue;
        await app.prefs.setInt(key, seen + 1);
        if (!mounted) return;
        await _announcementDialog(data);
      }
    } catch (_) {}
  }

  Future<void> _announcementDialog(Map<String, dynamic> d) {
    final tg = (d['telegramLink'] ?? '').toString();
    final web = (d['webLink'] ?? '').toString();
    final cancelAllowed = d['cancelAllowed'] == true;
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (c) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: Text((d['title'] ?? '').toString()),
          content: SingleChildScrollView(child: Text((d['content'] ?? '').toString())),
          actions: [
            if (tg.isNotEmpty)
              FilledButton.icon(
                icon: const Icon(Icons.send),
                label: const Text('Join Telegram'),
                onPressed: () {
                  openUrl(tg);
                  Navigator.pop(c);
                },
              ),
            if (web.isNotEmpty)
              FilledButton.tonalIcon(
                icon: const Icon(Icons.public),
                label: const Text('Visit Web'),
                onPressed: () {
                  openUrl(web);
                  Navigator.pop(c);
                },
              ),
            if (cancelAllowed || (tg.isEmpty && web.isEmpty))
              TextButton(
                  onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
