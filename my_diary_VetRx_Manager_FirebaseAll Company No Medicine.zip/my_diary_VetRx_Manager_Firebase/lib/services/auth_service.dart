import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:my_diary/services/db.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  static const String adminEmail = 'admin@mydiary.app';
  static const String adminDefaultPassword = 'Solution2@';

  /// "admin" -> admin@mydiary.app ; real e-mails are used as they are.
  static String toEmail(String input) {
    final s = input.trim().toLowerCase();
    return s.contains('@') ? s : '$s@mydiary.app';
  }

  static Future<void> login(String id, String password) async {
    final email = toEmail(id);
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
    } on FirebaseAuthException catch (e) {
      final canSeed = email == adminEmail &&
          password == adminDefaultPassword &&
          (e.code == 'user-not-found' ||
              e.code == 'invalid-credential' ||
              e.code == 'invalid-login-credentials' ||
              e.code == 'wrong-password');
      if (!canSeed) rethrow;
      // First ever start: create the default administrator account.
      try {
        final cred = await _auth.createUserWithEmailAndPassword(
            email: adminEmail, password: adminDefaultPassword);
        await Db.users.doc(cred.user!.uid).set({
          'firstName': 'Admin',
          'lastName': '',
          'email': adminEmail,
          'phone': '',
          'location': '',
          'role': 'admin',
          'createdAt': Timestamp.now(),
        }, SetOptions(merge: true));
      } on FirebaseAuthException catch (e2) {
        // account exists but password is different (it was changed) -> wrong password
        if (e2.code == 'email-already-in-use') throw e;
        rethrow;
      }
    }
  }

  static Future<void> register({
    required String firstName,
    required String lastName,
    required String email,
    required String phone,
    required String location,
    required String password,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim().toLowerCase(), password: password);
    await Db.users.doc(cred.user!.uid).set({
      'firstName': firstName.trim(),
      'lastName': lastName.trim(),
      'email': email.trim().toLowerCase(),
      'phone': phone.trim(),
      'location': location.trim(),
      'role': 'user',
      'createdAt': Timestamp.now(),
    }, SetOptions(merge: true));
  }

  static Future<void> changePassword(String current, String next) async {
    final u = _auth.currentUser!;
    final cred =
        EmailAuthProvider.credential(email: u.email!, password: current);
    await u.reauthenticateWithCredential(cred);
    await u.updatePassword(next);
  }

  static Future<void> logout() => _auth.signOut();

  /// Admin only: creates another account (optionally as admin) without
  /// logging the current admin out (uses a secondary Firebase app instance).
  static Future<void> createAccount({
    required String firstName,
    required String email,
    required String password,
    required bool admin,
  }) async {
    const name = 'secondary';
    FirebaseApp app;
    try {
      app = Firebase.app(name);
    } catch (_) {
      app = await Firebase.initializeApp(
          name: name, options: Firebase.app().options);
    }
    final secondAuth = FirebaseAuth.instanceFor(app: app);
    final cred = await secondAuth.createUserWithEmailAndPassword(
        email: toEmail(email), password: password);
    await secondAuth.signOut();
    await Db.users.doc(cred.user!.uid).set({
      'firstName': firstName.trim(),
      'lastName': '',
      'email': toEmail(email),
      'phone': '',
      'location': '',
      'role': admin ? 'admin' : 'user',
      'createdAt': Timestamp.now(),
    });
  }
}
