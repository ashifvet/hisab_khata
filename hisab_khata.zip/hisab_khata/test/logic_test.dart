import 'package:flutter_test/flutter_test.dart';
import 'package:hisab_khata/core/utils.dart';
import 'package:hisab_khata/models/models.dart';
import 'package:hisab_khata/services/message_service.dart';

void main() {
  test('compareVersions', () {
    expect(compareVersions('1.0.0', '1.0.1'), -1);
    expect(compareVersions('1.2.0', '1.1.9'), 1);
    expect(compareVersions('1.0', '1.0.0'), 0);
    expect(compareVersions('1.0.10', '1.0.9'), 1);
    expect(compareVersions('2.0.0+5', '2.0.0'), 0);
  });

  test('waNumber', () {
    expect(waNumber('01711989236'), '8801711989236');
    expect(waNumber('+880 1711-989236'), '8801711989236');
  });

  test('message text', () {
    final p = Party(
      id: '1', name: 'Karim', phone: '017', address: '', type: 'customer',
      balance: 1500, createdAt: DateTime.now());
    final biz = const Business(id: 'b', name: 'Shop', paymentInfo: 'bKash 017');
    final en = MessageService.build(p: p, biz: biz, lang: 'en');
    expect(en.contains('Karim'), true);
    expect(en.contains('1,500'), true);
    expect(en.contains('bKash 017'), true);
    expect(MessageService.build(p: p, biz: biz, lang: 'bn').contains('বাকি'), true);
  });

  test('money', () {
    expect(money(1234.5), '৳1,234.5');
  });
}
