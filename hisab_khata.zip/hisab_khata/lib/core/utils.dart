import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

/// Free Tally-Messages (SMS) every month.
const int kFreeSmsPerMonth = 25;

/// Maximum number of businesses one user can create.
const int kMaxBusinesses = 5;

final NumberFormat _numFmt = NumberFormat('#,##0.##');

String money(num v) => '৳${_numFmt.format(v)}';
String plainMoney(num v) => _numFmt.format(v);
String fmtDate(DateTime d) => DateFormat('dd MMM yyyy').format(d);
String fmtMonth(DateTime d) => DateFormat('MMMM yyyy').format(d);
String fmtMonthShort(DateTime d) => DateFormat('MMM yy').format(d);
String monthKey(DateTime d) => DateFormat('yyyy-MM').format(d);

double toDouble(dynamic v) {
  if (v is num) return v.toDouble();
  return double.tryParse('$v') ?? 0;
}

bool sameMonth(DateTime a, DateTime b) => a.year == b.year && a.month == b.month;

/// Compares two version names like "1.0.2" and "1.1.0".
/// Returns -1 if a < b, 0 if equal, 1 if a > b.
int compareVersions(String a, String b) {
  List<int> parse(String v) => v
      .split('+')
      .first
      .split('-')
      .first
      .split('.')
      .map((e) => int.tryParse(e.trim()) ?? 0)
      .toList();
  final x = parse(a);
  final y = parse(b);
  final n = x.length > y.length ? x.length : y.length;
  for (var i = 0; i < n; i++) {
    final p = i < x.length ? x[i] : 0;
    final q = i < y.length ? y[i] : 0;
    if (p != q) return p < q ? -1 : 1;
  }
  return 0;
}

/// Converts a Bangladeshi phone number to international format for WhatsApp.
String waNumber(String phone) {
  var d = phone.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('00')) d = d.substring(2);
  if (d.startsWith('0')) d = '88$d';
  return d;
}

String smsUrl(String phone, String body) {
  // Android uses "?body=" and iOS uses "&body=".
  final sep = defaultTargetPlatform == TargetPlatform.iOS ? '&' : '?';
  return 'sms:$phone${sep}body=${Uri.encodeComponent(body)}';
}

String waUrl(String phone, String text) =>
    'https://wa.me/${waNumber(phone)}?text=${Uri.encodeComponent(text)}';

Future<bool> openUrl(String url) async {
  try {
    return await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}

void toast(BuildContext context, String message) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(content: Text(message)));
}
