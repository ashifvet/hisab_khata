import 'package:flutter/material.dart';

/// Global navigator key. Used to show the update dialog from anywhere.
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
