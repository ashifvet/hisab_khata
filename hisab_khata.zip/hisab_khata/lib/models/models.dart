import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/utils.dart';

DateTime _dt(dynamic v) {
  if (v is Timestamp) return v.toDate();
  if (v is DateTime) return v;
  return DateTime.now();
}

class Business {
  final String id;
  final String name;
  final String phone;
  final String address;
  final String paymentInfo;

  const Business({
    required this.id,
    required this.name,
    this.phone = '',
    this.address = '',
    this.paymentInfo = '',
  });

  factory Business.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Business(
      id: d.id,
      name: (m['name'] ?? '').toString(),
      phone: (m['phone'] ?? '').toString(),
      address: (m['address'] ?? '').toString(),
      paymentInfo: (m['paymentInfo'] ?? '').toString(),
    );
  }

  bool sameAs(Business o) =>
      id == o.id &&
      name == o.name &&
      phone == o.phone &&
      address == o.address &&
      paymentInfo == o.paymentInfo;
}

class Party {
  final String id;
  final String name;
  final String phone;
  final String address;

  /// 'customer' or 'supplier'
  final String type;

  /// Positive  = you WILL GET this amount.
  /// Negative  = you WILL GIVE this amount.
  final double balance;
  final DateTime createdAt;

  const Party({
    required this.id,
    required this.name,
    required this.phone,
    required this.address,
    required this.type,
    required this.balance,
    required this.createdAt,
  });

  factory Party.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Party(
      id: d.id,
      name: (m['name'] ?? '').toString(),
      phone: (m['phone'] ?? '').toString(),
      address: (m['address'] ?? '').toString(),
      type: (m['type'] ?? 'customer').toString(),
      balance: toDouble(m['balance']),
      createdAt: _dt(m['createdAt']),
    );
  }
}

class TxnEntry {
  final String id;
  final String partyId;
  final String partyName;
  final String partyType;

  /// 'gave' = You gave (balance goes up), 'got' = You got (balance goes down)
  final String kind;
  final double amount;
  final String note;
  final DateTime date;

  const TxnEntry({
    required this.id,
    required this.partyId,
    required this.partyName,
    required this.partyType,
    required this.kind,
    required this.amount,
    required this.note,
    required this.date,
  });

  bool get isGave => kind == 'gave';

  factory TxnEntry.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return TxnEntry(
      id: d.id,
      partyId: (m['partyId'] ?? '').toString(),
      partyName: (m['partyName'] ?? '').toString(),
      partyType: (m['partyType'] ?? 'customer').toString(),
      kind: (m['kind'] ?? 'gave').toString(),
      amount: toDouble(m['amount']),
      note: (m['note'] ?? '').toString(),
      date: _dt(m['date']),
    );
  }
}

class Product {
  final String id;
  final String name;
  final String unit;
  final double qty;
  final double buyPrice;
  final double sellPrice;

  const Product({
    required this.id,
    required this.name,
    required this.unit,
    required this.qty,
    required this.buyPrice,
    required this.sellPrice,
  });

  double get stockValue => qty * buyPrice;
  double get retailValue => qty * sellPrice;

  factory Product.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Product(
      id: d.id,
      name: (m['name'] ?? '').toString(),
      unit: (m['unit'] ?? 'pcs').toString(),
      qty: toDouble(m['qty']),
      buyPrice: toDouble(m['buyPrice']),
      sellPrice: toDouble(m['sellPrice']),
    );
  }
}

class CashEntry {
  final String id;

  /// 'income' or 'expense'
  final String type;
  final double amount;
  final String category;
  final String note;
  final DateTime date;

  const CashEntry({
    required this.id,
    required this.type,
    required this.amount,
    required this.category,
    required this.note,
    required this.date,
  });

  bool get isIncome => type == 'income';

  factory CashEntry.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return CashEntry(
      id: d.id,
      type: (m['type'] ?? 'expense').toString(),
      amount: toDouble(m['amount']),
      category: (m['category'] ?? 'other').toString(),
      note: (m['note'] ?? '').toString(),
      date: _dt(m['date']),
    );
  }
}

class NoteItem {
  final String id;
  final String title;
  final String body;
  final DateTime updatedAt;

  const NoteItem({
    required this.id,
    required this.title,
    required this.body,
    required this.updatedAt,
  });

  factory NoteItem.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return NoteItem(
      id: d.id,
      title: (m['title'] ?? '').toString(),
      body: (m['body'] ?? '').toString(),
      updatedAt: _dt(m['updatedAt']),
    );
  }
}
