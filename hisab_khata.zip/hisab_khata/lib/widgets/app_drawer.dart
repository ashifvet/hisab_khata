import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../screens/about_screen.dart';
import '../screens/businesses_screen.dart';
import '../screens/group_tagada_screen.dart';
import '../screens/notes_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/settings_screen.dart';
import '../services/db.dart';
import 'common.dart';

class AppDrawer extends StatefulWidget {
  const AppDrawer({super.key});

  @override
  State<AppDrawer> createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  late final Stream<DocumentSnapshot<Json>> _profile = Db.profileStream();
  late final Future<PackageInfo> _info = PackageInfo.fromPlatform();

  void _go(Widget page) {
    Navigator.pop(context); // close the drawer
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page));
  }

  Future<void> _logout() async {
    final app = context.read<AppState>();
    final yes = await confirmDialog(context, app.t('logout'), app.t('logout_confirm'));
    if (!yes) return;
    await FirebaseAuth.instance.signOut();
    app.clearBusiness();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final scheme = Theme.of(context).colorScheme;
    final email = FirebaseAuth.instance.currentUser?.email ?? '';

    return Drawer(
      child: Column(
        children: [
          StreamBuilder<DocumentSnapshot<Json>>(
            stream: _profile,
            builder: (context, snap) {
              final m = snap.data?.data() ?? {};
              final name = '${m['firstName'] ?? ''} ${m['lastName'] ?? ''}'.trim();
              return UserAccountsDrawerHeader(
                decoration: BoxDecoration(color: scheme.primary),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: scheme.onPrimary,
                  child: Text(
                    (name.isNotEmpty ? name : (email.isNotEmpty ? email : 'H'))[0].toUpperCase(),
                    style: TextStyle(fontSize: 28, color: scheme.primary, fontWeight: FontWeight.bold),
                  ),
                ),
                accountName: Text(name.isNotEmpty ? name : 'Hisab Khata'),
                accountEmail: Text(email),
              );
            },
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                  leading: const Icon(Icons.storefront),
                  title: Text(t('my_businesses')),
                  onTap: () => _go(const BusinessesScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(t('edit_profile')),
                  onTap: () => _go(const ProfileScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.campaign),
                  title: Text(t('group_tagada')),
                  onTap: () => _go(const GroupTagadaScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.sticky_note_2),
                  title: Text(t('notes')),
                  onTap: () => _go(const NotesScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.settings),
                  title: Text(t('settings')),
                  onTap: () => _go(const SettingsScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.info),
                  title: Text(t('about_developer')),
                  onTap: () => _go(const AboutScreen()),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          FutureBuilder<PackageInfo>(
            future: _info,
            builder: (context, snap) => ListTile(
              dense: true,
              leading: const Icon(Icons.verified_outlined),
              title: Text('${t('version')} ${snap.data?.version ?? ''}'),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: Text(t('logout'), style: const TextStyle(color: Colors.red)),
            onTap: _logout,
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
