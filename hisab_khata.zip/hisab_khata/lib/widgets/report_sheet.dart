import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../providers/app_state.dart';

/// Bottom sheet: Share (WhatsApp, imo, Messenger...) or Print / Save as PDF.
Future<void> showReportSheet(
  BuildContext context, {
  required Future<Uint8List> Function() build,
  required String filename,
}) {
  final t = context.tr;
  return showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.share),
            title: Text(t('share_pdf')),
            subtitle: Text(t('share_pdf_hint')),
            onTap: () async {
              Navigator.of(ctx).pop();
              final bytes = await build();
              await Printing.sharePdf(bytes: bytes, filename: filename);
            },
          ),
          ListTile(
            leading: const Icon(Icons.print),
            title: Text(t('print_save')),
            subtitle: Text(t('print_save_hint')),
            onTap: () async {
              Navigator.of(ctx).pop();
              final bytes = await build();
              await Printing.layoutPdf(onLayout: (_) async => bytes, name: filename);
            },
          ),
        ],
      ),
    ),
  );
}
