import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/strings.dart';
import '../models/models.dart';

/// Keeps: dark mode, language and the currently selected business.
/// Everything is stored on the phone (SharedPreferences) so it also works offline.
class AppState extends ChangeNotifier {
  AppState(this._prefs)
      : dark = _prefs.getBool('dark') ?? false,
        lang = _prefs.getString('lang') ?? 'bn',
        businessId = _prefs.getString('businessId');

  final SharedPreferences _prefs;

  bool dark;
  String lang;
  String? businessId;
  Business? business;

  static Future<AppState> load() async {
    final prefs = await SharedPreferences.getInstance();
    return AppState(prefs);
  }

  /// Current business id (only used after the home screen has selected one).
  String get bid => businessId ?? '';

  /// Translate a key in the current language.
  String t(String key) => kStrings[lang]?[key] ?? kStrings['en']?[key] ?? key;

  void setDark(bool v) {
    dark = v;
    _prefs.setBool('dark', v);
    notifyListeners();
  }

  void setLang(String v) {
    lang = v;
    _prefs.setString('lang', v);
    notifyListeners();
  }

  void setBusiness(String id) {
    businessId = id;
    _prefs.setString('businessId', id);
    notifyListeners();
  }

  void setBusinessInfo(Business b) {
    if (business != null && business!.sameAs(b)) return;
    business = b;
    notifyListeners();
  }

  void clearBusiness() {
    businessId = null;
    business = null;
    _prefs.remove('businessId');
    notifyListeners();
  }
}

/// Shortcuts for translation.
///  - `context.tw('key')`  -> use inside build() (rebuilds when language changes)
///  - `context.tr('key')`  -> use inside button handlers / callbacks
extension TranslateX on BuildContext {
  String Function(String) get tw => watch<AppState>().t;
  String Function(String) get tr => read<AppState>().t;
}
