import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../services/message_service.dart';
import '../widgets/common.dart';

/// Group Tagada: send payment reminders to many customers in one go.
class GroupTagadaScreen extends StatefulWidget {
  const GroupTagadaScreen({super.key});

  @override
  State<GroupTagadaScreen> createState() => _GroupTagadaScreenState();
}

class _GroupTagadaScreenState extends State<GroupTagadaScreen> {
  late final String _bid = context.read<AppState>().bid;
  late final Stream<QuerySnapshot<Json>> _stream = Db.parties(_bid).snapshots();
  late final Stream<int> _usage = Db.smsUsedStream();
  final Set<String> _selected = {};
  String _channel = 'sms';

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    return Scaffold(
      appBar: AppBar(title: Text(t('group_tagada'))),
      body: StreamBuilder<QuerySnapshot<Json>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) return ErrorView(snap.error);
          if (!snap.hasData) return const LoadingView();
          final due = snap.data!.docs.map(Party.fromDoc).where((p) => p.type == 'customer' && p.balance > 0).toList()
            ..sort((a, b) => b.balance.compareTo(a.balance));
          final allSelected = due.isNotEmpty && due.every((p) => _selected.contains(p.id));
          final chosen = due.where((p) => _selected.contains(p.id)).toList();

          return Column(
            children: [
              StreamBuilder<int>(
                stream: _usage,
                builder: (context, u) {
                  final used = u.data ?? 0;
                  final left = (kFreeSmsPerMonth - used).clamp(0, kFreeSmsPerMonth);
                  return Container(
                    width: double.infinity,
                    margin: const EdgeInsets.all(12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.seed.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.mark_email_read),
                        const SizedBox(width: 10),
                        Expanded(child: Text('${t('free_tally_messages')}: $left / $kFreeSmsPerMonth')),
                      ],
                    ),
                  );
                },
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: SegmentedButton<String>(
                  segments: [
                    ButtonSegment(value: 'sms', icon: const Icon(Icons.sms), label: Text(t('sms'))),
                    ButtonSegment(value: 'wa', icon: const Icon(Icons.chat), label: Text(t('whatsapp'))),
                  ],
                  selected: {_channel},
                  onSelectionChanged: (s) => setState(() => _channel = s.first),
                ),
              ),
              if (due.isNotEmpty)
                CheckboxListTile(
                  value: allSelected,
                  title: Text(t('select_all')),
                  onChanged: (v) => setState(() {
                    if (v == true) {
                      _selected.addAll(due.map((p) => p.id));
                    } else {
                      _selected.clear();
                    }
                  }),
                ),
              Expanded(
                child: due.isEmpty
                    ? EmptyState(icon: Icons.celebration, text: t('no_dues'))
                    : ListView.builder(
                        itemCount: due.length,
                        itemBuilder: (context, i) {
                          final p = due[i];
                          return CheckboxListTile(
                            value: _selected.contains(p.id),
                            onChanged: (v) => setState(() {
                              if (v == true) {
                                _selected.add(p.id);
                              } else {
                                _selected.remove(p.id);
                              }
                            }),
                            title: Text(p.name),
                            subtitle: Text(p.phone.isEmpty ? t('no_phone') : p.phone),
                            secondary: Text(
                              money(p.balance),
                              style: const TextStyle(color: AppTheme.getColor, fontWeight: FontWeight.bold),
                            ),
                          );
                        },
                      ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                    onPressed: chosen.isEmpty
                        ? null
                        : () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(
                                builder: (_) => GroupSendScreen(parties: chosen, channel: _channel),
                              ),
                            ),
                    icon: const Icon(Icons.send),
                    label: Text('${t('send_to')} ${chosen.length}'),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Goes through the selected customers one by one.
/// Android/iOS do not allow apps to send many SMS silently, so for every
/// customer the SMS / WhatsApp app opens with the message already typed -
/// the user only has to press "Send" there and come back.
class GroupSendScreen extends StatefulWidget {
  const GroupSendScreen({super.key, required this.parties, required this.channel});
  final List<Party> parties;
  final String channel;

  @override
  State<GroupSendScreen> createState() => _GroupSendScreenState();
}

class _GroupSendScreenState extends State<GroupSendScreen> {
  int _index = 0;
  int _sent = 0;
  bool _busy = false;

  Future<void> _send(Party p, String body) async {
    if (_busy) return;
    setState(() => _busy = true);
    final bool ok = widget.channel == 'sms'
        ? await MessageService.sendSms(context, phone: p.phone, body: body)
        : await MessageService.sendWhatsApp(context, phone: p.phone, body: body);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) {
        _sent++;
        _index++;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final app = context.watch<AppState>();
    final total = widget.parties.length;
    final done = _index >= total;

    return Scaffold(
      appBar: AppBar(title: Text(t('group_tagada'))),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: done
            ? Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.check_circle, size: 80, color: AppTheme.getColor),
                    const SizedBox(height: 12),
                    Text('${t('messages_sent')}: $_sent / $total', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 20),
                    FilledButton(onPressed: () => Navigator.pop(context), child: Text(t('done'))),
                  ],
                ),
              )
            : Builder(builder: (context) {
                final p = widget.parties[_index];
                final body = MessageService.build(p: p, biz: app.business, lang: app.lang);
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    LinearProgressIndicator(value: _index / total, minHeight: 8),
                    const SizedBox(height: 8),
                    Text('${_index + 1} / $total'),
                    const SizedBox(height: 16),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(p.name, style: Theme.of(context).textTheme.titleLarge),
                            Text(p.phone.isEmpty ? t('no_phone') : p.phone),
                            const Divider(height: 24),
                            Text(body),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(t('group_hint'), style: Theme.of(context).textTheme.bodySmall),
                    const Spacer(),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _busy ? null : () => setState(() => _index++),
                            child: Text(t('skip')),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 2,
                          child: FilledButton.icon(
                            onPressed: _busy ? null : () => _send(p, body),
                            icon: const Icon(Icons.send),
                            label: Text(t('open_and_send')),
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              }),
      ),
    );
  }
}
