import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../widgets/common.dart';

/// Bottom sheet opened when the user taps the business name in the app bar.
void showBusinessSwitcher(BuildContext context, List<Business> list, Business current) {
  final app = context.read<AppState>();
  final t = app.t;
  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('${t('my_businesses')} (${list.length}/$kMaxBusinesses)',
                style: Theme.of(ctx).textTheme.titleMedium),
          ),
          for (final b in list)
            ListTile(
              leading: Icon(b.id == current.id ? Icons.radio_button_checked : Icons.radio_button_off),
              title: Text(b.name),
              subtitle: b.address.isEmpty ? null : Text(b.address),
              onTap: () {
                Navigator.pop(ctx);
                app.setBusiness(b.id);
              },
            ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.settings_applications),
            title: Text(t('manage_businesses')),
            onTap: () {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const BusinessesScreen()));
            },
          ),
        ],
      ),
    ),
  );
}

/// Add / edit a business.
Future<void> showBusinessForm(BuildContext context, {Business? edit, required int currentCount}) async {
  final t = context.tr;
  if (edit == null && currentCount >= kMaxBusinesses) {
    toast(context, t('max_businesses'));
    return;
  }
  final name = TextEditingController(text: edit?.name ?? '');
  final phone = TextEditingController(text: edit?.phone ?? '');
  final address = TextEditingController(text: edit?.address ?? '');
  final pay = TextEditingController(text: edit?.paymentInfo ?? '');
  final formKey = GlobalKey<FormState>();

  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(edit == null ? t('add_business') : t('edit_business')),
      content: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: name,
                decoration: InputDecoration(labelText: t('business_name')),
                validator: (v) => (v == null || v.trim().isEmpty) ? t('required') : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(labelText: t('phone')),
              ),
              const SizedBox(height: 10),
              TextFormField(controller: address, decoration: InputDecoration(labelText: t('address'))),
              const SizedBox(height: 10),
              TextFormField(
                controller: pay,
                decoration: InputDecoration(labelText: t('payment_info'), hintText: t('payment_info_hint')),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t('cancel'))),
        FilledButton(
          onPressed: () {
            if (formKey.currentState!.validate()) Navigator.pop(ctx, true);
          },
          child: Text(t('save')),
        ),
      ],
    ),
  );

  if (ok == true) {
    if (edit == null) {
      Db.createBusiness(
        name: name.text.trim(),
        phone: phone.text.trim(),
        address: address.text.trim(),
        paymentInfo: pay.text.trim(),
      );
      if (context.mounted) toast(context, t('business_created'));
    } else {
      Db.updateBusiness(edit.id, {
        'name': name.text.trim(),
        'phone': phone.text.trim(),
        'address': address.text.trim(),
        'paymentInfo': pay.text.trim(),
      });
    }
  }
  name.dispose();
  phone.dispose();
  address.dispose();
  pay.dispose();
}

class BusinessesScreen extends StatefulWidget {
  const BusinessesScreen({super.key});

  @override
  State<BusinessesScreen> createState() => _BusinessesScreenState();
}

class _BusinessesScreenState extends State<BusinessesScreen> {
  late final Stream<QuerySnapshot<Json>> _stream = Db.businessSnapshots();

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final app = context.watch<AppState>();
    return StreamBuilder<QuerySnapshot<Json>>(
      stream: _stream,
      builder: (context, snap) {
        final list = (snap.data?.docs.map(Business.fromDoc).toList() ?? <Business>[])
          ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        return Scaffold(
          appBar: AppBar(title: Text('${t('my_businesses')} (${list.length}/$kMaxBusinesses)')),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => showBusinessForm(context, currentCount: list.length),
            icon: const Icon(Icons.add_business),
            label: Text(t('add_business')),
          ),
          body: snap.hasError
              ? ErrorView(snap.error)
              : !snap.hasData
                  ? const LoadingView()
                  : ListView(
                      padding: const EdgeInsets.only(bottom: 90),
                      children: [
                        for (final b in list)
                          Card(
                            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            child: ListTile(
                              leading: CircleAvatar(
                                child: Icon(b.id == app.businessId ? Icons.check : Icons.store),
                              ),
                              title: Text(b.name),
                              subtitle: Text([b.phone, b.address].where((e) => e.isNotEmpty).join(' • ')),
                              onTap: () {
                                app.setBusiness(b.id);
                                Navigator.pop(context);
                              },
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) async {
                                  if (v == 'edit') {
                                    showBusinessForm(context, edit: b, currentCount: list.length);
                                  } else if (v == 'delete') {
                                    if (list.length <= 1) {
                                      toast(context, context.tr('cannot_delete_last'));
                                      return;
                                    }
                                    final yes = await confirmDialog(
                                      context,
                                      context.tr('delete_business'),
                                      context.tr('delete_business_msg'),
                                    );
                                    if (!yes) return;
                                    if (b.id == app.businessId) {
                                      final other = list.firstWhere((x) => x.id != b.id);
                                      app.setBusiness(other.id);
                                    }
                                    await Db.deleteBusiness(b.id);
                                  }
                                },
                                itemBuilder: (_) => [
                                  PopupMenuItem(value: 'edit', child: Text(t('edit'))),
                                  PopupMenuItem(value: 'delete', child: Text(t('delete'))),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
        );
      },
    );
  }
}
