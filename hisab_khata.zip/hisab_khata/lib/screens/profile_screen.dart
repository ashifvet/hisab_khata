import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../core/utils.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../widgets/common.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _location = TextEditingController();
  final _occupation = TextEditingController();
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    Map<String, dynamic> m = {};
    try {
      final s = await Db.profileStream().first.timeout(const Duration(seconds: 5));
      m = s.data() ?? {};
    } catch (_) {}
    _first.text = (m['firstName'] ?? '').toString();
    _last.text = (m['lastName'] ?? '').toString();
    _email.text = (m['email'] ?? FirebaseAuth.instance.currentUser?.email ?? '').toString();
    _phone.text = (m['phone'] ?? '').toString();
    _location.text = (m['location'] ?? '').toString();
    _occupation.text = (m['occupation'] ?? '').toString();
    if (mounted) setState(() => _ready = true);
  }

  @override
  void dispose() {
    _first.dispose();
    _last.dispose();
    _email.dispose();
    _phone.dispose();
    _location.dispose();
    _occupation.dispose();
    super.dispose();
  }

  void _save() {
    Db.saveProfile({
      'firstName': _first.text.trim(),
      'lastName': _last.text.trim(),
      'email': _email.text.trim(),
      'phone': _phone.text.trim(),
      'location': _location.text.trim(),
      'occupation': _occupation.text.trim(),
    });
    toast(context, context.tr('profile_saved'));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    return Scaffold(
      appBar: AppBar(title: Text(t('edit_profile'))),
      body: !_ready
          ? const LoadingView()
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  children: [
                    Expanded(child: TextField(controller: _first, decoration: InputDecoration(labelText: t('first_name')))),
                    const SizedBox(width: 10),
                    Expanded(child: TextField(controller: _last, decoration: InputDecoration(labelText: t('last_name')))),
                  ],
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(labelText: t('email'), prefixIcon: const Icon(Icons.email_outlined)),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(labelText: t('phone'), prefixIcon: const Icon(Icons.phone_outlined)),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _location,
                  decoration: InputDecoration(labelText: t('location'), prefixIcon: const Icon(Icons.location_on_outlined)),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _occupation,
                  decoration: InputDecoration(labelText: t('occupation'), prefixIcon: const Icon(Icons.work_outline)),
                ),
                const SizedBox(height: 24),
                FilledButton.icon(
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                  onPressed: _save,
                  icon: const Icon(Icons.save),
                  label: Text(t('save')),
                ),
              ],
            ),
    );
  }
}
