import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../widgets/app_drawer.dart';
import '../widgets/common.dart';
import 'businesses_screen.dart';
import 'cashbook_tab.dart';
import 'parties_tab.dart';
import 'reports_tab.dart';
import 'stock_tab.dart';

/// Loads the user's businesses, makes sure one is selected, then shows the app.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  late final Stream<QuerySnapshot<Json>> _stream = Db.businessSnapshots();
  bool _creating = false;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Json>>(
      stream: _stream,
      builder: (context, snap) {
        final app = context.watch<AppState>();
        if (snap.hasError) return Scaffold(body: ErrorView(snap.error));
        if (!snap.hasData) return const Scaffold(body: LoadingView());

        final docs = snap.data!.docs;
        if (docs.isEmpty) {
          // First login: create the first business automatically.
          if (!snap.data!.metadata.isFromCache && !_creating) {
            _creating = true;
            final name = app.t('my_business');
            WidgetsBinding.instance.addPostFrameCallback((_) {
              final id = Db.createBusiness(name: name);
              app.setBusiness(id);
            });
          }
          return const Scaffold(body: LoadingView());
        }

        final list = docs.map(Business.fromDoc).toList()
          ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        final current = list.firstWhere(
          (b) => b.id == app.businessId,
          orElse: () => list.first,
        );
        if (app.businessId != current.id) {
          WidgetsBinding.instance.addPostFrameCallback((_) => app.setBusiness(current.id));
          return const Scaffold(body: LoadingView());
        }
        WidgetsBinding.instance.addPostFrameCallback((_) => app.setBusinessInfo(current));
        return MainScaffold(key: ValueKey(current.id), businesses: list, current: current);
      },
    );
  }
}

class MainScaffold extends StatefulWidget {
  const MainScaffold({super.key, required this.businesses, required this.current});
  final List<Business> businesses;
  final Business current;

  @override
  State<MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends State<MainScaffold> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final tabs = <Widget>[
      const PartiesTab(type: 'customer'),
      const PartiesTab(type: 'supplier'),
      const StockTab(),
      const CashbookTab(),
      const ReportsTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: InkWell(
          onTap: () => showBusinessSwitcher(context, widget.businesses, widget.current),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(child: Text(widget.current.name, overflow: TextOverflow.ellipsis)),
                const Icon(Icons.arrow_drop_down),
              ],
            ),
          ),
        ),
      ),
      drawer: const AppDrawer(),
      body: tabs[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.people_outline), selectedIcon: const Icon(Icons.people), label: t('customers')),
          NavigationDestination(icon: const Icon(Icons.local_shipping_outlined), selectedIcon: const Icon(Icons.local_shipping), label: t('suppliers')),
          NavigationDestination(icon: const Icon(Icons.inventory_2_outlined), selectedIcon: const Icon(Icons.inventory_2), label: t('stock')),
          NavigationDestination(icon: const Icon(Icons.account_balance_wallet_outlined), selectedIcon: const Icon(Icons.account_balance_wallet), label: t('cash_book')),
          NavigationDestination(icon: const Icon(Icons.bar_chart_outlined), selectedIcon: const Icon(Icons.bar_chart), label: t('reports')),
        ],
      ),
    );
  }
}
