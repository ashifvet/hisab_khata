import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/nav.dart';
import '../core/utils.dart';
import '../providers/app_state.dart';
import '../services/version_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final t = app.t;
    return Scaffold(
      appBar: AppBar(title: Text(t('settings'))),
      body: ListView(
        children: [
          SwitchListTile(
            secondary: const Icon(Icons.dark_mode),
            title: Text(t('dark_mode')),
            value: app.dark,
            onChanged: app.setDark,
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Text(t('app_language'), style: Theme.of(context).textTheme.titleSmall),
          ),
          ListTile(
            leading: const Icon(Icons.language),
            title: const Text('বাংলা'),
            trailing: app.lang == 'bn' ? const Icon(Icons.check_circle, color: Colors.green) : null,
            onTap: () => app.setLang('bn'),
          ),
          ListTile(
            leading: const Icon(Icons.language),
            title: const Text('English'),
            trailing: app.lang == 'en' ? const Icon(Icons.check_circle, color: Colors.green) : null,
            onTap: () => app.setLang('en'),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.lock_reset),
            title: Text(t('change_password')),
            onTap: () => _changePassword(context),
          ),
          ListTile(
            leading: const Icon(Icons.system_update),
            title: Text(t('check_update')),
            onTap: () => VersionService.check(navigatorKey, app.t, app.lang, manual: true),
          ),
        ],
      ),
    );
  }

  Future<void> _changePassword(BuildContext context) async {
    final t = context.tr;
    final current = TextEditingController();
    final next = TextEditingController();
    final confirm = TextEditingController();
    final formKey = GlobalKey<FormState>();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t('change_password')),
        content: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: current,
                  obscureText: true,
                  decoration: InputDecoration(labelText: t('current_password')),
                  validator: (v) => (v == null || v.isEmpty) ? t('required') : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: next,
                  obscureText: true,
                  decoration: InputDecoration(labelText: t('new_password')),
                  validator: (v) => (v == null || v.length < 6) ? t('password_min') : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: confirm,
                  obscureText: true,
                  decoration: InputDecoration(labelText: t('confirm_password')),
                  validator: (v) => v != next.text ? t('password_mismatch') : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t('cancel'))),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) Navigator.pop(ctx, true);
            },
            child: Text(t('save')),
          ),
        ],
      ),
    );

    final oldPass = current.text;
    final newPass = next.text;
    current.dispose();
    next.dispose();
    confirm.dispose();
    if (ok != true) return;

    try {
      final user = FirebaseAuth.instance.currentUser!;
      final cred = EmailAuthProvider.credential(email: user.email ?? '', password: oldPass);
      await user.reauthenticateWithCredential(cred);
      await user.updatePassword(newPass);
      if (context.mounted) toast(context, t('password_changed'));
    } on FirebaseAuthException catch (e) {
      if (context.mounted) {
        toast(context, e.code == 'network-request-failed' ? t('need_internet_login') : (e.message ?? e.code));
      }
    }
  }
}
