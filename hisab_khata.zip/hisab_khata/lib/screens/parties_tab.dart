import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../widgets/common.dart';
import 'group_tagada_screen.dart';
import 'party_detail_screen.dart';

/// Add or edit a customer / supplier.
Future<void> showPartyForm(BuildContext context, {required String type, Party? edit}) async {
  final app = context.read<AppState>();
  final t = app.t;
  final name = TextEditingController(text: edit?.name ?? '');
  final phone = TextEditingController(text: edit?.phone ?? '');
  final address = TextEditingController(text: edit?.address ?? '');
  final formKey = GlobalKey<FormState>();
  final isCustomer = type == 'customer';

  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(edit != null
          ? t('edit')
          : (isCustomer ? t('add_customer') : t('add_supplier'))),
      content: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: name,
                autofocus: true,
                textCapitalization: TextCapitalization.words,
                decoration: InputDecoration(labelText: t('name')),
                validator: (v) => (v == null || v.trim().isEmpty) ? t('required') : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(labelText: t('phone')),
              ),
              const SizedBox(height: 10),
              TextFormField(controller: address, decoration: InputDecoration(labelText: t('address'))),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t('cancel'))),
        FilledButton(
          onPressed: () {
            if (formKey.currentState!.validate()) Navigator.pop(ctx, true);
          },
          child: Text(t('save')),
        ),
      ],
    ),
  );

  if (ok == true) {
    if (edit == null) {
      Db.addParty(
        app.bid,
        name: name.text.trim(),
        phone: phone.text.trim(),
        address: address.text.trim(),
        type: type,
      );
    } else {
      Db.updateParty(app.bid, edit.id, {
        'name': name.text.trim(),
        'phone': phone.text.trim(),
        'address': address.text.trim(),
      });
    }
  }
  name.dispose();
  phone.dispose();
  address.dispose();
}

class PartiesTab extends StatefulWidget {
  const PartiesTab({super.key, required this.type});

  /// 'customer' or 'supplier'
  final String type;

  @override
  State<PartiesTab> createState() => _PartiesTabState();
}

class _PartiesTabState extends State<PartiesTab> {
  late final Stream<QuerySnapshot<Json>> _stream = Db.parties(context.read<AppState>().bid).snapshots();
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final isCustomer = widget.type == 'customer';

    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showPartyForm(context, type: widget.type),
        icon: const Icon(Icons.person_add),
        label: Text(isCustomer ? t('add_customer') : t('add_supplier')),
      ),
      body: StreamBuilder<QuerySnapshot<Json>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) return ErrorView(snap.error);
          if (!snap.hasData) return const LoadingView();

          final all = snap.data!.docs.map(Party.fromDoc).where((p) => p.type == widget.type).toList()
            ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
          final get = all.where((p) => p.balance > 0).fold(0.0, (a, p) => a + p.balance);
          final give = all.where((p) => p.balance < 0).fold(0.0, (a, p) => a - p.balance);
          final q = _q.trim().toLowerCase();
          final shown = q.isEmpty
              ? all
              : all.where((p) => p.name.toLowerCase().contains(q) || p.phone.contains(q)).toList();

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
                child: Row(
                  children: [
                    AmountBox(label: t('you_will_get'), amount: get, color: AppTheme.getColor),
                    const SizedBox(width: 10),
                    AmountBox(label: t('you_will_give'), amount: give, color: AppTheme.giveColor),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: t('search'),
                          prefixIcon: const Icon(Icons.search),
                        ),
                        onChanged: (v) => setState(() => _q = v),
                      ),
                    ),
                    if (isCustomer) ...[
                      const SizedBox(width: 8),
                      FilledButton.tonalIcon(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute<void>(builder: (_) => const GroupTagadaScreen()),
                        ),
                        icon: const Icon(Icons.campaign),
                        label: Text(t('group_tagada')),
                      ),
                    ],
                  ],
                ),
              ),
              Expanded(
                child: shown.isEmpty
                    ? EmptyState(
                        icon: isCustomer ? Icons.people_outline : Icons.local_shipping_outlined,
                        text: isCustomer ? t('no_customers') : t('no_suppliers'),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.only(bottom: 90),
                        itemCount: shown.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final p = shown[i];
                          return ListTile(
                            leading: CircleAvatar(child: Text(p.name.isEmpty ? '?' : p.name[0].toUpperCase())),
                            title: Text(p.name),
                            subtitle: p.phone.isEmpty ? null : Text(p.phone),
                            trailing: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  money(p.balance.abs()),
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: balanceColor(p.balance),
                                  ),
                                ),
                                Text(balanceLabel(context, p.balance), style: Theme.of(context).textTheme.labelSmall),
                              ],
                            ),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(builder: (_) => PartyDetailScreen(partyId: p.id)),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
