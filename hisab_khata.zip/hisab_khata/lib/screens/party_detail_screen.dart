import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../services/message_service.dart';
import '../services/pdf_service.dart';
import '../widgets/common.dart';
import '../widgets/report_sheet.dart';
import 'parties_tab.dart';

class PartyDetailScreen extends StatefulWidget {
  const PartyDetailScreen({super.key, required this.partyId});
  final String partyId;

  @override
  State<PartyDetailScreen> createState() => _PartyDetailScreenState();
}

class _PartyDetailScreenState extends State<PartyDetailScreen> {
  late final String _bid = context.read<AppState>().bid;
  late final Stream<DocumentSnapshot<Json>> _partyStream = Db.parties(_bid).doc(widget.partyId).snapshots();
  late final Stream<QuerySnapshot<Json>> _txnStream =
      Db.txns(_bid).where('partyId', isEqualTo: widget.partyId).snapshots();

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final app = context.watch<AppState>();

    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: _partyStream,
      builder: (context, pSnap) {
        if (pSnap.hasError) return Scaffold(appBar: AppBar(), body: ErrorView(pSnap.error));
        if (!pSnap.hasData) return Scaffold(appBar: AppBar(), body: const LoadingView());
        if (!pSnap.data!.exists) {
          return Scaffold(appBar: AppBar(), body: EmptyState(icon: Icons.person_off, text: t('not_found')));
        }
        final party = Party.fromDoc(pSnap.data!);

        return StreamBuilder<QuerySnapshot<Json>>(
          stream: _txnStream,
          builder: (context, tSnap) {
            if (tSnap.hasError) return Scaffold(appBar: AppBar(), body: ErrorView(tSnap.error));
            if (!tSnap.hasData) return Scaffold(appBar: AppBar(), body: const LoadingView());
            final txns = tSnap.data!.docs.map(TxnEntry.fromDoc).toList()
              ..sort((a, b) => b.date.compareTo(a.date));

            return Scaffold(
              appBar: AppBar(
                title: Text(party.name),
                actions: [
                  IconButton(
                    tooltip: t('statement'),
                    icon: const Icon(Icons.picture_as_pdf),
                    onPressed: () => showReportSheet(
                      context,
                      filename: 'statement_${party.name}.pdf',
                      build: () => PdfService.partyStatement(
                        biz: app.business,
                        party: party,
                        txns: txns,
                        t: app.t,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: t('send_reminder'),
                    icon: const Icon(Icons.sms),
                    onPressed: () => _sendMessage(context, party),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'call') {
                        if (party.phone.isEmpty) {
                          toast(context, context.tr('no_phone'));
                        } else {
                          openUrl('tel:${party.phone}');
                        }
                      } else if (v == 'edit') {
                        showPartyForm(context, type: party.type, edit: party);
                      } else if (v == 'delete') {
                        final yes = await confirmDialog(context, context.tr('delete'), context.tr('delete_party_msg'));
                        if (!yes || !context.mounted) return;
                        Navigator.pop(context);
                        Db.deleteParty(_bid, party.id);
                      }
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 'call', child: Text(t('call'))),
                      PopupMenuItem(value: 'edit', child: Text(t('edit'))),
                      PopupMenuItem(value: 'delete', child: Text(t('delete'))),
                    ],
                  ),
                ],
              ),
              body: Column(
                children: [
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.all(12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: balanceColor(party.balance).withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      children: [
                        Text(balanceLabel(context, party.balance)),
                        const SizedBox(height: 4),
                        Text(
                          money(party.balance.abs()),
                          style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                            color: balanceColor(party.balance),
                          ),
                        ),
                        if (party.phone.isNotEmpty) Text(party.phone),
                      ],
                    ),
                  ),
                  Expanded(
                    child: txns.isEmpty
                        ? EmptyState(icon: Icons.receipt_long, text: t('no_transactions'))
                        : ListView.separated(
                            itemCount: txns.length,
                            separatorBuilder: (_, _) => const Divider(height: 1),
                            itemBuilder: (context, i) {
                              final x = txns[i];
                              final c = x.isGave ? AppTheme.giveColor : AppTheme.getColor;
                              return ListTile(
                                title: Text(x.note.isEmpty ? (x.isGave ? t('you_gave') : t('you_got')) : x.note),
                                subtitle: Text('${fmtDate(x.date)} • ${x.isGave ? t('you_gave') : t('you_got')}'),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      money(x.amount),
                                      style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 16),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete_outline),
                                      onPressed: () async {
                                        final yes = await confirmDialog(
                                          context,
                                          context.tr('delete'),
                                          context.tr('delete_txn_msg'),
                                        );
                                        if (yes) Db.deleteTxn(_bid, x);
                                      },
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
              bottomNavigationBar: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(
                        child: FilledButton(
                          style: FilledButton.styleFrom(backgroundColor: AppTheme.giveColor, minimumSize: const Size.fromHeight(48)),
                          onPressed: () => showTxnSheet(context, party: party, kind: 'gave'),
                          child: Text(t('you_gave')),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton(
                          style: FilledButton.styleFrom(backgroundColor: AppTheme.getColor, minimumSize: const Size.fromHeight(48)),
                          onPressed: () => showTxnSheet(context, party: party, kind: 'got'),
                          child: Text(t('you_got')),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _sendMessage(BuildContext context, Party party) {
    final app = context.read<AppState>();
    final body = MessageService.build(p: party, biz: app.business, lang: app.lang);
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(body),
            ),
            ListTile(
              leading: const Icon(Icons.sms),
              title: Text(app.t('send_sms')),
              subtitle: Text(app.t('counts_as_tally')),
              onTap: () {
                Navigator.pop(ctx);
                MessageService.sendSms(context, phone: party.phone, body: body);
              },
            ),
            ListTile(
              leading: const Icon(Icons.chat),
              title: Text(app.t('send_whatsapp')),
              onTap: () {
                Navigator.pop(ctx);
                MessageService.sendWhatsApp(context, phone: party.phone, body: body);
              },
            ),
          ],
        ),
      ),
    );
  }
}

/// Bottom sheet to add a "You gave" / "You got" entry.
Future<void> showTxnSheet(BuildContext context, {required Party party, required String kind}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: _TxnForm(party: party, kind: kind),
    ),
  );
}

class _TxnForm extends StatefulWidget {
  const _TxnForm({required this.party, required this.kind});
  final Party party;
  final String kind;

  @override
  State<_TxnForm> createState() => _TxnFormState();
}

class _TxnFormState extends State<_TxnForm> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  DateTime _date = DateTime.now();

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (d != null) setState(() => _date = d);
  }

  void _save() {
    final amount = double.tryParse(_amount.text.trim()) ?? 0;
    if (amount <= 0) {
      toast(context, context.tr('enter_amount'));
      return;
    }
    final bid = context.read<AppState>().bid;
    Db.addTxn(
      bid,
      party: widget.party,
      kind: widget.kind,
      amount: amount,
      note: _note.text.trim(),
      date: _date,
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final gave = widget.kind == 'gave';
    final color = gave ? AppTheme.giveColor : AppTheme.getColor;
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            '${gave ? t('you_gave') : t('you_got')} - ${widget.party.name}',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(color: color, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _amount,
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: t('amount'), prefixText: '৳ '),
          ),
          const SizedBox(height: 10),
          TextField(controller: _note, decoration: InputDecoration(labelText: t('note'))),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _pickDate,
            icon: const Icon(Icons.calendar_today),
            label: Text(fmtDate(_date)),
          ),
          const SizedBox(height: 14),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: color, minimumSize: const Size.fromHeight(48)),
            onPressed: _save,
            child: Text(t('save')),
          ),
        ],
      ),
    );
  }
}
