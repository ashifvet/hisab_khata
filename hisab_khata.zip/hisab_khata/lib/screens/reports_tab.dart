import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../services/pdf_service.dart';
import '../widgets/common.dart';
import '../widgets/report_sheet.dart';
import 'party_detail_screen.dart';

/// Reports: Monthly report, Cost & Savings, Due list.
/// (Reports for a single customer / supplier are inside the customer page.)
class ReportsTab extends StatefulWidget {
  const ReportsTab({super.key});

  @override
  State<ReportsTab> createState() => _ReportsTabState();
}

class _ReportsTabState extends State<ReportsTab> {
  late final String _bid = context.read<AppState>().bid;
  late final Stream<QuerySnapshot<Json>> _partyStream = Db.parties(_bid).snapshots();
  late final Stream<QuerySnapshot<Json>> _txnStream = Db.txns(_bid).snapshots();
  late final Stream<QuerySnapshot<Json>> _cashStream = Db.cash(_bid).snapshots();
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);

  void _shift(int d) => setState(() => _month = DateTime(_month.year, _month.month + d));

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          TabBar(
            tabs: [
              Tab(text: t('monthly_report')),
              Tab(text: t('cost_savings')),
              Tab(text: t('due_list')),
            ],
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Json>>(
              stream: _partyStream,
              builder: (context, pSnap) => StreamBuilder<QuerySnapshot<Json>>(
                stream: _txnStream,
                builder: (context, tSnap) => StreamBuilder<QuerySnapshot<Json>>(
                  stream: _cashStream,
                  builder: (context, cSnap) {
                    final err = pSnap.error ?? tSnap.error ?? cSnap.error;
                    if (err != null) return ErrorView(err);
                    if (!pSnap.hasData || !tSnap.hasData || !cSnap.hasData) return const LoadingView();
                    final parties = pSnap.data!.docs.map(Party.fromDoc).toList();
                    final txns = tSnap.data!.docs.map(TxnEntry.fromDoc).toList();
                    final cash = cSnap.data!.docs.map(CashEntry.fromDoc).toList();
                    return TabBarView(
                      children: [
                        _monthly(context, txns, cash),
                        _cost(context, cash, txns),
                        _due(context, parties),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _monthBar(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(onPressed: () => _shift(-1), icon: const Icon(Icons.chevron_left)),
          Text(fmtMonth(_month), style: Theme.of(context).textTheme.titleMedium),
          IconButton(onPressed: () => _shift(1), icon: const Icon(Icons.chevron_right)),
        ],
      );

  double _sum(Iterable<TxnEntry> l) => l.fold(0.0, (a, b) => a + b.amount);

  // ----------------------------------------------------------- Monthly report
  Widget _monthly(BuildContext context, List<TxnEntry> allTx, List<CashEntry> allCash) {
    final t = context.tw;
    final app = context.read<AppState>();
    final tx = allTx.where((x) => sameMonth(x.date, _month)).toList();
    final cash = allCash.where((x) => sameMonth(x.date, _month)).toList();
    final cust = tx.where((x) => x.partyType == 'customer');
    final supp = tx.where((x) => x.partyType == 'supplier');
    final income = cash.where((c) => c.isIncome).fold(0.0, (a, b) => a + b.amount);
    final expense = cash.where((c) => !c.isIncome).fold(0.0, (a, b) => a + b.amount);

    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        _monthBar(context),
        SectionTitle(t('customers')),
        KeyValueRow(t('you_gave'), money(_sum(cust.where((x) => x.isGave))), color: AppTheme.giveColor),
        KeyValueRow(t('you_got'), money(_sum(cust.where((x) => !x.isGave))), color: AppTheme.getColor),
        SectionTitle(t('suppliers')),
        KeyValueRow(t('you_gave'), money(_sum(supp.where((x) => x.isGave))), color: AppTheme.giveColor),
        KeyValueRow(t('you_got'), money(_sum(supp.where((x) => !x.isGave))), color: AppTheme.getColor),
        SectionTitle(t('cost_savings')),
        KeyValueRow(t('income'), money(income), color: AppTheme.getColor),
        KeyValueRow(t('expense'), money(expense), color: AppTheme.giveColor),
        const Divider(),
        KeyValueRow(t('savings'), money(income - expense), bold: true, color: income - expense >= 0 ? AppTheme.getColor : AppTheme.giveColor),
        const SizedBox(height: 4),
        KeyValueRow(t('transactions'), '${tx.length + cash.length}'),
        Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton.icon(
            icon: const Icon(Icons.picture_as_pdf),
            label: Text(t('download_report')),
            onPressed: () => showReportSheet(
              context,
              filename: 'monthly_report_${monthKey(_month)}.pdf',
              build: () => PdfService.monthlyReport(
                biz: app.business,
                month: _month,
                txns: tx,
                cash: cash,
                t: app.t,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // --------------------------------------------------------- Cost & savings
  Widget _cost(BuildContext context, List<CashEntry> allCash, List<TxnEntry> allTx) {
    final t = context.tw;
    final app = context.read<AppState>();
    final cash = allCash.where((x) => sameMonth(x.date, _month)).toList();
    final tx = allTx.where((x) => sameMonth(x.date, _month)).toList();
    final income = cash.where((c) => c.isIncome).fold(0.0, (a, b) => a + b.amount);
    final expense = cash.where((c) => !c.isIncome).fold(0.0, (a, b) => a + b.amount);
    final savings = income - expense;

    final byCat = <String, double>{};
    for (final c in cash.where((c) => !c.isIncome)) {
      byCat[c.category] = (byCat[c.category] ?? 0) + c.amount;
    }
    final cats = byCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    final months = [for (var i = 5; i >= 0; i--) DateTime(_month.year, _month.month - i)];

    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        _monthBar(context),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              AmountBox(label: t('income'), amount: income, color: AppTheme.getColor),
              const SizedBox(width: 8),
              AmountBox(label: t('expense'), amount: expense, color: AppTheme.giveColor),
              const SizedBox(width: 8),
              AmountBox(label: t('savings'), amount: savings, color: savings >= 0 ? AppTheme.seed : AppTheme.giveColor),
            ],
          ),
        ),
        if (income > 0)
          KeyValueRow(t('savings_rate'), '${(savings / income * 100).toStringAsFixed(1)}%'),
        SectionTitle(t('expense_by_category')),
        if (cats.isEmpty)
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text(t('no_entries'))),
        for (final e in cats)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [Text(t('cat_${e.key}')), Text(money(e.value))],
                ),
                const SizedBox(height: 3),
                LinearProgressIndicator(value: expense == 0 ? 0 : e.value / expense, minHeight: 6),
              ],
            ),
          ),
        SectionTitle(t('last_6_months')),
        for (final m in months)
          Builder(builder: (context) {
            final mc = allCash.where((x) => sameMonth(x.date, m));
            final inc = mc.where((c) => c.isIncome).fold(0.0, (a, b) => a + b.amount);
            final exp = mc.where((c) => !c.isIncome).fold(0.0, (a, b) => a + b.amount);
            final sv = inc - exp;
            return ListTile(
              dense: true,
              title: Text(fmtMonthShort(m)),
              subtitle: Text('${t('income')} ${money(inc)} • ${t('expense')} ${money(exp)}'),
              trailing: Text(
                money(sv),
                style: TextStyle(fontWeight: FontWeight.bold, color: sv >= 0 ? AppTheme.getColor : AppTheme.giveColor),
              ),
            );
          }),
        Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton.icon(
            icon: const Icon(Icons.picture_as_pdf),
            label: Text(t('download_report')),
            onPressed: () => showReportSheet(
              context,
              filename: 'cost_savings_${monthKey(_month)}.pdf',
              build: () => PdfService.monthlyReport(
                biz: app.business,
                month: _month,
                txns: tx,
                cash: cash,
                t: app.t,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // --------------------------------------------------------------- Due list
  Widget _due(BuildContext context, List<Party> parties) {
    final t = context.tw;
    final app = context.read<AppState>();
    List<Party> pick(String type) => parties.where((p) => p.type == type && p.balance != 0).toList()
      ..sort((a, b) => b.balance.compareTo(a.balance));
    final cust = pick('customer');
    final supp = pick('supplier');

    Widget block(String title, List<Party> l) {
      final get = l.where((p) => p.balance > 0).fold(0.0, (a, p) => a + p.balance);
      final give = l.where((p) => p.balance < 0).fold(0.0, (a, p) => a - p.balance);
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionTitle(title),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                AmountBox(label: t('you_will_get'), amount: get, color: AppTheme.getColor),
                const SizedBox(width: 8),
                AmountBox(label: t('you_will_give'), amount: give, color: AppTheme.giveColor),
              ],
            ),
          ),
          for (final p in l)
            ListTile(
              dense: true,
              title: Text(p.name),
              subtitle: p.phone.isEmpty ? null : Text(p.phone),
              trailing: Text(
                money(p.balance.abs()),
                style: TextStyle(fontWeight: FontWeight.bold, color: balanceColor(p.balance)),
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute<void>(builder: (_) => PartyDetailScreen(partyId: p.id)),
              ),
            ),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        block(t('customers'), cust),
        block(t('suppliers'), supp),
        Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton.icon(
            icon: const Icon(Icons.picture_as_pdf),
            label: Text(t('download_report')),
            onPressed: () => showReportSheet(
              context,
              filename: 'due_list.pdf',
              build: () => PdfService.dueList(biz: app.business, parties: parties, t: app.t),
            ),
          ),
        ),
      ],
    );
  }
}
