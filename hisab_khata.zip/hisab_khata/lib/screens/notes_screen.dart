import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../widgets/common.dart';

/// Business notes - replaces the paper notebook.
class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  late final String _bid = context.read<AppState>().bid;
  late final Stream<QuerySnapshot<Json>> _stream = Db.notes(_bid).snapshots();

  void _open([NoteItem? note]) {
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => NoteEditorScreen(note: note)));
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    return Scaffold(
      appBar: AppBar(title: Text(t('notes'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _open,
        icon: const Icon(Icons.edit_note),
        label: Text(t('add_note')),
      ),
      body: StreamBuilder<QuerySnapshot<Json>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) return ErrorView(snap.error);
          if (!snap.hasData) return const LoadingView();
          final list = snap.data!.docs.map(NoteItem.fromDoc).toList()
            ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
          if (list.isEmpty) return EmptyState(icon: Icons.sticky_note_2_outlined, text: t('no_notes'));
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final n = list[i];
              return Card(
                child: ListTile(
                  title: Text(n.title.isEmpty ? t('untitled') : n.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(
                    '${n.body}\n${fmtDate(n.updatedAt)}',
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  isThreeLine: true,
                  onTap: () => _open(n),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      final yes = await confirmDialog(context, context.tr('delete'), context.tr('delete_note_msg'));
                      if (yes) Db.deleteNote(_bid, n.id);
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class NoteEditorScreen extends StatefulWidget {
  const NoteEditorScreen({super.key, this.note});
  final NoteItem? note;

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late final TextEditingController _title = TextEditingController(text: widget.note?.title ?? '');
  late final TextEditingController _body = TextEditingController(text: widget.note?.body ?? '');

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  void _save() {
    if (_title.text.trim().isEmpty && _body.text.trim().isEmpty) {
      Navigator.pop(context);
      return;
    }
    Db.saveNote(
      context.read<AppState>().bid,
      id: widget.note?.id,
      title: _title.text.trim(),
      body: _body.text.trim(),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.note == null ? t('add_note') : t('edit')),
        actions: [IconButton(icon: const Icon(Icons.check), tooltip: t('save'), onPressed: _save)],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _title, decoration: InputDecoration(labelText: t('title'))),
            const SizedBox(height: 12),
            Expanded(
              child: TextField(
                controller: _body,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                decoration: InputDecoration(labelText: t('note'), alignLabelWithHint: true),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
