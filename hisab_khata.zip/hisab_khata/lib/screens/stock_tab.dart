import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../widgets/common.dart';

/// Stock & Inventory accounting.
class StockTab extends StatefulWidget {
  const StockTab({super.key});

  @override
  State<StockTab> createState() => _StockTabState();
}

class _StockTabState extends State<StockTab> {
  late final String _bid = context.read<AppState>().bid;
  late final Stream<QuerySnapshot<Json>> _stream = Db.products(_bid).snapshots();

  Future<void> _productForm({Product? edit}) async {
    final t = context.tr;
    final name = TextEditingController(text: edit?.name ?? '');
    final unit = TextEditingController(text: edit?.unit ?? 'pcs');
    final qty = TextEditingController(text: edit == null ? '' : plainMoney(edit.qty).replaceAll(',', ''));
    final buy = TextEditingController(text: edit == null ? '' : plainMoney(edit.buyPrice).replaceAll(',', ''));
    final sell = TextEditingController(text: edit == null ? '' : plainMoney(edit.sellPrice).replaceAll(',', ''));
    final formKey = GlobalKey<FormState>();
    const numKb = TextInputType.numberWithOptions(decimal: true);

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(edit == null ? t('add_product') : t('edit')),
        content: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: name,
                  decoration: InputDecoration(labelText: t('product_name')),
                  validator: (v) => (v == null || v.trim().isEmpty) ? t('required') : null,
                ),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: TextFormField(
                      controller: qty,
                      keyboardType: numKb,
                      decoration: InputDecoration(labelText: t('quantity')),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextFormField(controller: unit, decoration: InputDecoration(labelText: t('unit'))),
                  ),
                ]),
                const SizedBox(height: 10),
                TextFormField(
                  controller: buy,
                  keyboardType: numKb,
                  decoration: InputDecoration(labelText: t('buy_price'), prefixText: '৳ '),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: sell,
                  keyboardType: numKb,
                  decoration: InputDecoration(labelText: t('sell_price'), prefixText: '৳ '),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t('cancel'))),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) Navigator.pop(ctx, true);
            },
            child: Text(t('save')),
          ),
        ],
      ),
    );

    if (ok == true) {
      final q = double.tryParse(qty.text.trim()) ?? 0;
      final b = double.tryParse(buy.text.trim()) ?? 0;
      final s = double.tryParse(sell.text.trim()) ?? 0;
      final u = unit.text.trim().isEmpty ? 'pcs' : unit.text.trim();
      if (edit == null) {
        Db.addProduct(_bid, name: name.text.trim(), unit: u, qty: q, buyPrice: b, sellPrice: s);
      } else {
        Db.updateProduct(_bid, edit.id, {
          'name': name.text.trim(),
          'unit': u,
          'qty': q,
          'buyPrice': b,
          'sellPrice': s,
        });
      }
    }
    name.dispose();
    unit.dispose();
    qty.dispose();
    buy.dispose();
    sell.dispose();
  }

  Future<void> _adjust(Product p, bool stockIn) async {
    final t = context.tr;
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${stockIn ? t('stock_in') : t('stock_out')} - ${p.name}'),
        content: TextField(
          controller: c,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: '${t('quantity')} (${p.unit})'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(t('save'))),
        ],
      ),
    );
    final n = double.tryParse(c.text.trim()) ?? 0;
    c.dispose();
    if (ok == true && n > 0) {
      Db.adjustStock(_bid, p.id, stockIn ? n : -n);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _productForm(),
        icon: const Icon(Icons.add),
        label: Text(t('add_product')),
      ),
      body: StreamBuilder<QuerySnapshot<Json>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) return ErrorView(snap.error);
          if (!snap.hasData) return const LoadingView();
          final list = snap.data!.docs.map(Product.fromDoc).toList()
            ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
          final value = list.fold(0.0, (a, p) => a + p.stockValue);
          final retail = list.fold(0.0, (a, p) => a + p.retailValue);

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
                child: Row(
                  children: [
                    AmountBox(label: t('stock_value'), amount: value, color: AppTheme.seed),
                    const SizedBox(width: 10),
                    AmountBox(label: t('sale_value'), amount: retail, color: AppTheme.getColor),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('${t('total_items')}: ${list.length}'),
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? EmptyState(icon: Icons.inventory_2_outlined, text: t('no_products'))
                    : ListView.separated(
                        padding: const EdgeInsets.only(bottom: 90),
                        itemCount: list.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final p = list[i];
                          final low = p.qty <= 0;
                          return ListTile(
                            title: Text(p.name),
                            subtitle: Text(
                              '${plainMoney(p.qty)} ${p.unit} • ${t('buy_price')} ${money(p.buyPrice)} • ${t('sell_price')} ${money(p.sellPrice)}',
                            ),
                            leading: CircleAvatar(
                              backgroundColor: low ? AppTheme.giveColor : AppTheme.getColor,
                              foregroundColor: Colors.white,
                              child: Icon(low ? Icons.warning_amber : Icons.inventory_2),
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(money(p.stockValue), style: const TextStyle(fontWeight: FontWeight.bold)),
                                PopupMenuButton<String>(
                                  onSelected: (v) async {
                                    if (v == 'in') {
                                      _adjust(p, true);
                                    } else if (v == 'out') {
                                      _adjust(p, false);
                                    } else if (v == 'edit') {
                                      _productForm(edit: p);
                                    } else if (v == 'delete') {
                                      final yes = await confirmDialog(
                                        context,
                                        context.tr('delete'),
                                        context.tr('delete_product_msg'),
                                      );
                                      if (yes) Db.deleteProduct(_bid, p.id);
                                    }
                                  },
                                  itemBuilder: (_) => [
                                    PopupMenuItem(value: 'in', child: Text(t('stock_in'))),
                                    PopupMenuItem(value: 'out', child: Text(t('stock_out'))),
                                    PopupMenuItem(value: 'edit', child: Text(t('edit'))),
                                    PopupMenuItem(value: 'delete', child: Text(t('delete'))),
                                  ],
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
