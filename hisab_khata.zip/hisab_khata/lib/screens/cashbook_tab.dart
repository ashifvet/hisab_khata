import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/db.dart';
import '../widgets/common.dart';

const List<String> kExpenseCategories = ['purchase', 'rent', 'salary', 'transport', 'utility', 'food', 'other'];
const List<String> kIncomeCategories = ['sales', 'other'];

/// Cash book: daily income and expense (cost & savings).
class CashbookTab extends StatefulWidget {
  const CashbookTab({super.key});

  @override
  State<CashbookTab> createState() => _CashbookTabState();
}

class _CashbookTabState extends State<CashbookTab> {
  late final String _bid = context.read<AppState>().bid;
  late final Stream<QuerySnapshot<Json>> _stream = Db.cash(_bid).snapshots();
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);

  void _shift(int d) => setState(() => _month = DateTime(_month.year, _month.month + d));

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    return Scaffold(
      floatingActionButton: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.extended(
            heroTag: 'income',
            backgroundColor: AppTheme.getColor,
            foregroundColor: Colors.white,
            onPressed: () => showCashSheet(context, type: 'income'),
            icon: const Icon(Icons.add),
            label: Text(t('income')),
          ),
          const SizedBox(width: 10),
          FloatingActionButton.extended(
            heroTag: 'expense',
            backgroundColor: AppTheme.giveColor,
            foregroundColor: Colors.white,
            onPressed: () => showCashSheet(context, type: 'expense'),
            icon: const Icon(Icons.remove),
            label: Text(t('expense')),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Json>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) return ErrorView(snap.error);
          if (!snap.hasData) return const LoadingView();
          final all = snap.data!.docs.map(CashEntry.fromDoc).toList();
          final list = all.where((e) => sameMonth(e.date, _month)).toList()
            ..sort((a, b) => b.date.compareTo(a.date));
          final income = list.where((e) => e.isIncome).fold(0.0, (a, e) => a + e.amount);
          final expense = list.where((e) => !e.isIncome).fold(0.0, (a, e) => a + e.amount);
          final savings = income - expense;

          return Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(onPressed: () => _shift(-1), icon: const Icon(Icons.chevron_left)),
                  Text(fmtMonth(_month), style: Theme.of(context).textTheme.titleMedium),
                  IconButton(onPressed: () => _shift(1), icon: const Icon(Icons.chevron_right)),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  children: [
                    AmountBox(label: t('income'), amount: income, color: AppTheme.getColor),
                    const SizedBox(width: 8),
                    AmountBox(label: t('expense'), amount: expense, color: AppTheme.giveColor),
                    const SizedBox(width: 8),
                    AmountBox(
                      label: t('savings'),
                      amount: savings,
                      color: savings >= 0 ? AppTheme.seed : AppTheme.giveColor,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Expanded(
                child: list.isEmpty
                    ? EmptyState(icon: Icons.account_balance_wallet_outlined, text: t('no_entries'))
                    : ListView.separated(
                        padding: const EdgeInsets.only(bottom: 90),
                        itemCount: list.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final e = list[i];
                          final c = e.isIncome ? AppTheme.getColor : AppTheme.giveColor;
                          return ListTile(
                            leading: CircleAvatar(
                              backgroundColor: c.withValues(alpha: 0.15),
                              child: Icon(e.isIncome ? Icons.arrow_downward : Icons.arrow_upward, color: c),
                            ),
                            title: Text(t('cat_${e.category}')),
                            subtitle: Text('${fmtDate(e.date)}${e.note.isEmpty ? '' : ' • ${e.note}'}'),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(money(e.amount), style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 16)),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline),
                                  onPressed: () async {
                                    final yes = await confirmDialog(
                                      context,
                                      context.tr('delete'),
                                      context.tr('delete_entry_msg'),
                                    );
                                    if (yes) Db.deleteCash(_bid, e.id);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

Future<void> showCashSheet(BuildContext context, {required String type}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: _CashForm(type: type),
    ),
  );
}

class _CashForm extends StatefulWidget {
  const _CashForm({required this.type});
  final String type;

  @override
  State<_CashForm> createState() => _CashFormState();
}

class _CashFormState extends State<_CashForm> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  DateTime _date = DateTime.now();
  late String _category = widget.type == 'income' ? 'sales' : 'purchase';

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (d != null) setState(() => _date = d);
  }

  void _save() {
    final amount = double.tryParse(_amount.text.trim()) ?? 0;
    if (amount <= 0) {
      toast(context, context.tr('enter_amount'));
      return;
    }
    Db.addCash(
      context.read<AppState>().bid,
      type: widget.type,
      amount: amount,
      category: _category,
      note: _note.text.trim(),
      date: _date,
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final income = widget.type == 'income';
    final color = income ? AppTheme.getColor : AppTheme.giveColor;
    final cats = income ? kIncomeCategories : kExpenseCategories;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            income ? t('add_income') : t('add_expense'),
            style: Theme.of(context).textTheme.titleMedium?.copyWith(color: color, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _amount,
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: t('amount'), prefixText: '৳ '),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: [
              for (final c in cats)
                ChoiceChip(
                  label: Text(t('cat_$c')),
                  selected: _category == c,
                  onSelected: (_) => setState(() => _category = c),
                ),
            ],
          ),
          const SizedBox(height: 10),
          TextField(controller: _note, decoration: InputDecoration(labelText: t('note'))),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _pickDate,
            icon: const Icon(Icons.calendar_today),
            label: Text(fmtDate(_date)),
          ),
          const SizedBox(height: 14),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: color, minimumSize: const Size.fromHeight(48)),
            onPressed: _save,
            child: Text(t('save')),
          ),
        ],
      ),
    );
  }
}
