import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../core/utils.dart';
import '../providers/app_state.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Widget _row(IconData icon, String label, String value, {VoidCallback? onTap}) {
    return ListTile(
      leading: Icon(icon),
      title: Text(label, style: const TextStyle(fontSize: 12)),
      subtitle: Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tw;
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(t('about_developer'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 48,
              backgroundColor: scheme.primary,
              child: Icon(Icons.person, size: 56, color: scheme.onPrimary),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              'Dr. MD. ASHIF IQBAL',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
            ),
          ),
          const Center(child: Text('DVM, MSc, BCS')),
          const SizedBox(height: 16),
          Card(
            child: Column(
              children: [
                _row(Icons.badge, t('designation'), 'Veterinary Surgeon'),
                _row(Icons.local_hospital, t('workplace'), 'Maheshpur'),
                _row(Icons.phone, t('phone'), '01711989236', onTap: () => openUrl('tel:01711989236')),
                _row(Icons.home, t('hometown'), 'Kushtia'),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => openUrl('tel:01711989236'),
                  icon: const Icon(Icons.call),
                  label: Text(t('call')),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => openUrl('https://wa.me/8801711989236'),
                  icon: const Icon(Icons.chat),
                  label: const Text('WhatsApp'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Card(
            child: FutureBuilder<PackageInfo>(
              future: PackageInfo.fromPlatform(),
              builder: (context, snap) {
                final i = snap.data;
                return Column(
                  children: [
                    _row(Icons.menu_book, t('app_name'), 'Hisab Khata'),
                    _row(Icons.verified, t('version_name'), i == null ? '' : i.version),
                    _row(Icons.numbers, t('build_number'), i == null ? '' : i.buildNumber),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
