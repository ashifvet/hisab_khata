import 'package:flutter/material.dart';

import '../core/utils.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import 'db.dart';

/// Builds balance / reminder texts and sends them through the phone's
/// SMS app or WhatsApp. SMS messages ("Tally-Messages") are counted
/// against the free monthly quota (25 per month).
class MessageService {
  MessageService._();

  static String build({required Party p, required Business? biz, required String lang}) {
    final shop = (biz?.name ?? '').trim();
    final amt = money(p.balance.abs());
    final pay = (biz?.paymentInfo ?? '').trim();
    final bn = lang == 'bn';
    String text;
    if (p.balance > 0) {
      text = bn
          ? 'প্রিয় ${p.name}, $shop-এ আপনার বাকি $amt। অনুগ্রহ করে দ্রুত পরিশোধ করুন।'
          : 'Dear ${p.name}, your outstanding balance with $shop is $amt. Please pay at your earliest convenience.';
      if (pay.isNotEmpty) text += bn ? ' পেমেন্ট: $pay' : ' Payment: $pay';
    } else if (p.balance < 0) {
      text = bn
          ? 'প্রিয় ${p.name}, $shop থেকে আপনার পাওনা $amt।'
          : 'Dear ${p.name}, balance update from $shop: we owe you $amt.';
    } else {
      text = bn
          ? 'প্রিয় ${p.name}, $shop-এ আপনার কোনো বাকি নেই। ধন্যবাদ!'
          : 'Dear ${p.name}, you have no due balance with $shop. Thank you!';
    }
    return text;
  }

  static Future<int> remaining() async {
    final used = await Db.smsUsed();
    final r = kFreeSmsPerMonth - used;
    return r < 0 ? 0 : r;
  }

  /// Opens the SMS app with the message. Counts 1 Tally-Message.
  static Future<bool> sendSms(BuildContext context, {required String phone, required String body}) async {
    final t = context.tr;
    if (phone.trim().isEmpty) {
      toast(context, t('no_phone'));
      return false;
    }
    final rem = await remaining();
    if (!context.mounted) return false;
    if (rem <= 0) {
      toast(context, t('sms_limit_reached'));
      return false;
    }
    final ok = await openUrl(smsUrl(phone.trim(), body));
    if (ok) {
      Db.addSmsUsage(1);
    } else if (context.mounted) {
      toast(context, t('cannot_open'));
    }
    return ok;
  }

  /// Opens WhatsApp with the message (unlimited, not counted).
  static Future<bool> sendWhatsApp(BuildContext context, {required String phone, required String body}) async {
    final t = context.tr;
    if (phone.trim().isEmpty) {
      toast(context, t('no_phone'));
      return false;
    }
    final ok = await openUrl(waUrl(phone, body));
    if (!ok && context.mounted) toast(context, t('cannot_open'));
    return ok;
  }
}
