import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../core/utils.dart';

/// Force-update / update-notification checker.
///
/// Firestore document:   app_config / version
/// Fields:
///   latestVersion : "1.0.3"   (newest version you published)
///   minVersion    : "1.0.2"   (older than this => user MUST update, cannot use app)
///   forceUpdate   : false     (true => everybody below latestVersion must update)
///   updateUrl     : "https://play.google.com/store/apps/details?id=..."
///   messageEn     : "Bug fixes and new reports."   (optional)
///   messageBn     : "..."                          (optional)
class VersionService {
  VersionService._();

  static bool _showing = false;

  static Future<void> check(
    GlobalKey<NavigatorState> navKey,
    String Function(String) t,
    String lang, {
    bool manual = false,
  }) async {
    if (_showing) return;
    try {
      final info = await PackageInfo.fromPlatform();
      final snap = await FirebaseFirestore.instance
          .collection('app_config')
          .doc('version')
          .get()
          .timeout(const Duration(seconds: 8));

      final overlayContext = navKey.currentState?.overlay?.context;
      if (overlayContext == null) return;

      if (!snap.exists || snap.data() == null) {
        if (manual && overlayContext.mounted) toast(overlayContext, t('up_to_date'));
        return;
      }
      final d = snap.data()!;
      final latest = (d['latestVersion'] ?? '').toString().trim();
      final min = (d['minVersion'] ?? '').toString().trim();
      final url = (d['updateUrl'] ?? '').toString().trim();
      final forceAll = d['forceUpdate'] == true;
      final cur = info.version;

      final older = latest.isNotEmpty && compareVersions(cur, latest) < 0;
      final belowMin = min.isNotEmpty && compareVersions(cur, min) < 0;
      final force = belowMin || (forceAll && older);

      if (!older && !force) {
        if (manual && overlayContext.mounted) toast(overlayContext, t('up_to_date'));
        return;
      }

      final custom = (lang == 'bn' ? d['messageBn'] : d['messageEn'])?.toString() ?? '';
      final message = custom.isNotEmpty ? custom : t(force ? 'force_update_msg' : 'update_msg');
      final target = latest.isNotEmpty ? latest : min;

      if (!overlayContext.mounted) return;
      _showing = true;
      await showDialog<void>(
        context: overlayContext,
        barrierDismissible: !force,
        builder: (ctx) => PopScope(
          canPop: !force,
          child: AlertDialog(
            icon: const Icon(Icons.system_update, size: 40),
            title: Text(force ? t('update_required') : t('update_available')),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('${t('your_version')}: $cur'),
                Text('${t('new_version')}: $target'),
                const SizedBox(height: 12),
                Text(message, textAlign: TextAlign.center),
              ],
            ),
            actions: [
              if (!force)
                TextButton(onPressed: () => Navigator.pop(ctx), child: Text(t('later'))),
              FilledButton(
                onPressed: () async {
                  if (url.isNotEmpty) await openUrl(url);
                },
                child: Text(t('update_now')),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      debugPrint('Version check skipped: $e');
    } finally {
      _showing = false;
    }
  }
}
