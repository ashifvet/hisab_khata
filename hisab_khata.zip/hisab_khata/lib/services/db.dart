import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

import '../core/utils.dart';
import '../models/models.dart';

typedef Json = Map<String, dynamic>;

/// All Firestore reads/writes live in this one file.
///
/// IMPORTANT (offline support):
/// Firestore keeps a local copy of the data. When the phone is offline every
/// write is saved on the phone immediately and is uploaded automatically
/// when the internet comes back. Because of this we do NOT `await` write
/// operations (an awaited write would wait for the server and "hang" offline).
///
/// Data layout:
/// users/{uid}                              -> profile
/// users/{uid}/businesses/{bid}             -> business
/// users/{uid}/businesses/{bid}/parties     -> customers & suppliers (with balance)
/// users/{uid}/businesses/{bid}/txns        -> You gave / You got entries
/// users/{uid}/businesses/{bid}/products    -> stock items
/// users/{uid}/businesses/{bid}/cash        -> income / expense (cost & savings)
/// users/{uid}/businesses/{bid}/notes       -> business notes
/// users/{uid}/sms_usage/{yyyy-MM}          -> Tally-Message counter
class Db {
  Db._();

  static final FirebaseFirestore _fs = FirebaseFirestore.instance;

  static String get uid => FirebaseAuth.instance.currentUser!.uid;

  static void _fire(Future<void> f) {
    unawaited(f.catchError((Object e) {
      debugPrint('Firestore write error: $e');
    }));
  }

  static Timestamp _ts(DateTime d) => Timestamp.fromDate(d);

  // ---------------------------------------------------------------- refs
  static DocumentReference<Json> get userDoc => _fs.collection('users').doc(uid);
  static CollectionReference<Json> get businessCol => userDoc.collection('businesses');
  static DocumentReference<Json> biz(String b) => businessCol.doc(b);
  static CollectionReference<Json> parties(String b) => biz(b).collection('parties');
  static CollectionReference<Json> txns(String b) => biz(b).collection('txns');
  static CollectionReference<Json> products(String b) => biz(b).collection('products');
  static CollectionReference<Json> cash(String b) => biz(b).collection('cash');
  static CollectionReference<Json> notes(String b) => biz(b).collection('notes');
  static CollectionReference<Json> get smsUsage => userDoc.collection('sms_usage');

  // ------------------------------------------------------------- profile
  static Stream<DocumentSnapshot<Json>> profileStream() => userDoc.snapshots();

  static void saveProfile(Json data) {
    _fire(userDoc.set(data, SetOptions(merge: true)));
  }

  // ----------------------------------------------------------- businesses
  static Stream<QuerySnapshot<Json>> businessSnapshots() => businessCol.snapshots();

  static String createBusiness({
    required String name,
    String phone = '',
    String address = '',
    String paymentInfo = '',
  }) {
    final ref = businessCol.doc();
    _fire(ref.set({
      'name': name,
      'phone': phone,
      'address': address,
      'paymentInfo': paymentInfo,
      'createdAt': _ts(DateTime.now()),
    }));
    return ref.id;
  }

  static void updateBusiness(String id, Json data) {
    _fire(biz(id).update(data));
  }

  static Future<void> _deleteCollection(CollectionReference<Json> col) async {
    final snap = await col.get();
    var batch = _fs.batch();
    var count = 0;
    for (final d in snap.docs) {
      batch.delete(d.reference);
      count++;
      if (count == 400) {
        _fire(batch.commit());
        batch = _fs.batch();
        count = 0;
      }
    }
    if (count > 0) _fire(batch.commit());
  }

  static Future<void> deleteBusiness(String id) async {
    await _deleteCollection(parties(id));
    await _deleteCollection(txns(id));
    await _deleteCollection(products(id));
    await _deleteCollection(cash(id));
    await _deleteCollection(notes(id));
    _fire(biz(id).delete());
  }

  // -------------------------------------------------------------- parties
  static String addParty(
    String bid, {
    required String name,
    required String phone,
    required String address,
    required String type,
  }) {
    final ref = parties(bid).doc();
    _fire(ref.set({
      'name': name,
      'phone': phone,
      'address': address,
      'type': type,
      'balance': 0,
      'createdAt': _ts(DateTime.now()),
    }));
    return ref.id;
  }

  static void updateParty(String bid, String id, Json data) {
    _fire(parties(bid).doc(id).update(data));
  }

  static Future<void> deleteParty(String bid, String id) async {
    final snap = await txns(bid).where('partyId', isEqualTo: id).get();
    final batch = _fs.batch();
    for (final d in snap.docs) {
      batch.delete(d.reference);
    }
    batch.delete(parties(bid).doc(id));
    _fire(batch.commit());
  }

  // --------------------------------------------------------- transactions
  static void addTxn(
    String bid, {
    required Party party,
    required String kind,
    required double amount,
    required String note,
    required DateTime date,
  }) {
    final batch = _fs.batch();
    batch.set(txns(bid).doc(), {
      'partyId': party.id,
      'partyName': party.name,
      'partyType': party.type,
      'kind': kind,
      'amount': amount,
      'note': note,
      'date': _ts(date),
    });
    final delta = kind == 'gave' ? amount : -amount;
    batch.update(parties(bid).doc(party.id), {'balance': FieldValue.increment(delta)});
    _fire(batch.commit());
  }

  static void deleteTxn(String bid, TxnEntry t) {
    final batch = _fs.batch();
    batch.delete(txns(bid).doc(t.id));
    final delta = t.isGave ? -t.amount : t.amount;
    batch.update(parties(bid).doc(t.partyId), {'balance': FieldValue.increment(delta)});
    _fire(batch.commit());
  }

  // ------------------------------------------------------------- products
  static void addProduct(
    String bid, {
    required String name,
    required String unit,
    required double qty,
    required double buyPrice,
    required double sellPrice,
  }) {
    _fire(products(bid).doc().set({
      'name': name,
      'unit': unit,
      'qty': qty,
      'buyPrice': buyPrice,
      'sellPrice': sellPrice,
      'createdAt': _ts(DateTime.now()),
    }));
  }

  static void updateProduct(String bid, String id, Json data) {
    _fire(products(bid).doc(id).update(data));
  }

  static void adjustStock(String bid, String id, double delta) {
    _fire(products(bid).doc(id).update({'qty': FieldValue.increment(delta)}));
  }

  static void deleteProduct(String bid, String id) {
    _fire(products(bid).doc(id).delete());
  }

  // ----------------------------------------------------------------- cash
  static void addCash(
    String bid, {
    required String type,
    required double amount,
    required String category,
    required String note,
    required DateTime date,
  }) {
    _fire(cash(bid).doc().set({
      'type': type,
      'amount': amount,
      'category': category,
      'note': note,
      'date': _ts(date),
    }));
  }

  static void deleteCash(String bid, String id) {
    _fire(cash(bid).doc(id).delete());
  }

  // ---------------------------------------------------------------- notes
  static void saveNote(String bid, {String? id, required String title, required String body}) {
    final ref = id == null ? notes(bid).doc() : notes(bid).doc(id);
    _fire(ref.set({
      'title': title,
      'body': body,
      'updatedAt': _ts(DateTime.now()),
    }, SetOptions(merge: true)));
  }

  static void deleteNote(String bid, String id) {
    _fire(notes(bid).doc(id).delete());
  }

  // ------------------------------------------------------ Tally-Messages
  static Stream<int> smsUsedStream() {
    return smsUsage.doc(monthKey(DateTime.now())).snapshots().map((d) {
      final m = d.data();
      return m == null ? 0 : (toDouble(m['used'])).toInt();
    });
  }

  static Future<int> smsUsed() async {
    try {
      final d = await smsUsage.doc(monthKey(DateTime.now())).get();
      final m = d.data();
      return m == null ? 0 : (toDouble(m['used'])).toInt();
    } catch (_) {
      return 0;
    }
  }

  static void addSmsUsage(int n) {
    _fire(smsUsage.doc(monthKey(DateTime.now())).set({
      'used': FieldValue.increment(n),
    }, SetOptions(merge: true)));
  }
}
