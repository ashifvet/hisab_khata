
import 'package:flutter/foundation.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../core/utils.dart';
import '../models/models.dart';

/// Creates the PDF statements / reports.
/// The Bangla font is downloaded the first time (needs internet once) and
/// cached by the `printing` package. If it cannot be loaded, the default
/// font is used (English text still works).
class PdfService {
  PdfService._();

  static pw.ThemeData? _theme;
  static bool _bengali = false;

  static Future<pw.ThemeData> _loadTheme() async {
    if (_theme != null) return _theme!;
    try {
      final regular = await PdfGoogleFonts.notoSansBengaliRegular();
      final bold = await PdfGoogleFonts.notoSansBengaliBold();
      _theme = pw.ThemeData.withFont(base: regular, bold: bold);
      _bengali = true;
    } catch (e) {
      debugPrint('Bangla PDF font not available: $e');
      _theme = pw.ThemeData.base();
      _bengali = false;
    }
    return _theme!;
  }

  static String _cur(num v) => _bengali ? money(v) : 'Tk ${plainMoney(v)}';

  static pw.Widget _title(String bizName, String title, String sub) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(bizName, style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 4),
        pw.Text(title, style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold, color: PdfColors.teal800)),
        if (sub.isNotEmpty) pw.Text(sub, style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
        pw.Divider(),
      ],
    );
  }

  static pw.Widget _table(List<String> headers, List<List<String>> rows, {Set<int> rightAlign = const {}}) {
    final align = <int, pw.Alignment>{
      for (final i in rightAlign) i: pw.Alignment.centerRight,
    };
    return pw.TableHelper.fromTextArray(
      headers: headers,
      data: rows,
      headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10, color: PdfColors.white),
      headerDecoration: const pw.BoxDecoration(color: PdfColors.teal700),
      cellStyle: const pw.TextStyle(fontSize: 9),
      cellAlignments: align,
      cellPadding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3),
      border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
    );
  }

  static pw.Widget _kv(String k, String v, {bool bold = false}) {
    final style = pw.TextStyle(fontSize: 11, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal);
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [pw.Text(k, style: style), pw.Text(v, style: style)],
      ),
    );
  }

  // ------------------------------------------------ customer/supplier statement
  static Future<Uint8List> partyStatement({
    required Business? biz,
    required Party party,
    required List<TxnEntry> txns,
    required String Function(String) t,
  }) async {
    final theme = await _loadTheme();
    final sorted = [...txns]..sort((a, b) => a.date.compareTo(b.date));
    var running = 0.0;
    var totalGave = 0.0;
    var totalGot = 0.0;
    final rows = <List<String>>[];
    for (final x in sorted) {
      if (x.isGave) {
        running += x.amount;
        totalGave += x.amount;
      } else {
        running -= x.amount;
        totalGot += x.amount;
      }
      rows.add([
        fmtDate(x.date),
        x.note,
        x.isGave ? _cur(x.amount) : '',
        x.isGave ? '' : _cur(x.amount),
        _cur(running.abs()) + (running > 0 ? ' ${t('dr_get')}' : (running < 0 ? ' ${t('dr_give')}' : '')),
      ]);
    }
    final doc = pw.Document(theme: theme);
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      build: (ctx) => [
        _title(biz?.name ?? '', '${t('statement')}: ${party.name}',
            '${party.phone}   ${t('date')}: ${fmtDate(DateTime.now())}'),
        _table(
          [t('date'), t('note'), t('you_gave'), t('you_got'), t('balance')],
          rows,
          rightAlign: {2, 3, 4},
        ),
        pw.SizedBox(height: 12),
        _kv(t('you_gave'), _cur(totalGave)),
        _kv(t('you_got'), _cur(totalGot)),
        pw.Divider(),
        _kv(
          party.balance >= 0 ? t('you_will_get') : t('you_will_give'),
          _cur(party.balance.abs()),
          bold: true,
        ),
      ],
    ));
    return doc.save();
  }

  // ------------------------------------------------------------ monthly report
  static Future<Uint8List> monthlyReport({
    required Business? biz,
    required DateTime month,
    required List<TxnEntry> txns,
    required List<CashEntry> cash,
    required String Function(String) t,
  }) async {
    final theme = await _loadTheme();
    double sum(Iterable<TxnEntry> l) => l.fold(0.0, (a, b) => a + b.amount);
    final cust = txns.where((x) => x.partyType == 'customer');
    final supp = txns.where((x) => x.partyType == 'supplier');
    final income = cash.where((c) => c.isIncome).fold(0.0, (a, b) => a + b.amount);
    final expense = cash.where((c) => !c.isIncome).fold(0.0, (a, b) => a + b.amount);
    final sortedTx = [...txns]..sort((a, b) => a.date.compareTo(b.date));
    final sortedCash = [...cash]..sort((a, b) => a.date.compareTo(b.date));

    final doc = pw.Document(theme: theme);
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      build: (ctx) => [
        _title(biz?.name ?? '', '${t('monthly_report')} - ${fmtMonth(month)}', ''),
        pw.Text(t('customers'), style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        _kv(t('you_gave'), _cur(sum(cust.where((x) => x.isGave)))),
        _kv(t('you_got'), _cur(sum(cust.where((x) => !x.isGave)))),
        pw.SizedBox(height: 8),
        pw.Text(t('suppliers'), style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        _kv(t('you_gave'), _cur(sum(supp.where((x) => x.isGave)))),
        _kv(t('you_got'), _cur(sum(supp.where((x) => !x.isGave)))),
        pw.SizedBox(height: 8),
        pw.Text(t('cost_savings'), style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        _kv(t('income'), _cur(income)),
        _kv(t('expense'), _cur(expense)),
        pw.Divider(),
        _kv(t('savings'), _cur(income - expense), bold: true),
        pw.SizedBox(height: 14),
        if (sortedTx.isNotEmpty) ...[
          pw.Text(t('transactions'), style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          _table(
            [t('date'), t('name'), t('note'), t('you_gave'), t('you_got')],
            [
              for (final x in sortedTx)
                [
                  fmtDate(x.date),
                  x.partyName,
                  x.note,
                  x.isGave ? _cur(x.amount) : '',
                  x.isGave ? '' : _cur(x.amount),
                ]
            ],
            rightAlign: {3, 4},
          ),
          pw.SizedBox(height: 14),
        ],
        if (sortedCash.isNotEmpty) ...[
          pw.Text(t('cash_book'), style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          _table(
            [t('date'), t('category'), t('note'), t('income'), t('expense')],
            [
              for (final c in sortedCash)
                [
                  fmtDate(c.date),
                  t('cat_${c.category}'),
                  c.note,
                  c.isIncome ? _cur(c.amount) : '',
                  c.isIncome ? '' : _cur(c.amount),
                ]
            ],
            rightAlign: {3, 4},
          ),
        ],
      ],
    ));
    return doc.save();
  }

  // ------------------------------------------------------------------ due list
  static Future<Uint8List> dueList({
    required Business? biz,
    required List<Party> parties,
    required String Function(String) t,
  }) async {
    final theme = await _loadTheme();
    List<Party> pick(String type) =>
        parties.where((p) => p.type == type && p.balance != 0).toList()
          ..sort((a, b) => b.balance.compareTo(a.balance));
    final cust = pick('customer');
    final supp = pick('supplier');
    double get(List<Party> l) => l.where((p) => p.balance > 0).fold(0.0, (a, b) => a + b.balance);
    double give(List<Party> l) => l.where((p) => p.balance < 0).fold(0.0, (a, b) => a - b.balance);

    pw.Widget block(String title, List<Party> l) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(title, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 13)),
            pw.SizedBox(height: 4),
            _table(
              [t('name'), t('phone'), t('you_will_get'), t('you_will_give')],
              [
                for (final p in l)
                  [
                    p.name,
                    p.phone,
                    p.balance > 0 ? _cur(p.balance) : '',
                    p.balance < 0 ? _cur(-p.balance) : '',
                  ]
              ],
              rightAlign: {2, 3},
            ),
            pw.SizedBox(height: 4),
            _kv(t('you_will_get'), _cur(get(l))),
            _kv(t('you_will_give'), _cur(give(l))),
            pw.SizedBox(height: 14),
          ],
        );

    final doc = pw.Document(theme: theme);
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      build: (ctx) => [
        _title(biz?.name ?? '', t('due_list'), fmtDate(DateTime.now())),
        block(t('customers'), cust),
        block(t('suppliers'), supp),
      ],
    ));
    return doc.save();
  }
}
