package com.hisabkhata.hisab_khata

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
