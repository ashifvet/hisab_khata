// ignore_for_file: deprecated_member_use

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/app_state.dart';
import 'core/i18n.dart';
import 'firebase_options.dart';
import 'screens/auth_screen.dart';
import 'screens/home_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (DefaultFirebaseOptions.currentPlatform.apiKey == 'REPLACE_ME') {
    runApp(const _SetupNeeded());
    return;
  }

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    // Offline-first: everything is cached on the phone and synchronised to the
    // cloud automatically as soon as the internet is available.
    FirebaseFirestore.instance.settings = const Settings(
      persistenceEnabled: true,
      cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
    );
  } catch (e) {
    runApp(_SetupNeeded(error: e.toString()));
    return;
  }

  final app = AppState();
  await app.init();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppState>.value(value: app),
        ChangeNotifierProvider.value(value: app.shared),
      ],
      child: const MyDiaryApp(),
    ),
  );
}

class MyDiaryApp extends StatelessWidget {
  const MyDiaryApp({super.key});

  ThemeData _theme(Brightness b) => ThemeData(
    useMaterial3: true,
    colorSchemeSeed: const Color(0xFF00796B),
    brightness: b,
    appBarTheme: const AppBarTheme(centerTitle: false),
    inputDecorationTheme: const InputDecorationTheme(isDense: true),
  );

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return LangScope(
      lang: app.lang,
      child: MaterialApp(
        title: 'My Diary',
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: app.themeMode,
        home: !app.authReady
            ? const Scaffold(body: Center(child: CircularProgressIndicator()))
            : (app.user == null ? const AuthScreen() : const HomeShell()),
      ),
    );
  }
}

class _SetupNeeded extends StatelessWidget {
  const _SetupNeeded({this.error});
  final String? error;

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.cloud_off, size: 64),
              const SizedBox(height: 16),
              const Text(
                'My Diary',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              const Text(
                'Firebase is not configured yet.\n\nRun this command inside your project folder:\n\nflutterfire configure\n\nthen restart the app.',
                textAlign: TextAlign.center,
              ),
              if (error != null) ...[
                const SizedBox(height: 16),
                Text(
                  error!,
                  style: const TextStyle(color: Colors.red, fontSize: 12),
                ),
              ],
            ],
          ),
        ),
      ),
    ),
  );
}
