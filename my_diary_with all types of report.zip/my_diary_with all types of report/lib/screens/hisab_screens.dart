import 'dart:async';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/pdf_reports.dart';
import '../core/repo.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import 'stock_screens.dart';

final Color _green = Colors.green.shade700;
final Color _red = Colors.red.shade700;

// ===========================================================================
// Business switcher (app bar) + management
// ===========================================================================
class BusinessMenu extends StatelessWidget {
  const BusinessMenu({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final name = app.business?.name ?? '...';
    return PopupMenuButton<String>(
      tooltip: 'Business',
      onSelected: (v) {
        if (v == '_manage') {
          Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const ManageBusinessesScreen()));
        } else {
          app.setBusiness(v);
        }
      },
      itemBuilder: (c) => [
        for (final b in app.businesses)
          PopupMenuItem(
            value: b.id,
            child: Row(children: [
              Icon(b.id == app.bizId ? Icons.check_circle : Icons.circle_outlined, size: 18),
              const SizedBox(width: 10),
              Flexible(child: Text(b.name, overflow: TextOverflow.ellipsis)),
            ]),
          ),
        const PopupMenuDivider(),
        PopupMenuItem(value: '_manage', child: Text(c.t('Manage businesses'))),
      ],
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 160),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.store_outlined, size: 20),
            const SizedBox(width: 6),
            Flexible(child: Text(name, overflow: TextOverflow.ellipsis)),
            const Icon(Icons.arrow_drop_down),
          ]),
        ),
      ),
    );
  }
}

class ManageBusinessesScreen extends StatelessWidget {
  const ManageBusinessesScreen({super.key});

  Future<void> _edit(BuildContext context, AppState app, Business? b) async {
    final name = TextEditingController(text: b?.name ?? '');
    final phone = TextEditingController(text: b?.phone ?? '');
    final addr = TextEditingController(text: b?.address ?? '');
    final pay = TextEditingController(text: b?.payInfo ?? '');
    final form = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(b == null ? 'New business' : 'Edit business'),
        content: Form(
          key: form,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              AppField(controller: name, label: 'Name', required: true),
              if (b != null) ...[
                AppField(controller: phone, label: 'Phone', keyboard: TextInputType.phone),
                AppField(controller: addr, label: 'Location'),
                AppField(controller: pay, label: 'Payment info / link (sent in reminders)', maxLines: 2),
              ],
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(c.t('Cancel'))),
          FilledButton(
            onPressed: () {
              if (form.currentState!.validate()) Navigator.pop(c, true);
            },
            child: Text(c.t('Save')),
          ),
        ],
      ),
    );
    if (ok == true) {
      if (b == null) {
        final err = app.addBusiness(name.text);
        if (err != null && context.mounted) snack(context, err);
      } else {
        HisabRepo(app.ownerUid, b.id).updateBusiness({
          'name': name.text.trim(),
          'phone': phone.text.trim(),
          'address': addr.text.trim(),
          'payInfo': pay.text.trim(),
        });
      }
    }
    name.dispose();
    phone.dispose();
    addr.dispose();
    pay.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Manage businesses'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add_business),
        label: Text('Add (${app.businesses.length}/${AppState.maxBusinesses})'),
        onPressed: () {
          if (app.businesses.length >= AppState.maxBusinesses) {
            snack(context, 'You can manage up to ${AppState.maxBusinesses} businesses.');
          } else {
            _edit(context, app, null);
          }
        },
      ),
      body: ListView(children: [
        for (final b in app.businesses)
          ListTile(
            leading: Icon(b.id == app.bizId ? Icons.check_circle : Icons.store_outlined,
                color: b.id == app.bizId ? _green : null),
            title: Text(b.name),
            subtitle: Text('${context.t('Cash balance')}: ${money(b.cashBalance)}'),
            onTap: () {
              app.setBusiness(b.id);
              Navigator.pop(context);
            },
            trailing: IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _edit(context, app, b)),
          ),
      ]),
    );
  }
}

// ===========================================================================
// HISAB HOME
// ===========================================================================
class HisabHome extends StatefulWidget {
  const HisabHome({super.key, required this.repo});
  final HisabRepo repo;

  @override
  State<HisabHome> createState() => _HisabHomeState();
}

class _HisabHomeState extends State<HisabHome> {
  Business? _biz;
  List<Party> _parties = [];
  List<Product> _products = [];
  final _subs = <StreamSubscription<dynamic>>[];

  @override
  void initState() {
    super.initState();
    void err(Object e) => debugPrint('hisab: $e');
    _subs.add(widget.repo.business().listen((b) => setState(() => _biz = b), onError: err));
    _subs.add(widget.repo.parties().listen((l) => setState(() => _parties = l), onError: err));
    _subs.add(widget.repo.products().listen((l) => setState(() => _products = l), onError: err));
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }

  void _push(Widget w) => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => w));

  Widget _tile(IconData icon, String label, String sub, Color color, Widget page) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _push(page),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              CircleAvatar(
                  radius: 22, backgroundColor: color.withValues(alpha: 0.15), child: Icon(icon, color: color)),
              const SizedBox(height: 8),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              if (sub.isNotEmpty) Text(sub, style: const TextStyle(fontSize: 11)),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final r = widget.repo;
    final receivable = _parties.where((p) => p.balance > 0).fold<double>(0, (a, p) => a + p.balance);
    final payable = _parties.where((p) => p.balance < 0).fold<double>(0, (a, p) => a - p.balance);
    final stockValue = _products.fold<double>(0, (a, p) => a + p.value);
    final customers = _parties.where((p) => p.type == 'customer').length;
    final suppliers = _parties.where((p) => p.type == 'supplier').length;
    final b = _biz;

    return ListView(padding: const EdgeInsets.all(12), children: [
      if (app.viewingOther)
        Card(
          color: Colors.orange.shade100,
          child: ListTile(
            leading: const Icon(Icons.visibility, color: Colors.deepOrange),
            title: Text("Viewing ${app.viewName}'s data", style: const TextStyle(color: Colors.black87)),
            trailing: TextButton(onPressed: app.stopViewing, child: const Text('Back to mine')),
          ),
        ),
      Row(children: [
        Expanded(child: _SummaryCard(label: context.t("You'll get"), value: money(receivable), color: _green)),
        const SizedBox(width: 10),
        Expanded(child: _SummaryCard(label: context.t("You'll give"), value: money(payable), color: _red)),
      ]),
      const SizedBox(height: 10),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(context.t('Cash balance'), style: const TextStyle(fontSize: 13)),
            Text(money(b?.cashBalance ?? 0),
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: (b?.cashBalance ?? 0) >= 0 ? _green : _red)),
            const SizedBox(height: 6),
            Wrap(spacing: 14, children: [
              Text('${context.t('Income')}: ${money(b?.income ?? 0)}', style: TextStyle(color: _green, fontSize: 12)),
              Text('${context.t('Expense')}: ${money(b?.expense ?? 0)}', style: TextStyle(color: _red, fontSize: 12)),
              Text('${context.t('Savings')}: ${money(b?.saving ?? 0)}', style: const TextStyle(color: Colors.blue, fontSize: 12)),
            ]),
          ]),
        ),
      ),
      const SizedBox(height: 4),
      GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 0.82,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        children: [
          _tile(Icons.people_alt, context.t('Customers'), '$customers', Colors.teal, PartiesScreen(repo: r, type: 'customer')),
          _tile(Icons.local_shipping, context.t('Suppliers'), '$suppliers', Colors.indigo, PartiesScreen(repo: r, type: 'supplier')),
          _tile(Icons.menu_book, context.t('Cashbook'), '', Colors.green, CashbookScreen(repo: r)),
          _tile(Icons.inventory_2, context.t('Stock & Inventory'), money(stockValue), Colors.orange, StockScreen(repo: r)),
          _tile(Icons.sticky_note_2, context.t('Business Notes'), '', Colors.amber.shade800, NotesScreen(repo: r)),
          _tile(Icons.picture_as_pdf, context.t('Reports'), '', Colors.red, ReportsScreen(repo: r)),
          _tile(Icons.campaign, context.t('Group Reminders'), '', Colors.purple, RemindersScreen(repo: r)),
        ],
      ),
      const SizedBox(height: 12),
      Text(
        'Works offline. Everything you enter is saved on this phone and synchronised to the cloud automatically when the internet is available.',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.outline),
      ),
    ]);
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.label, required this.value, required this.color});
  final String label, value;
  final Color color;

  @override
  Widget build(BuildContext context) => Card(
        color: color.withValues(alpha: 0.12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color))),
          ]),
        ),
      );
}

// ===========================================================================
// CUSTOMERS / SUPPLIERS
// ===========================================================================
Future<void> showPartyDialog(BuildContext context, HisabRepo repo, String type, {Party? edit}) async {
  final name = TextEditingController(text: edit?.name ?? '');
  final phone = TextEditingController(text: edit?.phone ?? '');
  final addr = TextEditingController(text: edit?.address ?? '');
  final form = GlobalKey<FormState>();
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(edit == null
          ? (type == 'customer' ? 'Add customer' : 'Add supplier')
          : 'Edit ${type == 'customer' ? 'customer' : 'supplier'}'),
      content: Form(
        key: form,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            AppField(controller: name, label: 'Name', required: true),
            AppField(controller: phone, label: 'Phone number', keyboard: TextInputType.phone),
            AppField(controller: addr, label: 'Location'),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(c.t('Cancel'))),
        FilledButton(
          onPressed: () {
            if (form.currentState!.validate()) Navigator.pop(c, true);
          },
          child: Text(c.t('Save')),
        ),
      ],
    ),
  );
  if (ok == true) {
    repo.saveParty(
        id: edit?.id, name: name.text.trim(), type: type, phone: phone.text.trim(), address: addr.text.trim());
  }
  name.dispose();
  phone.dispose();
  addr.dispose();
}

class PartiesScreen extends StatefulWidget {
  const PartiesScreen({super.key, required this.repo, required this.type});
  final HisabRepo repo;
  final String type;

  @override
  State<PartiesScreen> createState() => _PartiesScreenState();
}

class _PartiesScreenState extends State<PartiesScreen> {
  final _q = TextEditingController();
  late final Stream<List<Party>> _stream = widget.repo.parties();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isCustomer = widget.type == 'customer';
    return Scaffold(
      appBar: AppBar(title: Text(context.t(isCustomer ? 'Customers' : 'Suppliers'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.person_add),
        label: Text(isCustomer ? 'Add customer' : 'Add supplier'),
        onPressed: () => showPartyDialog(context, widget.repo, widget.type),
      ),
      body: StreamBuilder<List<Party>>(
        stream: _stream,
        builder: (c, snap) {
          if (!snap.hasData) return const Loading();
          final all = snap.data!.where((p) => p.type == widget.type).toList();
          final q = _q.text.trim().toLowerCase();
          final list = all.where((p) => q.isEmpty || p.name.toLowerCase().contains(q) || p.phone.contains(q)).toList();
          final get = all.where((p) => p.balance > 0).fold<double>(0, (a, p) => a + p.balance);
          final give = all.where((p) => p.balance < 0).fold<double>(0, (a, p) => a - p.balance);
          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
              child: Row(children: [
                Expanded(child: _SummaryCard(label: c.t("You'll get"), value: money(get), color: _green)),
                const SizedBox(width: 10),
                Expanded(child: _SummaryCard(label: c.t("You'll give"), value: money(give), color: _red)),
              ]),
            ),
            SearchBox(controller: _q, onChanged: (_) => setState(() {})),
            Expanded(
              child: list.isEmpty
                  ? EmptyState(message: isCustomer ? 'No customers yet' : 'No suppliers yet')
                  : ListView.separated(
                      padding: const EdgeInsets.only(bottom: 90),
                      itemCount: list.length,
                      separatorBuilder: (_, _) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final p = list[i];
                        final bal = p.balance;
                        return ListTile(
                          leading: CircleAvatar(child: Text(p.name.isEmpty ? '?' : p.name.characters.first.toUpperCase())),
                          title: Text(p.name),
                          subtitle: Text(p.phone.isEmpty ? '—' : p.phone, style: const TextStyle(fontSize: 12)),
                          trailing: bal == 0
                              ? const Text('—')
                              : Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                                  Text(money(bal.abs()), style: TextStyle(fontWeight: FontWeight.bold, color: bal > 0 ? _green : _red)),
                                  Text(c.t(bal > 0 ? "You'll get" : "You'll give"), style: TextStyle(fontSize: 11, color: bal > 0 ? _green : _red)),
                                ]),
                          onTap: () => Navigator.push(
                              c,
                              MaterialPageRoute<void>(
                                  builder: (_) => PartyDetailScreen(repo: widget.repo, partyId: p.id))),
                        );
                      },
                    ),
            ),
          ]);
        },
      ),
    );
  }
}

String buildReminder(Business? b, Party p) {
  final biz = (b?.name.isNotEmpty ?? false) ? b!.name : 'My Business';
  final amt = money(p.balance.abs(), sym: 'Tk');
  final pay = (b?.payInfo.isNotEmpty ?? false) ? '\nPayment: ${b!.payInfo}' : '';
  if (p.balance > 0) {
    return 'Dear ${p.name}, your outstanding balance with $biz is $amt. Please pay at your earliest convenience.$pay\nThank you.';
  }
  if (p.balance < 0) {
    return 'Dear ${p.name}, our balance update from $biz: we owe you $amt.\nThank you.';
  }
  return 'Dear ${p.name}, your account with $biz is settled (balance Tk 0). Thank you.';
}

class PartyDetailScreen extends StatefulWidget {
  const PartyDetailScreen({super.key, required this.repo, required this.partyId});
  final HisabRepo repo;
  final String partyId;

  @override
  State<PartyDetailScreen> createState() => _PartyDetailScreenState();
}

class _PartyDetailScreenState extends State<PartyDetailScreen> {
  late final Stream<Party?> _party = widget.repo.party(widget.partyId);
  late final Stream<List<Entry>> _entries = widget.repo.entries(widget.partyId);

  Future<void> _entrySheet(Party p, String kind) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (c) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
        child: _EntrySheet(repo: widget.repo, party: p, kind: kind),
      ),
    );
  }

  Future<void> _remind(Party p) async {
    final biz = context.read<AppState>().business;
    final msg = TextEditingController(text: buildReminder(biz, p));
    final phone = p.phone;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (c) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(c).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(c.t('Send reminder'), style: Theme.of(c).textTheme.titleMedium),
          const SizedBox(height: 10),
          TextField(controller: msg, maxLines: 5, decoration: const InputDecoration(border: OutlineInputBorder())),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                icon: const Icon(Icons.sms),
                label: const Text('SMS'),
                onPressed: phone.isEmpty ? null : () => sendSms(phone, msg.text),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.icon(
                icon: const Icon(Icons.chat),
                label: const Text('WhatsApp'),
                onPressed: phone.isEmpty ? null : () => sendWhatsApp(phone, msg.text),
              ),
            ),
          ]),
          if (phone.isEmpty) const Padding(padding: EdgeInsets.only(top: 8), child: Text('No phone number saved for this party.')),
        ]),
      ),
    );
    msg.dispose();
  }

  Future<void> _statement(Party p) async {
    try {
      final biz = context.read<AppState>().business;
      final entries = await widget.repo.entriesOnce(p.id);
      final bytes = await ReportBuilder.partyStatement(biz: biz, party: p, entries: entries);
      await Printing.sharePdf(bytes: bytes, filename: 'statement_${slug(p.name)}.pdf');
    } catch (e) {
      if (mounted) snack(context, 'Could not create the report: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Party?>(
      stream: _party,
      builder: (c, ps) {
        final p = ps.data;
        if (ps.connectionState == ConnectionState.waiting && p == null) {
          return Scaffold(appBar: AppBar(), body: const Loading());
        }
        if (p == null) return Scaffold(appBar: AppBar(), body: const EmptyState(message: 'Not found'));
        final isCustomer = p.type == 'customer';
        final bal = p.balance;
        return Scaffold(
          appBar: AppBar(
            title: Text(p.name),
            actions: [
              if (p.phone.isNotEmpty) IconButton(icon: const Icon(Icons.call), onPressed: () => callNumber(p.phone)),
              PopupMenuButton<String>(
                onSelected: (v) async {
                  if (v == 'pdf') {
                    _statement(p);
                  } else if (v == 'remind') {
                    _remind(p);
                  } else if (v == 'edit') {
                    showPartyDialog(context, widget.repo, p.type, edit: p);
                  } else if (v == 'delete') {
                    final nav = Navigator.of(context);
                    final ok = await confirmDialog(context, 'Delete ${p.name}?', 'All entries of this ${p.type} will be deleted.');
                    if (ok) {
                      widget.repo.deleteParty(p);
                      nav.pop();
                    }
                  }
                },
                itemBuilder: (c) => [
                  PopupMenuItem(value: 'pdf', child: Text(c.t('Share PDF'))),
                  PopupMenuItem(value: 'remind', child: Text(c.t('Send reminder'))),
                  PopupMenuItem(value: 'edit', child: Text(c.t('Edit'))),
                  PopupMenuItem(value: 'delete', child: Text(c.t('Delete'))),
                ],
              ),
            ],
          ),
          body: Column(children: [
            Card(
              margin: const EdgeInsets.all(12),
              color: (bal == 0 ? Colors.grey : (bal > 0 ? _green : _red)).withValues(alpha: 0.12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(bal == 0 ? 'Settled' : c.t(bal > 0 ? "You'll get" : "You'll give"),
                          style: TextStyle(fontWeight: FontWeight.w600, color: bal > 0 ? _green : (bal < 0 ? _red : null))),
                      Text(money(bal.abs()),
                          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: bal > 0 ? _green : (bal < 0 ? _red : null))),
                    ]),
                  ),
                  if (p.phone.isNotEmpty || p.address.isNotEmpty)
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      if (p.phone.isNotEmpty) Text(p.phone),
                      if (p.address.isNotEmpty) Text(p.address, style: const TextStyle(fontSize: 12)),
                    ]),
                ]),
              ),
            ),
            Expanded(
              child: StreamBuilder<List<Entry>>(
                stream: _entries,
                builder: (c, es) {
                  if (!es.hasData) return const Loading();
                  final list = es.data!;
                  if (list.isEmpty) return const EmptyState(message: 'No entries yet', icon: Icons.receipt_long);
                  return ListView.separated(
                    itemCount: list.length,
                    separatorBuilder: (_, _) => const Divider(height: 1),
                    itemBuilder: (c, i) {
                      final e = list[i];
                      final gave = e.kind == 'gave';
                      return ListTile(
                        title: Text(c.t(gave ? 'You gave' : 'You got')),
                        subtitle: Text('${fmtDate(e.date)}${e.note.isEmpty ? '' : '  •  ${e.note}'}${e.cash ? '  •  Cashbook' : ''}'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(money(e.amount), style: TextStyle(fontWeight: FontWeight.bold, color: gave ? _red : _green)),
                          IconButton(
                            icon: const Icon(Icons.delete_outline, size: 20),
                            onPressed: () async {
                              if (await confirmDialog(c, 'Delete entry?', '${money(e.amount)} on ${fmtDate(e.date)}')) {
                                widget.repo.deleteEntry(e);
                              }
                            },
                          ),
                        ]),
                      );
                    },
                  );
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  Expanded(
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: _red, padding: const EdgeInsets.symmetric(vertical: 14)),
                      onPressed: () => _entrySheet(p, 'gave'),
                      child: Text(isCustomer ? '${c.t('You gave')} (credit)' : '${c.t('You gave')} (payment)'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: _green, padding: const EdgeInsets.symmetric(vertical: 14)),
                      onPressed: () => _entrySheet(p, 'got'),
                      child: Text(isCustomer ? '${c.t('You got')} (payment)' : '${c.t('You got')} (credit)'),
                    ),
                  ),
                ]),
              ),
            ),
          ]),
        );
      },
    );
  }
}

class _EntrySheet extends StatefulWidget {
  const _EntrySheet({required this.repo, required this.party, required this.kind});
  final HisabRepo repo;
  final Party party;
  final String kind;

  @override
  State<_EntrySheet> createState() => _EntrySheetState();
}

class _EntrySheetState extends State<_EntrySheet> {
  final _form = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _note = TextEditingController();
  DateTime _date = DateTime.now();
  bool _cash = true;

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cashType = HisabRepo.cashTypeFor(widget.party.type, widget.kind);
    final gave = widget.kind == 'gave';
    return Form(
      key: _form,
      child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(16), children: [
        Text('${context.t(gave ? 'You gave' : 'You got')} • ${widget.party.name}',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(color: gave ? _red : _green)),
        const SizedBox(height: 12),
        AppField(
          controller: _amount,
          label: 'Amount',
          prefixText: '৳ ',
          keyboard: const TextInputType.numberWithOptions(decimal: true),
          validator: (s) => parseAmount(s ?? '') <= 0 ? 'Enter an amount' : null,
        ),
        AppField(controller: _note, label: 'Note'),
        DateField(value: _date, onChanged: (d) => setState(() => _date = d)),
        if (cashType != null)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Also record in Cashbook as $cashType'),
            value: _cash,
            onChanged: (v) => setState(() => _cash = v),
          ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: gave ? _red : _green),
          onPressed: () {
            if (!_form.currentState!.validate()) return;
            widget.repo.addEntry(widget.party, widget.kind, parseAmount(_amount.text), _note.text.trim(), _date,
                cash: _cash);
            Navigator.pop(context);
          },
          child: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(context.t('Save'))),
        ),
      ]),
    );
  }
}

// ===========================================================================
// CASHBOOK
// ===========================================================================
const _incomeCats = ['Consultation fee', 'Sale', 'Medicine sale', 'Other income'];
const _expenseCats = ['Medicine purchase', 'Transport', 'Rent', 'Salary', 'Utilities', 'Food', 'Other expense'];
const _savingCats = ['Savings deposit', 'Bank', 'DPS', 'Other savings'];

class CashbookScreen extends StatefulWidget {
  const CashbookScreen({super.key, required this.repo});
  final HisabRepo repo;

  @override
  State<CashbookScreen> createState() => _CashbookScreenState();
}

class _CashbookScreenState extends State<CashbookScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  late Stream<List<CashEntry>> _stream = _make();

  Stream<List<CashEntry>> _make() =>
      widget.repo.cash(_month, DateTime(_month.year, _month.month + 1));

  void _shift(int d) => setState(() {
        _month = DateTime(_month.year, _month.month + d);
        _stream = _make();
      });

  Future<void> _sheet(String type, {CashEntry? edit}) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (c) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
        child: _CashSheet(repo: widget.repo, type: type, edit: edit),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Cashbook'))),
      body: StreamBuilder<List<CashEntry>>(
        stream: _stream,
        builder: (c, snap) {
          if (!snap.hasData) return const Loading();
          final list = snap.data!;
          double inc = 0, exp = 0, sav = 0;
          for (final e in list) {
            if (e.type == 'income') inc += e.amount;
            if (e.type == 'expense') exp += e.amount;
            if (e.type == 'saving') sav += e.amount;
          }
          return Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _shift(-1)),
              Text(fmtMonth(_month), style: Theme.of(c).textTheme.titleMedium),
              IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _shift(1)),
            ]),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(children: [
                Expanded(child: _SummaryCard(label: c.t('Income'), value: money(inc), color: _green)),
                const SizedBox(width: 8),
                Expanded(child: _SummaryCard(label: c.t('Expense'), value: money(exp), color: _red)),
                const SizedBox(width: 8),
                Expanded(child: _SummaryCard(label: c.t('Savings'), value: money(sav), color: Colors.blue)),
              ]),
            ),
            const SizedBox(height: 4),
            Expanded(
              child: list.isEmpty
                  ? const EmptyState(message: 'No entries this month', icon: Icons.menu_book)
                  : ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, _) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final e = list[i];
                        final color = e.type == 'income' ? _green : (e.type == 'expense' ? _red : Colors.blue);
                        final sign = e.type == 'income' ? '+' : '-';
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: color.withValues(alpha: 0.15),
                            child: Icon(
                                e.type == 'income' ? Icons.south_west : (e.type == 'expense' ? Icons.north_east : Icons.savings),
                                color: color,
                                size: 20),
                          ),
                          title: Text(e.category.isEmpty ? e.type : e.category),
                          subtitle: Text('${fmtDate(e.date)}${e.note.isEmpty ? '' : '  •  ${e.note}'}'),
                          trailing: Text('$sign${money(e.amount)}', style: TextStyle(fontWeight: FontWeight.bold, color: color)),
                          onTap: () {
                            if (e.ref.isNotEmpty) {
                              snack(c, 'This entry was created automatically (${e.ref}). Edit or delete it from its source.');
                            } else {
                              _sheet(e.type, edit: e);
                            }
                          },
                        );
                      },
                    ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  Expanded(
                      child: FilledButton(
                          style: FilledButton.styleFrom(backgroundColor: _green),
                          onPressed: () => _sheet('income'),
                          child: Text('+ ${c.t('Income')}'))),
                  const SizedBox(width: 8),
                  Expanded(
                      child: FilledButton(
                          style: FilledButton.styleFrom(backgroundColor: _red),
                          onPressed: () => _sheet('expense'),
                          child: Text('- ${c.t('Expense')}'))),
                  const SizedBox(width: 8),
                  Expanded(
                      child: FilledButton(
                          style: FilledButton.styleFrom(backgroundColor: Colors.blue),
                          onPressed: () => _sheet('saving'),
                          child: Text(c.t('Savings')))),
                ]),
              ),
            ),
          ]);
        },
      ),
    );
  }
}

class _CashSheet extends StatefulWidget {
  const _CashSheet({required this.repo, required this.type, this.edit});
  final HisabRepo repo;
  final String type;
  final CashEntry? edit;

  @override
  State<_CashSheet> createState() => _CashSheetState();
}

class _CashSheetState extends State<_CashSheet> {
  final _form = GlobalKey<FormState>();
  late final _amount = TextEditingController(
      text: widget.edit == null ? '' : widget.edit!.amount.toString().replaceAll(RegExp(r'\.0$'), ''));
  late final _cat = TextEditingController(text: widget.edit?.category ?? '');
  late final _note = TextEditingController(text: widget.edit?.note ?? '');
  late DateTime _date = widget.edit?.date ?? DateTime.now();

  @override
  void dispose() {
    _amount.dispose();
    _cat.dispose();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cats = widget.type == 'income'
        ? _incomeCats
        : (widget.type == 'expense' ? _expenseCats : _savingCats);
    final color = widget.type == 'income' ? _green : (widget.type == 'expense' ? _red : Colors.blue);
    return Form(
      key: _form,
      child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(16), children: [
        Text(
          '${widget.edit == null ? 'Add' : 'Edit'} ${widget.type == 'saving' ? 'savings' : widget.type}',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(color: color),
        ),
        const SizedBox(height: 12),
        AppField(
          controller: _amount,
          label: 'Amount',
          prefixText: '৳ ',
          keyboard: const TextInputType.numberWithOptions(decimal: true),
          validator: (s) => parseAmount(s ?? '') <= 0 ? 'Enter an amount' : null,
        ),
        AppField(controller: _cat, label: 'Category'),
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Wrap(spacing: 6, runSpacing: 0, children: [
            for (final c in cats) ActionChip(label: Text(c, style: const TextStyle(fontSize: 12)), onPressed: () => setState(() => _cat.text = c)),
          ]),
        ),
        AppField(controller: _note, label: 'Note'),
        DateField(value: _date, onChanged: (d) => setState(() => _date = d)),
        Row(children: [
          if (widget.edit != null)
            Padding(
              padding: const EdgeInsets.only(right: 10),
              child: OutlinedButton.icon(
                icon: const Icon(Icons.delete_outline),
                label: Text(context.t('Delete')),
                onPressed: () {
                  widget.repo.deleteCash(widget.edit!);
                  Navigator.pop(context);
                },
              ),
            ),
          Expanded(
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: color),
              onPressed: () {
                if (!_form.currentState!.validate()) return;
                widget.repo.setCash(
                  id: widget.edit?.id,
                  old: widget.edit,
                  type: widget.type,
                  amount: parseAmount(_amount.text),
                  category: _cat.text.trim(),
                  note: _note.text.trim(),
                  date: _date,
                );
                Navigator.pop(context);
              },
              child: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(context.t('Save'))),
            ),
          ),
        ]),
      ]),
    );
  }
}

// ===========================================================================
// BUSINESS NOTES
// ===========================================================================
class NotesScreen extends StatelessWidget {
  const NotesScreen({super.key, required this.repo});
  final HisabRepo repo;

  void _open(BuildContext context, NoteItem? n) => Navigator.push(
      context, MaterialPageRoute<void>(builder: (_) => NoteEditor(repo: repo, note: n)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Business Notes'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.note_add),
        label: const Text('New note'),
        onPressed: () => _open(context, null),
      ),
      body: StreamBuilder<List<NoteItem>>(
        stream: repo.notes(),
        builder: (c, snap) {
          if (!snap.hasData) return const Loading();
          final list = snap.data!;
          if (list.isEmpty) return const EmptyState(message: 'No notes yet. Replace your paper notebook!', icon: Icons.sticky_note_2_outlined);
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            itemBuilder: (c, i) {
              final n = list[i];
              return Card(
                margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: ListTile(
                  title: Text(n.title.isEmpty ? '(No title)' : n.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('${n.body}\n${fmtDate(n.updated)}', maxLines: 3, overflow: TextOverflow.ellipsis),
                  isThreeLine: true,
                  onTap: () => _open(c, n),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class NoteEditor extends StatefulWidget {
  const NoteEditor({super.key, required this.repo, this.note});
  final HisabRepo repo;
  final NoteItem? note;

  @override
  State<NoteEditor> createState() => _NoteEditorState();
}

class _NoteEditorState extends State<NoteEditor> {
  late final _title = TextEditingController(text: widget.note?.title ?? '');
  late final _body = TextEditingController(text: widget.note?.body ?? '');

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  void _save() {
    if (_title.text.trim().isEmpty && _body.text.trim().isEmpty) {
      Navigator.pop(context);
      return;
    }
    widget.repo.saveNote(widget.note?.id, _title.text.trim(), _body.text.trim());
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.note == null ? 'New note' : 'Edit note'),
        actions: [
          if (widget.note != null)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final nav = Navigator.of(context);
                if (await confirmDialog(context, 'Delete note?', widget.note!.title)) {
                  widget.repo.deleteNote(widget.note!.id);
                  nav.pop();
                }
              },
            ),
          IconButton(icon: const Icon(Icons.check), onPressed: _save),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: _title, decoration: InputDecoration(labelText: context.t('Title'), border: const OutlineInputBorder())),
          const SizedBox(height: 12),
          Expanded(
            child: TextField(
              controller: _body,
              expands: true,
              maxLines: null,
              minLines: null,
              textAlignVertical: TextAlignVertical.top,
              decoration: InputDecoration(labelText: context.t('Note'), alignLabelWithHint: true, border: const OutlineInputBorder()),
            ),
          ),
        ]),
      ),
    );
  }
}
