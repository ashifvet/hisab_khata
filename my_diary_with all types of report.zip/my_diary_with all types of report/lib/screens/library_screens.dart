import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/repo.dart';
import '../core/utils.dart';
import '../core/widgets.dart';
import 'forms.dart';

void _openEdit(BuildContext context, String title, Widget Function(VoidCallback done) form) {
  Navigator.push(
    context,
    MaterialPageRoute<void>(
      builder: (c) => Scaffold(
        appBar: AppBar(title: Text(c.t(title))),
        body: form(() => Navigator.pop(c)),
      ),
    ),
  );
}

// ===========================================================================
// COMPANIES
// ===========================================================================
class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  final _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = context.watch<SharedData>();
    final q = _q.text.trim().toLowerCase();
    final list = data.companies.where((c) => c.name.toLowerCase().contains(q)).toList();
    int countOf(Company co) => data.medicines
        .where((m) => m.companyId == co.id || m.companyName == co.name)
        .length;
    return Column(children: [
      SearchBox(controller: _q, hint: 'Search', onChanged: (_) => setState(() {})),
      Expanded(
        child: list.isEmpty
            ? const EmptyState(message: 'No companies yet. Use the Add tab.', icon: Icons.business)
            : ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, _) => const Divider(height: 1),
                itemBuilder: (c, i) {
                  final co = list[i];
                  return ListTile(
                    leading: CircleAvatar(child: Text(co.name.isEmpty ? '?' : co.name.characters.first.toUpperCase())),
                    title: Text(co.name),
                    subtitle: Text('${countOf(co)} ${c.t('Medicines')}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(
                        c, MaterialPageRoute<void>(builder: (_) => CompanyDetailScreen(companyId: co.id))),
                  );
                },
              ),
      ),
    ]);
  }
}

class CompanyDetailScreen extends StatefulWidget {
  const CompanyDetailScreen({super.key, required this.companyId});
  final String companyId;

  @override
  State<CompanyDetailScreen> createState() => _CompanyDetailScreenState();
}

class _CompanyDetailScreenState extends State<CompanyDetailScreen> {
  bool _onlyFav = true;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final data = context.watch<SharedData>();
    Company? co;
    for (final c in data.companies) {
      if (c.id == widget.companyId) co = c;
    }
    if (co == null) {
      return Scaffold(appBar: AppBar(), body: const EmptyState(message: 'Company not found'));
    }
    final company = co;
    final all = data.medicines
        .where((m) => m.companyId == company.id || m.companyName == company.name)
        .toList();
    final shown = _onlyFav ? all.where((m) => app.favs.contains(m.id)).toList() : all;

    return Scaffold(
      appBar: AppBar(
        title: Text(company.name),
        actions: [
          if (app.canEdit(company.createdBy)) ...[
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              onPressed: () =>
                  _openEdit(context, 'Edit', (done) => CompanyForm(edit: company, onDone: done)),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final nav = Navigator.of(context);
                final ok = await confirmDialog(context, 'Delete company?',
                    'The company "${company.name}" will be deleted. Its medicines are kept.');
                if (ok) {
                  SharedRepo.delete('companies', company.id);
                  nav.pop();
                }
              },
            ),
          ],
        ],
      ),
      body: Column(children: [
        if (company.description.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Text(company.description),
          ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: SegmentedButton<bool>(
            segments: [
              ButtonSegment(
                  value: true,
                  icon: const Icon(Icons.favorite, size: 18),
                  label: Text('${context.t('Favourites')} (${all.where((m) => app.favs.contains(m.id)).length})')),
              ButtonSegment(
                  value: false,
                  icon: const Icon(Icons.list, size: 18),
                  label: Text('${context.t('All')} (${all.length})')),
            ],
            selected: {_onlyFav},
            onSelectionChanged: (s) => setState(() => _onlyFav = s.first),
          ),
        ),
        Expanded(
          child: shown.isEmpty
              ? EmptyState(
                  message: _onlyFav
                      ? 'No favourite medicines yet. Tap the heart on a medicine to add it here.'
                      : 'No medicines for this company yet.',
                  icon: Icons.medication_outlined)
              : MedicineListView(items: shown),
        ),
      ]),
    );
  }
}

// ===========================================================================
// MEDICINES
// ===========================================================================
class MedicinesScreen extends StatefulWidget {
  const MedicinesScreen({super.key});

  @override
  State<MedicinesScreen> createState() => _MedicinesScreenState();
}

class _MedicinesScreenState extends State<MedicinesScreen> {
  final _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = context.watch<SharedData>();
    final q = _q.text.trim().toLowerCase();
    final all = data.medicines.where((m) => q.isEmpty || m.searchText.contains(q)).toList();
    final preg = all.where((m) => m.pregSafe).toList();
    final pet = all.where((m) => m.petSafe).toList();
    return DefaultTabController(
      length: 3,
      child: Column(children: [
        SearchBox(controller: _q, hint: 'Search name, component or company', onChanged: (_) => setState(() {})),
        TabBar(tabs: [
          Tab(text: '${context.t('All Medicines')} (${all.length})'),
          Tab(text: '${context.t('Pregnancy Safe')} (${preg.length})'),
          Tab(text: '${context.t('Pet Medicines')} (${pet.length})'),
        ]),
        Expanded(
          child: TabBarView(children: [
            MedicineListView(items: all),
            MedicineListView(items: preg),
            MedicineListView(items: pet),
          ]),
        ),
      ]),
    );
  }
}

/// Alphabetical list (with letter headers) of medicines.
class MedicineListView extends StatelessWidget {
  const MedicineListView({super.key, required this.items});
  final List<Medicine> items;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const EmptyState(icon: Icons.medication_outlined);
    final app = context.watch<AppState>();
    final rows = <Object>[];
    String last = '';
    for (final m in items) {
      final l = m.name.isEmpty ? '#' : m.name.characters.first.toUpperCase();
      if (l != last) {
        rows.add(l);
        last = l;
      }
      rows.add(m);
    }
    return ListView.builder(
      itemCount: rows.length,
      itemBuilder: (c, i) {
        final r = rows[i];
        if (r is String) {
          return Container(
            color: Theme.of(c).colorScheme.surfaceContainerHighest,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Text(r, style: const TextStyle(fontWeight: FontWeight.bold)),
          );
        }
        final m = r as Medicine;
        final sub = [m.generic, m.companyName].where((e) => e.isNotEmpty).join('  •  ');
        return ListTile(
          title: Text('${m.name}${m.strength.isEmpty ? '' : '  ${m.strength}'}',
              maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            if (app.favs.contains(m.id)) const Icon(Icons.favorite, size: 16, color: Colors.redAccent),
            if (m.pregSafe)
              const Padding(
                  padding: EdgeInsets.only(left: 6),
                  child: Icon(Icons.pregnant_woman, size: 18, color: Colors.green)),
            if (m.petSafe)
              const Padding(
                  padding: EdgeInsets.only(left: 6),
                  child: Icon(Icons.pets, size: 16, color: Colors.teal)),
          ]),
          onTap: () => Navigator.push(
              c, MaterialPageRoute<void>(builder: (_) => MedicineDetailScreen(medicineId: m.id))),
        );
      },
    );
  }
}

class MedicineDetailScreen extends StatelessWidget {
  const MedicineDetailScreen({super.key, required this.medicineId});
  final String medicineId;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final data = context.watch<SharedData>();
    Medicine? med;
    for (final m in data.medicines) {
      if (m.id == medicineId) med = m;
    }
    if (med == null) {
      return Scaffold(appBar: AppBar(), body: const EmptyState(message: 'Medicine not found'));
    }
    final m = med;
    final fav = app.favs.contains(m.id);
    return Scaffold(
      appBar: AppBar(
        title: Text(m.name),
        actions: [
          IconButton(
            tooltip: 'Favourite',
            icon: Icon(fav ? Icons.favorite : Icons.favorite_border, color: fav ? Colors.redAccent : null),
            onPressed: () => app.toggleFavorite(m.id),
          ),
          if (app.canEdit(m.createdBy)) ...[
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => _openEdit(context, 'Edit', (done) => MedicineForm(edit: m, onDone: done)),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final nav = Navigator.of(context);
                final ok = await confirmDialog(context, 'Delete medicine?', 'Delete "${m.name}" for all users?');
                if (ok) {
                  SharedRepo.delete('medicines', m.id);
                  nav.pop();
                }
              },
            ),
          ],
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(m.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        if (m.strength.isNotEmpty || m.form.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text([m.strength, m.form].where((e) => e.isNotEmpty).join('  •  ')),
          ),
        const SizedBox(height: 4),
        Text(m.companyName, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 6, children: [
          Pill('${context.t('Pregnancy')}: ${context.t(m.pregSafe ? 'Safe' : 'Unsafe')}',
              color: m.pregSafe ? Colors.green : Colors.orange, icon: Icons.pregnant_woman),
          Pill('${context.t('Pet safety')}: ${context.t(m.petSafe ? 'Safe' : 'Unsafe')}',
              color: m.petSafe ? Colors.green : Colors.orange, icon: Icons.pets),
        ]),
        const SizedBox(height: 18),
        DetailBlock('Components / generic', m.generic),
        DetailBlock('When to use', m.use),
        DetailBlock('Dose', m.dose),
        DetailBlock('Other details', m.details),
        if (m.createdByName.isNotEmpty)
          Text('${context.t('Added by')}: ${m.createdByName}',
              style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.outline)),
      ]),
    );
  }
}

// ===========================================================================
// DISEASES
// ===========================================================================
class DiseasesScreen extends StatefulWidget {
  const DiseasesScreen({super.key});

  @override
  State<DiseasesScreen> createState() => _DiseasesScreenState();
}

class _DiseasesScreenState extends State<DiseasesScreen> {
  final _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = context.watch<SharedData>();
    final q = _q.text.trim().toLowerCase();
    final all = data.diseases.where((d) => q.isEmpty || d.searchText.contains(q)).toList();
    final good = all.where((d) => d.prognosis == 'Good').toList();
    final poor = all.where((d) => d.prognosis == 'Poor').toList();
    return DefaultTabController(
      length: 3,
      child: Column(children: [
        SearchBox(controller: _q, hint: 'Search title, owner or phone', onChanged: (_) => setState(() {})),
        TabBar(tabs: [
          Tab(text: '${context.t('All')} (${all.length})'),
          Tab(text: '${context.t('Good Prognosis')} (${good.length})'),
          Tab(text: '${context.t('Poor Prognosis')} (${poor.length})'),
        ]),
        Expanded(
          child: TabBarView(children: [
            _DiseaseList(items: all),
            _DiseaseList(items: good),
            _DiseaseList(items: poor),
          ]),
        ),
      ]),
    );
  }
}

class _DiseaseList extends StatelessWidget {
  const _DiseaseList({required this.items});
  final List<Disease> items;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const EmptyState(icon: Icons.pets_outlined);
    return ListView.separated(
      itemCount: items.length,
      separatorBuilder: (_, _) => const Divider(height: 1),
      itemBuilder: (c, i) {
        final d = items[i];
        final good = d.prognosis == 'Good';
        return ListTile(
          title: Text(d.title, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(
            [d.ownerName, d.phone].where((e) => e.isNotEmpty).join('  •  '),
            style: const TextStyle(fontSize: 12),
          ),
          trailing: Pill(c.t(d.prognosis), color: good ? Colors.green : Colors.red),
          onTap: () => Navigator.push(
              c, MaterialPageRoute<void>(builder: (_) => DiseaseDetailScreen(diseaseId: d.id))),
        );
      },
    );
  }
}

class DiseaseDetailScreen extends StatelessWidget {
  const DiseaseDetailScreen({super.key, required this.diseaseId});
  final String diseaseId;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final data = context.watch<SharedData>();
    Disease? found;
    for (final d in data.diseases) {
      if (d.id == diseaseId) found = d;
    }
    if (found == null) {
      return Scaffold(appBar: AppBar(), body: const EmptyState(message: 'Record not found'));
    }
    final d = found;
    final good = d.prognosis == 'Good';
    return Scaffold(
      appBar: AppBar(
        title: Text(d.title),
        actions: [
          if (app.canEdit(d.createdBy)) ...[
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => _openEdit(context, 'Edit', (done) => DiseaseForm(edit: d, onDone: done)),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final nav = Navigator.of(context);
                final ok = await confirmDialog(context, 'Delete record?', 'Delete "${d.title}"?');
                if (!ok) return;
                // Remove the consultation fee that was added to the cashbook.
                if (d.businessId.isNotEmpty) {
                  final h = HisabRepo(d.createdBy, d.businessId);
                  final c = await h.cashFromCache('d_${d.id}');
                  if (c != null) h.deleteCash(c);
                }
                SharedRepo.delete('diseases', d.id);
                nav.pop();
              },
            ),
          ],
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(d.title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 6, children: [
          Pill('${context.t('Prognosis')}: ${context.t(d.prognosis)}', color: good ? Colors.green : Colors.red),
          Pill(context.t(d.location), color: Colors.blueGrey, icon: Icons.local_hospital),
          Pill('${context.t('Skin parasite')}: ${context.t(d.skinParasite ? 'Present' : 'Absent')}',
              color: d.skinParasite ? Colors.orange : Colors.green, icon: Icons.bug_report),
        ]),
        const SizedBox(height: 16),
        DetailBlock('Owner name', d.ownerName),
        DetailBlock('Phone number', d.phone),
        if (d.location == 'Private' && d.fee > 0) DetailBlock('Fee taken', money(d.fee)),
        DetailBlock('Temperature', d.temperature.isEmpty ? '' : '${d.temperature} °F'),
        DetailBlock('Signs & symptoms (told by owner)', d.symptoms),
        DetailBlock('Clinical findings', d.findings),
        DetailBlock('Treatment', d.treatment),
        if (d.createdByName.isNotEmpty)
          Text('${context.t('Added by')}: ${d.createdByName}  •  ${fmtDate(d.createdAt)}',
              style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.outline)),
      ]),
    );
  }
}

// ===========================================================================
// PROBLEMS & SOLUTIONS
// ===========================================================================
class ProblemsScreen extends StatefulWidget {
  const ProblemsScreen({super.key});

  @override
  State<ProblemsScreen> createState() => _ProblemsScreenState();
}

class _ProblemsScreenState extends State<ProblemsScreen> {
  final _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = context.watch<SharedData>();
    final q = _q.text.trim().toLowerCase();
    final list = data.problems
        .where((p) => q.isEmpty || p.title.toLowerCase().contains(q) || p.problem.toLowerCase().contains(q))
        .toList();
    return Column(children: [
      SearchBox(controller: _q, onChanged: (_) => setState(() {})),
      Expanded(
        child: list.isEmpty
            ? const EmptyState(message: 'No problems & solutions yet. Use the Add tab.', icon: Icons.lightbulb_outline)
            : ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, _) => const Divider(height: 1),
                itemBuilder: (c, i) {
                  final p = list[i];
                  return ListTile(
                    leading: const Icon(Icons.lightbulb_outline),
                    title: Text(p.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(p.problem, maxLines: 2, overflow: TextOverflow.ellipsis),
                    onTap: () => Navigator.push(
                        c, MaterialPageRoute<void>(builder: (_) => ProblemDetailScreen(problemId: p.id))),
                  );
                },
              ),
      ),
    ]);
  }
}

class ProblemDetailScreen extends StatelessWidget {
  const ProblemDetailScreen({super.key, required this.problemId});
  final String problemId;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final data = context.watch<SharedData>();
    Problem? found;
    for (final p in data.problems) {
      if (p.id == problemId) found = p;
    }
    if (found == null) {
      return Scaffold(appBar: AppBar(), body: const EmptyState(message: 'Record not found'));
    }
    final p = found;
    return Scaffold(
      appBar: AppBar(
        title: Text(p.title),
        actions: [
          if (app.canEdit(p.createdBy)) ...[
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => _openEdit(context, 'Edit', (done) => ProblemForm(edit: p, onDone: done)),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final nav = Navigator.of(context);
                final ok = await confirmDialog(context, 'Delete record?', 'Delete "${p.title}"?');
                if (ok) {
                  SharedRepo.delete('problems', p.id);
                  nav.pop();
                }
              },
            ),
          ],
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(p.title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        DetailBlock('Problem', p.problem),
        DetailBlock('Solution', p.solution),
        DetailBlock('Prognosis', p.prognosis),
        if (p.createdByName.isNotEmpty)
          Text('${context.t('Added by')}: ${p.createdByName}',
              style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.outline)),
      ]),
    );
  }
}
