import 'package:flutter/material.dart';

import '../core/i18n.dart';
import '../core/repo.dart';
import '../core/widgets.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _form = GlobalKey<FormState>();
  bool _register = false;
  bool _busy = false;
  bool _hide = true;
  String? _error;

  final _id = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _phone = TextEditingController();
  final _loc = TextEditingController();

  @override
  void dispose() {
    for (final c in [_id, _pass, _pass2, _first, _last, _phone, _loc]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final err = _register
        ? await AuthService.register(
            firstName: _first.text,
            lastName: _last.text,
            email: _id.text,
            phone: _phone.text,
            location: _loc.text,
            password: _pass.text)
        : await AuthService.signIn(_id.text, _pass.text);
    if (!mounted) return;
    // On success the app switches to the home screen automatically.
    setState(() {
      _busy = false;
      _error = err;
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _form,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Icon(Icons.menu_book_rounded, size: 72, color: cs.primary),
                    const SizedBox(height: 8),
                    Text('My Diary',
                        textAlign: TextAlign.center,
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(fontWeight: FontWeight.bold)),
                    Text('Veterinary library & business Hisab',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: cs.outline)),
                    const SizedBox(height: 28),
                    if (_register) ...[
                      Row(children: [
                        Expanded(child: AppField(controller: _first, label: 'First name', required: true)),
                        const SizedBox(width: 10),
                        Expanded(child: AppField(controller: _last, label: 'Last name')),
                      ]),
                      AppField(controller: _phone, label: 'Phone number', keyboard: TextInputType.phone),
                      AppField(controller: _loc, label: 'Location'),
                    ],
                    AppField(
                      controller: _id,
                      label: _register ? 'Email' : 'Email or username',
                      required: true,
                      keyboard: TextInputType.emailAddress,
                      validator: (s) {
                        final v = (s ?? '').trim();
                        if (v.isEmpty) return context.t('Required');
                        if (_register && !v.contains('@')) return 'Enter a valid e-mail';
                        return null;
                      },
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: TextFormField(
                        controller: _pass,
                        obscureText: _hide,
                        decoration: InputDecoration(
                          labelText: '${context.t('Password')} *',
                          border: const OutlineInputBorder(),
                          suffixIcon: IconButton(
                            icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                            onPressed: () => setState(() => _hide = !_hide),
                          ),
                        ),
                        validator: (s) {
                          if ((s ?? '').isEmpty) return context.t('Required');
                          if (_register && s!.length < 6) return 'At least 6 characters';
                          return null;
                        },
                      ),
                    ),
                    if (_register)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: TextFormField(
                          controller: _pass2,
                          obscureText: _hide,
                          decoration: const InputDecoration(
                              labelText: 'Confirm password *', border: OutlineInputBorder()),
                          validator: (s) => s != _pass.text ? 'Passwords do not match' : null,
                        ),
                      ),
                    if (_error != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text(_error!, style: TextStyle(color: cs.error)),
                      ),
                    FilledButton(
                      onPressed: _busy ? null : _submit,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: _busy
                            ? const SizedBox(
                                width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                            : Text(context.t(_register ? 'Create account' : 'Login')),
                      ),
                    ),
                    TextButton(
                      onPressed: _busy
                          ? null
                          : () => setState(() {
                                _register = !_register;
                                _error = null;
                              }),
                      child: Text(_register
                          ? 'Already have an account? Login'
                          : 'New user? Create an account'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
