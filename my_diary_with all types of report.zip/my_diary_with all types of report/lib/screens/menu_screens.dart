import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/repo.dart';
import '../core/utils.dart';
import '../core/widgets.dart';

// ===========================================================================
// PROFILE
// ===========================================================================
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _form = GlobalKey<FormState>();
  late final AppUser? _p = context.read<AppState>().profile;
  late final _first = TextEditingController(text: _p?.firstName ?? '');
  late final _last = TextEditingController(text: _p?.lastName ?? '');
  late final _phone = TextEditingController(text: _p?.phone ?? '');
  late final _loc = TextEditingController(text: _p?.location ?? '');
  late final _desig = TextEditingController(text: _p?.designation ?? '');

  @override
  void dispose() {
    for (final c in [_first, _last, _phone, _loc, _desig]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Edit Profile'))),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppField(controller: _first, label: 'First name', required: true),
          AppField(controller: _last, label: 'Last name'),
          InputDecorator(
            decoration: InputDecoration(labelText: context.t('Email'), border: const OutlineInputBorder()),
            child: Text(app.user?.email ?? ''),
          ),
          const SizedBox(height: 14),
          AppField(controller: _phone, label: 'Phone number', keyboard: TextInputType.phone),
          AppField(controller: _loc, label: 'Location'),
          AppField(controller: _desig, label: 'Designation / Clinic (optional)'),
          FilledButton.icon(
            icon: const Icon(Icons.save),
            label: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(context.t('Save'))),
            onPressed: () {
              if (!_form.currentState!.validate()) return;
              app.updateProfile({
                'firstName': _first.text.trim(),
                'lastName': _last.text.trim(),
                'phone': _phone.text.trim(),
                'location': _loc.text.trim(),
                'designation': _desig.text.trim(),
              });
              snack(context, context.t('Saved'));
              Navigator.pop(context);
            },
          ),
        ]),
      ),
    );
  }
}

// ===========================================================================
// SETTINGS
// ===========================================================================
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _changePassword(BuildContext context) async {
    final cur = TextEditingController();
    final nw = TextEditingController();
    final form = GlobalKey<FormState>();
    String? error;
    bool busy = false;
    final done = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: Text(c.t('Change password')),
          content: Form(
            key: form,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextFormField(
                controller: cur,
                obscureText: true,
                decoration: InputDecoration(labelText: c.t('Current password'), border: const OutlineInputBorder()),
                validator: (s) => (s ?? '').isEmpty ? c.t('Required') : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: nw,
                obscureText: true,
                decoration: InputDecoration(labelText: c.t('New password'), border: const OutlineInputBorder()),
                validator: (s) => (s ?? '').length < 6 ? 'At least 6 characters' : null,
              ),
              if (error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(error!, style: TextStyle(color: Theme.of(c).colorScheme.error)),
                ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: Text(c.t('Cancel'))),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      if (!form.currentState!.validate()) return;
                      setS(() {
                        busy = true;
                        error = null;
                      });
                      final r = await AuthService.changePassword(cur.text, nw.text);
                      if (r == null) {
                        if (c.mounted) Navigator.pop(c, true);
                      } else {
                        setS(() {
                          busy = false;
                          error = r;
                        });
                      }
                    },
              child: Text(c.t('Save')),
            ),
          ],
        ),
      ),
    );
    cur.dispose();
    nw.dispose();
    if (done == true && context.mounted) snack(context, context.t('Password changed'));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Settings'))),
      body: ListView(children: [
        SwitchListTile(
          secondary: const Icon(Icons.dark_mode_outlined),
          title: Text(context.t('Dark mode')),
          value: app.themeMode == ThemeMode.dark,
          onChanged: app.setDark,
        ),
        const Divider(height: 1),
        ListTile(
          leading: const Icon(Icons.language),
          title: Text(context.t('App language')),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 8),
            child: SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'bn', label: Text('বাংলা')),
                ButtonSegment(value: 'en', label: Text('English')),
              ],
              selected: {app.lang},
              showSelectedIcon: false,
              onSelectionChanged: (s) => app.setLang(s.first),
            ),
          ),
        ),
        const Divider(height: 1),
        ListTile(
          leading: const Icon(Icons.lock_outline),
          title: Text(context.t('Change password')),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _changePassword(context),
        ),
      ]),
    );
  }
}

// ===========================================================================
// ABOUT DEVELOPER
// ===========================================================================
class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> {
  String _version = '';

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((p) {
      if (mounted) setState(() => _version = '${p.version} (${p.buildNumber})');
    }).catchError((Object _) {});
  }

  Widget _row(IconData i, String k, String v, {VoidCallback? onTap}) => ListTile(
        leading: Icon(i),
        title: Text(k, style: const TextStyle(fontSize: 12)),
        subtitle: Text(v, style: const TextStyle(fontSize: 16)),
        onTap: onTap,
      );

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(context.t('About Developer'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Center(child: CircleAvatar(radius: 44, backgroundColor: cs.primaryContainer, child: Icon(Icons.person, size: 52, color: cs.primary))),
        const SizedBox(height: 12),
        Text('My Diary',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Card(
          child: Column(children: [
            _row(Icons.badge_outlined, 'Name', 'Dr. MD. ASHIF IQBAL, DVM, MSc, BCS'),
            _row(Icons.local_hospital_outlined, 'Designation', 'Veterinary Surgeon, Maheshpur'),
            _row(Icons.phone_outlined, 'Phone', '01711989236', onTap: () => callNumber('01711989236')),
            _row(Icons.home_outlined, 'Hometown', 'Kushtia'),
            _row(Icons.verified_outlined, context.t('Version'), _version),
          ]),
        ),
      ]),
    );
  }
}

// ===========================================================================
// ADMIN: ANNOUNCEMENTS
// ===========================================================================
class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Announcements'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('New'),
        onPressed: () => Navigator.push(
            context, MaterialPageRoute<void>(builder: (_) => const AnnouncementForm())),
      ),
      body: StreamBuilder<QuerySnapshot<Json>>(
        stream: fs.collection('announcements').snapshots(),
        builder: (c, snap) {
          if (!snap.hasData) return const Loading();
          final list = snap.data!.docs.map((d) => Announcement.fromMap(d.id, d.data())).toList()
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
          if (list.isEmpty) return const EmptyState(message: 'No announcements yet', icon: Icons.campaign_outlined);
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            itemBuilder: (c, i) {
              final a = list[i];
              return Card(
                margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: ListTile(
                  title: Text(a.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(
                    '${a.content}\n\nShown ${a.times}x per user  •  Cancel ${a.cancelAllowed ? 'allowed' : 'not allowed'}',
                    maxLines: 5,
                    overflow: TextOverflow.ellipsis,
                  ),
                  isThreeLine: true,
                  onTap: () => Navigator.push(
                      c, MaterialPageRoute<void>(builder: (_) => AnnouncementForm(edit: a))),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Switch(
                      value: a.active,
                      onChanged: (v) => fire(fs.collection('announcements').doc(a.id).update({'active': v})),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        if (await confirmDialog(c, 'Delete announcement?', a.title)) {
                          fire(fs.collection('announcements').doc(a.id).delete());
                        }
                      },
                    ),
                  ]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class AnnouncementForm extends StatefulWidget {
  const AnnouncementForm({super.key, this.edit});
  final Announcement? edit;

  @override
  State<AnnouncementForm> createState() => _AnnouncementFormState();
}

class _AnnouncementFormState extends State<AnnouncementForm> {
  final _form = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.edit?.title ?? '');
  late final _content = TextEditingController(text: widget.edit?.content ?? '');
  late final _tg = TextEditingController(text: widget.edit?.telegram ?? '');
  late final _web = TextEditingController(text: widget.edit?.web ?? '');
  late final _times = TextEditingController(text: '${widget.edit?.times ?? 1}');
  late bool _cancel = widget.edit?.cancelAllowed ?? true;

  @override
  void dispose() {
    for (final c in [_title, _content, _tg, _web, _times]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final data = {
      'title': _title.text.trim(),
      'content': _content.text.trim(),
      'telegram': _tg.text.trim(),
      'web': _web.text.trim(),
      'cancelAllowed': _cancel,
      'times': int.tryParse(_times.text.trim()) ?? 1,
    };
    final col = fs.collection('announcements');
    if (widget.edit == null) {
      fire(col.doc().set({...data, 'active': true, 'createdAt': Timestamp.now()}));
    } else {
      fire(col.doc(widget.edit!.id).update(data));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.edit == null ? 'New announcement' : 'Edit announcement')),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppField(controller: _title, label: 'Title of the dialog box', required: true),
          AppField(controller: _content, label: 'Content of the dialog box', required: true, maxLines: 8),
          AppField(controller: _tg, label: 'Telegram link', keyboard: TextInputType.url),
          AppField(controller: _web, label: 'Website link', keyboard: TextInputType.url),
          ChoiceRow(
            label: 'Cancel allowed',
            value: _cancel ? 'Yes' : 'No',
            options: const {'Yes': 'Yes', 'No': 'No'},
            onChanged: (v) => setState(() => _cancel = v == 'Yes'),
          ),
          AppField(
            controller: _times,
            label: 'How many times will the user see it?',
            keyboard: TextInputType.number,
            validator: (s) => (int.tryParse((s ?? '').trim()) ?? 0) < 1 ? 'Enter 1 or more' : null,
          ),
          FilledButton.icon(
            icon: const Icon(Icons.save),
            label: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(context.t('Save'))),
            onPressed: _save,
          ),
        ]),
      ),
    );
  }
}

// ===========================================================================
// ADMIN: USERS & ADMINS
// ===========================================================================
class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  void _actions(BuildContext context, AppUser u) {
    final app = context.read<AppState>();
    final self = u.uid == app.uid;
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            title: Text(u.fullName, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${u.email}\n${u.phone}'),
            isThreeLine: u.phone.isNotEmpty,
          ),
          if (!self)
            ListTile(
              leading: const Icon(Icons.visibility_outlined),
              title: const Text("Open this user's Hisab data"),
              onTap: () {
                Navigator.pop(c); // sheet
                app.viewUser(u.uid, u.fullName);
                Navigator.pop(context); // users page -> home
                snack(context, "Viewing ${u.fullName}'s Hisab (Hisab tab)");
              },
            ),
          if (!self)
            ListTile(
              leading: Icon(u.isAdmin ? Icons.remove_moderator_outlined : Icons.add_moderator_outlined),
              title: Text(u.isAdmin ? 'Remove admin rights' : 'Make administrator'),
              onTap: () {
                Navigator.pop(c);
                fire(fs.collection('users').doc(u.uid).update({'role': u.isAdmin ? 'user' : 'admin'}));
              },
            ),
          if (self)
            const ListTile(leading: Icon(Icons.info_outline), title: Text('This is your own account')),
        ]),
      ),
    );
  }

  Future<void> _createAdmin(BuildContext context) async {
    final form = GlobalKey<FormState>();
    final first = TextEditingController();
    final email = TextEditingController();
    final pass = TextEditingController();
    String? error;
    bool busy = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Create new administrator'),
          content: Form(
            key: form,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                AppField(controller: first, label: 'Name', required: true),
                AppField(controller: email, label: 'Email', required: true, keyboard: TextInputType.emailAddress),
                AppField(
                  controller: pass,
                  label: 'Password',
                  validator: (s) => (s ?? '').length < 6 ? 'At least 6 characters' : null,
                ),
                if (error != null) Text(error!, style: TextStyle(color: Theme.of(c).colorScheme.error)),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: Text(c.t('Cancel'))),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      if (!form.currentState!.validate()) return;
                      setS(() {
                        busy = true;
                        error = null;
                      });
                      final r = await AuthService.createAdmin(
                          name: first.text.trim(), email: email.text.trim(), password: pass.text);
                      if (r == null) {
                        if (c.mounted) Navigator.pop(c, true);
                      } else {
                        setS(() {
                          busy = false;
                          error = r;
                        });
                      }
                    },
              child: const Text('Create'),
            ),
          ],
        ),
      ),
    );
    first.dispose();
    email.dispose();
    pass.dispose();
    if (ok == true && context.mounted) snack(context, 'Administrator created');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Users & Admins'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('New admin'),
        onPressed: () => _createAdmin(context),
      ),
      body: StreamBuilder<QuerySnapshot<Json>>(
        stream: fs.collection('users').snapshots(),
        builder: (c, snap) {
          if (snap.hasError) return const EmptyState(message: 'Cannot load users (administrator only).');
          if (!snap.hasData) return const Loading();
          final list = snap.data!.docs.map((d) => AppUser.fromMap(d.id, d.data())).toList()
            ..sort((a, b) => a.fullName.toLowerCase().compareTo(b.fullName.toLowerCase()));
          return ListView.separated(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            separatorBuilder: (_, _) => const Divider(height: 1),
            itemBuilder: (c, i) {
              final u = list[i];
              return ListTile(
                leading: CircleAvatar(child: Text(u.fullName.isEmpty ? '?' : u.fullName.characters.first.toUpperCase())),
                title: Text(u.fullName),
                subtitle: Text(u.email),
                trailing: u.isAdmin ? const Pill('Admin', color: Colors.deepPurple) : null,
                onTap: () => _actions(c, u),
              );
            },
          );
        },
      ),
    );
  }
}

// ===========================================================================
// ADMIN: PUBLISH APP VERSION (forced update)
// ===========================================================================
class PublishVersionScreen extends StatefulWidget {
  const PublishVersionScreen({super.key});

  @override
  State<PublishVersionScreen> createState() => _PublishVersionScreenState();
}

class _PublishVersionScreenState extends State<PublishVersionScreen> {
  final _form = GlobalKey<FormState>();
  final _latest = TextEditingController();
  final _min = TextEditingController();
  final _url = TextEditingController();
  final _msg = TextEditingController();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    fs.collection('app_config').doc('version').get().then((s) {
      final d = s.data();
      if (d != null && mounted) {
        _latest.text = (d['latestVersion'] ?? '').toString();
        _min.text = (d['minVersion'] ?? '').toString();
        _url.text = (d['updateUrl'] ?? '').toString();
        _msg.text = (d['message'] ?? '').toString();
      }
      if (mounted) setState(() => _loaded = true);
    }).catchError((Object _) {
      if (mounted) setState(() => _loaded = true);
    });
  }

  @override
  void dispose() {
    for (final c in [_latest, _min, _url, _msg]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _ver(String? s) =>
      RegExp(r'^\d+\.\d+\.\d+$').hasMatch((s ?? '').trim()) ? null : 'Use the format 1.2.3';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Publish App Version'))),
      body: !_loaded
          ? const Loading()
          : Form(
              key: _form,
              child: ListView(padding: const EdgeInsets.all(16), children: [
                const Text(
                  'Users on an older version see an update dialog.\n'
                  '• Users below the MINIMUM version are forced to update (they cannot continue).\n'
                  '• Users below the LATEST version get an optional update message.',
                ),
                const SizedBox(height: 16),
                AppField(controller: _latest, label: 'Latest version (e.g. 1.0.1)', required: true, validator: _ver),
                AppField(controller: _min, label: 'Minimum required version (force update below this)', required: true, validator: _ver),
                AppField(controller: _url, label: 'Download / Play Store link', required: true, keyboard: TextInputType.url),
                AppField(controller: _msg, label: 'Message (optional)', maxLines: 3),
                FilledButton.icon(
                  icon: const Icon(Icons.cloud_upload_outlined),
                  label: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Publish')),
                  onPressed: () {
                    if (!_form.currentState!.validate()) return;
                    fire(fs.collection('app_config').doc('version').set({
                      'latestVersion': _latest.text.trim(),
                      'minVersion': _min.text.trim(),
                      'updateUrl': _url.text.trim(),
                      'message': _msg.text.trim(),
                      'updatedAt': Timestamp.now(),
                    }));
                    snack(context, 'Published');
                    Navigator.pop(context);
                  },
                ),
              ]),
            ),
    );
  }
}
