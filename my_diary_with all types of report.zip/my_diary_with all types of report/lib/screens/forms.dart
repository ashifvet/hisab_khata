import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/repo.dart';
import '../core/utils.dart';
import '../core/widgets.dart';

const _safeOptions = {'Safe': 'Safe', 'Unsafe': 'Unsafe'};

Widget _saveButton(BuildContext context, VoidCallback onPressed, {bool busy = false}) =>
    Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 24),
      child: FilledButton.icon(
        onPressed: busy ? null : onPressed,
        icon: const Icon(Icons.save),
        label: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Text(context.t('Save')),
        ),
      ),
    );

// ===========================================================================
// COMPANY
// ===========================================================================
class CompanyForm extends StatefulWidget {
  const CompanyForm({super.key, this.edit, required this.onDone});
  final Company? edit;
  final VoidCallback onDone;

  @override
  State<CompanyForm> createState() => _CompanyFormState();
}

class _CompanyFormState extends State<CompanyForm> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.edit?.name ?? '');
  late final _desc = TextEditingController(text: widget.edit?.description ?? '');

  @override
  void dispose() {
    _name.dispose();
    _desc.dispose();
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    final shared = context.read<SharedData>();
    final name = _name.text.trim();
    final dup = shared.companies.any((c) =>
        c.id != widget.edit?.id && c.name.toLowerCase() == name.toLowerCase());
    if (dup) {
      snack(context, 'This company already exists.');
      return;
    }
    final data = {'name': name, 'description': _desc.text.trim()};
    if (widget.edit == null) {
      SharedRepo.create('companies', data, uid: app.uid, name: app.fullName);
    } else {
      SharedRepo.update('companies', widget.edit!.id, data);
    }
    snack(context, context.t('Saved'));
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) => Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppField(controller: _name, label: 'Company name', required: true),
          AppField(controller: _desc, label: 'Other details', maxLines: 4),
          _saveButton(context, _save),
        ]),
      );
}

// ===========================================================================
// MEDICINE
// ===========================================================================
class MedicineForm extends StatefulWidget {
  const MedicineForm({super.key, this.edit, required this.onDone});
  final Medicine? edit;
  final VoidCallback onDone;

  @override
  State<MedicineForm> createState() => _MedicineFormState();
}

class _MedicineFormState extends State<MedicineForm> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.edit?.name ?? '');
  late final _generic = TextEditingController(text: widget.edit?.generic ?? '');
  late final _strength = TextEditingController(text: widget.edit?.strength ?? '');
  late final _formType = TextEditingController(text: widget.edit?.form ?? '');
  late final _use = TextEditingController(text: widget.edit?.use ?? '');
  late final _dose = TextEditingController(text: widget.edit?.dose ?? '');
  late final _details = TextEditingController(text: widget.edit?.details ?? '');
  late bool _preg = widget.edit?.pregSafe ?? false;
  late bool _pet = widget.edit?.petSafe ?? false;
  String? _companyId;

  @override
  void initState() {
    super.initState();
    _companyId = widget.edit?.companyId;
  }

  @override
  void dispose() {
    for (final c in [_name, _generic, _strength, _formType, _use, _dose, _details]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    final shared = context.read<SharedData>();
    Company? co;
    for (final c in shared.companies) {
      if (c.id == _companyId) co = c;
    }
    if (co == null) {
      snack(context, 'Please choose a company.');
      return;
    }
    final data = {
      'name': _name.text.trim(),
      'generic': _generic.text.trim(),
      'strength': _strength.text.trim(),
      'form': _formType.text.trim(),
      'companyId': co.id,
      'companyName': co.name,
      'use': _use.text.trim(),
      'dose': _dose.text.trim(),
      'details': _details.text.trim(),
      'pregSafe': _preg,
      'petSafe': _pet,
    };
    if (widget.edit == null) {
      SharedRepo.create('medicines', data, uid: app.uid, name: app.fullName);
    } else {
      SharedRepo.update('medicines', widget.edit!.id, data);
    }
    snack(context, context.t('Saved'));
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    final companies = context.watch<SharedData>().companies;
    if (_companyId != null && !companies.any((c) => c.id == _companyId)) {
      // Company was created from the old id/name; keep dropdown valid.
      final byName = widget.edit == null
          ? null
          : companies.where((c) => c.name == widget.edit!.companyName).firstOrNull;
      _companyId = byName?.id;
    }
    return Form(
      key: _form,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        AppField(controller: _name, label: 'Medicine name', required: true),
        Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: DropdownButtonFormField<String>(
            key: ValueKey('co_${companies.length}_$_companyId'),
            initialValue: _companyId,
            isExpanded: true,
            decoration: InputDecoration(
              labelText: '${context.t('Company')} *',
              border: const OutlineInputBorder(),
              helperText: companies.isEmpty ? 'Add a company first (Company tab)' : null,
            ),
            items: [
              for (final c in companies)
                DropdownMenuItem(value: c.id, child: Text(c.name, overflow: TextOverflow.ellipsis)),
            ],
            onChanged: (v) => setState(() => _companyId = v),
            validator: (v) => v == null ? context.t('Required') : null,
          ),
        ),
        AppField(controller: _generic, label: 'Components / generic', required: true, maxLines: 3),
        Row(children: [
          Expanded(child: AppField(controller: _strength, label: 'Strength')),
          const SizedBox(width: 10),
          Expanded(child: AppField(controller: _formType, label: 'Form (tablet, injection...)')),
        ]),
        AppField(controller: _use, label: 'When to use', required: true, maxLines: 5),
        AppField(controller: _dose, label: 'Dose', required: true, maxLines: 5),
        ChoiceRow(
          label: 'Pregnancy',
          value: _preg ? 'Safe' : 'Unsafe',
          options: _safeOptions,
          onChanged: (v) => setState(() => _preg = v == 'Safe'),
        ),
        ChoiceRow(
          label: 'Pet safety',
          value: _pet ? 'Safe' : 'Unsafe',
          options: _safeOptions,
          onChanged: (v) => setState(() => _pet = v == 'Safe'),
        ),
        AppField(controller: _details, label: 'Other details', maxLines: 8),
        _saveButton(context, _save),
      ]),
    );
  }
}

// ===========================================================================
// DISEASE
// ===========================================================================
class DiseaseForm extends StatefulWidget {
  const DiseaseForm({super.key, this.edit, required this.onDone});
  final Disease? edit;
  final VoidCallback onDone;

  @override
  State<DiseaseForm> createState() => _DiseaseFormState();
}

class _DiseaseFormState extends State<DiseaseForm> {
  final _form = GlobalKey<FormState>();
  late final _owner = TextEditingController(text: widget.edit?.ownerName ?? '');
  late final _phone = TextEditingController(text: widget.edit?.phone ?? '');
  late final _fee = TextEditingController(
      text: (widget.edit?.fee ?? 0) > 0 ? widget.edit!.fee.toString().replaceAll(RegExp(r'\.0$'), '') : '');
  late final _title = TextEditingController(text: widget.edit?.title ?? '');
  late final _temp = TextEditingController(text: widget.edit?.temperature ?? '');
  late final _symptoms = TextEditingController(text: widget.edit?.symptoms ?? '');
  late final _findings = TextEditingController(text: widget.edit?.findings ?? '');
  late final _treatment = TextEditingController(text: widget.edit?.treatment ?? '');
  late String _location = widget.edit?.location ?? 'Hospital';
  late bool _skin = widget.edit?.skinParasite ?? false;
  late String _prognosis = widget.edit?.prognosis ?? 'Good';
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_owner, _phone, _fee, _title, _temp, _symptoms, _findings, _treatment]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    final fee = _location == 'Private' ? parseAmount(_fee.text) : 0.0;
    final title = _title.text.trim();
    final owner = _owner.text.trim();
    final data = <String, dynamic>{
      'title': title,
      'ownerName': owner,
      'phone': _phone.text.trim(),
      'location': _location,
      'fee': fee,
      'temperature': _temp.text.trim(),
      'symptoms': _symptoms.text.trim(),
      'findings': _findings.text.trim(),
      'skinParasite': _skin,
      'treatment': _treatment.text.trim(),
      'prognosis': _prognosis,
    };
    final cashNote = '$title - $owner';
    setState(() => _busy = true);

    final edit = widget.edit;
    if (edit == null) {
      // New record: the private-practice fee goes to MY cashbook as income.
      final ownBiz = app.viewingOther ? null : app.bizId;
      data['businessId'] = ownBiz ?? '';
      final id = SharedRepo.create('diseases', data, uid: app.uid, name: app.fullName);
      if (fee > 0 && ownBiz != null) {
        HisabRepo(app.uid, ownBiz).setCash(
            id: 'd_$id',
            type: 'income',
            amount: fee,
            category: 'Consultation fee',
            note: cashNote,
            date: DateTime.now(),
            ref: 'disease');
      }
    } else {
      String biz = edit.businessId;
      if (biz.isEmpty && fee > 0 && edit.createdBy == app.uid && !app.viewingOther && app.bizId != null) {
        biz = app.bizId!;
        data['businessId'] = biz;
      }
      SharedRepo.update('diseases', edit.id, data);
      if (biz.isNotEmpty) {
        final h = HisabRepo(edit.createdBy, biz);
        final old = await h.cashFromCache('d_${edit.id}');
        if (fee > 0) {
          h.setCash(
              id: 'd_${edit.id}',
              old: old,
              type: 'income',
              amount: fee,
              category: 'Consultation fee',
              note: cashNote,
              date: old?.date ?? DateTime.now(),
              ref: 'disease');
        } else if (old != null) {
          h.deleteCash(old);
        }
      }
    }
    if (!mounted) return;
    snack(context, context.t('Saved'));
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        AppField(controller: _owner, label: 'Owner name', required: true),
        AppField(controller: _phone, label: 'Phone number', keyboard: TextInputType.phone),
        ChoiceRow(
          label: 'Location',
          value: _location,
          options: const {'Hospital': 'Hospital', 'Private': 'Private'},
          onChanged: (v) => setState(() => _location = v),
        ),
        if (_location == 'Private')
          AppField(
            controller: _fee,
            label: 'Fee taken',
            keyboard: const TextInputType.numberWithOptions(decimal: true),
            prefixText: '৳ ',
            validator: (s) => parseAmount(s ?? '') <= 0 ? 'Enter the fee (it is added to your cashbook income)' : null,
          ),
        AppField(controller: _title, label: 'Title of the disease', required: true),
        AppField(
            controller: _temp,
            label: 'Temperature',
            suffix: '°F',
            keyboard: const TextInputType.numberWithOptions(decimal: true)),
        AppField(controller: _symptoms, label: 'Signs & symptoms (told by owner)', maxLines: 6),
        AppField(controller: _findings, label: 'Clinical findings', maxLines: 6),
        ChoiceRow(
          label: 'Skin parasite',
          value: _skin ? 'Present' : 'Absent',
          options: const {'Present': 'Present', 'Absent': 'Absent'},
          onChanged: (v) => setState(() => _skin = v == 'Present'),
        ),
        WordField(controller: _treatment, label: 'Treatment', maxWords: 1000, minLines: 5, maxLines: 14),
        ChoiceRow(
          label: 'Prognosis after 10 days',
          value: _prognosis,
          options: const {'Good': 'Good', 'Poor': 'Poor'},
          onChanged: (v) => setState(() => _prognosis = v),
        ),
        _saveButton(context, _save, busy: _busy),
      ]),
    );
  }
}

// ===========================================================================
// PROBLEM & SOLUTION
// ===========================================================================
class ProblemForm extends StatefulWidget {
  const ProblemForm({super.key, this.edit, required this.onDone});
  final Problem? edit;
  final VoidCallback onDone;

  @override
  State<ProblemForm> createState() => _ProblemFormState();
}

class _ProblemFormState extends State<ProblemForm> {
  final _form = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.edit?.title ?? '');
  late final _problem = TextEditingController(text: widget.edit?.problem ?? '');
  late final _solution = TextEditingController(text: widget.edit?.solution ?? '');
  late final _prognosis = TextEditingController(text: widget.edit?.prognosis ?? '');

  @override
  void dispose() {
    for (final c in [_title, _problem, _solution, _prognosis]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final app = context.read<AppState>();
    final data = {
      'title': _title.text.trim(),
      'problem': _problem.text.trim(),
      'solution': _solution.text.trim(),
      'prognosis': _prognosis.text.trim(),
    };
    if (widget.edit == null) {
      SharedRepo.create('problems', data, uid: app.uid, name: app.fullName);
    } else {
      SharedRepo.update('problems', widget.edit!.id, data);
    }
    snack(context, context.t('Saved'));
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) => Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppField(controller: _title, label: 'Title', required: true),
          WordField(controller: _problem, label: 'Problem', maxWords: 1000, required: true, minLines: 4, maxLines: 12),
          WordField(controller: _solution, label: 'Solution', maxWords: 2000, required: true, minLines: 5, maxLines: 16),
          WordField(controller: _prognosis, label: 'Prognosis', maxWords: 300, minLines: 3, maxLines: 8),
          _saveButton(context, _save),
        ]),
      );
}
