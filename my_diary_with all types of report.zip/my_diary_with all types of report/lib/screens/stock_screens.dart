import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/pdf_reports.dart';
import '../core/repo.dart';
import '../core/utils.dart';
import '../core/widgets.dart';

String _qty(double v) => v % 1 == 0 ? v.toStringAsFixed(0) : v.toStringAsFixed(2);
String _plain(double v) => v % 1 == 0 ? v.toStringAsFixed(0) : v.toString();

// ===========================================================================
// STOCK & INVENTORY
// ===========================================================================
class StockScreen extends StatefulWidget {
  const StockScreen({super.key, required this.repo});
  final HisabRepo repo;

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  late final Stream<List<Product>> _stream = widget.repo.products();

  Future<void> _add() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (c) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
        child: _ProductSheet(repo: widget.repo),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Stock & Inventory'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: Text(context.t('Add product')),
        onPressed: _add,
      ),
      body: StreamBuilder<List<Product>>(
        stream: _stream,
        builder: (c, snap) {
          if (!snap.hasData) return const Loading();
          final list = snap.data!;
          final total = list.fold<double>(0, (a, p) => a + p.value);
          return Column(children: [
            Card(
              margin: const EdgeInsets.all(12),
              color: Colors.orange.withValues(alpha: 0.12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(c.t('Stock value'), style: const TextStyle(fontWeight: FontWeight.w600)),
                      Text(money(total), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                  Text('${list.length} products'),
                ]),
              ),
            ),
            Expanded(
              child: list.isEmpty
                  ? const EmptyState(message: 'No products yet', icon: Icons.inventory_2_outlined)
                  : ListView.separated(
                      padding: const EdgeInsets.only(bottom: 90),
                      itemCount: list.length,
                      separatorBuilder: (_, _) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final p = list[i];
                        final low = p.qty <= 0;
                        return ListTile(
                          title: Text(p.name),
                          subtitle: Text('${_qty(p.qty)} ${p.unit}  •  cost ${money(p.costPrice)}'),
                          trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(money(p.value), style: const TextStyle(fontWeight: FontWeight.bold)),
                            if (low) const Text('Out of stock', style: TextStyle(color: Colors.red, fontSize: 11)),
                          ]),
                          onTap: () => Navigator.push(
                              c,
                              MaterialPageRoute<void>(
                                  builder: (_) => ProductDetailScreen(repo: widget.repo, productId: p.id))),
                        );
                      },
                    ),
            ),
          ]);
        },
      ),
    );
  }
}

class _ProductSheet extends StatefulWidget {
  const _ProductSheet({required this.repo, this.edit});
  final HisabRepo repo;
  final Product? edit;

  @override
  State<_ProductSheet> createState() => _ProductSheetState();
}

class _ProductSheetState extends State<_ProductSheet> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.edit?.name ?? '');
  late final _unit = TextEditingController(text: widget.edit?.unit ?? 'pcs');
  final _qtyC = TextEditingController();
  final _cost = TextEditingController();
  late final _sell = TextEditingController(
      text: (widget.edit?.sellPrice ?? 0) > 0 ? _plain(widget.edit!.sellPrice) : '');
  DateTime _date = DateTime.now();

  @override
  void dispose() {
    for (final c in [_name, _unit, _qtyC, _cost, _sell]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.edit != null;
    return Form(
      key: _form,
      child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(16), children: [
        Text(editing ? 'Edit product' : 'Add product', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        AppField(controller: _name, label: 'Name', required: true),
        AppField(controller: _unit, label: 'Unit (pcs, kg, vial, box...)', required: true),
        if (!editing) ...[
          AppField(
              controller: _qtyC,
              label: 'Opening quantity',
              keyboard: const TextInputType.numberWithOptions(decimal: true)),
          AppField(
              controller: _cost,
              label: 'Buying price (per unit)',
              prefixText: '৳ ',
              keyboard: const TextInputType.numberWithOptions(decimal: true)),
        ],
        AppField(
            controller: _sell,
            label: 'Selling price (per unit)',
            prefixText: '৳ ',
            keyboard: const TextInputType.numberWithOptions(decimal: true)),
        if (!editing) DateField(label: 'Date entered', value: _date, onChanged: (d) => setState(() => _date = d)),
        FilledButton(
          onPressed: () {
            if (!_form.currentState!.validate()) return;
            if (editing) {
              widget.repo.updateProduct(widget.edit!.id,
                  name: _name.text.trim(), unit: _unit.text.trim(), sell: parseAmount(_sell.text));
            } else {
              widget.repo.addProduct(
                name: _name.text.trim(),
                unit: _unit.text.trim(),
                qty: parseAmount(_qtyC.text),
                cost: parseAmount(_cost.text),
                sell: parseAmount(_sell.text),
                date: _date,
              );
            }
            Navigator.pop(context);
          },
          child: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(context.t('Save'))),
        ),
      ]),
    );
  }
}

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key, required this.repo, required this.productId});
  final HisabRepo repo;
  final String productId;

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late final Stream<Product?> _product = widget.repo.product(widget.productId);
  late final Stream<List<StockMove>> _moves = widget.repo.moves(widget.productId);

  Future<void> _sheet(Widget child) => showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (c) => Padding(padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom), child: child),
      );

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Product?>(
      stream: _product,
      builder: (c, ps) {
        final p = ps.data;
        if (p == null) {
          return Scaffold(
              appBar: AppBar(),
              body: ps.connectionState == ConnectionState.waiting ? const Loading() : const EmptyState(message: 'Not found'));
        }
        return Scaffold(
          appBar: AppBar(
            title: Text(p.name),
            actions: [
              IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _sheet(_ProductSheet(repo: widget.repo, edit: p))),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  final nav = Navigator.of(context);
                  if (await confirmDialog(context, 'Delete product?', p.name)) {
                    widget.repo.deleteProduct(p.id);
                    nav.pop();
                  }
                },
              ),
            ],
          ),
          body: Column(children: [
            Card(
              margin: const EdgeInsets.all(12),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${_qty(p.qty)} ${p.unit} in stock',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text('Stock value: ${money(p.value)}'),
                  Text('Buying price: ${money(p.costPrice)}   |   Selling price: ${money(p.sellPrice)}'),
                  Text('Date entered: ${fmtDate(p.entered)}'),
                  Text('Last sold: ${p.lastSold == null ? '-' : fmtDate(p.lastSold!)}'),
                ]),
              ),
            ),
            Expanded(
              child: StreamBuilder<List<StockMove>>(
                stream: _moves,
                builder: (c, ms) {
                  if (!ms.hasData) return const Loading();
                  final list = ms.data!;
                  if (list.isEmpty) return const EmptyState(message: 'No stock movement yet');
                  return ListView.separated(
                    itemCount: list.length,
                    separatorBuilder: (_, _) => const Divider(height: 1),
                    itemBuilder: (c, i) {
                      final m = list[i];
                      final out = m.type == 'out';
                      return ListTile(
                        leading: Icon(out ? Icons.north_east : Icons.south_west, color: out ? Colors.red : Colors.green),
                        title: Text('${out ? 'Sold' : 'Stock in'}: ${_qty(m.qty)} ${p.unit}  @ ${money(m.unitPrice)}'),
                        subtitle: Text(out
                            ? '${fmtDate(m.date)}  •  ${m.buyerName}${m.buyerPhone.isEmpty ? '' : '  •  ${m.buyerPhone}'}'
                            : '${fmtDate(m.date)}${m.note.isEmpty ? '' : '  •  ${m.note}'}'),
                        trailing: Text(money(m.qty * m.unitPrice), style: const TextStyle(fontWeight: FontWeight.bold)),
                      );
                    },
                  );
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.add),
                      label: Text(c.t('Stock in')),
                      onPressed: () => _sheet(_StockInSheet(repo: widget.repo, product: p)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      icon: const Icon(Icons.sell),
                      label: Text(c.t('Sell / Stock out')),
                      onPressed: p.qty <= 0 ? null : () => _sheet(_StockOutSheet(repo: widget.repo, product: p)),
                    ),
                  ),
                ]),
              ),
            ),
          ]),
        );
      },
    );
  }
}

class _StockInSheet extends StatefulWidget {
  const _StockInSheet({required this.repo, required this.product});
  final HisabRepo repo;
  final Product product;

  @override
  State<_StockInSheet> createState() => _StockInSheetState();
}

class _StockInSheetState extends State<_StockInSheet> {
  final _form = GlobalKey<FormState>();
  final _qtyC = TextEditingController();
  late final _cost = TextEditingController(text: widget.product.costPrice > 0 ? _plain(widget.product.costPrice) : '');
  final _note = TextEditingController();
  DateTime _date = DateTime.now();

  @override
  void dispose() {
    _qtyC.dispose();
    _cost.dispose();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(16), children: [
        Text('Stock in • ${widget.product.name}', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        AppField(
          controller: _qtyC,
          label: 'Quantity',
          suffix: widget.product.unit,
          keyboard: const TextInputType.numberWithOptions(decimal: true),
          validator: (s) => parseAmount(s ?? '') <= 0 ? 'Enter quantity' : null,
        ),
        AppField(
            controller: _cost,
            label: 'Buying price (per unit)',
            prefixText: '৳ ',
            keyboard: const TextInputType.numberWithOptions(decimal: true)),
        AppField(controller: _note, label: 'Note / supplier'),
        DateField(label: 'Date entered', value: _date, onChanged: (d) => setState(() => _date = d)),
        FilledButton(
          onPressed: () {
            if (!_form.currentState!.validate()) return;
            widget.repo.stockIn(widget.product, parseAmount(_qtyC.text), parseAmount(_cost.text), _note.text.trim(), _date);
            Navigator.pop(context);
          },
          child: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(context.t('Save'))),
        ),
      ]),
    );
  }
}

class _StockOutSheet extends StatefulWidget {
  const _StockOutSheet({required this.repo, required this.product});
  final HisabRepo repo;
  final Product product;

  @override
  State<_StockOutSheet> createState() => _StockOutSheetState();
}

class _StockOutSheetState extends State<_StockOutSheet> {
  final _form = GlobalKey<FormState>();
  final _qtyC = TextEditingController();
  late final _price = TextEditingController(text: widget.product.sellPrice > 0 ? _plain(widget.product.sellPrice) : '');
  final _buyer = TextEditingController();
  final _phone = TextEditingController();
  DateTime _date = DateTime.now();
  bool _cash = true;

  @override
  void dispose() {
    for (final c in [_qtyC, _price, _buyer, _phone]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    return Form(
      key: _form,
      child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(16), children: [
        Text('Sell • ${p.name}  (available ${_qty(p.qty)} ${p.unit})', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        AppField(
          controller: _qtyC,
          label: 'Quantity',
          suffix: p.unit,
          keyboard: const TextInputType.numberWithOptions(decimal: true),
          validator: (s) {
            final q = parseAmount(s ?? '');
            if (q <= 0) return 'Enter quantity';
            if (q > p.qty) return 'Only ${_qty(p.qty)} ${p.unit} in stock';
            return null;
          },
        ),
        AppField(
            controller: _price,
            label: 'Selling price (per unit)',
            prefixText: '৳ ',
            keyboard: const TextInputType.numberWithOptions(decimal: true)),
        AppField(controller: _buyer, label: 'Buyer name', required: true),
        AppField(controller: _phone, label: 'Buyer phone', keyboard: TextInputType.phone),
        DateField(value: _date, onChanged: (d) => setState(() => _date = d)),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Add the sale to Cashbook income'),
          value: _cash,
          onChanged: (v) => setState(() => _cash = v),
        ),
        FilledButton(
          onPressed: () {
            if (!_form.currentState!.validate()) return;
            widget.repo.stockOut(p, parseAmount(_qtyC.text), parseAmount(_price.text), _buyer.text.trim(),
                _phone.text.trim(), _date,
                addToCash: _cash);
            Navigator.pop(context);
          },
          child: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(context.t('Save'))),
        ),
      ]),
    );
  }
}

// ===========================================================================
// GROUP REMINDERS
// ===========================================================================
class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key, required this.repo});
  final HisabRepo repo;

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  late final Stream<List<Party>> _stream = widget.repo.parties();
  final _selected = <String>{};
  String _channel = 'sms';
  late final TextEditingController _msg;
  List<Party> _queue = [];
  int _idx = -1; // -1 = not started

  @override
  void initState() {
    super.initState();
    _msg = TextEditingController(
        text: 'Dear {name}, your outstanding balance with {business} is Tk {amount}. Please pay at your earliest convenience. Thank you.');
  }

  @override
  void dispose() {
    _msg.dispose();
    super.dispose();
  }

  String _personal(Party p, Business? b) {
    var t = _msg.text
        .replaceAll('{name}', p.name)
        .replaceAll('{amount}', _plain(p.balance.abs()))
        .replaceAll('{business}', (b?.name ?? '').isEmpty ? 'My Business' : b!.name);
    if ((b?.payInfo ?? '').isNotEmpty) t = '$t\nPayment: ${b!.payInfo}';
    return t;
  }

  Future<void> _sendCurrent() async {
    final b = context.read<AppState>().business;
    final p = _queue[_idx];
    final text = _personal(p, b);
    final ok = _channel == 'sms' ? await sendSms(p.phone, text) : await sendWhatsApp(p.phone, text);
    if (!mounted) return;
    if (!ok) {
      snack(context, 'Could not open the messaging app.');
      return;
    }
    setState(() => _idx++);
  }

  @override
  Widget build(BuildContext context) {
    final started = _idx >= 0;
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Group Reminders'))),
      body: StreamBuilder<List<Party>>(
        stream: _stream,
        builder: (c, snap) {
          if (!snap.hasData) return const Loading();
          final due = snap.data!.where((p) => p.balance > 0).toList()
            ..sort((a, b) => b.balance.compareTo(a.balance));
          if (due.isEmpty) return const EmptyState(message: 'Nobody owes you money right now.', icon: Icons.celebration_outlined);

          if (started) {
            final finished = _idx >= _queue.length;
            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                LinearProgressIndicator(value: _idx / _queue.length),
                const SizedBox(height: 16),
                if (finished) ...[
                  const Icon(Icons.check_circle, size: 64, color: Colors.green),
                  const SizedBox(height: 8),
                  Text('All ${_queue.length} reminders processed.', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
                  const SizedBox(height: 16),
                  FilledButton(onPressed: () => setState(() => _idx = -1), child: const Text('Done')),
                ] else ...[
                  Text('Message ${_idx + 1} of ${_queue.length}', textAlign: TextAlign.center),
                  const SizedBox(height: 8),
                  Card(
                    child: ListTile(
                      title: Text(_queue[_idx].name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${_queue[_idx].phone}\n\n${_personal(_queue[_idx], context.read<AppState>().business)}'),
                      isThreeLine: true,
                    ),
                  ),
                  const SizedBox(height: 8),
                  FilledButton.icon(
                    icon: Icon(_channel == 'sms' ? Icons.sms : Icons.chat),
                    onPressed: _sendCurrent,
                    label: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Text(_channel == 'sms' ? 'Open SMS & send' : 'Open WhatsApp & send'),
                    ),
                  ),
                  TextButton(onPressed: () => setState(() => _idx++), child: const Text('Skip this one')),
                  TextButton(onPressed: () => setState(() => _idx = -1), child: const Text('Stop')),
                  const SizedBox(height: 8),
                  const Text(
                    'After sending, come back to this app and tap the button again for the next customer.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ]),
            );
          }

          final selectable = due.where((p) => p.phone.trim().isNotEmpty).toList();
          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: Column(children: [
                TextField(
                  controller: _msg,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Message  ({name} {amount} {business} are replaced automatically)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 8),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'sms', icon: Icon(Icons.sms), label: Text('SMS')),
                    ButtonSegment(value: 'wa', icon: Icon(Icons.chat), label: Text('WhatsApp')),
                  ],
                  selected: {_channel},
                  onSelectionChanged: (s) => setState(() => _channel = s.first),
                ),
              ]),
            ),
            CheckboxListTile(
              dense: true,
              title: Text('Select all (${selectable.length})'),
              value: selectable.isNotEmpty && _selected.length == selectable.length,
              onChanged: (v) => setState(() {
                _selected.clear();
                if (v == true) _selected.addAll(selectable.map((p) => p.id));
              }),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(children: [
                for (final p in due)
                  CheckboxListTile(
                    value: _selected.contains(p.id),
                    onChanged: p.phone.trim().isEmpty
                        ? null
                        : (v) => setState(() => v == true ? _selected.add(p.id) : _selected.remove(p.id)),
                    title: Text(p.name),
                    subtitle: Text(p.phone.isEmpty ? 'No phone number' : p.phone),
                    secondary: Text(money(p.balance), style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green.shade700)),
                  ),
              ]),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    icon: const Icon(Icons.send),
                    onPressed: _selected.isEmpty
                        ? null
                        : () => setState(() {
                              _queue = due.where((p) => _selected.contains(p.id)).toList();
                              _idx = 0;
                            }),
                    label: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Text('Start sending (${_selected.length})'),
                    ),
                  ),
                ),
              ),
            ),
          ]);
        },
      ),
    );
  }
}

// ===========================================================================
// REPORTS
// ===========================================================================
class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key, required this.repo});
  final HisabRepo repo;

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String _type = 'party';
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  String? _partyId;
  List<Party> _parties = [];
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    widget.repo.partiesOnce().then((l) {
      if (mounted) setState(() => _parties = l);
    }).catchError((Object _) {});
  }

  Future<Uint8List> _build() async {
    final biz = context.read<AppState>().business;
    final from = _month;
    final to = DateTime(_month.year, _month.month + 1);
    switch (_type) {
      case 'party':
        final p = _parties.firstWhere((e) => e.id == _partyId);
        final entries = await widget.repo.entriesOnce(p.id);
        return ReportBuilder.partyStatement(biz: biz, party: p, entries: entries);
      case 'stock':
        final products = await widget.repo.productsOnce();
        final moves = await widget.repo.movesOnce();
        return ReportBuilder.stockReport(biz: biz, products: products, moves: moves);
      case 'cost':
        final cash = await widget.repo.cashOnce(from, to);
        return ReportBuilder.costSavings(biz: biz, month: _month, cash: cash);
      default:
        final cash = await widget.repo.cashOnce(from, to);
        final parties = await widget.repo.partiesOnce();
        return ReportBuilder.monthly(biz: biz, month: _month, cash: cash, parties: parties);
    }
  }

  String get _fileName => switch (_type) {
        'party' => 'statement_${slug(_parties.where((e) => e.id == _partyId).firstOrNull?.name ?? 'party')}.pdf',
        'stock' => 'stock_report.pdf',
        'cost' => 'cost_savings_${_month.year}_${_month.month}.pdf',
        _ => 'monthly_report_${_month.year}_${_month.month}.pdf',
      };

  Future<void> _run(bool share) async {
    if (_type == 'party' && _partyId == null) {
      snack(context, 'Please choose a customer / supplier.');
      return;
    }
    setState(() => _busy = true);
    try {
      final bytes = await _build();
      final name = _fileName;
      if (share) {
        await Printing.sharePdf(bytes: bytes, filename: name);
      } else {
        await Printing.layoutPdf(onLayout: (_) async => bytes, name: name);
      }
    } catch (e) {
      if (mounted) snack(context, 'Could not create the report: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _pickMonth() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _month,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      helpText: 'Pick any day of the month',
    );
    if (d != null) setState(() => _month = DateTime(d.year, d.month));
  }

  @override
  Widget build(BuildContext context) {
    final needsMonth = _type == 'cost' || _type == 'monthly';
    return Scaffold(
      appBar: AppBar(title: Text(context.t('Reports'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(
          initialValue: _type,
          decoration: const InputDecoration(labelText: 'Report', border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'party', child: Text('Customer / Supplier statement')),
            DropdownMenuItem(value: 'stock', child: Text('Stock & Inventory report')),
            DropdownMenuItem(value: 'cost', child: Text('Cost & Savings report')),
            DropdownMenuItem(value: 'monthly', child: Text('Monthly report')),
          ],
          onChanged: (v) => setState(() => _type = v ?? 'party'),
        ),
        const SizedBox(height: 14),
        if (_type == 'party')
          DropdownButtonFormField<String>(
            key: ValueKey('p${_parties.length}'),
            initialValue: _partyId,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Customer / Supplier', border: OutlineInputBorder()),
            items: [
              for (final p in _parties)
                DropdownMenuItem(
                    value: p.id, child: Text('${p.name} (${p.type == 'customer' ? 'customer' : 'supplier'})', overflow: TextOverflow.ellipsis)),
            ],
            onChanged: (v) => setState(() => _partyId = v),
          ),
        if (needsMonth)
          InkWell(
            onTap: _pickMonth,
            child: InputDecorator(
              decoration: const InputDecoration(labelText: 'Month', border: OutlineInputBorder(), suffixIcon: Icon(Icons.calendar_month)),
              child: Text(fmtMonth(_month)),
            ),
          ),
        const SizedBox(height: 24),
        FilledButton.icon(
          icon: const Icon(Icons.share),
          onPressed: _busy ? null : () => _run(true),
          label: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text('${context.t('Share PDF')}  (WhatsApp / imo ...)')),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          icon: const Icon(Icons.print),
          onPressed: _busy ? null : () => _run(false),
          label: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(context.t('Print / Save PDF'))),
        ),
        if (_busy) const Padding(padding: EdgeInsets.only(top: 20), child: Center(child: CircularProgressIndicator())),
        const SizedBox(height: 20),
        Text(
          'Tip: choose "Share PDF" and pick WhatsApp or imo to send the statement directly to your customer or supplier.',
          style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.outline),
        ),
      ]),
    );
  }
}
