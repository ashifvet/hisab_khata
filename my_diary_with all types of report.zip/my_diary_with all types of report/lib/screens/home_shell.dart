import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/models.dart';
import '../core/repo.dart';
import '../core/utils.dart';
import 'add_screen.dart';
import 'hisab_screens.dart';
import 'library_screens.dart';
import 'menu_screens.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) runStartupChecks(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final h = app.hisab;

    final pages = <Widget>[
      h == null
          ? const Center(child: CircularProgressIndicator())
          : HisabHome(key: ValueKey('${h.owner}/${h.biz}'), repo: h),
      const CompaniesScreen(),
      const MedicinesScreen(),
      const DiseasesScreen(),
      const ProblemsScreen(),
      const AddScreen(),
    ];
    final titles = [
      'Hisab',
      'Companies',
      'Medicines',
      'Diseases',
      'Problems & Solutions',
      'Add',
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(context.t(titles[_index])),
        actions: [if (_index == 0) const BusinessMenu()],
      ),
      drawer: const AppDrawer(),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        height: 68,
        destinations: [
          NavigationDestination(
              icon: const Icon(Icons.account_balance_wallet_outlined),
              selectedIcon: const Icon(Icons.account_balance_wallet),
              label: context.t('Hisab')),
          NavigationDestination(
              icon: const Icon(Icons.business_outlined),
              selectedIcon: const Icon(Icons.business),
              label: context.t('Companies')),
          NavigationDestination(
              icon: const Icon(Icons.medication_outlined),
              selectedIcon: const Icon(Icons.medication),
              label: context.t('Medicines')),
          NavigationDestination(
              icon: const Icon(Icons.pets_outlined),
              selectedIcon: const Icon(Icons.pets),
              label: context.t('Diseases')),
          NavigationDestination(
              icon: const Icon(Icons.lightbulb_outline),
              selectedIcon: const Icon(Icons.lightbulb),
              label: context.t('P&S')),
          NavigationDestination(
              icon: const Icon(Icons.add_circle_outline),
              selectedIcon: const Icon(Icons.add_circle),
              label: context.t('Add')),
        ],
      ),
    );
  }
}

// ===========================================================================
// Drawer
// ===========================================================================
class AppDrawer extends StatefulWidget {
  const AppDrawer({super.key});

  @override
  State<AppDrawer> createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  String _version = '';

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((p) {
      if (mounted) setState(() => _version = '${p.version} (${p.buildNumber})');
    }).catchError((Object _) {});
  }

  void _go(Widget page) {
    Navigator.pop(context); // close drawer
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    return Drawer(
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + 24, 20, 20),
            color: cs.primaryContainer,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: cs.primary,
                child: Text(
                  app.fullName.isEmpty ? '?' : app.fullName.characters.first.toUpperCase(),
                  style: TextStyle(fontSize: 26, color: cs.onPrimary),
                ),
              ),
              const SizedBox(height: 12),
              Text('${context.t(greetingKey())},',
                  style: TextStyle(color: cs.onPrimaryContainer, fontSize: 14)),
              Text(app.fullName,
                  style: TextStyle(
                      color: cs.onPrimaryContainer, fontSize: 20, fontWeight: FontWeight.bold)),
              if (app.isAdmin)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(context.t('Administrator'),
                      style: TextStyle(color: cs.primary, fontWeight: FontWeight.w600)),
                ),
            ]),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                  leading: const Icon(Icons.person_outline),
                  title: Text(context.t('Edit Profile')),
                  onTap: () => _go(const ProfileScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.settings_outlined),
                  title: Text(context.t('Settings')),
                  onTap: () => _go(const SettingsScreen()),
                ),
                if (app.isAdmin) ...[
                  const Divider(),
                  ListTile(
                    leading: const Icon(Icons.campaign_outlined),
                    title: Text(context.t('Announcements')),
                    onTap: () => _go(const AnnouncementsScreen()),
                  ),
                  ListTile(
                    leading: const Icon(Icons.admin_panel_settings_outlined),
                    title: Text(context.t('Users & Admins')),
                    onTap: () => _go(const UsersScreen()),
                  ),
                  ListTile(
                    leading: const Icon(Icons.system_update_outlined),
                    title: Text(context.t('Publish App Version')),
                    onTap: () => _go(const PublishVersionScreen()),
                  ),
                ],
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(context.t('About Developer')),
                  onTap: () => _go(const AboutScreen()),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          ListTile(
            dense: true,
            leading: const Icon(Icons.verified_outlined),
            title: Text('${context.t('Version')} $_version'),
          ),
          ListTile(
            leading: Icon(Icons.logout, color: cs.error),
            title: Text(context.t('Logout'), style: TextStyle(color: cs.error)),
            onTap: () async {
              final ok = await confirmDialog(
                  context, context.t('Logout'), 'Do you want to log out?',
                  yes: context.t('Logout'));
              if (ok) {
                await AuthService.signOut();
              }
            },
          ),
          SizedBox(height: MediaQuery.of(context).padding.bottom),
        ],
      ),
    );
  }
}

// ===========================================================================
// Startup checks: forced update + announcement dialogs
// ===========================================================================
Future<void> runStartupChecks(BuildContext context) async {
  final app = context.read<AppState>();
  await _checkVersion(context);
  if (!context.mounted) return;
  await _showAnnouncements(context, app);
}

Future<void> _checkVersion(BuildContext context) async {
  try {
    final info = await PackageInfo.fromPlatform();
    final snap = await fs
        .collection('app_config')
        .doc('version')
        .get()
        .timeout(const Duration(seconds: 8));
    final d = snap.data();
    if (d == null) return;
    final latest = (d['latestVersion'] ?? '').toString();
    final minV = (d['minVersion'] ?? '').toString();
    final url = (d['updateUrl'] ?? '').toString();
    final msg = (d['message'] ?? '').toString();

    final force = minV.isNotEmpty && compareVersions(info.version, minV) < 0;
    final optional = latest.isNotEmpty && compareVersions(info.version, latest) < 0;
    if (!force && !optional) return;
    if (!context.mounted) return;

    await showDialog<void>(
      context: context,
      barrierDismissible: !force,
      builder: (c) => PopScope(
        canPop: !force,
        child: AlertDialog(
          icon: const Icon(Icons.system_update, size: 36),
          title: Text(force ? 'Update required' : 'New version available'),
          content: Text(
            '${msg.isEmpty ? (force ? 'Please update the app to continue.' : 'A newer version of My Diary is available.') : msg}\n\n'
            'Your version: ${info.version}\nLatest version: ${latest.isEmpty ? minV : latest}',
          ),
          actions: [
            if (!force) TextButton(onPressed: () => Navigator.pop(c), child: const Text('Later')),
            FilledButton(
              onPressed: () async {
                await openUrl(url);
                // A forced update keeps the dialog open until the app is updated.
                if (!force && c.mounted) Navigator.pop(c);
              },
              child: const Text('Update now'),
            ),
          ],
        ),
      ),
    );
  } catch (_) {
    // Offline or no version document yet: just continue.
  }
}

Future<void> _showAnnouncements(BuildContext context, AppState app) async {
  List<Announcement> list;
  try {
    final snap = await fs
        .collection('announcements')
        .get()
        .timeout(const Duration(seconds: 8));
    list = snap.docs.map((d) => Announcement.fromMap(d.id, d.data())).toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
  } catch (_) {
    return;
  }
  for (final a in list) {
    if (!a.active || app.seenCount(a.id) >= a.times) continue;
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (c) {
        final hasTg = a.telegram.trim().isNotEmpty;
        final hasWeb = a.web.trim().isNotEmpty;
        return PopScope(
          canPop: false,
          child: AlertDialog(
            title: Text(a.title),
            content: SingleChildScrollView(child: Text(a.content)),
            actions: [
              if (a.cancelAllowed)
                TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
              if (hasTg)
                FilledButton.icon(
                  icon: const Icon(Icons.send),
                  onPressed: () async {
                    await openUrl(a.telegram);
                    if (c.mounted) Navigator.pop(c);
                  },
                  label: const Text('Join Telegram'),
                ),
              if (hasWeb)
                FilledButton.icon(
                  icon: const Icon(Icons.language),
                  onPressed: () async {
                    await openUrl(a.web);
                    if (c.mounted) Navigator.pop(c);
                  },
                  label: const Text('Visit Web'),
                ),
              // Safety net so the user can never get stuck on a dialog that
              // has no buttons at all.
              if (!a.cancelAllowed && !hasTg && !hasWeb)
                FilledButton(onPressed: () => Navigator.pop(c), child: const Text('OK')),
            ],
          ),
        );
      },
    );
    app.markSeen(a.id);
  }
}
