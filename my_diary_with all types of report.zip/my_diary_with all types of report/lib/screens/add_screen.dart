import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/repo.dart';
import '../core/utils.dart';
import 'forms.dart';

/// The "Add" tab: Company | Medicine | Disease | Problems & Solutions
class AddScreen extends StatefulWidget {
  const AddScreen({super.key});

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  // Changing a key rebuilds (clears) the matching form after saving.
  int _c = 0, _m = 0, _d = 0, _p = 0;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Column(children: [
        TabBar(isScrollable: true, tabAlignment: TabAlignment.start, tabs: [
          Tab(text: context.t('Company')),
          Tab(text: context.t('Medicine')),
          Tab(text: context.t('Disease')),
          const Tab(text: 'P&S'),
        ]),
        Expanded(
          child: TabBarView(children: [
            CompanyForm(key: ValueKey('c$_c'), onDone: () => setState(() => _c++)),
            Column(children: [
              const ImportMedicinesCard(),
              Expanded(child: MedicineForm(key: ValueKey('m$_m'), onDone: () => setState(() => _m++))),
            ]),
            DiseaseForm(key: ValueKey('d$_d'), onDone: () => setState(() => _d++)),
            ProblemForm(key: ValueKey('p$_p'), onDone: () => setState(() => _p++)),
          ]),
        ),
      ]),
    );
  }
}

/// Imports the bundled veterinary medicine database (from MedEx).
/// Disabled for everybody once an import has been done.
class ImportMedicinesCard extends StatefulWidget {
  const ImportMedicinesCard({super.key});

  @override
  State<ImportMedicinesCard> createState() => _ImportMedicinesCardState();
}

class _ImportMedicinesCardState extends State<ImportMedicinesCard> {
  bool _busy = false;
  double _progress = 0;

  Future<void> _import() async {
    final app = context.read<AppState>();
    final shared = context.read<SharedData>();
    final ok = await confirmDialog(
      context,
      'Import medicines',
      'Import 430 veterinary medicines (9 companies) from the built-in MedEx database?\n\n'
          'Internet is required. After importing, this button is disabled for everybody.',
      yes: 'Import',
    );
    if (!ok || !mounted) return;
    setState(() {
      _busy = true;
      _progress = 0;
    });
    try {
      final n = await SharedRepo.importLocalMedicines(
        uid: app.uid,
        name: app.fullName,
        existingCompanySlugs: shared.companies.map((c) => slug(c.name)).toSet(),
        onProgress: (p) {
          if (mounted) setState(() => _progress = p);
        },
      );
      if (mounted) snack(context, '$n medicines imported');
    } catch (e) {
      if (mounted) snack(context, 'Import failed. Please check your internet connection and try again.');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final imported = context.select<SharedData, bool>((d) => d.medicinesImported);
    final cs = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      color: cs.secondaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(imported ? Icons.check_circle : Icons.download, color: cs.onSecondaryContainer),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                imported
                    ? 'Veterinary medicine database already imported.'
                    : 'Import 430 veterinary medicines from the built-in database (MedEx).',
                style: TextStyle(color: cs.onSecondaryContainer),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          if (_busy) LinearProgressIndicator(value: _progress == 0 ? null : _progress),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.tonal(
              // Disabled (null) once imported.
              onPressed: (imported || _busy) ? null : _import,
              child: Text(imported ? 'Imported' : context.t('Import medicines')),
            ),
          ),
        ]),
      ),
    );
  }
}
