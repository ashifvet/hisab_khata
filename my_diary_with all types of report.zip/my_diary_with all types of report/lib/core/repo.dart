import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'models.dart';
import 'utils.dart';

FirebaseFirestore get fs => FirebaseFirestore.instance;

/// Fire-and-forget write. IMPORTANT: Firestore write futures only complete
/// when the server confirms them, so awaiting them would freeze the UI while
/// offline. The local cache is updated instantly and the SDK syncs later.
void fire(Future<void> f) {
  f.catchError((Object e) {
    debugPrint('Firestore write error: $e');
  });
}

// ===========================================================================
// Authentication
// ===========================================================================
class AuthService {
  static const adminUsername = 'admin';
  static const adminEmail = 'admin@mydiary.app';
  static const adminPassword = 'Solution2@';

  /// "admin" -> admin@mydiary.app. Real e-mail addresses are used as they are.
  static String toEmail(String id) {
    final t = id.trim();
    return t.contains('@') ? t : '${t.toLowerCase()}@mydiary.app';
  }

  static String message(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'The e-mail / username is not valid.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
      case 'invalid-login-credentials':
        return 'Wrong username/e-mail or password.';
      case 'email-already-in-use':
        return 'This e-mail is already registered.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'network-request-failed':
        return 'No internet connection. Please connect once to log in.';
      case 'too-many-requests':
        return 'Too many attempts. Try again later.';
      default:
        return e.message ?? 'Something went wrong (${e.code}).';
    }
  }

  /// Returns null on success, otherwise an error message.
  static Future<String?> signIn(String id, String password) async {
    final auth = FirebaseAuth.instance;
    final email = toEmail(id);
    try {
      await auth.signInWithEmailAndPassword(email: email, password: password);
      return null;
    } on FirebaseAuthException catch (e) {
      final missing = e.code == 'user-not-found' ||
          e.code == 'invalid-credential' ||
          e.code == 'invalid-login-credentials';
      // First ever login of the default administrator: create the account.
      if (email == adminEmail && password == adminPassword && missing) {
        try {
          final c = await auth.createUserWithEmailAndPassword(
              email: email, password: password);
          await fs.collection('users').doc(c.user!.uid).set({
            'firstName': 'System',
            'lastName': 'Administrator',
            'email': email,
            'role': 'admin',
            'createdAt': Timestamp.now(),
          });
          return null;
        } on FirebaseAuthException catch (e2) {
          return message(e2);
        }
      }
      return message(e);
    } catch (e) {
      return e.toString();
    }
  }

  static Future<String?> register({
    required String firstName,
    required String lastName,
    required String email,
    required String phone,
    required String location,
    required String password,
  }) async {
    try {
      final c = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email.trim(), password: password);
      await fs.collection('users').doc(c.user!.uid).set({
        'firstName': firstName.trim(),
        'lastName': lastName.trim(),
        'email': email.trim(),
        'phone': phone.trim(),
        'location': location.trim(),
        'role': 'user',
        'createdAt': Timestamp.now(),
      });
      return null;
    } on FirebaseAuthException catch (e) {
      return message(e);
    } catch (e) {
      return e.toString();
    }
  }

  static Future<String?> changePassword(String current, String next) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email == null) return 'Not logged in.';
    try {
      final cred =
          EmailAuthProvider.credential(email: user.email!, password: current);
      await user.reauthenticateWithCredential(cred);
      await user.updatePassword(next);
      return null;
    } on FirebaseAuthException catch (e) {
      return message(e);
    }
  }

  /// Administrator creates another administrator account without being
  /// logged out (a second, temporary Firebase app instance is used).
  static Future<String?> createAdmin({
    required String name,
    required String email,
    required String password,
  }) async {
    FirebaseApp? second;
    try {
      for (final a in Firebase.apps) {
        if (a.name == 'adminCreator') second = a;
      }
      second ??= await Firebase.initializeApp(
          name: 'adminCreator', options: Firebase.app().options);
      final auth = FirebaseAuth.instanceFor(app: second);
      final c = await auth.createUserWithEmailAndPassword(email: email, password: password);
      final uid = c.user!.uid;
      await auth.signOut();
      // Written by the logged-in administrator (allowed by the security rules).
      await fs.collection('users').doc(uid).set({
        'firstName': name,
        'lastName': '',
        'email': email,
        'role': 'admin',
        'createdAt': Timestamp.now(),
      });
      return null;
    } on FirebaseAuthException catch (e) {
      return message(e);
    } catch (e) {
      return e.toString();
    }
  }

  static Future<void> signOut() => FirebaseAuth.instance.signOut();
}

// ===========================================================================
// Shared library: companies / medicines / diseases / problems
// ===========================================================================
class SharedRepo {
  /// Creates a document, returns its id. Never blocks while offline.
  static String create(String col, Json data,
      {required String uid, required String name, String? id}) {
    final ref = id == null ? fs.collection(col).doc() : fs.collection(col).doc(id);
    fire(ref.set({
      ...data,
      'createdBy': uid,
      'createdByName': name,
      'createdAt': Timestamp.now(),
    }));
    return ref.id;
  }

  static void update(String col, String id, Json data) =>
      fire(fs.collection(col).doc(id).update(data));

  static void delete(String col, String id) =>
      fire(fs.collection(col).doc(id).delete());

  /// Imports the bundled MedEx veterinary list. Needs internet (it must be
  /// confirmed by the server so the "already imported" flag is reliable).
  static Future<int> importLocalMedicines({
    required String uid,
    required String name,
    required Set<String> existingCompanySlugs,
    required void Function(double progress) onProgress,
  }) async {
    final raw = await rootBundle.loadString('assets/medicines.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    final companies = (data['companies'] as List).cast<String>();
    final meds = (data['medicines'] as List).cast<Map<String, dynamic>>();
    final now = Timestamp.now();

    final ops = <void Function(WriteBatch)>[];
    for (final c in companies) {
      if (existingCompanySlugs.contains(slug(c))) continue;
      final ref = fs.collection('companies').doc('c_${slug(c)}');
      ops.add((b) => b.set(ref, {
            'name': c,
            'description': 'Veterinary / animal health products',
            'createdBy': uid,
            'createdByName': name,
            'createdAt': now,
          }));
    }
    for (final m in meds) {
      final ref = fs.collection('medicines').doc(m['id'] as String);
      final company = m['company'] as String;
      ops.add((b) => b.set(ref, {
            'name': m['name'],
            'generic': m['generic'],
            'strength': m['strength'],
            'form': m['form'],
            'companyId': 'c_${slug(company)}',
            'companyName': company,
            'use': m['use'],
            'dose': m['dose'],
            'details': m['details'],
            'pregSafe': m['preg'] == true,
            'petSafe': m['pet'] == true,
            'imported': true,
            'createdBy': uid,
            'createdByName': name,
            'createdAt': now,
          }));
    }

    const chunk = 400;
    for (var i = 0; i < ops.length; i += chunk) {
      final b = fs.batch();
      for (final op in ops.skip(i).take(chunk)) {
        op(b);
      }
      await b.commit().timeout(const Duration(seconds: 60));
      onProgress(((i + chunk) / ops.length).clamp(0.0, 1.0));
    }
    await fs.collection('app_config').doc('seed').set({
      'medicinesImported': true,
      'by': uid,
      'at': now,
    }).timeout(const Duration(seconds: 30));
    return meds.length;
  }
}

/// Live copy of the shared library, kept in memory for instant screens.
class SharedData extends ChangeNotifier {
  List<Company> companies = [];
  List<Medicine> medicines = [];
  List<Disease> diseases = [];
  List<Problem> problems = [];
  bool medicinesImported = false;
  final List<StreamSubscription<dynamic>> _subs = [];

  int _cmp(String a, String b) => a.toLowerCase().compareTo(b.toLowerCase());

  void _listen<T>(String col, T Function(String, Json) f, void Function(List<T>) set) {
    _subs.add(fs.collection(col).snapshots().listen((s) {
      set(s.docs.map((d) => f(d.id, d.data())).toList());
      notifyListeners();
    }, onError: (Object e) => debugPrint('listen $col: $e')));
  }

  void start() {
    stop();
    _listen<Company>('companies', Company.fromMap,
        (l) => companies = l..sort((a, b) => _cmp(a.name, b.name)));
    _listen<Medicine>('medicines', Medicine.fromMap,
        (l) => medicines = l..sort((a, b) => _cmp(a.name, b.name)));
    _listen<Disease>('diseases', Disease.fromMap,
        (l) => diseases = l..sort((a, b) => b.createdAt.compareTo(a.createdAt)));
    _listen<Problem>('problems', Problem.fromMap,
        (l) => problems = l..sort((a, b) => _cmp(a.title, b.title)));
    _subs.add(fs.collection('app_config').doc('seed').snapshots().listen((s) {
      medicinesImported = s.data()?['medicinesImported'] == true;
      notifyListeners();
    }, onError: (Object e) => debugPrint('seed: $e')));
  }

  void stop() {
    for (final s in _subs) {
      s.cancel();
    }
    _subs.clear();
    companies = [];
    medicines = [];
    diseases = [];
    problems = [];
    medicinesImported = false;
  }

  @override
  void dispose() {
    stop();
    super.dispose();
  }
}

// ===========================================================================
// Hisab (private business data of one user)
// users/{owner}/businesses/{biz}/(parties|entries|cash|products|moves|notes)
// ===========================================================================
class HisabRepo {
  HisabRepo(this.owner, this.biz);
  final String owner, biz;

  static CollectionReference<Json> businessesOf(String owner) =>
      fs.collection('users').doc(owner).collection('businesses');

  static Stream<List<Business>> businesses(String owner) =>
      businessesOf(owner).snapshots().map((s) => s.docs
          .map((d) => Business.fromMap(d.id, d.data()))
          .toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt)));

  static void createBusiness(String owner, String name) {
    fire(businessesOf(owner).doc().set({
      'name': name,
      'phone': '',
      'address': '',
      'payInfo': '',
      'income': 0,
      'expense': 0,
      'saving': 0,
      'createdAt': Timestamp.now(),
    }));
  }

  DocumentReference<Json> get bizRef => businessesOf(owner).doc(biz);
  CollectionReference<Json> col(String n) => bizRef.collection(n);

  Stream<Business?> business() => bizRef
      .snapshots()
      .map((s) => s.exists ? Business.fromMap(s.id, s.data()!) : null);

  void updateBusiness(Json data) => fire(bizRef.set(data, SetOptions(merge: true)));

  // ---- parties -------------------------------------------------------------
  Stream<List<Party>> parties() => col('parties').snapshots().map((s) => s.docs
      .map((d) => Party.fromMap(d.id, d.data()))
      .toList()
    ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase())));

  Stream<Party?> party(String id) => col('parties')
      .doc(id)
      .snapshots()
      .map((s) => s.exists ? Party.fromMap(s.id, s.data()!) : null);

  Future<List<Party>> partiesOnce() async {
    final s = await col('parties').get();
    return s.docs.map((d) => Party.fromMap(d.id, d.data())).toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  }

  void saveParty({String? id, required String name, required String type, String phone = '', String address = ''}) {
    final ref = id == null ? col('parties').doc() : col('parties').doc(id);
    if (id == null) {
      fire(ref.set({
        'name': name,
        'type': type,
        'phone': phone,
        'address': address,
        'balance': 0,
        'createdAt': Timestamp.now(),
      }));
    } else {
      fire(ref.update({'name': name, 'phone': phone, 'address': address}));
    }
  }

  Stream<List<Entry>> entries(String partyId) => col('entries')
      .where('partyId', isEqualTo: partyId)
      .snapshots()
      .map((s) => s.docs.map((d) => Entry.fromMap(d.id, d.data())).toList()
        ..sort((a, b) => b.date.compareTo(a.date)));

  Future<List<Entry>> entriesOnce(String partyId) async {
    final s = await col('entries').where('partyId', isEqualTo: partyId).get();
    return s.docs.map((d) => Entry.fromMap(d.id, d.data())).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
  }

  /// Cash type produced by a ledger entry, or null when no money moves.
  static String? cashTypeFor(String partyType, String kind) {
    if (partyType == 'customer' && kind == 'got') return 'income';
    if (partyType == 'supplier' && kind == 'gave') return 'expense';
    return null;
  }

  void _totals(WriteBatch b, String type, double amount) {
    b.set(bizRef, {type: FieldValue.increment(amount)}, SetOptions(merge: true));
  }

  void addEntry(Party p, String kind, double amount, String note, DateTime date,
      {bool cash = false}) {
    final b = fs.batch();
    final ref = col('entries').doc();
    final cashType = cashTypeFor(p.type, kind);
    final linked = cash && cashType != null;
    b.set(ref, {
      'partyId': p.id,
      'partyName': p.name,
      'partyType': p.type,
      'kind': kind,
      'amount': amount,
      'note': note,
      'date': Timestamp.fromDate(date),
      'cash': linked,
    });
    b.update(col('parties').doc(p.id),
        {'balance': FieldValue.increment(kind == 'gave' ? amount : -amount)});
    if (linked) {
      b.set(col('cash').doc('e_${ref.id}'), {
        'type': cashType,
        'amount': amount,
        'category': p.type == 'customer' ? 'Customer payment' : 'Supplier payment',
        'note': '${p.name}${note.isEmpty ? '' : ' - $note'}',
        'date': Timestamp.fromDate(date),
        'ref': 'entry',
      });
      _totals(b, cashType, amount);
    }
    fire(b.commit());
  }

  void deleteEntry(Entry e) {
    final b = fs.batch();
    b.delete(col('entries').doc(e.id));
    b.update(col('parties').doc(e.partyId),
        {'balance': FieldValue.increment(-e.signed)});
    final cashType = cashTypeFor(e.partyType, e.kind);
    if (e.cash && cashType != null) {
      b.delete(col('cash').doc('e_${e.id}'));
      _totals(b, cashType, -e.amount);
    }
    fire(b.commit());
  }

  Future<void> deleteParty(Party p) async {
    final snap = await col('entries').where('partyId', isEqualTo: p.id).get();
    final b = fs.batch();
    for (final d in snap.docs) {
      final e = Entry.fromMap(d.id, d.data());
      b.delete(d.reference);
      final cashType = cashTypeFor(e.partyType, e.kind);
      if (e.cash && cashType != null) {
        b.delete(col('cash').doc('e_${e.id}'));
        _totals(b, cashType, -e.amount);
      }
    }
    b.delete(col('parties').doc(p.id));
    fire(b.commit());
  }

  // ---- cashbook ------------------------------------------------------------
  Stream<List<CashEntry>> cash(DateTime from, DateTime to) => col('cash')
      .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(from))
      .where('date', isLessThan: Timestamp.fromDate(to))
      .snapshots()
      .map((s) => s.docs.map((d) => CashEntry.fromMap(d.id, d.data())).toList()
        ..sort((a, b) => b.date.compareTo(a.date)));

  Future<List<CashEntry>> cashOnce(DateTime from, DateTime to) async {
    final s = await col('cash')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(from))
        .where('date', isLessThan: Timestamp.fromDate(to))
        .get();
    return s.docs.map((d) => CashEntry.fromMap(d.id, d.data())).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
  }

  /// Creates or replaces a cash entry and keeps business totals correct.
  void setCash({String? id, CashEntry? old, required String type, required double amount, String category = '', String note = '', required DateTime date, String ref = ''}) {
    final b = fs.batch();
    final doc = id == null ? col('cash').doc() : col('cash').doc(id);
    if (old != null) _totals(b, old.type, -old.amount);
    b.set(doc, {
      'type': type,
      'amount': amount,
      'category': category,
      'note': note,
      'date': Timestamp.fromDate(date),
      'ref': ref,
    });
    _totals(b, type, amount);
    fire(b.commit());
  }

  void deleteCash(CashEntry e) {
    final b = fs.batch();
    b.delete(col('cash').doc(e.id));
    _totals(b, e.type, -e.amount);
    fire(b.commit());
  }

  /// Reads one cash entry from the local cache only (works offline).
  Future<CashEntry?> cashFromCache(String id) async {
    try {
      final s = await col('cash').doc(id).get(const GetOptions(source: Source.cache));
      return s.exists ? CashEntry.fromMap(s.id, s.data()!) : null;
    } catch (_) {
      return null;
    }
  }

  // ---- stock ---------------------------------------------------------------
  Stream<List<Product>> products() => col('products').snapshots().map((s) => s.docs
      .map((d) => Product.fromMap(d.id, d.data()))
      .toList()
    ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase())));

  Future<List<Product>> productsOnce() async {
    final s = await col('products').get();
    return s.docs.map((d) => Product.fromMap(d.id, d.data())).toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  }

  Stream<Product?> product(String id) => col('products')
      .doc(id)
      .snapshots()
      .map((s) => s.exists ? Product.fromMap(s.id, s.data()!) : null);

  Stream<List<StockMove>> moves(String productId) => col('moves')
      .where('productId', isEqualTo: productId)
      .snapshots()
      .map((s) => s.docs.map((d) => StockMove.fromMap(d.id, d.data())).toList()
        ..sort((a, b) => b.date.compareTo(a.date)));

  Future<List<StockMove>> movesOnce() async {
    final s = await col('moves').get();
    return s.docs.map((d) => StockMove.fromMap(d.id, d.data())).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
  }

  void addProduct({required String name, required String unit, required double qty, required double cost, required double sell, required DateTime date}) {
    final b = fs.batch();
    final ref = col('products').doc();
    b.set(ref, {
      'name': name,
      'unit': unit,
      'qty': qty,
      'costPrice': cost,
      'sellPrice': sell,
      'entered': Timestamp.fromDate(date),
    });
    if (qty > 0) {
      b.set(col('moves').doc(), {
        'productId': ref.id,
        'productName': name,
        'type': 'in',
        'qty': qty,
        'unitPrice': cost,
        'unitCost': cost,
        'note': 'Opening stock',
        'date': Timestamp.fromDate(date),
      });
    }
    fire(b.commit());
  }

  void updateProduct(String id, {required String name, required String unit, required double sell}) =>
      fire(col('products').doc(id).update({'name': name, 'unit': unit, 'sellPrice': sell}));

  void deleteProduct(String id) => fire(col('products').doc(id).delete());

  void stockIn(Product p, double qty, double unitCost, String note, DateTime date) {
    final newQty = p.qty + qty;
    final newCost = newQty <= 0
        ? unitCost
        : ((p.qty * p.costPrice) + (qty * unitCost)) / newQty;
    final b = fs.batch();
    b.set(col('moves').doc(), {
      'productId': p.id,
      'productName': p.name,
      'type': 'in',
      'qty': qty,
      'unitPrice': unitCost,
      'unitCost': unitCost,
      'note': note,
      'date': Timestamp.fromDate(date),
    });
    b.update(col('products').doc(p.id),
        {'qty': FieldValue.increment(qty), 'costPrice': newCost});
    fire(b.commit());
  }

  void stockOut(Product p, double qty, double unitPrice, String buyerName,
      String buyerPhone, DateTime date, {bool addToCash = true}) {
    final b = fs.batch();
    final mv = col('moves').doc();
    b.set(mv, {
      'productId': p.id,
      'productName': p.name,
      'type': 'out',
      'qty': qty,
      'unitPrice': unitPrice,
      'unitCost': p.costPrice,
      'buyerName': buyerName,
      'buyerPhone': buyerPhone,
      'note': '',
      'date': Timestamp.fromDate(date),
    });
    b.update(col('products').doc(p.id), {
      'qty': FieldValue.increment(-qty),
      'lastSold': Timestamp.fromDate(date),
    });
    if (addToCash && unitPrice * qty > 0) {
      b.set(col('cash').doc('s_${mv.id}'), {
        'type': 'income',
        'amount': unitPrice * qty,
        'category': 'Sale',
        'note': '${p.name} x ${qty.toStringAsFixed(qty % 1 == 0 ? 0 : 2)} to $buyerName',
        'date': Timestamp.fromDate(date),
        'ref': 'sale',
      });
      _totals(b, 'income', unitPrice * qty);
    }
    fire(b.commit());
  }

  // ---- notes ---------------------------------------------------------------
  Stream<List<NoteItem>> notes() => col('notes').snapshots().map((s) => s.docs
      .map((d) => NoteItem.fromMap(d.id, d.data()))
      .toList()
    ..sort((a, b) => b.updated.compareTo(a.updated)));

  void saveNote(String? id, String title, String body) {
    final ref = id == null ? col('notes').doc() : col('notes').doc(id);
    fire(ref.set({'title': title, 'body': body, 'updated': Timestamp.now()}));
  }

  void deleteNote(String id) => fire(col('notes').doc(id).delete());
}
