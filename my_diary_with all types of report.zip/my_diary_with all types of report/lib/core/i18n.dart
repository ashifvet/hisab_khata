import 'package:flutter/widgets.dart';

/// Wraps the whole app so every widget that calls `context.t('...')`
/// is rebuilt automatically when the language changes.
class LangScope extends InheritedWidget {
  const LangScope({super.key, required this.lang, required super.child});
  final String lang;

  static String of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<LangScope>()?.lang ?? 'en';

  @override
  bool updateShouldNotify(LangScope old) => old.lang != lang;
}

extension TranslateX on BuildContext {
  /// Translate an English UI string (falls back to English when missing).
  String t(String s) => LangScope.of(this) == 'bn' ? (_bn[s] ?? s) : s;
}

const Map<String, String> _bn = {
  // navigation
  'Hisab': 'হিসাব',
  'Companies': 'কোম্পানি',
  'Medicines': 'ঔষধ',
  'Diseases': 'রোগ',
  'P&S': 'সমস্যা-সমাধান',
  'Add': 'যোগ করুন',
  'Problems & Solutions': 'সমস্যা ও সমাধান',
  // greetings
  'Good morning': 'শুভ সকাল',
  'Good afternoon': 'শুভ অপরাহ্ন',
  'Good evening': 'শুভ সন্ধ্যা',
  'Good night': 'শুভ রাত্রি',
  // drawer
  'Edit Profile': 'প্রোফাইল এডিট',
  'Settings': 'সেটিংস',
  'About Developer': 'ডেভেলপার সম্পর্কে',
  'Announcements': 'ঘোষণা',
  'Users & Admins': 'ইউজার ও অ্যাডমিন',
  'Publish App Version': 'অ্যাপ ভার্সন প্রকাশ',
  'Logout': 'লগআউট',
  'Version': 'ভার্সন',
  'Administrator': 'অ্যাডমিনিস্ট্রেটর',
  // settings
  'Dark mode': 'ডার্ক মোড',
  'Change password': 'পাসওয়ার্ড পরিবর্তন',
  'App language': 'অ্যাপের ভাষা',
  'Current password': 'বর্তমান পাসওয়ার্ড',
  'New password': 'নতুন পাসওয়ার্ড',
  'Password changed': 'পাসওয়ার্ড পরিবর্তন হয়েছে',
  // generic
  'Save': 'সংরক্ষণ',
  'Cancel': 'বাতিল',
  'Delete': 'মুছুন',
  'Edit': 'এডিট',
  'Search': 'খুঁজুন',
  'Name': 'নাম',
  'Phone': 'ফোন',
  'Location': 'ঠিকানা',
  'Email': 'ইমেইল',
  'First name': 'প্রথম নাম',
  'Last name': 'শেষ নাম',
  'Required': 'আবশ্যক',
  'Saved': 'সংরক্ষিত হয়েছে',
  'Nothing here yet': 'এখনো কিছু নেই',
  'Amount': 'পরিমাণ',
  'Note': 'নোট',
  'Date': 'তারিখ',
  'Total': 'মোট',
  'Yes': 'হ্যাঁ',
  'No': 'না',
  'Added by': 'যোগ করেছেন',
  // auth
  'Login': 'লগইন',
  'Register': 'নিবন্ধন',
  'Password': 'পাসওয়ার্ড',
  'Email or username': 'ইমেইল বা ইউজারনেম',
  'Create account': 'অ্যাকাউন্ট তৈরি করুন',
  // add tab
  'Company': 'কোম্পানি',
  'Medicine': 'ঔষধ',
  'Disease': 'রোগ',
  'Company name': 'কোম্পানির নাম',
  'Medicine name': 'ঔষধের নাম',
  'Components / generic': 'উপাদান / জেনেরিক',
  'When to use': 'কখন ব্যবহার করবেন',
  'Dose': 'ডোজ',
  'Pregnancy': 'গর্ভাবস্থা',
  'Pet safety': 'পোষা প্রাণীর জন্য',
  'Safe': 'নিরাপদ',
  'Unsafe': 'অনিরাপদ',
  'Other details': 'অন্যান্য তথ্য',
  'Owner name': 'মালিকের নাম',
  'Phone number': 'ফোন নম্বর',
  'Hospital': 'হাসপাতাল',
  'Private': 'প্রাইভেট',
  'Fee taken': 'ফি (টাকা)',
  'Title of the disease': 'রোগের শিরোনাম',
  'Temperature': 'তাপমাত্রা',
  'Signs & symptoms (told by owner)': 'লক্ষণ (মালিকের বর্ণনা)',
  'Clinical findings': 'ক্লিনিক্যাল ফাইন্ডিংস',
  'Skin parasite': 'চর্মের পরজীবী',
  'Present': 'আছে',
  'Absent': 'নেই',
  'Treatment': 'চিকিৎসা',
  'Prognosis after 10 days': '১০ দিন পর প্রাগনোসিস',
  'Good': 'ভালো',
  'Poor': 'খারাপ',
  'Title': 'শিরোনাম',
  'Problem': 'সমস্যা',
  'Solution': 'সমাধান',
  'Prognosis': 'প্রাগনোসিস',
  // medicines
  'All Medicines': 'সব ঔষধ',
  'Pregnancy Safe': 'গর্ভাবস্থায় নিরাপদ',
  'Pet Medicines': 'পোষা প্রাণীর ঔষধ',
  'All': 'সব',
  'Good Prognosis': 'ভালো প্রাগনোসিস',
  'Poor Prognosis': 'খারাপ প্রাগনোসিস',
  'Favourites': 'প্রিয়',
  // hisab
  "You'll get": 'পাবো',
  "You'll give": 'দেবো',
  'Cash balance': 'ক্যাশ ব্যালেন্স',
  'Stock value': 'স্টকের মূল্য',
  'Customers': 'কাস্টমার',
  'Suppliers': 'সাপ্লায়ার',
  'Cashbook': 'ক্যাশবুক',
  'Stock & Inventory': 'স্টক ও ইনভেন্টরি',
  'Business Notes': 'ব্যবসায়িক নোট',
  'Reports': 'রিপোর্ট',
  'Group Reminders': 'গ্রুপ রিমাইন্ডার',
  'Income': 'আয়',
  'Expense': 'খরচ',
  'Savings': 'সঞ্চয়',
  'You gave': 'দিলাম',
  'You got': 'পেলাম',
  'Manage businesses': 'ব্যবসা ম্যানেজ করুন',
  'Add product': 'পণ্য যোগ করুন',
  'Stock in': 'স্টক ইন',
  'Sell / Stock out': 'বিক্রি / স্টক আউট',
  'Quantity': 'পরিমাণ',
  'Buyer name': 'ক্রেতার নাম',
  'Buyer phone': 'ক্রেতার ফোন',
  'Share PDF': 'PDF শেয়ার',
  'Print / Save PDF': 'প্রিন্ট / PDF সেভ',
  'Send reminder': 'রিমাইন্ডার পাঠান',
  'Import medicines': 'ঔষধ ইমপোর্ট',
};
