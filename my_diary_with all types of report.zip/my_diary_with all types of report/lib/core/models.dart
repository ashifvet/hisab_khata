import 'package:cloud_firestore/cloud_firestore.dart';

typedef Json = Map<String, dynamic>;

String _s(Json m, String k) => (m[k] ?? '').toString();
double _d(Json m, String k) {
  final v = m[k];
  return v is num ? v.toDouble() : 0;
}

bool _b(Json m, String k) => m[k] == true;
DateTime _t(Json m, String k) {
  final v = m[k];
  return v is Timestamp ? v.toDate() : DateTime.fromMillisecondsSinceEpoch(0);
}

DateTime? _tn(Json m, String k) {
  final v = m[k];
  return v is Timestamp ? v.toDate() : null;
}

// ---------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------
class AppUser {
  AppUser({
    required this.uid,
    this.firstName = '',
    this.lastName = '',
    this.email = '',
    this.phone = '',
    this.location = '',
    this.designation = '',
    this.role = 'user',
  });
  final String uid, firstName, lastName, email, phone, location, designation, role;

  bool get isAdmin => role == 'admin';
  String get fullName {
    final n = '$firstName $lastName'.trim();
    if (n.isNotEmpty) return n;
    return email.split('@').first;
  }

  factory AppUser.fromMap(String id, Json m) => AppUser(
        uid: id,
        firstName: _s(m, 'firstName'),
        lastName: _s(m, 'lastName'),
        email: _s(m, 'email'),
        phone: _s(m, 'phone'),
        location: _s(m, 'location'),
        designation: _s(m, 'designation'),
        role: _s(m, 'role').isEmpty ? 'user' : _s(m, 'role'),
      );
}

// ---------------------------------------------------------------------------
// Shared library (visible to all users)
// ---------------------------------------------------------------------------
class Company {
  Company({
    required this.id,
    required this.name,
    this.description = '',
    this.createdBy = '',
    this.createdByName = '',
  });
  final String id, name, description, createdBy, createdByName;

  factory Company.fromMap(String id, Json m) => Company(
        id: id,
        name: _s(m, 'name'),
        description: _s(m, 'description'),
        createdBy: _s(m, 'createdBy'),
        createdByName: _s(m, 'createdByName'),
      );
}

class Medicine {
  Medicine({
    required this.id,
    required this.name,
    this.generic = '',
    this.strength = '',
    this.form = '',
    this.companyId = '',
    this.companyName = '',
    this.use = '',
    this.dose = '',
    this.details = '',
    this.pregSafe = false,
    this.petSafe = false,
    this.createdBy = '',
    this.createdByName = '',
  });
  final String id, name, generic, strength, form, companyId, companyName;
  final String use, dose, details, createdBy, createdByName;
  final bool pregSafe, petSafe;

  factory Medicine.fromMap(String id, Json m) => Medicine(
        id: id,
        name: _s(m, 'name'),
        generic: _s(m, 'generic'),
        strength: _s(m, 'strength'),
        form: _s(m, 'form'),
        companyId: _s(m, 'companyId'),
        companyName: _s(m, 'companyName'),
        use: _s(m, 'use'),
        dose: _s(m, 'dose'),
        details: _s(m, 'details'),
        pregSafe: _b(m, 'pregSafe'),
        petSafe: _b(m, 'petSafe'),
        createdBy: _s(m, 'createdBy'),
        createdByName: _s(m, 'createdByName'),
      );

  String get searchText =>
      '$name $generic $companyName $form $strength'.toLowerCase();
}

class Disease {
  Disease({
    required this.id,
    required this.title,
    this.ownerName = '',
    this.phone = '',
    this.location = 'Hospital',
    this.fee = 0,
    this.temperature = '',
    this.symptoms = '',
    this.findings = '',
    this.skinParasite = false,
    this.treatment = '',
    this.prognosis = 'Good',
    this.businessId = '',
    this.createdBy = '',
    this.createdByName = '',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
  final String id, title, ownerName, phone, location, temperature;
  final String symptoms, findings, treatment, prognosis, businessId;
  final String createdBy, createdByName;
  final double fee;
  final bool skinParasite;
  final DateTime createdAt;

  factory Disease.fromMap(String id, Json m) => Disease(
        id: id,
        title: _s(m, 'title'),
        ownerName: _s(m, 'ownerName'),
        phone: _s(m, 'phone'),
        location: _s(m, 'location').isEmpty ? 'Hospital' : _s(m, 'location'),
        fee: _d(m, 'fee'),
        temperature: _s(m, 'temperature'),
        symptoms: _s(m, 'symptoms'),
        findings: _s(m, 'findings'),
        skinParasite: _b(m, 'skinParasite'),
        treatment: _s(m, 'treatment'),
        prognosis: _s(m, 'prognosis').isEmpty ? 'Good' : _s(m, 'prognosis'),
        businessId: _s(m, 'businessId'),
        createdBy: _s(m, 'createdBy'),
        createdByName: _s(m, 'createdByName'),
        createdAt: _t(m, 'createdAt'),
      );

  String get searchText => '$title $ownerName $phone'.toLowerCase();
}

class Problem {
  Problem({
    required this.id,
    required this.title,
    this.problem = '',
    this.solution = '',
    this.prognosis = '',
    this.createdBy = '',
    this.createdByName = '',
  });
  final String id, title, problem, solution, prognosis, createdBy, createdByName;

  factory Problem.fromMap(String id, Json m) => Problem(
        id: id,
        title: _s(m, 'title'),
        problem: _s(m, 'problem'),
        solution: _s(m, 'solution'),
        prognosis: _s(m, 'prognosis'),
        createdBy: _s(m, 'createdBy'),
        createdByName: _s(m, 'createdByName'),
      );
}

class Announcement {
  Announcement({
    required this.id,
    this.title = '',
    this.content = '',
    this.telegram = '',
    this.web = '',
    this.cancelAllowed = true,
    this.times = 1,
    this.active = true,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
  final String id, title, content, telegram, web;
  final bool cancelAllowed, active;
  final int times;
  final DateTime createdAt;

  factory Announcement.fromMap(String id, Json m) => Announcement(
        id: id,
        title: _s(m, 'title'),
        content: _s(m, 'content'),
        telegram: _s(m, 'telegram'),
        web: _s(m, 'web'),
        cancelAllowed: m['cancelAllowed'] != false,
        times: (m['times'] is num) ? (m['times'] as num).toInt() : 1,
        active: m['active'] != false,
        createdAt: _t(m, 'createdAt'),
      );
}

// ---------------------------------------------------------------------------
// Hisab (private to each user)
// ---------------------------------------------------------------------------
class Business {
  Business({
    required this.id,
    required this.name,
    this.phone = '',
    this.address = '',
    this.payInfo = '',
    this.income = 0,
    this.expense = 0,
    this.saving = 0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
  final String id, name, phone, address, payInfo;
  final double income, expense, saving;
  final DateTime createdAt;

  double get cashBalance => income - expense - saving;

  factory Business.fromMap(String id, Json m) => Business(
        id: id,
        name: _s(m, 'name'),
        phone: _s(m, 'phone'),
        address: _s(m, 'address'),
        payInfo: _s(m, 'payInfo'),
        income: _d(m, 'income'),
        expense: _d(m, 'expense'),
        saving: _d(m, 'saving'),
        createdAt: _t(m, 'createdAt'),
      );
}

class Party {
  Party({
    required this.id,
    required this.name,
    required this.type,
    this.phone = '',
    this.address = '',
    this.balance = 0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);

  /// type: 'customer' or 'supplier'
  final String id, name, type, phone, address;

  /// balance = (total gave) - (total got).
  /// > 0 : you will get money.   < 0 : you will give money.
  final double balance;
  final DateTime createdAt;

  factory Party.fromMap(String id, Json m) => Party(
        id: id,
        name: _s(m, 'name'),
        type: _s(m, 'type').isEmpty ? 'customer' : _s(m, 'type'),
        phone: _s(m, 'phone'),
        address: _s(m, 'address'),
        balance: _d(m, 'balance'),
        createdAt: _t(m, 'createdAt'),
      );
}

class Entry {
  Entry({
    required this.id,
    required this.partyId,
    required this.partyName,
    required this.partyType,
    required this.kind,
    required this.amount,
    this.note = '',
    required this.date,
    this.cash = false,
  });

  /// kind: 'gave' or 'got'
  final String id, partyId, partyName, partyType, kind, note;
  final double amount;
  final DateTime date;
  final bool cash;

  /// Signed effect on the party balance.
  double get signed => kind == 'gave' ? amount : -amount;

  factory Entry.fromMap(String id, Json m) => Entry(
        id: id,
        partyId: _s(m, 'partyId'),
        partyName: _s(m, 'partyName'),
        partyType: _s(m, 'partyType'),
        kind: _s(m, 'kind'),
        amount: _d(m, 'amount'),
        note: _s(m, 'note'),
        date: _t(m, 'date'),
        cash: _b(m, 'cash'),
      );
}

class CashEntry {
  CashEntry({
    required this.id,
    required this.type,
    required this.amount,
    this.category = '',
    this.note = '',
    required this.date,
    this.ref = '',
  });

  /// type: 'income' | 'expense' | 'saving'
  final String id, type, category, note, ref;
  final double amount;
  final DateTime date;

  factory CashEntry.fromMap(String id, Json m) => CashEntry(
        id: id,
        type: _s(m, 'type'),
        amount: _d(m, 'amount'),
        category: _s(m, 'category'),
        note: _s(m, 'note'),
        date: _t(m, 'date'),
        ref: _s(m, 'ref'),
      );
}

class Product {
  Product({
    required this.id,
    required this.name,
    this.unit = 'pcs',
    this.qty = 0,
    this.costPrice = 0,
    this.sellPrice = 0,
    required this.entered,
    this.lastSold,
  });
  final String id, name, unit;
  final double qty, costPrice, sellPrice;
  final DateTime entered;
  final DateTime? lastSold;

  double get value => qty * costPrice;

  factory Product.fromMap(String id, Json m) => Product(
        id: id,
        name: _s(m, 'name'),
        unit: _s(m, 'unit').isEmpty ? 'pcs' : _s(m, 'unit'),
        qty: _d(m, 'qty'),
        costPrice: _d(m, 'costPrice'),
        sellPrice: _d(m, 'sellPrice'),
        entered: _t(m, 'entered'),
        lastSold: _tn(m, 'lastSold'),
      );
}

class StockMove {
  StockMove({
    required this.id,
    required this.productId,
    required this.productName,
    required this.type,
    required this.qty,
    this.unitPrice = 0,
    this.unitCost = 0,
    this.buyerName = '',
    this.buyerPhone = '',
    this.note = '',
    required this.date,
  });

  /// type: 'in' | 'out'
  final String id, productId, productName, type, buyerName, buyerPhone, note;
  final double qty, unitPrice, unitCost;
  final DateTime date;

  factory StockMove.fromMap(String id, Json m) => StockMove(
        id: id,
        productId: _s(m, 'productId'),
        productName: _s(m, 'productName'),
        type: _s(m, 'type'),
        qty: _d(m, 'qty'),
        unitPrice: _d(m, 'unitPrice'),
        unitCost: _d(m, 'unitCost'),
        buyerName: _s(m, 'buyerName'),
        buyerPhone: _s(m, 'buyerPhone'),
        note: _s(m, 'note'),
        date: _t(m, 'date'),
      );
}

class NoteItem {
  NoteItem({required this.id, this.title = '', this.body = '', required this.updated});
  final String id, title, body;
  final DateTime updated;

  factory NoteItem.fromMap(String id, Json m) => NoteItem(
        id: id,
        title: _s(m, 'title'),
        body: _s(m, 'body'),
        updated: _t(m, 'updated'),
      );
}
