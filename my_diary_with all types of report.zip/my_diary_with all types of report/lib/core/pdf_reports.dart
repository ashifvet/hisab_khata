import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import 'models.dart';
import 'utils.dart';

/// Builds printable / shareable PDF reports.
class ReportBuilder {
  static Future<pw.ThemeData> _theme() async {
    try {
      // Bengali-capable font (downloaded once, needs internet the first time).
      final base = await PdfGoogleFonts.notoSansBengaliRegular();
      final bold = await PdfGoogleFonts.notoSansBengaliBold();
      return pw.ThemeData.withFont(base: base, bold: bold);
    } catch (_) {
      return pw.ThemeData.base();
    }
  }

  static String _m(num v) => money(v, sym: 'Tk');
  static String _d(DateTime? d) => d == null ? '-' : fmtDate(d);
  static String _n(double v) => v % 1 == 0 ? v.toStringAsFixed(0) : v.toStringAsFixed(2);

  static pw.Widget _header(Business? biz, String title, String subtitle) {
    return pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      pw.Text(biz?.name ?? 'My Diary', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
      if ((biz?.phone ?? '').isNotEmpty || (biz?.address ?? '').isNotEmpty)
        pw.Text([biz?.phone ?? '', biz?.address ?? ''].where((e) => e.isNotEmpty).join('  |  '),
            style: const pw.TextStyle(fontSize: 10)),
      pw.SizedBox(height: 8),
      pw.Text(title, style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold, color: PdfColors.teal800)),
      if (subtitle.isNotEmpty) pw.Text(subtitle, style: const pw.TextStyle(fontSize: 10)),
      pw.Text('Generated: ${fmtDate(DateTime.now())}', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
      pw.Divider(),
    ]);
  }

  static pw.Widget _table(List<String> headers, List<List<String>> rows, {Map<int, pw.Alignment>? align}) {
    if (rows.isEmpty) {
      return pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 8),
        child: pw.Text('No data', style: const pw.TextStyle(color: PdfColors.grey700)),
      );
    }
    return pw.TableHelper.fromTextArray(
      headers: headers,
      data: rows,
      headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 9),
      headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
      cellStyle: const pw.TextStyle(fontSize: 9),
      cellPadding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3),
      cellAlignments: align,
      border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.4),
    );
  }

  static pw.Widget _h2(String t) => pw.Padding(
        padding: const pw.EdgeInsets.only(top: 14, bottom: 4),
        child: pw.Text(t, style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
      );

  static pw.Widget _kv(String k, String v, {PdfColor? color}) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 1),
        child: pw.Row(children: [
          pw.SizedBox(width: 170, child: pw.Text(k, style: const pw.TextStyle(fontSize: 10))),
          pw.Text(v, style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold, color: color)),
        ]),
      );

  static Future<Uint8List> _build(List<pw.Widget> Function() children) async {
    final doc = pw.Document(theme: await _theme());
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      build: (ctx) => children(),
      footer: (ctx) => pw.Align(
        alignment: pw.Alignment.centerRight,
        child: pw.Text('My Diary  -  page ${ctx.pageNumber}/${ctx.pagesCount}',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
      ),
    ));
    return doc.save();
  }

  // -------------------------------------------------------------------------
  // Customer / supplier statement
  // -------------------------------------------------------------------------
  static Future<Uint8List> partyStatement({
    required Business? biz,
    required Party party,
    required List<Entry> entries, // oldest first
  }) {
    final sorted = [...entries]..sort((a, b) => a.date.compareTo(b.date));
    double run = 0, gave = 0, got = 0;
    final rows = <List<String>>[];
    for (final e in sorted) {
      run += e.signed;
      if (e.kind == 'gave') {
        gave += e.amount;
      } else {
        got += e.amount;
      }
      rows.add([
        _d(e.date),
        e.note,
        e.kind == 'gave' ? _m(e.amount) : '',
        e.kind == 'got' ? _m(e.amount) : '',
        _m(run.abs()) + (run > 0 ? ' (get)' : (run < 0 ? ' (give)' : '')),
      ]);
    }
    final bal = party.balance;
    return _build(() => [
          _header(biz, '${party.type == 'customer' ? 'Customer' : 'Supplier'} statement',
              '${party.name}${party.phone.isEmpty ? '' : '  |  ${party.phone}'}'),
          _table(['Date', 'Note', 'You gave', 'You got', 'Balance'], rows, align: {
            2: pw.Alignment.centerRight,
            3: pw.Alignment.centerRight,
            4: pw.Alignment.centerRight,
          }),
          pw.SizedBox(height: 10),
          _kv('Total you gave', _m(gave)),
          _kv('Total you got', _m(got)),
          _kv(bal >= 0 ? 'Net amount you will get' : 'Net amount you will give', _m(bal.abs()),
              color: bal >= 0 ? PdfColors.green800 : PdfColors.red800),
        ]);
  }

  // -------------------------------------------------------------------------
  // Stock & inventory
  // -------------------------------------------------------------------------
  static Future<Uint8List> stockReport({
    required Business? biz,
    required List<Product> products,
    required List<StockMove> moves,
  }) {
    final totalValue = products.fold<double>(0, (a, p) => a + p.value);
    final prodRows = [
      for (final p in products)
        [
          p.name,
          p.unit,
          _d(p.entered),
          _n(p.qty),
          _m(p.costPrice),
          _m(p.value),
          _m(p.sellPrice),
          _d(p.lastSold),
        ]
    ];
    final moveRows = [
      for (final m in moves)
        [
          _d(m.date),
          m.productName,
          m.type == 'in' ? 'IN' : 'OUT',
          _n(m.qty),
          _m(m.unitPrice),
          m.type == 'out' ? m.buyerName : m.note,
          m.type == 'out' ? m.buyerPhone : '',
        ]
    ];
    return _build(() => [
          _header(biz, 'Stock & inventory report', '${products.length} products'),
          _table(['Product', 'Unit', 'Date entered', 'Qty', 'Cost', 'Stock value', 'Sell price', 'Last sold'], prodRows,
              align: {3: pw.Alignment.centerRight, 4: pw.Alignment.centerRight, 5: pw.Alignment.centerRight, 6: pw.Alignment.centerRight}),
          pw.SizedBox(height: 8),
          _kv('Total stock value', _m(totalValue)),
          _h2('Stock movements (entered / sold)'),
          _table(['Date', 'Product', 'Type', 'Qty', 'Unit price', 'Buyer / note', 'Buyer phone'], moveRows,
              align: {3: pw.Alignment.centerRight, 4: pw.Alignment.centerRight}),
        ]);
  }

  static List<List<String>> _byCategory(List<CashEntry> list, String type) {
    final map = <String, double>{};
    for (final e in list.where((e) => e.type == type)) {
      final k = e.category.isEmpty ? 'Other' : e.category;
      map[k] = (map[k] ?? 0) + e.amount;
    }
    final keys = map.keys.toList()..sort((a, b) => map[b]!.compareTo(map[a]!));
    return [for (final k in keys) [k, _m(map[k]!)]];
  }

  // -------------------------------------------------------------------------
  // Cost & savings
  // -------------------------------------------------------------------------
  static Future<Uint8List> costSavings({
    required Business? biz,
    required DateTime month,
    required List<CashEntry> cash,
  }) {
    final exp = cash.where((e) => e.type == 'expense').toList();
    final sav = cash.where((e) => e.type == 'saving').toList();
    final te = exp.fold<double>(0, (a, e) => a + e.amount);
    final ts = sav.fold<double>(0, (a, e) => a + e.amount);
    List<List<String>> rows(List<CashEntry> l) => [
          for (final e in l) [_d(e.date), e.category, e.note, _m(e.amount)]
        ];
    return _build(() => [
          _header(biz, 'Cost & savings report', fmtMonth(month)),
          _kv('Total cost', _m(te), color: PdfColors.red800),
          _kv('Total savings', _m(ts), color: PdfColors.blue800),
          _h2('Cost by category'),
          _table(['Category', 'Amount'], _byCategory(cash, 'expense'), align: {1: pw.Alignment.centerRight}),
          _h2('All costs'),
          _table(['Date', 'Category', 'Note', 'Amount'], rows(exp), align: {3: pw.Alignment.centerRight}),
          _h2('Savings'),
          _table(['Date', 'Category', 'Note', 'Amount'], rows(sav), align: {3: pw.Alignment.centerRight}),
        ]);
  }

  // -------------------------------------------------------------------------
  // Monthly report
  // -------------------------------------------------------------------------
  static Future<Uint8List> monthly({
    required Business? biz,
    required DateTime month,
    required List<CashEntry> cash,
    required List<Party> parties,
  }) {
    double inc = 0, exp = 0, sav = 0;
    final days = <int, List<double>>{};
    for (final e in cash) {
      final d = days.putIfAbsent(e.date.day, () => [0, 0, 0]);
      if (e.type == 'income') {
        inc += e.amount;
        d[0] += e.amount;
      } else if (e.type == 'expense') {
        exp += e.amount;
        d[1] += e.amount;
      } else if (e.type == 'saving') {
        sav += e.amount;
        d[2] += e.amount;
      }
    }
    final dayKeys = days.keys.toList()..sort();
    final dayRows = [
      for (final k in dayKeys)
        [
          '${k.toString().padLeft(2, '0')} ${fmtMonth(month)}',
          _m(days[k]![0]),
          _m(days[k]![1]),
          _m(days[k]![2]),
        ]
    ];
    final recv = parties.where((p) => p.balance > 0).toList();
    final pay = parties.where((p) => p.balance < 0).toList();
    final net = inc - exp - sav;
    return _build(() => [
          _header(biz, 'Monthly report', fmtMonth(month)),
          _kv('Total income', _m(inc), color: PdfColors.green800),
          _kv('Total expense', _m(exp), color: PdfColors.red800),
          _kv('Total savings', _m(sav), color: PdfColors.blue800),
          _kv('Net cash change', _m(net), color: net >= 0 ? PdfColors.green800 : PdfColors.red800),
          _h2('Income by category'),
          _table(['Category', 'Amount'], _byCategory(cash, 'income'), align: {1: pw.Alignment.centerRight}),
          _h2('Expense by category'),
          _table(['Category', 'Amount'], _byCategory(cash, 'expense'), align: {1: pw.Alignment.centerRight}),
          _h2('Day by day'),
          _table(['Date', 'Income', 'Expense', 'Savings'], dayRows,
              align: {1: pw.Alignment.centerRight, 2: pw.Alignment.centerRight, 3: pw.Alignment.centerRight}),
          _h2('Current dues - you will get'),
          _table(['Name', 'Type', 'Phone', 'Amount'],
              [for (final p in recv) [p.name, p.type, p.phone, _m(p.balance)]],
              align: {3: pw.Alignment.centerRight}),
          _h2('Current dues - you will give'),
          _table(['Name', 'Type', 'Phone', 'Amount'],
              [for (final p in pay) [p.name, p.type, p.phone, _m(-p.balance)]],
              align: {3: pw.Alignment.centerRight}),
        ]);
  }
}
