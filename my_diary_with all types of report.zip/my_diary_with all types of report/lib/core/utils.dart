import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

/// Number of words in [s].
int wordCount(String s) {
  final t = s.trim();
  return t.isEmpty ? 0 : t.split(RegExp(r'\s+')).length;
}

/// Compare two version strings like "1.2.3" or "1.2.3+4". Returns <0, 0, >0.
int compareVersions(String a, String b) {
  List<int> parse(String v) => v
      .split('+')
      .first
      .split('.')
      .map((e) => int.tryParse(e.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0)
      .toList();
  final x = parse(a), y = parse(b);
  for (var i = 0; i < 3; i++) {
    final xi = i < x.length ? x[i] : 0;
    final yi = i < y.length ? y[i] : 0;
    if (xi != yi) return xi.compareTo(yi);
  }
  return 0;
}

String money(num v, {String sym = '৳'}) =>
    '$sym ${NumberFormat('#,##0.##').format(v)}';

String fmtDate(DateTime d) => DateFormat('dd MMM yyyy').format(d);
String fmtMonth(DateTime d) => DateFormat('MMMM yyyy').format(d);

double parseAmount(String s) =>
    double.tryParse(s.trim().replaceAll(',', '')) ?? 0;

/// Bangladeshi phone -> international digits (01711... -> 8801711...).
String normalizePhone(String raw) {
  var d = raw.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('00')) d = d.substring(2);
  if (d.startsWith('01') && d.length == 11) d = '88$d';
  return d;
}

String slug(String s) => s
    .toLowerCase()
    .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
    .replaceAll(RegExp(r'^_+|_+$'), '');

String greetingKey() {
  final h = DateTime.now().hour;
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  if (h < 20) return 'Good evening';
  return 'Good night';
}

void snack(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<bool> confirmDialog(BuildContext context, String title, String message,
    {String yes = 'Delete', String no = 'Cancel'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(no)),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(yes)),
      ],
    ),
  );
  return r ?? false;
}

/// Opens [url] in the browser / external app.
Future<bool> openUrl(String url) async {
  var u = url.trim();
  if (u.isEmpty) return false;
  if (!u.contains(':')) u = 'https://$u';
  try {
    return await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}

Future<bool> callNumber(String phone) => openUrl('tel:${phone.trim()}');

Future<bool> sendSms(String phone, String body) {
  final sep = defaultTargetPlatform == TargetPlatform.iOS ? '&' : '?';
  return openUrl('sms:${phone.trim()}${sep}body=${Uri.encodeComponent(body)}');
}

Future<bool> sendWhatsApp(String phone, String body) => openUrl(
    'https://wa.me/${normalizePhone(phone)}?text=${Uri.encodeComponent(body)}');
