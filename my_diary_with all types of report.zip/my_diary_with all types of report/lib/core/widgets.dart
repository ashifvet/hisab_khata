import 'package:flutter/material.dart';

import 'i18n.dart';
import 'utils.dart';

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, this.message = 'Nothing here yet', this.icon = Icons.inbox_outlined});
  final String message;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(context.t(message),
                textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).colorScheme.outline)),
          ]),
        ),
      );
}

class SearchBox extends StatelessWidget {
  const SearchBox({super.key, required this.controller, this.hint = 'Search', this.onChanged});
  final TextEditingController controller;
  final String hint;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
        child: TextField(
          controller: controller,
          onChanged: onChanged,
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search),
            hintText: context.t(hint),
            isDense: true,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(28)),
            suffixIcon: controller.text.isEmpty
                ? null
                : IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      controller.clear();
                      onChanged?.call('');
                    }),
          ),
        ),
      );
}

/// Text field with a live word counter and a maximum word limit.
class WordField extends StatelessWidget {
  const WordField({
    super.key,
    required this.controller,
    required this.label,
    required this.maxWords,
    this.minLines = 3,
    this.maxLines = 8,
    this.required = false,
  });
  final TextEditingController controller;
  final String label;
  final int maxWords, minLines, maxLines;
  final bool required;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<TextEditingValue>(
      valueListenable: controller,
      builder: (context, v, _) {
        final n = wordCount(v.text);
        return Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: TextFormField(
            controller: controller,
            minLines: minLines,
            maxLines: maxLines,
            keyboardType: TextInputType.multiline,
            decoration: InputDecoration(
              labelText: context.t(label) + (required ? ' *' : ''),
              alignLabelWithHint: true,
              border: const OutlineInputBorder(),
              counterText: '$n / $maxWords words',
              counterStyle: TextStyle(
                  color: n > maxWords ? Theme.of(context).colorScheme.error : null),
            ),
            validator: (s) {
              final c = wordCount(s ?? '');
              if (required && c == 0) return context.t('Required');
              if (c > maxWords) return 'Maximum $maxWords words allowed';
              return null;
            },
          ),
        );
      },
    );
  }
}

/// Normal text field with consistent look.
class AppField extends StatelessWidget {
  const AppField({
    super.key,
    required this.controller,
    required this.label,
    this.required = false,
    this.keyboard,
    this.maxLines = 1,
    this.suffix,
    this.validator,
    this.prefixText,
  });
  final TextEditingController controller;
  final String label;
  final bool required;
  final TextInputType? keyboard;
  final int maxLines;
  final String? suffix, prefixText;
  final String? Function(String?)? validator;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TextFormField(
          controller: controller,
          keyboardType: keyboard ?? (maxLines > 1 ? TextInputType.multiline : null),
          minLines: 1,
          maxLines: maxLines,
          decoration: InputDecoration(
            labelText: context.t(label) + (required ? ' *' : ''),
            border: const OutlineInputBorder(),
            suffixText: suffix,
            prefixText: prefixText,
          ),
          validator: validator ??
              (required
                  ? (s) => (s == null || s.trim().isEmpty) ? context.t('Required') : null
                  : null),
        ),
      );
}

/// Segmented choice (e.g. Safe / Unsafe).
class ChoiceRow extends StatelessWidget {
  const ChoiceRow({super.key, required this.label, required this.value, required this.options, required this.onChanged});
  final String label;
  final String value;

  /// stored value -> shown label (English, translated automatically)
  final Map<String, String> options;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(context.t(label), style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 6),
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<String>(
              segments: [
                for (final e in options.entries)
                  ButtonSegment<String>(value: e.key, label: Text(context.t(e.value))),
              ],
              selected: {value},
              showSelectedIcon: false,
              onSelectionChanged: (s) => onChanged(s.first),
            ),
          ),
        ]),
      );
}

class DateField extends StatelessWidget {
  const DateField({super.key, required this.value, required this.onChanged, this.label = 'Date'});
  final DateTime value;
  final ValueChanged<DateTime> onChanged;
  final String label;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: InkWell(
          onTap: () async {
            final d = await showDatePicker(
              context: context,
              initialDate: value,
              firstDate: DateTime(2000),
              lastDate: DateTime(2100),
            );
            if (d != null) {
              onChanged(DateTime(d.year, d.month, d.day, DateTime.now().hour, DateTime.now().minute));
            }
          },
          child: InputDecorator(
            decoration: InputDecoration(
              labelText: context.t(label),
              border: const OutlineInputBorder(),
              suffixIcon: const Icon(Icons.calendar_today, size: 18),
            ),
            child: Text(fmtDate(value)),
          ),
        ),
      );
}

/// Label + selectable text block used in detail pages.
class DetailBlock extends StatelessWidget {
  const DetailBlock(this.label, this.text, {super.key});
  final String label;
  final String text;

  @override
  Widget build(BuildContext context) {
    if (text.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(context.t(label),
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        SelectableText(text, style: const TextStyle(fontSize: 15, height: 1.4)),
      ]),
    );
  }
}

class Pill extends StatelessWidget {
  const Pill(this.text, {super.key, required this.color, this.icon});
  final String text;
  final Color color;
  final IconData? icon;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.14),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[Icon(icon, size: 14, color: color), const SizedBox(width: 4)],
          Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
      );
}

/// Shows a message while loading data.
class Loading extends StatelessWidget {
  const Loading({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: CircularProgressIndicator());
}
