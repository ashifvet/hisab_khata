import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'repo.dart';

class AppState extends ChangeNotifier {
  final SharedData shared = SharedData();
  SharedPreferences? _prefs;

  ThemeMode themeMode = ThemeMode.light;
  String lang = 'en';

  bool authReady = false;
  User? user;
  AppUser? profile;

  List<Business> businesses = [];
  String? bizId;
  bool _creatingBiz = false;

  /// When an administrator opens another user's Hisab.
  String? viewUid;
  String? viewName;

  Set<String> favs = {};

  StreamSubscription<User?>? _authSub;
  StreamSubscription<dynamic>? _profSub, _bizSub, _favSub;

  static const maxBusinesses = 5;

  // ---- derived ---------------------------------------------------------------
  bool get isAdmin => profile?.isAdmin == true;
  String get uid => user?.uid ?? '';
  String get ownerUid => viewUid ?? uid;
  bool get viewingOther => viewUid != null && viewUid != uid;
  String get fullName =>
      profile?.fullName ?? (user?.email?.split('@').first ?? '');

  bool canEdit(String createdBy) => isAdmin || (uid.isNotEmpty && createdBy == uid);

  Business? get business {
    for (final b in businesses) {
      if (b.id == bizId) return b;
    }
    return null;
  }

  HisabRepo? get hisab =>
      (user == null || bizId == null) ? null : HisabRepo(ownerUid, bizId!);

  // ---- lifecycle ---------------------------------------------------------------
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    themeMode = (_prefs!.getBool('dark') ?? false) ? ThemeMode.dark : ThemeMode.light;
    lang = _prefs!.getString('lang') ?? 'en';
    _authSub = FirebaseAuth.instance.authStateChanges().listen(_onAuth);
  }

  void _onAuth(User? u) {
    _profSub?.cancel();
    _bizSub?.cancel();
    _favSub?.cancel();
    user = u;
    viewUid = null;
    viewName = null;
    businesses = [];
    bizId = null;
    favs = {};
    profile = null;
    shared.stop();
    if (u != null) {
      _profSub = fs.collection('users').doc(u.uid).snapshots().listen((s) {
        if (s.exists) {
          profile = AppUser.fromMap(s.id, s.data()!);
          notifyListeners();
        } else if (!s.metadata.isFromCache) {
          // Account exists but no profile document yet: create a basic one.
          fire(fs.collection('users').doc(u.uid).set({
            'email': u.email ?? '',
            'role': u.email == AuthService.adminEmail ? 'admin' : 'user',
            'createdAt': Timestamp.now(),
          }, SetOptions(merge: true)));
        }
      }, onError: (Object e) => debugPrint('profile: $e'));
      shared.start();
      _listenBusinesses();
      _favSub = fs
          .collection('users')
          .doc(u.uid)
          .collection('favorites')
          .snapshots()
          .listen((s) {
        favs = s.docs.map((d) => d.id).toSet();
        notifyListeners();
      }, onError: (Object e) => debugPrint('favs: $e'));
    }
    authReady = true;
    notifyListeners();
  }

  void _listenBusinesses() {
    _bizSub?.cancel();
    if (user == null) return;
    final owner = ownerUid;
    _bizSub = HisabRepo.businessesOf(owner).snapshots().listen((snap) {
      final list = snap.docs.map((d) => Business.fromMap(d.id, d.data())).toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      businesses = list;
      if (list.isEmpty) {
        // Only create the first business when the SERVER confirmed there is
        // none (a cache-only empty result could just be a new device).
        if (!snap.metadata.isFromCache && !viewingOther && !_creatingBiz) {
          _creatingBiz = true;
          HisabRepo.createBusiness(owner, 'My Business');
        }
        bizId = null;
      } else {
        _creatingBiz = false;
        final saved = _prefs?.getString('biz_$owner');
        if (bizId == null || !list.any((b) => b.id == bizId)) {
          bizId = list.any((b) => b.id == saved) ? saved : list.first.id;
        }
      }
      notifyListeners();
    }, onError: (Object e) => debugPrint('businesses: $e'));
  }

  // ---- actions -----------------------------------------------------------------
  void setBusiness(String id) {
    bizId = id;
    _prefs?.setString('biz_$ownerUid', id);
    notifyListeners();
  }

  /// Returns an error message or null.
  String? addBusiness(String name) {
    if (businesses.length >= maxBusinesses) {
      return 'You can manage up to $maxBusinesses businesses.';
    }
    HisabRepo.createBusiness(ownerUid, name.trim());
    return null;
  }

  void viewUser(String uid, String name) {
    viewUid = uid;
    viewName = name;
    bizId = null;
    businesses = [];
    _listenBusinesses();
    notifyListeners();
  }

  void stopViewing() {
    viewUid = null;
    viewName = null;
    bizId = null;
    businesses = [];
    _listenBusinesses();
    notifyListeners();
  }

  void toggleFavorite(String medId) {
    if (user == null) return;
    final ref = fs.collection('users').doc(uid).collection('favorites').doc(medId);
    if (favs.contains(medId)) {
      favs = {...favs}..remove(medId);
      fire(ref.delete());
    } else {
      favs = {...favs, medId};
      fire(ref.set({'at': Timestamp.now()}));
    }
    notifyListeners();
  }

  void setDark(bool v) {
    themeMode = v ? ThemeMode.dark : ThemeMode.light;
    _prefs?.setBool('dark', v);
    notifyListeners();
  }

  void setLang(String l) {
    lang = l;
    _prefs?.setString('lang', l);
    notifyListeners();
  }

  void updateProfile(Json data) {
    if (user == null) return;
    fire(fs.collection('users').doc(uid).set(data, SetOptions(merge: true)));
  }

  /// Number of times an announcement was already shown on this device.
  int seenCount(String id) => _prefs?.getInt('ann_$id') ?? 0;
  void markSeen(String id) => _prefs?.setInt('ann_$id', seenCount(id) + 1);

  @override
  void dispose() {
    _authSub?.cancel();
    _profSub?.cancel();
    _bizSub?.cancel();
    _favSub?.cancel();
    shared.dispose();
    super.dispose();
  }
}
