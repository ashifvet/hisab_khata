import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:my_diary/core/app_state.dart';
import 'package:my_diary/core/i18n.dart';
import 'package:my_diary/core/models.dart';
import 'package:my_diary/screens/add_screen.dart';
import 'package:my_diary/screens/auth_screen.dart';
import 'package:my_diary/screens/library_screens.dart';
import 'package:provider/provider.dart';

Widget host(AppState app, Widget child, {String lang = 'en'}) => MultiProvider(
      providers: [
        ChangeNotifierProvider<AppState>.value(value: app),
        ChangeNotifierProvider.value(value: app.shared),
      ],
      child: LangScope(
        lang: lang,
        child: MaterialApp(home: Scaffold(body: child)),
      ),
    );

AppState seeded() {
  final app = AppState();
  app.shared.companies = [Company(id: 'c1', name: 'Square Pharmaceuticals PLC')];
  app.shared.medicines = [
    Medicine(id: 'm1', name: 'Alpha Vet', generic: 'Ivermectin', companyId: 'c1', companyName: 'Square Pharmaceuticals PLC', pregSafe: true, petSafe: true, use: 'Worms', dose: '1ml'),
    Medicine(id: 'm2', name: 'Beta Vet', generic: 'Oxytetracycline', companyId: 'c1', companyName: 'Square Pharmaceuticals PLC'),
  ];
  app.shared.diseases = [
    Disease(id: 'd1', title: 'Mange', ownerName: 'Karim', phone: '017', prognosis: 'Good'),
    Disease(id: 'd2', title: 'Parvo', ownerName: 'Rahim', phone: '018', prognosis: 'Poor'),
  ];
  app.shared.problems = [Problem(id: 'p1', title: 'Milk drop', problem: 'Low milk', solution: 'Feed')];
  return app;
}

void main() {
  testWidgets('medicines tabs filter correctly', (t) async {
    await t.pumpWidget(host(seeded(), const MedicinesScreen()));
    expect(find.textContaining('Alpha Vet'), findsOneWidget);
    expect(find.textContaining('Beta Vet'), findsOneWidget);
    await t.tap(find.textContaining('Pregnancy Safe'));
    await t.pumpAndSettle();
    expect(find.textContaining('Alpha Vet'), findsOneWidget);
    expect(find.textContaining('Beta Vet'), findsNothing);
    await t.tap(find.textContaining('Pet Medicines'));
    await t.pumpAndSettle();
    expect(find.textContaining('Alpha Vet'), findsOneWidget);
    // search
    await t.enterText(find.byType(TextField), 'oxytetra');
    await t.pumpAndSettle();
    await t.tap(find.textContaining('All Medicines'));
    await t.pumpAndSettle();
    expect(find.textContaining('Beta Vet'), findsOneWidget);
    expect(find.textContaining('Alpha Vet'), findsNothing);
  });

  testWidgets('medicine detail shows all details', (t) async {
    await t.pumpWidget(host(seeded(), const MedicineDetailScreen(medicineId: 'm1')));
    expect(find.text('Ivermectin'), findsOneWidget);
    expect(find.text('Worms'), findsOneWidget);
    expect(find.textContaining('Pregnancy: Safe'), findsOneWidget);
  });

  testWidgets('diseases tabs', (t) async {
    await t.pumpWidget(host(seeded(), const DiseasesScreen()));
    expect(find.text('Mange'), findsOneWidget);
    expect(find.text('Parvo'), findsOneWidget);
    await t.tap(find.textContaining('Poor Prognosis'));
    await t.pumpAndSettle();
    expect(find.text('Parvo'), findsOneWidget);
    expect(find.text('Mange'), findsNothing);
  });

  testWidgets('companies + detail + problems', (t) async {
    final app = seeded();
    await t.pumpWidget(host(app, const CompaniesScreen()));
    expect(find.text('Square Pharmaceuticals PLC'), findsOneWidget);
    await t.tap(find.text('Square Pharmaceuticals PLC'));
    await t.pumpAndSettle();
    // favourites empty first
    expect(find.textContaining('No favourite'), findsOneWidget);
    await t.tap(find.textContaining('All ('));
    await t.pumpAndSettle();
    expect(find.textContaining('Alpha Vet'), findsOneWidget);
  });

  testWidgets('problems list + detail', (t) async {
    await t.pumpWidget(host(seeded(), const ProblemsScreen()));
    expect(find.text('Milk drop'), findsOneWidget);
    await t.tap(find.text('Milk drop'));
    await t.pumpAndSettle();
    expect(find.text('Feed'), findsOneWidget);
  });

  testWidgets('add screen renders all four forms and import card', (t) async {
    await t.binding.setSurfaceSize(const Size(420, 900));
    final app = seeded();
    await t.pumpWidget(host(app, const AddScreen()));
    expect(find.textContaining('Company name'), findsOneWidget);
    await t.tap(find.text('Medicine'));
    await t.pumpAndSettle();
    expect(find.textContaining('Import'), findsWidgets);
    // import enabled until flag is set, then disabled
    FilledButton btn() => t.widget<FilledButton>(find.widgetWithText(FilledButton, 'Import medicines'));
    expect(btn().onPressed, isNotNull);
    app.shared.medicinesImported = true;
    app.shared.notifyListeners();
    await t.pumpAndSettle();
    expect(t.widget<FilledButton>(find.widgetWithText(FilledButton, 'Imported')).onPressed, isNull);
    await t.tap(find.text('Disease'));
    await t.pumpAndSettle();
    expect(find.textContaining('Owner name'), findsOneWidget);
    // choosing Private shows the fee box
    expect(find.textContaining('Fee taken'), findsNothing);
    await t.tap(find.text('Private'));
    await t.pumpAndSettle();
    expect(find.textContaining('Fee taken'), findsOneWidget);
    await t.tap(find.text('P&S'));
    await t.pumpAndSettle();
    expect(find.textContaining('0 / 1000 words'), findsOneWidget);
    expect(find.textContaining('0 / 2000 words'), findsOneWidget);
    expect(find.textContaining('0 / 300 words'), findsOneWidget);
  });

  testWidgets('bangla translation works', (t) async {
    await t.pumpWidget(host(seeded(), const DiseasesScreen(), lang: 'bn'));
    expect(find.textContaining('সব'), findsWidgets);
  });

  testWidgets('auth screen toggles register', (t) async {
    await t.binding.setSurfaceSize(const Size(420, 900));
    await t.pumpWidget(host(seeded(), const AuthScreen()));
    expect(find.text('Login'), findsWidgets);
    await t.tap(find.textContaining('New user'));
    await t.pumpAndSettle();
    expect(find.text('Create account'), findsOneWidget);
  });
}
