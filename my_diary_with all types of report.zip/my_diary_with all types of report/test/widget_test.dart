import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:my_diary/core/utils.dart';

void main() {
  test('word counter', () {
    expect(wordCount(''), 0);
    expect(wordCount('  one   two\nthree '), 3);
  });

  test('version compare', () {
    expect(compareVersions('1.0.0', '1.0.1') < 0, true);
    expect(compareVersions('1.2.0+5', '1.2.0'), 0);
    expect(compareVersions('2.0.0', '1.9.9') > 0, true);
    expect(compareVersions('1.10.0', '1.9.0') > 0, true);
  });

  test('phone normalisation', () {
    expect(normalizePhone('01711-989236'), '8801711989236');
    expect(normalizePhone('+8801711989236'), '8801711989236');
  });

  test('slug', () {
    expect(slug('Square Pharmaceuticals PLC'), 'square_pharmaceuticals_plc');
  });

  test('bundled medicine database is valid', () {
    final data = jsonDecode(File('assets/medicines.json').readAsStringSync()) as Map<String, dynamic>;
    final meds = (data['medicines'] as List).cast<Map<String, dynamic>>();
    expect(meds.length, greaterThan(400));
    final ids = meds.map((m) => m['id']).toSet();
    expect(ids.length, meds.length); // unique ids
    expect((data['companies'] as List).length, greaterThan(10));
    for (final m in meds) {
      expect((m['name'] as String).isNotEmpty, true);
      expect((m['company'] as String).isNotEmpty, true);
    }
  });
}
