import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/db.dart';

/// The 13 companies from your list.
const _companies = <(String, String, String)>[
  ('renata', 'Renata PLC (Animal Health)',
      'Antibacterials, nutritional supplements and poultry vaccines.'),
  ('acme', 'The ACME Laboratories Ltd (Veterinary Unit)',
      'Antibiotics, vitamins, minerals, antihistamines, dewormers and aquaculture products.'),
  ('aci', 'ACI Limited / ACI Animal Health',
      'Livestock, poultry, aquaculture and pet health products, feed supplements and vaccines.'),
  ('square', 'Square Pharmaceuticals PLC (Veterinary Division)',
      'Vitamins, minerals, antibacterials and anti-protozoals.'),
  ('opsonin', 'Opsonin Pharma Limited (Agrovet)',
      'Vitamins, antibacterials, dewormers and feed additives.'),
  ('skf', 'Eskayef Pharmaceuticals Ltd. (Animal Health)',
      'Electrolytes, NSAIDs and animal nutrition products.'),
  ('incepta', 'Incepta Pharmaceuticals Ltd (Animal Health)',
      'Antibacterial combinations and vaccines.'),
  ('popular', 'Popular Pharmaceuticals PLC (Agrovet)',
      'Vitamin and mineral solutions.'),
  ('navana', 'Navana Pharmaceuticals PLC (Veterinary)',
      'Vitamins, antibacterials and veterinary formulations.'),
  ('aristo', 'Aristopharma Ltd (Animal Health Division)',
      'Animal health division serving livestock and poultry.'),
  ('everest', 'Everest Agrogenics Ltd.',
      'Amino acids, minerals, and bird/pet health lines.'),
  ('techno', 'Techno Drugs Ltd',
      'Veterinary and specialized medicines.'),
  ('gentry', 'Gentry Pharmaceuticals Ltd.',
      'Privately held animal health company.'),
];

/// ACME Laboratories veterinary brands, copied from
/// https://www.acmeglobal.com/products/veterinary/brand/
/// Format:  Brand | Category | Composition (as printed on the website;
/// some texts are shortened by the website itself).
/// Pregnancy / pet safety are NOT on the website, so they are saved as
/// "Unknown" - open the medicine, press Edit and choose Safe / Unsafe.
const _acme = '''
A-CAL VET|Nutritionals|Calcium, Magnesium, Phosphorus, Dextrose & Boric acid
A-COLD VET|Expectorant|Bromhexine
A-MECTIN PLUS VET|Anthelmintic|Ivermectin & Clorsulon
A-MECTIN VET|Anthelmintic|Ivermectin
A-MILK VET|Vitamin & Mineral|Herbs, Vitamin, Mineral & Amino Acids
A-SOL VET|Anthelmintic|Ivermectin
A-XYLA VET|Sedative|Xylazine Hydrochloride USP
AC-MILK VET|Milk Replacer|Whey powder, Vegetable oils (palm, rapeseed, copra), Soya flour, Skimmed milk
ACIDIFIER VET|Acidifier|Lactic acid, Citric Acid, Formic Acid, Phosphoric Acid, Acetic acid
ACME-S EGG FORMULA VET|Vitamin & Mineral|Vitamin A 3000 IU, Vitamin D3 1000 IU, Vitamin E 2 mg, Vitamin K3 2 mg and others
ACME-S ZEOLITE VET|Aqua Product|Natural zeolite
Acmetil Vet|Antibiotics|Tilmicosin Phosphate INN
ACMEZYME Vet|Enzymes|Multienzyme
ACME's BKC|Disinfectant|Benzalkonium Chloride
ACXIN VET|Antibiotics|Difloxacin Hydrochloride Trihydrate BP
Amflor Vet|Antibiotics|Florfenicol INN
Amflor Vet Inj|Antibiotic & Chemotherapeutics|Florfenicol INN
Amflor Vet Plus|Antibiotic & Anti-Inflammatory|Florfenicol INN & Flunixin USP
AMMOCURE VET|Vitamin & Mineral|Yucca Schidigera
Ammogut Vet|Nutritionals|Yucca extract, Formic acid, Propionic acid, Phosphoric acid, Monopropylene glycol
Anora Vet|GI Products|Cobalt Sulphate, Ferrous sulphate, Vitamin B1, Vitamin B12, Choline bitartrate
ANTICOC VET|Anticoccidial|Toltrazuril INN
Arbocin Vet|Antibiotics|Marbofloxacin
ASTA-VET|Antihistamine|Pheniramine Maleate
Atical-Vet|Nutritionals|Active Calcium, Calcium, Active Phosphorus, Phosphorus, Leptadenia reticulata
ATIVET Vet|Antibiotics|Trimethoprim & Sulphadiazine
AURITOX-PLUS Vet|Toxin Binder|Yeast Extract, Citric Acid, Phosphoric Acid, Malic Acid
AviMax Vet|Nutritional Supplement|Vitamin, Mineral and Amino Acid
Babecure Vet|Anthelmintic|Imidocarb Dipropionate
Benazol Vet|Anthelmintic|Albendazole
BETALYTE VET|Vitamin & Mineral|Betaine, Vitamin-C, Potassium Chloride, Magnesium Chloride, Calcium
BIOGUT VET|Probiotics|Probiotic, prebiotic, enzyme, vitamin, mineral & amino acids
BIOGUT VET PLUS|Probiotics|Probiotic-Prebiotic formulation fortified with Yeast, Enzyme, Vitamin
Biovigor|Growth Promoter|Growth factor, Chelated trace element, Probiotics, Yeast & Biofactor
BLOAT STOP VET|GI Products|Simethicone
BOVI CARE VET|GI Products|Gentian, Calcium, Silicium oxide, dl-Methionine & others
BRONCHOVET|Expectorant|Herbal Extract & Vitamins
CALNANO VET|Nutritional Supplement|Calcium (Nano), Phosphorus (Nano), Magnesium (Nano), Phytobio-Calphos
CEFQUEEN VET|Antibiotics|Cefquinome sulfate INN
CIPRO-A VET|Antibiotics|Ciprofloxacin
Cipro-D Vet|Antibiotic & Anti-Inflammatory|Ciprofloxacin Hydrochloride USP & Dexamethasone BP
COCCI-OFF VET|Anti-Coccidial|Amprolium, Sulfaquinoxaline & Vitamin-K
COMBIPEN VET|Antibiotics|Procaine Penicillins & Benzyl Penicillins
CP-VET|Vitamin & Mineral|Calcium, Magnesium, Phosphorus, Vitamin D3, Vitamin B12
CP-VET PLUS|Vitamin & Mineral|Calcium, Phosphorus, Magnesium, Potassium, Sodium, Vitamin D3, Vitamin E & others
D-PRO VET|Nutritionals|25-Hydroxycholecalciferol (Hy.D), Vitamin D3 & Vitamin C
DECAM VET|Vitamin & Mineral|Calcium, Magnesium, Phosphorus, Dextrose & Boric acid
DILORES VET|Bronchodilator & Expectorant|Eucalyptus oil, Mint oil, Thyme oil, Menthol, Camphor, Ocimum sanctum
DIROVET Vet|Antiprotozoal|Metronidazole
Doloryl Vet|Anti-Inflammatory|Carprofen USP
Doxy-A Vet|Antibiotics|Doxycycline
DRESSGEL-FR VET|Fly repellent|Neem oil, Marigold oil, Mustard oil, Dedaru oil, Halud & Mongistha
E-VET|Vitamin & Mineral|Vitamin-E
E-Vet Plus Vet|Vitamin & Mineral|Vitamin E & Selenium
ECOPOND|Pond Management|Probiotics, Prebiotic, Enzymes, Yucca, Yeast, Ionized minerals & Gas adsorbent
ECSE Vet|Phytobiotic|Citrus aurantium L.
EDECURE VET|Diuretics|Furosemide
ENROVET Vet|Antibiotics|Enrofloxacin
Eraplus Vet|Antibiotics|Erythromycin Stearate USP, Neomycin Sulfate BP, Sulphadimidine BP, Trimethoprim
ERAPRIM VET|Antibiotics|Erythromycin, Sulphadiazine & Trimethoprim
FAST-VET|Anti-Inflammatory|Paracetamol
FENAZOL VET|Anthelmintic|Fenbendazole BP
FEROVET Vet|Vitamin & Mineral|Ferrous Sulphate, Copper Sulphate, Zinc sulphate, Cobalt & Vitamin B12
FLY-OUT VET|Fly repellent|Neem extract, Castor oil & Polyherbal mixture
FMD CURE VET|Antiseptic|Natrii carbonas
GENTA-10 Vet|Antibiotics|Gentamicin
GLUCOLYTE Vet|Electrolyte|Sodium bicarbonate, Sodium chloride, Potassium chloride, Vitamin A & Glucose
Glucovet Aqua|Nutritionals|Glucose & Vitamin C
GLUCOVET Vet|Electrolyte|Sodium bicarbonate, Sodium chloride, Potassium chloride, Vitamin A & Glucose
Hepafit Aqua|Liver tonic|Sorbitol 500 mg, Sodium (Chloride), Magnesium (Chloride), Methionine hydroxy analogue
HEPAFIT VET|Liver tonic|Sorbitol, Sodium (Chloride), Magnesium (Chloride), Methionine hydroxy analogue
Hepatovet|Liver tonic|Aphanamixis polystachya, Terminalia chebula, Rheum emodi, Andrographis paniculata
IRB 800|Probiotics|Probiotics (Bacillus spp.), Amino acid (from plants), Enhancing agents
KETO-A VET|Anti-Inflammatory|Ketoprofen
Lega Vet|Anti-Inflammatory|Flunixin Meglumine USP
LEOVET Vet|Antibiotics|Levofloxacin USP
Leva Vet|Anthelmintic|Levamisole
LEVANID Vet|Anthelmintic|Tetramisole & Oxiclosanide
LSD-NDOLL|Vaccine|LSD Neethling Strain 10^3.5 TCID50
LT-VET|Anthelmintic|Levamisole & Triclabendazole INN
LT-Vet DS|Anthelmintic|Levamisole & Triclabendazole INN
M-LIME Vet|Plankton Enhancer|Probiotic, Yeast, Fermented plants, Humus, Molasses & Dolomite
MAGVET PLUS Vet|Antibiotics|Amoxicillin
MAGVET Vet|GI Products|Magnesium Hydroxide
MEL VET PLUS Vet|Anti-Inflammatory|Meloxicam & Paracetamol
MEL-VET Vet|Anti-Inflammatory|Meloxicam
MOXILIN VET|Antibiotics|Amoxicillin
MOXILIN VET DS|Antibiotics|Amoxicillin
Moxilin-CV Vet|Antibiotics|Erythromycin Stearate USP, Neomycin Sulfate BP, Sulphadimidine BP, Trimethoprim
Mura Plus Vet|Immunomodulator|Lysozyme, Vitamin E, Vitamin C, L-Carnitine, Sodium Selenite, Sorbitol
NEFGUARD VET|Feed additive|Methenamine, Vitamin B1, Vitamin B2 & Vitamin K3
NEFTONIC VET|Kidney Tonic|Halite, Salmiac, Glucitol, Citrosodine & Alpha Propylene
NEOTRAX VET|Anthelmintic|Levamisole
Nimocin Vet|Antibiotics|Neomycin Sulfate USP
Nimocin Vet Plus|Antibiotics|Lincomycin HCL BP & Neomycin Sulfate USP
NITROX-A Vet|Anthelmintic|Nitroxinil
NORVET Vet|Anthelmintic|Nitroxinil
Oxecone-S Vet|GI Products|Magnesium Hydroxide, Aluminium Hydroxide & Simethicone
OXY-A Vet|Aqua Product|Sodium percarbonate
PEFLOX VET|Antibiotics|Pefloxacin
PERAVET Vet|Anthelmintic|Piperazine citrate
PHENADRYL VET|Antihistamine|Diphenhydramine HCl
Phytoclean|Aqua & Herbal|Azadirachta indica, Allium sativum, Bacopa monnieri, Phyllanthus emblica
POLITRIM VET|Antibiotics|Sulfamethoxazole & Trimethoprim
Postbio Vet|Postbiotic|Postbiotic (Heat killed Lactobacillus paracasei & Heat killed Bifidobacterium)
PREMAFAT VET|Energy booster|Vegetable fat
PROMAST VET|Antimastitis agent|Antimastitis agent
PROZYME VET|Probiotics|Probiotic, prebiotic, enzyme, vitamin & mineral
Prycin Vet|Antibiotic & Chemotherapeutics|Apramycin Sulfate BP
RUMIGEST VET|GI Products|Antimony Potassium Tartrate & Ferrous Sulphate
SB NATE VET|Alkalizer|Sodium Bicarbonate
SCZ Vet|Anticoccidial|Sulphaclozine Sodium
SP-VET|Antibiotics|Penicillin G procaine, Penicillin G Sodium & Streptomycin
STERON VET|Anti-Inflammatory|Dexamethasone
STERON VET PLUS|Anti-Inflammatory|Prednisolone Sodium Phosphate USP & Dexamethasone Sodium Phosphate BP
SULFASOL VET|Antibiotics|Sulfadimidine Sodium
SULPHADIN Vet|Antibiotics|Sulphadiazine, Sulphadimidine, Sulphapyridine
SULPHAVET Vet|Antibiotics|Sulphanilamide
SYNBIOZYME VET|Enzymes|Enzyme, Probiotic & Prebiotic
Tamic Vet|Anti-Inflammatory|Tolfenamic acid
Tetravet Vet|Antibiotics|Oxytetracycline
TICOFON VET|Anthelmintic|Trichlorfon
TIFUR VET|Antibiotics|Ceftiofur Sodium
TIM-AC|Disinfectant|Dodecyl Dimethyl Benzyl Ammonium Chloride, Cetylpyridinium Chloride & Urea
TRACID VET|Antihaemorrhagic|Tranexamic Acid
TRIZON VET|Antibiotics|Ceftriaxone Sodium
TROPIN VET|Anticholinergic|Atropine Sulphate
Tulavet|Antibiotics|Tulathromycin INN
TYLOVET Vet|Antibiotics|Tylosin Tartrate
TYLVASIN VET|Antibiotics|Tylvalosin Tartrate INN
Uteron Vet|Ecbolic|24 herbs & 4 minerals
V PLEX VET (B+C) Vet|Vitamins & Minerals|Vitamin B complex & Vitamin C
V-PLEX PLUS VET|Vitamin & Mineral|Vitamin B complex & minerals
V-PLEX VET|Vitamin & Mineral|Vitamin B complex & minerals
ValleyVac Xceed|Vaccine|Low Pathogenic Avian Influenza (H9N2) & Newcastle Disease
VIRMAX VET|Immunomodulator|Ideal Mixture of Phytogenic Extracts
VITA D PLUS VET|Nutritional Supplement|Vitamin D3 & Propylene Glycol
VITA-3 Vet|Vitamin & Mineral|Vitamin B1, B2 & B6
VITA-ADE Vet|Vitamin & Mineral|Vitamin A, Vitamin D3 & Vitamin E
VITA-K Vet|Vitamin & Mineral|Vitamin K
VITALAMINO FORTE VET|Vitamin & Mineral|Amino acid, Vitamin & Mineral
VITAMIX DB SUPER VET|Vitamin & Mineral|Multivitamin & Multimineral
VITAMIX DB VET|Vitamin & Mineral|Multivitamin & Multimineral
Vitamix F Aqua Premium Vet|Aqua Product|Multivitamin & Multimineral
VITAMIX WS Vet|Vitamin & Mineral|Multivitamin
Vitamix-C Aqua|Nutritionals|Vitamin C
VITAMIX-C Vet|Vitamin & Mineral|Vitamin C
VITAORAL VET|Vitamin & Mineral|Vitamin A, Vitamin D3, Vitamin E & Vitamin C
Xilian Vet|Antiviral & Immune stimulant|Andrographis Paniculata
ZIS-VET|Nutritional Supplement|Zinc Sulphate Monohydrate
ZYMOVET Vet|GI Products|Ammonium bicarbonate, Sodium bicarbonate, Nux vomica, Ginger, Gentian
''';

String _slug(String s) =>
    s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_');

/// Writes the 13 companies + the ACME medicines to Firestore.
/// Fixed document ids -> pressing the button twice does NOT create duplicates.
/// Returns how many documents were written.
Future<int> importStarterData() async {
  final batch = Db.fs.batch();
  var n = 0;
  for (final c in _companies) {
    batch.set(
      Db.col('companies').doc('seed_${c.$1}'),
      {
        'name': c.$2,
        'details': c.$3,
        ...Db.creatorStamp(),
        'seed': true,
      },
      SetOptions(merge: true),
    );
    n++;
  }
  for (final line in _acme.split('\n')) {
    final p = line.trim().split('|');
    if (p.length < 3) continue;
    batch.set(
      Db.col('medicines').doc('seed_acme_${_slug(p[0])}'),
      {
        'name': p[0],
        'companyId': 'seed_acme',
        'companyName': 'The ACME Laboratories Ltd (Veterinary Unit)',
        'category': p[1],
        'components': p[2],
        'whenToUse': '',
        'dose': '',
        'pregnancy': 'Unknown',
        'petSafety': 'Unknown',
        'details':
            'Category: ${p[1]}\nSource: ACME Laboratories website. Please verify indication, dose and safety before use.',
        'favourite': false,
        ...Db.creatorStamp(),
        'seed': true,
      },
      SetOptions(merge: true),
    );
    n++;
  }
  // Not awaited when offline: Firestore queues the batch and uploads it later.
  await batch.commit().timeout(const Duration(seconds: 20), onTimeout: () {});
  return n;
}
