import 'package:material_ui/material_ui.dart';
import '../core/db.dart';
import '../core/launch.dart';
import '../core/settings.dart';

/// Shows the dialog boxes created by the administrator
/// (Drawer > Announcements). Each dialog is shown at most `maxShows` times
/// per phone.
class AnnouncementService {
  static Future<void> showPending(BuildContext context) async {
    try {
      final snap = await Db.col('announcements')
          .get()
          .timeout(const Duration(seconds: 6));
      final list = snap.docs.map(Rec.from).where((a) {
        if (!a.b('active')) return false;
        final max = a.d('maxShows').toInt();
        return appSettings.announcementSeen(a.id) < (max <= 0 ? 1 : max);
      }).toList()
        ..sort((a, b) => a.dt('createdAt').compareTo(b.dt('createdAt')));

      for (final a in list) {
        if (!context.mounted) return;
        await appSettings.announcementShown(a.id);
        if (!context.mounted) return;
        await showAnnouncement(context, a);
      }
    } catch (_) {
      // offline -> nothing to show
    }
  }

  static Future<void> showAnnouncement(BuildContext context, Rec a) {
    final cancelAllowed = a.b('cancelAllowed');
    final tg = a.s('telegramLink');
    final web = a.s('webLink');
    return showDialog<void>(
      context: context,
      barrierDismissible: cancelAllowed,
      builder: (ctx) => PopScope(
        canPop: cancelAllowed,
        child: AlertDialog(
          title: Text(a.s('title')),
          content: SingleChildScrollView(child: Text(a.s('content'))),
          actionsOverflowDirection: VerticalDirection.down,
          actions: [
            if (tg.isNotEmpty)
              FilledButton.icon(
                icon: const Icon(Icons.telegram),
                label: const Text('Join Telegram'),
                onPressed: () {
                  openUrl(ctx, tg);
                  Navigator.pop(ctx);
                },
              ),
            if (web.isNotEmpty)
              FilledButton.tonalIcon(
                icon: const Icon(Icons.public),
                label: const Text('Visit Web'),
                onPressed: () {
                  openUrl(ctx, web);
                  Navigator.pop(ctx);
                },
              ),
            // Cancel works only when "CancelAllowed" = Yes.
            TextButton(
              onPressed: cancelAllowed ? () => Navigator.pop(ctx) : null,
              child: const Text('Cancel'),
            ),
          ],
        ),
      ),
    );
  }
}
