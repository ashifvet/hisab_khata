import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../core/launch.dart';

/// Reads  config/app  from Firestore:
///   latestVersion : "1.0.3"   -> optional update dialog
///   minVersion    : "1.0.2"   -> FORCE update (dialog cannot be closed)
///   updateUrl     : link to Play Store / website / Drive
///   message       : text shown in the dialog
/// Admin can change these from  Drawer > App Update.
class UpdateService {
  static int _cmp(String a, String b) {
    List<int> p(String s) => s
        .split('+')
        .first
        .split('.')
        .map((e) => int.tryParse(e.trim()) ?? 0)
        .toList();
    final x = p(a), y = p(b);
    for (var i = 0; i < 3; i++) {
      final xi = i < x.length ? x[i] : 0;
      final yi = i < y.length ? y[i] : 0;
      if (xi != yi) return xi.compareTo(yi);
    }
    return 0;
  }

  static Future<void> check(BuildContext context) async {
    try {
      final info = await PackageInfo.fromPlatform();
      final snap = await FirebaseFirestore.instance
          .collection('config')
          .doc('app')
          .get()
          .timeout(const Duration(seconds: 6));
      final d = snap.data();
      if (d == null) return;
      final latest = (d['latestVersion'] ?? '').toString();
      final min = (d['minVersion'] ?? '').toString();
      final url = (d['updateUrl'] ?? '').toString();
      final msg = (d['message'] ?? '').toString();
      final current = info.version;
      if (!context.mounted) return;

      if (min.isNotEmpty && _cmp(current, min) < 0) {
        await _dialog(context,
            force: true, current: current, latest: latest.isEmpty ? min : latest, url: url, msg: msg);
      } else if (latest.isNotEmpty && _cmp(current, latest) < 0) {
        await _dialog(context,
            force: false, current: current, latest: latest, url: url, msg: msg);
      }
    } catch (_) {
      // offline or no config yet -> silently continue
    }
  }

  static Future<void> _dialog(
    BuildContext context, {
    required bool force,
    required String current,
    required String latest,
    required String url,
    required String msg,
  }) {
    return showDialog<void>(
      context: context,
      barrierDismissible: !force,
      builder: (ctx) => PopScope(
        canPop: !force,
        child: AlertDialog(
          icon: const Icon(Icons.system_update, size: 40),
          title: Text(force ? 'Update required' : 'New version available'),
          content: Text(
            '${msg.isEmpty ? (force ? 'Please update the app to continue.' : 'A new version of My Diary is ready.') : msg}\n\nYour version: $current\nNew version: $latest',
          ),
          actions: [
            if (!force)
              TextButton(
                  onPressed: () => Navigator.pop(ctx), child: const Text('Later')),
            FilledButton(
              onPressed: () {
                if (url.isNotEmpty) openUrl(ctx, url);
                if (!force) Navigator.pop(ctx);
              },
              child: const Text('Update now'),
            ),
          ],
        ),
      ),
    );
  }
}
