import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import 'package:intl/intl.dart';
import '../core/db.dart';
import '../core/l10n.dart';

String money(num v) => '৳ ${NumberFormat('#,##0.##').format(v)}';
String fmtDate(DateTime d) => DateFormat('dd MMM yyyy').format(d);
String fmtMonth(DateTime d) => DateFormat('MMMM yyyy').format(d);

int wordCount(String s) {
  final t = s.trim();
  return t.isEmpty ? 0 : t.split(RegExp(r'\s+')).length;
}

Future<bool> confirm(BuildContext c, String title, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(msg),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(ctx.tr('Cancel'))),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(ctx.tr('OK'))),
      ],
    ),
  );
  return r ?? false;
}

/// Live list of Firestore documents (works offline from the local cache).
class DocsStream extends StatefulWidget {
  const DocsStream({super.key, required this.query, required this.builder});
  final Query<Map<String, dynamic>> query;
  final Widget Function(BuildContext, List<Rec>) builder;

  @override
  State<DocsStream> createState() => _DocsStreamState();
}

class _DocsStreamState extends State<DocsStream> {
  late Stream<QuerySnapshot<Map<String, dynamic>>> _s;

  @override
  void initState() {
    super.initState();
    _s = widget.query.snapshots();
  }

  @override
  void didUpdateWidget(covariant DocsStream old) {
    super.didUpdateWidget(old);
    if (old.query != widget.query) _s = widget.query.snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _s,
      builder: (c, snap) {
        if (snap.hasError) {
          return Center(
              child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Error: ${snap.error}', textAlign: TextAlign.center),
          ));
        }
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        return widget.builder(c, snap.data!.docs.map(Rec.from).toList());
      },
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState(this.text, {super.key, this.icon = Icons.inbox_outlined});
  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 56, color: Theme.of(context).disabledColor),
            const SizedBox(height: 8),
            Text(text,
                textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).disabledColor)),
          ]),
        ),
      );
}

class Tag extends StatelessWidget {
  const Tag(this.text, this.color, {super.key});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(right: 4),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(text,
            style: TextStyle(
                fontSize: 11, color: color, fontWeight: FontWeight.w600)),
      );
}

class SearchBox extends StatelessWidget {
  const SearchBox({super.key, required this.onChanged});
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
        child: TextField(
          onChanged: onChanged,
          decoration: InputDecoration(
            hintText: context.tr('Search'),
            prefixIcon: const Icon(Icons.search),
            isDense: true,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
          ),
        ),
      );
}

/// Multi-line text box with a live word counter and a maximum word limit.
class WordField extends StatelessWidget {
  const WordField({
    super.key,
    required this.controller,
    required this.label,
    required this.maxWords,
    this.minLines = 3,
    this.required = false,
  });
  final TextEditingController controller;
  final String label;
  final int maxWords;
  final int minLines;
  final bool required;

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextFormField(
        controller: controller,
        minLines: minLines,
        maxLines: null,
        keyboardType: TextInputType.multiline,
        decoration: InputDecoration(
          labelText: label,
          alignLabelWithHint: true,
          border: const OutlineInputBorder(),
        ),
        validator: (v) {
          if (required && (v == null || v.trim().isEmpty)) {
            return context.tr('Required');
          }
          if (wordCount(v ?? '') > maxWords) return 'Maximum $maxWords words';
          return null;
        },
      ),
      ValueListenableBuilder<TextEditingValue>(
        valueListenable: controller,
        builder: (c, v, _) {
          final n = wordCount(v.text);
          return Padding(
            padding: const EdgeInsets.only(top: 2, right: 4),
            child: Align(
              alignment: Alignment.centerRight,
              child: Text('$n / $maxWords words',
                  style: TextStyle(
                      fontSize: 11,
                      color: n > maxWords ? Colors.red : Colors.grey)),
            ),
          );
        },
      ),
    ]);
  }
}

/// Normal single/multi-line input used by all forms.
class Input extends StatelessWidget {
  const Input(
    this.controller,
    this.label, {
    super.key,
    this.required = false,
    this.keyboard,
    this.lines = 1,
    this.suffix,
  });
  final TextEditingController controller;
  final String label;
  final bool required;
  final TextInputType? keyboard;
  final int lines;
  final String? suffix;

  @override
  Widget build(BuildContext context) => TextFormField(
        controller: controller,
        keyboardType: keyboard,
        minLines: lines,
        maxLines: lines == 1 ? 1 : null,
        decoration: InputDecoration(
          labelText: label,
          suffixText: suffix,
          alignLabelWithHint: lines > 1,
          border: const OutlineInputBorder(),
        ),
        validator: required
            ? (v) => (v == null || v.trim().isEmpty)
                ? context.tr('Required')
                : null
            : null,
      );
}

/// Helper to space form children.
List<Widget> spaced(List<Widget> children, {double gap = 12}) {
  final out = <Widget>[];
  for (var i = 0; i < children.length; i++) {
    if (i > 0) out.add(SizedBox(height: gap));
    out.add(children[i]);
  }
  return out;
}

/// Read-only "label: value" card list for detail pages.
class DetailPage extends StatelessWidget {
  const DetailPage({
    super.key,
    required this.title,
    required this.rows,
    this.actions = const [],
    this.footer,
  });
  final String title;
  final List<(String, String)> rows;
  final List<Widget> actions;
  final Widget? footer;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title), actions: actions),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          for (final r in rows)
            if (r.$2.trim().isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(r.$1,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Theme.of(context).colorScheme.primary)),
                        const SizedBox(height: 4),
                        SelectableText(r.$2,
                            style: const TextStyle(fontSize: 15)),
                      ]),
                ),
              ),
          ?footer,
        ],
      ),
    );
  }
}

// ------------------------------------------------------------- field dialog
class FieldSpec {
  const FieldSpec(
    this.key,
    this.label, {
    this.number = false,
    this.lines = 1,
    this.initial = '',
    this.required = false,
    this.phone = false,
    this.obscure = false,
  });
  final String key;
  final String label;
  final bool number;
  final int lines;
  final String initial;
  final bool required;
  final bool phone;
  final bool obscure;
}

/// Small reusable dialog that asks for a few text fields (and optionally a
/// date). Returns null when cancelled. The date comes back under key `_date`
/// as an ISO-8601 string.
Future<Map<String, String>?> askFields(
  BuildContext context, {
  required String title,
  required List<FieldSpec> fields,
  bool withDate = false,
  DateTime? date,
  String ok = 'Save',
}) {
  return showDialog<Map<String, String>>(
    context: context,
    builder: (_) => _AskDialog(
        title: title, fields: fields, withDate: withDate, date: date, ok: ok),
  );
}

class _AskDialog extends StatefulWidget {
  const _AskDialog({
    required this.title,
    required this.fields,
    required this.withDate,
    required this.date,
    required this.ok,
  });
  final String title;
  final List<FieldSpec> fields;
  final bool withDate;
  final DateTime? date;
  final String ok;

  @override
  State<_AskDialog> createState() => _AskDialogState();
}

class _AskDialogState extends State<_AskDialog> {
  final _form = GlobalKey<FormState>();
  late final List<TextEditingController> _c;
  late DateTime _date;

  @override
  void initState() {
    super.initState();
    _c = [for (final f in widget.fields) TextEditingController(text: f.initial)];
    _date = widget.date ?? DateTime.now();
  }

  @override
  void dispose() {
    for (final c in _c) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: SingleChildScrollView(
        child: Form(
          key: _form,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < widget.fields.length; i++)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: TextFormField(
                  controller: _c[i],
                  obscureText: widget.fields[i].obscure,
                  minLines: widget.fields[i].lines,
                  maxLines: widget.fields[i].obscure
                      ? 1
                      : (widget.fields[i].lines == 1
                          ? 1
                          : widget.fields[i].lines + 3),
                  keyboardType: widget.fields[i].number
                      ? const TextInputType.numberWithOptions(decimal: true)
                      : widget.fields[i].phone
                          ? TextInputType.phone
                          : null,
                  decoration: InputDecoration(
                    labelText: widget.fields[i].label,
                    border: const OutlineInputBorder(),
                  ),
                  validator: (v) {
                    final f = widget.fields[i];
                    if (f.required && (v == null || v.trim().isEmpty)) {
                      return context.tr('Required');
                    }
                    if (f.number && v != null && v.trim().isNotEmpty) {
                      final n = double.tryParse(v.trim());
                      if (n == null || n < 0) return 'Invalid number';
                    }
                    return null;
                  },
                ),
              ),
            if (widget.withDate)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.calendar_today, size: 18),
                  label: Text(fmtDate(_date)),
                  onPressed: () async {
                    final d = await showDatePicker(
                      context: context,
                      initialDate: _date,
                      firstDate: DateTime(2015),
                      lastDate: DateTime(2100),
                    );
                    if (d != null) setState(() => _date = d);
                  },
                ),
              ),
          ]),
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(context.tr('Cancel'))),
        FilledButton(
          onPressed: () {
            if (!_form.currentState!.validate()) return;
            final out = <String, String>{
              for (var i = 0; i < widget.fields.length; i++)
                widget.fields[i].key: _c[i].text.trim(),
            };
            if (widget.withDate) out['_date'] = _date.toIso8601String();
            Navigator.pop(context, out);
          },
          child: Text(context.tr(widget.ok)),
        ),
      ],
    );
  }
}
