import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import '../core/db.dart';

/// Listens to ONE document so detail pages update instantly after an edit.
class LiveDoc extends StatefulWidget {
  const LiveDoc({
    super.key,
    required this.collection,
    required this.id,
    required this.builder,
  });
  final String collection;
  final String id;
  final Widget Function(BuildContext, Rec?) builder;

  @override
  State<LiveDoc> createState() => _LiveDocState();
}

class _LiveDocState extends State<LiveDoc> {
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> _s =
      Db.col(widget.collection).doc(widget.id).snapshots();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _s,
      builder: (c, snap) {
        if (snap.hasError) {
          return Scaffold(
              appBar: AppBar(),
              body: Center(child: Text('Error: ${snap.error}')));
        }
        if (!snap.hasData) {
          return Scaffold(
              appBar: AppBar(),
              body: const Center(child: CircularProgressIndicator()));
        }
        final d = snap.data!;
        return widget.builder(
            c, d.exists ? Rec(d.id, d.data() ?? <String, dynamic>{}) : null);
      },
    );
  }
}
