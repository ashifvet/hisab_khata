import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../widgets/common.dart';
import '../../widgets/live_doc.dart';
import '../add/forms.dart';

/// Diseases: All | Good Prognosis | Poor Prognosis
/// Every user sees only his own cases, the administrator sees all.
class DiseasesScreen extends StatefulWidget {
  const DiseasesScreen({super.key});

  @override
  State<DiseasesScreen> createState() => _DiseasesScreenState();
}

class _DiseasesScreenState extends State<DiseasesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(children: [
        TabBar(tabs: [
          Tab(text: context.tr('All')),
          Tab(text: context.tr('Good Prognosis')),
          Tab(text: context.tr('Poor Prognosis')),
        ]),
        SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase())),
        Expanded(
          child: DocsStream(
            query: Db.mine('diseases'),
            builder: (c, all) {
              final list = all
                  .where((d) =>
                      _q.isEmpty ||
                      d.s('title').toLowerCase().contains(_q) ||
                      d.s('owner').toLowerCase().contains(_q) ||
                      d.s('phone').contains(_q))
                  .toList()
                ..sort((a, b) => b.dt('createdAt').compareTo(a.dt('createdAt')));
              Widget view(List<Rec> items) {
                if (items.isEmpty) {
                  return EmptyState(context.tr('Nothing here yet'),
                      icon: Icons.healing_outlined);
                }
                return ListView.separated(
                  itemCount: items.length,
                  separatorBuilder: (c, i) => const Divider(height: 1),
                  itemBuilder: (c, i) {
                    final d = items[i];
                    return ListTile(
                      title: Text(d.s('title'),
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(
                        '${d.s('owner')} • ${d.s('phone')}'
                        '${Db.isAdmin ? '  (by ${d.s('ownerName')})' : ''}',
                        style: const TextStyle(fontSize: 11),
                      ),
                      trailing: Tag(
                        d.s('prognosis') == 'Poor' ? 'Poor' : 'Good',
                        d.s('prognosis') == 'Poor' ? Colors.red : Colors.green,
                      ),
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute<void>(
                              builder: (_) => DiseaseDetail(id: d.id))),
                    );
                  },
                );
              }

              return TabBarView(children: [
                view(list),
                view(list.where((d) => d.s('prognosis') != 'Poor').toList()),
                view(list.where((d) => d.s('prognosis') == 'Poor').toList()),
              ]);
            },
          ),
        ),
      ]),
    );
  }
}

class DiseaseDetail extends StatelessWidget {
  const DiseaseDetail({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    return LiveDoc(
      collection: 'diseases',
      id: id,
      builder: (context, d) {
        if (d == null) {
          return Scaffold(
              appBar: AppBar(),
              body: const EmptyState('This record was deleted.'));
        }
        return DetailPage(
          title: d.s('title'),
          actions: [
            IconButton(
              icon: const Icon(Icons.call),
              onPressed: () => callPhone(d.s('phone')),
            ),
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (_) => EditPage(
                    title: context.tr('Edit'),
                    child: Builder(
                      builder: (c) =>
                          DiseaseForm(edit: d, onSaved: () => Navigator.pop(c)),
                    ),
                  ),
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () async {
                if (await confirm(context, context.tr('Delete'), d.s('title'))) {
                  if (!context.mounted) return;
                  Db.run(context, Db.col('diseases').doc(d.id).delete());
                  if (d.d('fee') > 0) {
                    Db.run(context, Db.col('cash').doc('dis_${d.id}').delete());
                  }
                  Navigator.pop(context);
                }
              },
            ),
          ],
          rows: [
            (context.tr('Owner name'), d.s('owner')),
            (context.tr('Phone number'), d.s('phone')),
            (
              context.tr('Location'),
              d.s('location') == 'Private'
                  ? '${context.tr('Private')} - ${context.tr('Fee taken')}: ${money(d.d('fee'))}'
                  : context.tr('Hospital')
            ),
            ('Date', fmtDate(d.dt('createdAt'))),
            (context.tr('Title of the disease'), d.s('title')),
            (context.tr('Temperature'),
                d.s('temperature').isEmpty ? '' : '${d.s('temperature')} °F'),
            (context.tr('Sign & symptoms told by owner'), d.s('symptoms')),
            (context.tr('Clinical findings'), d.s('findings')),
            (context.tr('Skin parasite'), context.tr(d.s('skinParasite'))),
            (context.tr('Treatment'), d.s('treatment')),
            (context.tr('Prognosis after 10 days of treatment'),
                context.tr(d.s('prognosis'))),
            if (Db.isAdmin) ('Added by', d.s('ownerName')),
          ],
        );
      },
    );
  }
}
