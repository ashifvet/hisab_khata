import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../widgets/common.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _first, _last, _phone, _location, _about;

  @override
  void initState() {
    super.initState();
    final p = Db.profile.value;
    String v(String k) => (p[k] ?? '').toString();
    _first = TextEditingController(text: v('firstName'));
    _last = TextEditingController(text: v('lastName'));
    _phone = TextEditingController(text: v('phone'));
    _location = TextEditingController(text: v('location'));
    _about = TextEditingController(text: v('about'));
  }

  @override
  void dispose() {
    for (final c in [_first, _last, _phone, _location, _about]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    Db.run(
      context,
      Db.fs.collection('users').doc(Db.uid).set({
        'firstName': _first.text.trim(),
        'lastName': _last.text.trim(),
        'email': Db.user?.email ?? '',
        'phone': _phone.text.trim(),
        'location': _location.text.trim(),
        'about': _about.text.trim(),
      }, SetOptions(merge: true)),
    );
    snack(context, context.tr('Saved'));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Edit Profile'))),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: spaced([
            Input(_first, context.tr('First name'), required: true),
            Input(_last, context.tr('Last name')),
            TextFormField(
              initialValue: Db.user?.email ?? '',
              enabled: false,
              decoration: InputDecoration(
                  labelText: context.tr('Email'),
                  border: const OutlineInputBorder()),
            ),
            Input(_phone, context.tr('Phone number'),
                keyboard: TextInputType.phone),
            Input(_location, context.tr('Location')),
            Input(_about, 'About / Designation / Chamber', lines: 3),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(context.tr('Save')),
            ),
          ]),
        ),
      ),
    );
  }
}
