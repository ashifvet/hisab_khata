import 'package:firebase_auth/firebase_auth.dart';
import 'package:material_ui/material_ui.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../core/settings.dart';
import '../../widgets/common.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _changePassword(BuildContext context) async {
    final r = await askFields(
      context,
      title: context.tr('Change password'),
      fields: const [
        FieldSpec('cur', 'Current password', obscure: true, required: true),
        FieldSpec('new', 'New password (min 6 characters)',
            obscure: true, required: true),
        FieldSpec('conf', 'Confirm new password', obscure: true, required: true),
      ],
    );
    if (r == null || !context.mounted) return;
    if (r['new']!.length < 6) {
      snack(context, 'New password must be at least 6 characters');
      return;
    }
    if (r['new'] != r['conf']) {
      snack(context, 'Passwords do not match');
      return;
    }
    final u = FirebaseAuth.instance.currentUser;
    if (u == null || u.email == null) return;
    try {
      final cred =
          EmailAuthProvider.credential(email: u.email!, password: r['cur']!);
      await u.reauthenticateWithCredential(cred);
      await u.updatePassword(r['new']!);
      if (context.mounted) snack(context, 'Password changed');
    } on FirebaseAuthException catch (e) {
      if (context.mounted) snack(context, e.message ?? e.code);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: Text(context.tr('Settings'))),
        body: ListView(children: [
          SwitchListTile(
            secondary: const Icon(Icons.dark_mode),
            title: Text(context.tr('Dark mode')),
            value: appSettings.dark,
            onChanged: appSettings.setDark,
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Row(children: [
              const Icon(Icons.language),
              const SizedBox(width: 16),
              Text(context.tr('Language'),
                  style: Theme.of(context).textTheme.titleMedium),
            ]),
          ),
          RadioGroup<String>(
            groupValue: appSettings.lang,
            onChanged: (v) => appSettings.setLang(v ?? 'en'),
            child: Column(children: [
              RadioListTile<String>(
                  value: 'en', title: const Text('English')),
              RadioListTile<String>(
                  value: 'bn', title: const Text('বাংলা (Bangla)')),
            ]),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.lock),
            title: Text(context.tr('Change password')),
            onTap: () => _changePassword(context),
          ),
        ]),
      ),
    );
  }
}
