import 'package:material_ui/material_ui.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('About Developer'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Center(
          child: Image.asset('asset/icon.png',
              width: 90,
              height: 90,
              errorBuilder: (c, e, s) =>
                  Icon(Icons.menu_book_rounded, size: 80, color: scheme.primary)),
        ),
        const SizedBox(height: 8),
        const Center(
            child: Text('My Diary',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
        FutureBuilder<PackageInfo>(
          future: PackageInfo.fromPlatform(),
          builder: (c, s) => Center(
            child: Text(
              s.hasData
                  ? '${context.tr('Version')} ${s.data!.version} (build ${s.data!.buildNumber})'
                  : '',
              style: const TextStyle(color: Colors.grey),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(context.tr('Developer'),
                  style: TextStyle(
                      color: scheme.primary, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              const Text('Dr. MD. ASHIF IQBAL',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const Text('DVM, MSc, BCS'),
              const SizedBox(height: 4),
              const Text('Veterinary Surgeon, Maheshpur'),
              const Divider(height: 28),
              Row(children: [
                const Icon(Icons.phone, size: 20),
                const SizedBox(width: 8),
                const Expanded(child: Text('Phone: 01711989236')),
                IconButton(
                  icon: const Icon(Icons.call),
                  onPressed: () => callPhone('01711989236'),
                ),
              ]),
              Row(children: [
                const Icon(Icons.home, size: 20),
                const SizedBox(width: 8),
                Text('${context.tr('Hometown')}: Kushtia'),
              ]),
            ]),
          ),
        ),
      ]),
    );
  }
}
