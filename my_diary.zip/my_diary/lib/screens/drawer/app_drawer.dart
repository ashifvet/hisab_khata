import 'package:firebase_auth/firebase_auth.dart';
import 'package:material_ui/material_ui.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import 'about_screen.dart';
import 'announcements_admin_screen.dart';
import 'edit_profile_screen.dart';
import 'settings_screen.dart';
import 'update_admin_screen.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  void _go(BuildContext context, Widget page) {
    Navigator.pop(context); // close drawer
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Drawer(
      child: Column(children: [
        // ---- greeting header
        ValueListenableBuilder<Map<String, dynamic>>(
          valueListenable: Db.profile,
          builder: (context, _, _) => Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(
                16, MediaQuery.of(context).padding.top + 20, 16, 20),
            color: scheme.primary,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: scheme.onPrimary,
                child: Text(
                  Db.displayName.isEmpty ? '?' : Db.displayName[0].toUpperCase(),
                  style: TextStyle(
                      fontSize: 28,
                      color: scheme.primary,
                      fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 12),
              Text(context.tr(greetingKey()),
                  style: TextStyle(color: scheme.onPrimary, fontSize: 14)),
              Text(Db.displayName,
                  style: TextStyle(
                      color: scheme.onPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
              if (Db.isAdmin)
                Text('Administrator account',
                    style: TextStyle(color: scheme.onPrimary, fontSize: 12)),
            ]),
          ),
        ),
        Expanded(
          child: ListView(padding: EdgeInsets.zero, children: [
            ListTile(
              leading: const Icon(Icons.person),
              title: Text(context.tr('Edit Profile')),
              onTap: () => _go(context, const EditProfileScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: Text(context.tr('Settings')),
              onTap: () => _go(context, const SettingsScreen()),
            ),
            if (Db.isAdmin) ...[
              ListTile(
                leading: const Icon(Icons.campaign),
                title: Text(context.tr('Announcements')),
                onTap: () => _go(context, const AnnouncementsAdminScreen()),
              ),
              ListTile(
                leading: const Icon(Icons.system_update),
                title: Text(context.tr('App Update')),
                onTap: () => _go(context, const UpdateAdminScreen()),
              ),
            ],
            ListTile(
              leading: const Icon(Icons.info),
              title: Text(context.tr('About Developer')),
              onTap: () => _go(context, const AboutScreen()),
            ),
          ]),
        ),
        const Divider(height: 1),
        FutureBuilder<PackageInfo>(
          future: PackageInfo.fromPlatform(),
          builder: (c, s) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              '${context.tr('Version')} ${s.data?.version ?? ''}',
              style: const TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: Text(context.tr('Logout'),
              style: const TextStyle(color: Colors.red)),
          onTap: () async {
            Navigator.pop(context);
            Db.stopProfile();
            await FirebaseAuth.instance.signOut();
          },
        ),
        SizedBox(height: MediaQuery.of(context).padding.bottom),
      ]),
    );
  }
}
