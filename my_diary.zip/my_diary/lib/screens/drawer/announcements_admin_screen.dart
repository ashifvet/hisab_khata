import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../services/announcement_service.dart';
import '../../widgets/common.dart';

/// Administrator only: create the pop-up dialog boxes shown to all users.
class AnnouncementsAdminScreen extends StatelessWidget {
  const AnnouncementsAdminScreen({super.key});

  void _edit(BuildContext context, [Rec? a]) {
    Navigator.push(
        context,
        MaterialPageRoute<void>(
            builder: (_) => AnnouncementForm(edit: a)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Announcements'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context),
        icon: const Icon(Icons.add),
        label: const Text('New dialog'),
      ),
      body: DocsStream(
        query: Db.col('announcements'),
        builder: (c, list) {
          list.sort((a, b) => b.dt('createdAt').compareTo(a.dt('createdAt')));
          if (list.isEmpty) {
            return const EmptyState('No announcements yet.\nTap "New dialog".',
                icon: Icons.campaign_outlined);
          }
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            itemBuilder: (c, i) {
              final a = list[i];
              return Card(
                margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: ListTile(
                  title: Text(a.s('title')),
                  subtitle: Text(
                      '${a.b('cancelAllowed') ? 'Cancel allowed' : 'Must click a button'}  •  shown ${a.d('maxShows').toInt()}x',
                      style: const TextStyle(fontSize: 12)),
                  onTap: () => _edit(context, a),
                  leading: Switch(
                    value: a.b('active'),
                    onChanged: (v) => Db.run(context,
                        Db.col('announcements').doc(a.id).update({'active': v})),
                  ),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'preview') {
                        AnnouncementService.showAnnouncement(context, a);
                      } else if (v == 'edit') {
                        _edit(context, a);
                      } else if (v == 'delete') {
                        if (await confirm(context, 'Delete?', a.s('title'))) {
                          if (context.mounted) {
                            Db.run(context,
                                Db.col('announcements').doc(a.id).delete());
                          }
                        }
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'preview', child: Text('Preview')),
                      PopupMenuItem(value: 'edit', child: Text('Edit')),
                      PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class AnnouncementForm extends StatefulWidget {
  const AnnouncementForm({super.key, this.edit});
  final Rec? edit;

  @override
  State<AnnouncementForm> createState() => _AnnouncementFormState();
}

class _AnnouncementFormState extends State<AnnouncementForm> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _title, _content, _tg, _web, _times;
  bool _cancel = true;
  bool _active = true;

  @override
  void initState() {
    super.initState();
    final e = widget.edit;
    _title = TextEditingController(text: e?.s('title') ?? '');
    _content = TextEditingController(text: e?.s('content') ?? '');
    _tg = TextEditingController(text: e?.s('telegramLink') ?? '');
    _web = TextEditingController(text: e?.s('webLink') ?? '');
    _times = TextEditingController(
        text: e == null ? '1' : e.d('maxShows').toInt().toString());
    _cancel = e?.b('cancelAllowed') ?? true;
    _active = e?.b('active') ?? true;
  }

  @override
  void dispose() {
    for (final c in [_title, _content, _tg, _web, _times]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final tg = _tg.text.trim(), web = _web.text.trim();
    if (!_cancel && tg.isEmpty && web.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'If Cancel is not allowed you must give a Telegram or Web link, otherwise users get stuck.')));
      return;
    }
    final data = {
      'title': _title.text.trim(),
      'content': _content.text.trim(),
      'telegramLink': tg,
      'webLink': web,
      'cancelAllowed': _cancel,
      'maxShows': int.tryParse(_times.text.trim()) ?? 1,
      'active': _active,
    };
    final ref = widget.edit == null
        ? Db.col('announcements').doc()
        : Db.col('announcements').doc(widget.edit!.id);
    Db.run(
        context,
        widget.edit == null
            ? ref.set({...data, 'createdAt': Timestamp.now()})
            : ref.update(data));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(widget.edit == null ? 'New dialog box' : 'Edit dialog box')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: spaced([
            Input(_title, 'Title of the dialog box', required: true),
            Input(_content, 'Content of the dialog box', required: true, lines: 4),
            Input(_tg, 'Telegram link', keyboard: TextInputType.url),
            Input(_web, 'Website link', keyboard: TextInputType.url),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Cancel allowed'),
              subtitle: Text(_cancel
                  ? 'Yes - user can close the dialog'
                  : 'No - user must click Join Telegram / Visit Web'),
              value: _cancel,
              onChanged: (v) => setState(() => _cancel = v),
            ),
            Input(_times, 'How many times will the user see it?',
                keyboard: TextInputType.number, required: true),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Active'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
            FilledButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.save),
                label: Text(context.tr('Save'))),
          ]),
        ),
      ),
    );
  }
}
