import 'package:material_ui/material_ui.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../widgets/common.dart';

/// Administrator only: publish the newest version name to Firebase.
/// Users with an older version get a dialog when they open the app.
/// If their version is lower than "minimum version" the update is FORCED.
class UpdateAdminScreen extends StatefulWidget {
  const UpdateAdminScreen({super.key});

  @override
  State<UpdateAdminScreen> createState() => _UpdateAdminScreenState();
}

class _UpdateAdminScreenState extends State<UpdateAdminScreen> {
  final _latest = TextEditingController();
  final _min = TextEditingController();
  final _url = TextEditingController();
  final _msg = TextEditingController();
  String _current = '';
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final info = await PackageInfo.fromPlatform();
    _current = info.version;
    try {
      final d = (await Db.col('config').doc('app').get()).data();
      if (d != null) {
        _latest.text = (d['latestVersion'] ?? '').toString();
        _min.text = (d['minVersion'] ?? '').toString();
        _url.text = (d['updateUrl'] ?? '').toString();
        _msg.text = (d['message'] ?? '').toString();
      }
    } catch (_) {}
    if (mounted) setState(() => _loaded = true);
  }

  @override
  void dispose() {
    for (final c in [_latest, _min, _url, _msg]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    Db.run(
      context,
      Db.col('config').doc('app').set({
        'latestVersion': _latest.text.trim(),
        'minVersion': _min.text.trim(),
        'updateUrl': _url.text.trim(),
        'message': _msg.text.trim(),
      }),
    );
    snack(context, context.tr('Saved'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('App Update'))),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: spaced([
                Text('This phone runs version $_current'),
                Input(_latest, 'Latest version (e.g. 1.0.3)',
                    keyboard: TextInputType.text),
                Input(_min, 'Minimum allowed version (older = FORCE update)'),
                Input(_url, 'Update link (Play Store / website)',
                    keyboard: TextInputType.url),
                Input(_msg, 'Message (what is new)', lines: 3),
                FilledButton.icon(
                    onPressed: _save,
                    icon: const Icon(Icons.cloud_upload),
                    label: const Text('Publish to Firebase')),
              ]),
            ),
    );
  }
}
