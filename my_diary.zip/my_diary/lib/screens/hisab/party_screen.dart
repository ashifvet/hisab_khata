import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../widgets/common.dart';
import 'biz.dart';
import 'report_pdf.dart';

/// One customer / supplier: balance, transaction history, reminders, report.
class PartyScreen extends StatelessWidget {
  const PartyScreen({super.key, required this.biz, required this.partyId});
  final Rec biz;
  final String partyId;

  Future<void> _addTxn(BuildContext context, Rec party, int dir) async {
    final r = await askFields(
      context,
      title: context.tr(dir == 1 ? 'You gave' : 'You got'),
      fields: [
        const FieldSpec('amount', 'Amount', number: true, required: true),
        const FieldSpec('note', 'Note / item details', lines: 2),
      ],
      withDate: true,
    );
    if (r == null || !context.mounted) return;
    final amount = double.tryParse(r['amount']!) ?? 0;
    if (amount <= 0) {
      snack(context, 'Amount must be greater than 0');
      return;
    }
    Db.run(
      context,
      Db.col('txns').add({
        'businessId': biz.id,
        'partyId': party.id,
        'partyName': party.s('name'),
        'dir': dir,
        'amount': amount,
        'note': r['note'],
        'date': Timestamp.fromDate(DateTime.parse(r['_date']!)),
        ...Db.ownerStamp(),
      }),
    );
  }

  String _reminder(Rec party, double bal) =>
      'Dear ${party.s('name')}, your due amount with ${biz.s('name')} is ${money(bal)}. '
      'Please pay it as soon as possible. Thank you.';

  Future<void> _edit(BuildContext context, Rec party) async {
    final r = await askFields(context, title: context.tr('Edit'), fields: [
      FieldSpec('name', context.tr('Name'), required: true, initial: party.s('name')),
      FieldSpec('phone', context.tr('Phone'), phone: true, initial: party.s('phone')),
      FieldSpec('address', context.tr('Address'), initial: party.s('address')),
    ]);
    if (r == null || !context.mounted) return;
    Db.run(
        context,
        Db.col('parties').doc(party.id).update(
            {'name': r['name'], 'phone': r['phone'], 'address': r['address']}));
  }

  Future<void> _deleteParty(BuildContext context, Rec party, Biz data) async {
    final ok = await confirm(context, context.tr('Delete'),
        '${party.s('name')} and all transactions with this party will be deleted.');
    if (!ok || !context.mounted) return;
    final batch = Db.fs.batch();
    for (final t in data.partyTxns(party.id)) {
      batch.delete(Db.col('txns').doc(t.id));
    }
    batch.delete(Db.col('parties').doc(party.id));
    Db.run(context, batch.commit());
    Navigator.pop(context);
  }

  Future<void> _report(BuildContext context, Rec party, Biz data) async {
    try {
      final bytes = await partyStatementPdf(
        business: biz.s('name'),
        party: party,
        txns: data.partyTxns(party.id),
      );
      await sharePdf(bytes, 'statement_${party.s('name')}.pdf');
    } catch (e) {
      if (context.mounted) snack(context, 'Could not create PDF: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return BizScope(
      businessId: biz.id,
      cols: const ['parties', 'txns'],
      builder: (context, data) {
        final matches = data.parties.where((p) => p.id == partyId);
        if (matches.isEmpty) {
          return Scaffold(
              appBar: AppBar(),
              body: const EmptyState('This party was deleted.'));
        }
        final party = matches.first;
        final bal = data.balance(party.id);
        final color = bal > 0
            ? Colors.green.shade700
            : bal < 0
                ? Colors.red.shade700
                : Colors.grey;
        final txns = data.partyTxns(party.id);
        // running balance, newest first in the list
        final running = <String, double>{};
        var run = 0.0;
        for (final t in txns) {
          run += t.d('dir') * t.d('amount');
          running[t.id] = run;
        }
        final shown = txns.reversed.toList();

        return Scaffold(
          appBar: AppBar(
            title: Text(party.s('name')),
            actions: [
              if (party.s('phone').isNotEmpty)
                IconButton(
                    icon: const Icon(Icons.call),
                    onPressed: () => callPhone(party.s('phone'))),
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'edit') _edit(context, party);
                  if (v == 'delete') _deleteParty(context, party, data);
                },
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'edit', child: Text(context.tr('Edit'))),
                  PopupMenuItem(
                      value: 'delete', child: Text(context.tr('Delete'))),
                ],
              ),
            ],
          ),
          body: Column(children: [
            Container(
              width: double.infinity,
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(children: [
                Text(
                    bal > 0
                        ? context.tr("You'll get")
                        : bal < 0
                            ? context.tr("You'll give")
                            : 'Settled',
                    style: TextStyle(color: color)),
                Text(money(bal.abs()),
                    style: TextStyle(
                        fontSize: 28, fontWeight: FontWeight.bold, color: color)),
                if (party.s('phone').isNotEmpty)
                  Text(party.s('phone'), style: const TextStyle(fontSize: 12)),
              ]),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              TextButton.icon(
                  onPressed: () => _report(context, party, data),
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('Report')),
              TextButton.icon(
                  onPressed: bal > 0 && party.s('phone').isNotEmpty
                      ? () => openWhatsApp(party.s('phone'), _reminder(party, bal))
                      : null,
                  icon: const Icon(Icons.chat),
                  label: const Text('WhatsApp')),
              TextButton.icon(
                  onPressed: bal > 0 && party.s('phone').isNotEmpty
                      ? () => sendSms([party.s('phone')], _reminder(party, bal))
                      : null,
                  icon: const Icon(Icons.sms),
                  label: const Text('SMS')),
            ]),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
              child: Row(children: [
                const Expanded(
                    child: Text('Entry', style: TextStyle(fontSize: 12, color: Colors.grey))),
                SizedBox(
                    width: 90,
                    child: Text(context.tr('You gave'),
                        textAlign: TextAlign.right,
                        style: const TextStyle(fontSize: 12, color: Colors.red))),
                SizedBox(
                    width: 90,
                    child: Text(context.tr('You got'),
                        textAlign: TextAlign.right,
                        style: const TextStyle(fontSize: 12, color: Colors.green))),
              ]),
            ),
            const Divider(height: 1),
            Expanded(
              child: shown.isEmpty
                  ? EmptyState(context.tr('Nothing here yet'),
                      icon: Icons.receipt_long_outlined)
                  : ListView.separated(
                      itemCount: shown.length,
                      separatorBuilder: (c, i) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final t = shown[i];
                        final gave = t.d('dir') > 0;
                        return InkWell(
                          onLongPress: () async {
                            if (await confirm(context, context.tr('Delete'),
                                '${money(t.d('amount'))} - ${fmtDate(t.dt('date'))}')) {
                              if (context.mounted) {
                                Db.run(context, Db.col('txns').doc(t.id).delete());
                              }
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            child: Row(children: [
                              Expanded(
                                child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(fmtDate(t.dt('date')),
                                          style: const TextStyle(
                                              fontWeight: FontWeight.w600)),
                                      if (t.s('note').isNotEmpty)
                                        Text(t.s('note'),
                                            style: const TextStyle(fontSize: 12)),
                                      Text('Bal ${money(running[t.id] ?? 0)}',
                                          style: const TextStyle(
                                              fontSize: 10, color: Colors.grey)),
                                    ]),
                              ),
                              SizedBox(
                                  width: 90,
                                  child: Text(gave ? money(t.d('amount')) : '',
                                      textAlign: TextAlign.right,
                                      style: const TextStyle(
                                          color: Colors.red,
                                          fontWeight: FontWeight.bold))),
                              SizedBox(
                                  width: 90,
                                  child: Text(!gave ? money(t.d('amount')) : '',
                                      textAlign: TextAlign.right,
                                      style: const TextStyle(
                                          color: Colors.green,
                                          fontWeight: FontWeight.bold))),
                            ]),
                          ),
                        );
                      },
                    ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  Expanded(
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                          backgroundColor: Colors.red.shade600,
                          minimumSize: const Size.fromHeight(48)),
                      onPressed: () => _addTxn(context, party, 1),
                      child: Text(context.tr('You gave')),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                          backgroundColor: Colors.green.shade700,
                          minimumSize: const Size.fromHeight(48)),
                      onPressed: () => _addTxn(context, party, -1),
                      child: Text(context.tr('You got')),
                    ),
                  ),
                ]),
              ),
            ),
          ]),
        );
      },
    );
  }
}
