import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../core/db.dart';
import 'biz.dart';

String _m(num v) => 'Tk ${NumberFormat('#,##0.##').format(v)}';
String _d(DateTime d) => DateFormat('dd MMM yyyy').format(d);
String _month(DateTime d) => DateFormat('MMMM yyyy').format(d);

/// Opens the phone's share sheet -> choose WhatsApp, imo, Messenger, e-mail ...
Future<void> sharePdf(Uint8List bytes, String filename) =>
    Printing.sharePdf(bytes: bytes, filename: filename.replaceAll(' ', '_'));

/// Opens the print / "Save as PDF" screen.
Future<void> printPdf(Uint8List bytes, String name) =>
    Printing.layoutPdf(name: name, onLayout: (_) async => bytes);

/// Uses Google "Noto Sans" + "Noto Sans Bengali" so English AND Bangla names
/// print correctly. Needs internet the first time; offline it falls back to
/// the standard font (Bangla letters may not show in that case).
Future<pw.Document> _newDoc() async {
  try {
    final base = await PdfGoogleFonts.notoSansRegular();
    final bold = await PdfGoogleFonts.notoSansBold();
    final bn = await PdfGoogleFonts.notoSansBengaliRegular();
    return pw.Document(
      theme: pw.ThemeData.withFont(base: base, bold: bold, fontFallback: [bn]),
    );
  } catch (_) {
    return pw.Document();
  }
}

pw.Widget _header(String title, String business, String sub) => pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('My Diary',
                style: pw.TextStyle(
                    fontSize: 10,
                    color: PdfColors.grey700,
                    fontWeight: pw.FontWeight.bold)),
            pw.Text('Generated ${_d(DateTime.now())}',
                style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
          ],
        ),
        pw.SizedBox(height: 6),
        pw.Text(title,
            style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
        pw.Text(business, style: const pw.TextStyle(fontSize: 12)),
        if (sub.isNotEmpty)
          pw.Text(sub,
              style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
        pw.Divider(),
      ],
    );

pw.Widget _table(
  List<String> headers,
  List<List<String>> rows, {
  Set<int> rightAlign = const {},
}) {
  return pw.TableHelper.fromTextArray(
    headers: headers,
    data: rows,
    headerStyle: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold),
    cellStyle: const pw.TextStyle(fontSize: 9),
    headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
    cellAlignments: {
      for (var i = 0; i < headers.length; i++)
        i: rightAlign.contains(i)
            ? pw.Alignment.centerRight
            : pw.Alignment.centerLeft,
    },
    cellPadding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3),
  );
}

pw.Widget _kv(String k, String v, {bool bold = false}) => pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(k,
              style: pw.TextStyle(
                  fontSize: 11,
                  fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
          pw.Text(v,
              style: pw.TextStyle(
                  fontSize: 11,
                  fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
        ],
      ),
    );

String _balText(double b) =>
    b > 0 ? '${_m(b)} (you will get)' : b < 0 ? '${_m(-b)} (you will give)' : 'Settled';

// ------------------------------------------------------- customer / supplier
Future<Uint8List> partyStatementPdf({
  required String business,
  required Rec party,
  required List<Rec> txns, // all txns of this party
  DateTime? from,
  DateTime? to,
}) async {
  final doc = await _newDoc();
  final sorted = [...txns]..sort((a, b) => a.dt('date').compareTo(b.dt('date')));
  var opening = 0.0;
  final inRange = <Rec>[];
  for (final t in sorted) {
    final d = t.dt('date');
    if (from != null && d.isBefore(from)) {
      opening += t.d('dir') * t.d('amount');
    } else if (to != null && d.isAfter(to)) {
      continue;
    } else {
      inRange.add(t);
    }
  }
  var run = opening;
  var gave = 0.0, got = 0.0;
  final rows = <List<String>>[];
  for (final t in inRange) {
    final amt = t.d('amount');
    if (t.d('dir') > 0) {
      gave += amt;
    } else {
      got += amt;
    }
    run += t.d('dir') * amt;
    rows.add([
      _d(t.dt('date')),
      t.s('note'),
      t.d('dir') > 0 ? _m(amt) : '',
      t.d('dir') < 0 ? _m(amt) : '',
      _m(run),
    ]);
  }
  final period = (from == null && to == null)
      ? 'All transactions'
      : '${from == null ? 'Start' : _d(from)}  to  ${to == null ? 'Today' : _d(to)}';

  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(28),
    build: (c) => [
      _header('Account Statement', business, period),
      pw.Text(party.s('name'),
          style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
      if (party.s('phone').isNotEmpty) pw.Text('Phone: ${party.s('phone')}'),
      if (party.s('address').isNotEmpty) pw.Text(party.s('address')),
      pw.SizedBox(height: 10),
      if (from != null) _kv('Opening balance', _balText(opening)),
      _kv('Total "You gave"', _m(gave)),
      _kv('Total "You got"', _m(got)),
      _kv('Closing balance', _balText(run), bold: true),
      pw.SizedBox(height: 10),
      _table(['Date', 'Details', 'You gave', 'You got', 'Balance'], rows,
          rightAlign: {2, 3, 4}),
    ],
  ));
  return doc.save();
}

// ------------------------------------------------------- all parties summary
Future<Uint8List> allPartiesPdf({required String business, required Biz data}) async {
  final doc = await _newDoc();
  List<List<String>> rowsOf(String type) {
    final list = data.parties
        .where((p) => (p.s('type').isEmpty ? 'customer' : p.s('type')) == type)
        .toList()
      ..sort((a, b) => a.s('name').toLowerCase().compareTo(b.s('name').toLowerCase()));
    return [
      for (final p in list)
        [p.s('name'), p.s('phone'), _balText(data.balance(p.id))],
    ];
  }

  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(28),
    build: (c) => [
      _header('Customers & Suppliers Summary', business, 'As of ${_d(DateTime.now())}'),
      _kv("Total you'll get", _m(data.toGet), bold: true),
      _kv("Total you'll give", _m(data.toGive), bold: true),
      pw.SizedBox(height: 10),
      pw.Text('Customers',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _table(['Name', 'Phone', 'Balance'], rowsOf('customer'), rightAlign: {2}),
      pw.SizedBox(height: 14),
      pw.Text('Suppliers',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _table(['Name', 'Phone', 'Balance'], rowsOf('supplier'), rightAlign: {2}),
    ],
  ));
  return doc.save();
}

// ------------------------------------------------------------ cost & savings
Future<Uint8List> costSavingsPdf({
  required String business,
  required Biz data,
  required DateTime month,
}) async {
  final doc = await _newDoc();
  final items = data.cash.where((c) => sameMonth(c.dt('date'), month)).toList()
    ..sort((a, b) => a.dt('date').compareTo(b.dt('date')));
  final inc = data.cashIn(month), exp = data.cashOut(month);
  Map<String, double> byCat(String type) {
    final m = <String, double>{};
    for (final c in items.where((c) => c.s('type') == type)) {
      final k = c.s('category').isEmpty ? 'Other' : c.s('category');
      m[k] = (m[k] ?? 0) + c.d('amount');
    }
    return m;
  }

  List<List<String>> catRows(Map<String, double> m, double total) {
    final keys = m.keys.toList()..sort((a, b) => m[b]!.compareTo(m[a]!));
    return [
      for (final k in keys)
        [k, _m(m[k]!), total == 0 ? '' : '${(m[k]! * 100 / total).toStringAsFixed(1)}%'],
    ];
  }

  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(28),
    build: (c) => [
      _header('Cost & Savings Report', business, _month(month)),
      _kv('Total income', _m(inc)),
      _kv('Total cost / expense', _m(exp)),
      _kv('Savings (income - cost)', _m(inc - exp), bold: true),
      if (inc > 0)
        _kv('Savings rate', '${((inc - exp) * 100 / inc).toStringAsFixed(1)}%'),
      pw.SizedBox(height: 12),
      pw.Text('Cost by category',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _table(['Category', 'Amount', 'Share'], catRows(byCat('out'), exp),
          rightAlign: {1, 2}),
      pw.SizedBox(height: 12),
      pw.Text('Income by source',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _table(['Source', 'Amount', 'Share'], catRows(byCat('in'), inc),
          rightAlign: {1, 2}),
      pw.SizedBox(height: 12),
      pw.Text('All entries',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _table(
        ['Date', 'Type', 'Category / note', 'Amount'],
        [
          for (final e in items)
            [
              _d(e.dt('date')),
              e.s('type') == 'in' ? 'Income' : 'Cost',
              '${e.s('category')} ${e.s('note')}'.trim(),
              _m(e.d('amount')),
            ],
        ],
        rightAlign: {3},
      ),
    ],
  ));
  return doc.save();
}

// ------------------------------------------------------------ monthly report
Future<Uint8List> monthlyReportPdf({
  required String business,
  required Biz data,
  required DateTime month,
}) async {
  final doc = await _newDoc();
  final tx = data.txns.where((t) => sameMonth(t.dt('date'), month)).toList()
    ..sort((a, b) => a.dt('date').compareTo(b.dt('date')));
  var gave = 0.0, got = 0.0;
  for (final t in tx) {
    if (t.d('dir') > 0) {
      gave += t.d('amount');
    } else {
      got += t.d('amount');
    }
  }
  final inc = data.cashIn(month), exp = data.cashOut(month);
  final names = {for (final p in data.parties) p.id: p.s('name')};

  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(28),
    build: (c) => [
      _header('Monthly Report', business, _month(month)),
      pw.Text('Cashbook',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _kv('Income', _m(inc)),
      _kv('Cost / expense', _m(exp)),
      _kv('Savings', _m(inc - exp), bold: true),
      pw.SizedBox(height: 10),
      pw.Text('Customers & suppliers (this month)',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _kv('Total "You gave" (credit given / paid)', _m(gave)),
      _kv('Total "You got" (received / purchased)', _m(got)),
      pw.SizedBox(height: 10),
      pw.Text('Position today',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _kv("Total you'll get", _m(data.toGet)),
      _kv("Total you'll give", _m(data.toGive)),
      _kv('Stock value', _m(data.stockValue)),
      pw.SizedBox(height: 12),
      pw.Text('Party transactions',
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
      _table(
        ['Date', 'Party', 'Details', 'You gave', 'You got'],
        [
          for (final t in tx)
            [
              _d(t.dt('date')),
              names[t.s('partyId')] ?? t.s('partyName'),
              t.s('note'),
              t.d('dir') > 0 ? _m(t.d('amount')) : '',
              t.d('dir') < 0 ? _m(t.d('amount')) : '',
            ],
        ],
        rightAlign: {3, 4},
      ),
    ],
  ));
  return doc.save();
}

// -------------------------------------------------------------------- stock
Future<Uint8List> stockPdf({required String business, required Biz data}) async {
  final doc = await _newDoc();
  final list = [...data.products]
    ..sort((a, b) => a.s('name').toLowerCase().compareTo(b.s('name').toLowerCase()));
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(28),
    build: (c) => [
      _header('Stock Report', business, 'As of ${_d(DateTime.now())}'),
      _kv('Total stock value (buying price)', _m(data.stockValue), bold: true),
      pw.SizedBox(height: 10),
      _table(
        ['Product', 'Qty', 'Unit', 'Buy price', 'Sell price', 'Value'],
        [
          for (final p in list)
            [
              p.s('name'),
              NumberFormat('#,##0.##').format(p.d('qty')),
              p.s('unit'),
              _m(p.d('buyPrice')),
              _m(p.d('sellPrice')),
              _m(p.d('qty') * p.d('buyPrice')),
            ],
        ],
        rightAlign: {1, 3, 4, 5},
      ),
    ],
  ));
  return doc.save();
}

/// Name of the signed-in user (printed nowhere yet, kept for future use).
String reportOwner() => Db.displayName;
