import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../widgets/common.dart';
import 'biz.dart';

/// Daily cashbook: income (cash in) and cost (cash out) by month.
/// Treatment fees from private disease visits appear here automatically.
class CashbookScreen extends StatefulWidget {
  const CashbookScreen({super.key, required this.biz});
  final Rec biz;

  @override
  State<CashbookScreen> createState() => _CashbookScreenState();
}

class _CashbookScreenState extends State<CashbookScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);

  void _shift(int d) =>
      setState(() => _month = DateTime(_month.year, _month.month + d));

  Future<void> _add(String type) async {
    final r = await askFields(
      context,
      title: context.tr(type == 'in' ? 'Cash in' : 'Cash out'),
      fields: [
        const FieldSpec('amount', 'Amount', number: true, required: true),
        FieldSpec('category',
            type == 'in' ? 'Source (sale, fee ...)' : 'Category (feed, rent, medicine ...)'),
        const FieldSpec('note', 'Note', lines: 2),
      ],
      withDate: true,
    );
    if (r == null || !mounted) return;
    final amount = double.tryParse(r['amount']!) ?? 0;
    if (amount <= 0) {
      snack(context, 'Amount must be greater than 0');
      return;
    }
    Db.run(
      context,
      Db.col('cash').add({
        'businessId': widget.biz.id,
        'type': type,
        'amount': amount,
        'category': r['category'],
        'note': r['note'],
        'date': Timestamp.fromDate(DateTime.parse(r['_date']!)),
        ...Db.ownerStamp(),
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${context.tr('Cashbook')} - ${widget.biz.s('name')}')),
      body: BizScope(
        businessId: widget.biz.id,
        cols: const ['cash'],
        builder: (context, data) {
          final items = data.cash
              .where((c) => sameMonth(c.dt('date'), _month))
              .toList()
            ..sort((a, b) => b.dt('date').compareTo(a.dt('date')));
          final inc = data.cashIn(_month);
          final exp = data.cashOut(_month);
          final all = data.cashIn() - data.cashOut();
          return Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(
                  onPressed: () => _shift(-1), icon: const Icon(Icons.chevron_left)),
              Text(fmtMonth(_month),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              IconButton(
                  onPressed: () => _shift(1), icon: const Icon(Icons.chevron_right)),
            ]),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(children: [
                _box(context.tr('Income'), inc, Colors.green.shade700),
                const SizedBox(width: 8),
                _box(context.tr('Expense'), exp, Colors.red.shade700),
                const SizedBox(width: 8),
                _box(context.tr('Savings'), inc - exp,
                    inc - exp >= 0 ? Colors.blue.shade700 : Colors.red.shade700),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text('Total cash balance (all time): ${money(all)}',
                  style: const TextStyle(fontSize: 12, color: Colors.grey)),
            ),
            const Divider(height: 1),
            Expanded(
              child: items.isEmpty
                  ? EmptyState(context.tr('Nothing here yet'),
                      icon: Icons.account_balance_wallet_outlined)
                  : ListView.separated(
                      itemCount: items.length,
                      separatorBuilder: (c, i) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final e = items[i];
                        final isIn = e.s('type') == 'in';
                        final title = e.s('category').isEmpty
                            ? (isIn ? 'Cash in' : 'Cash out')
                            : e.s('category');
                        return ListTile(
                          leading: Icon(
                              isIn ? Icons.south_west : Icons.north_east,
                              color: isIn ? Colors.green : Colors.red),
                          title: Text(title),
                          subtitle: Text(
                              '${fmtDate(e.dt('date'))}${e.s('note').isEmpty ? '' : '\n${e.s('note')}'}'),
                          isThreeLine: e.s('note').isNotEmpty,
                          trailing: Text(
                            '${isIn ? '+' : '-'} ${money(e.d('amount'))}',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isIn ? Colors.green : Colors.red),
                          ),
                          onLongPress: () async {
                            if (await confirm(context, context.tr('Delete'),
                                '$title ${money(e.d('amount'))}')) {
                              if (context.mounted) {
                                Db.run(context, Db.col('cash').doc(e.id).delete());
                              }
                            }
                          },
                        );
                      },
                    ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: Colors.green.shade700,
                          minimumSize: const Size.fromHeight(48)),
                      onPressed: () => _add('in'),
                      icon: const Icon(Icons.add),
                      label: Text(context.tr('Cash in')),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: Colors.red.shade600,
                          minimumSize: const Size.fromHeight(48)),
                      onPressed: () => _add('out'),
                      icon: const Icon(Icons.remove),
                      label: Text(context.tr('Cash out')),
                    ),
                  ),
                ]),
              ),
            ),
          ]);
        },
      ),
    );
  }

  Widget _box(String label, double v, Color color) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(children: [
            Text(label, style: TextStyle(fontSize: 11, color: color)),
            const SizedBox(height: 2),
            FittedBox(
              child: Text(money(v),
                  style: TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 14, color: color)),
            ),
          ]),
        ),
      );
}
