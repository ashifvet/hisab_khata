import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/settings.dart';
import '../../widgets/common.dart';
import 'biz.dart';
import 'business_screen.dart';
import 'cashbook_screen.dart';
import 'group_message_screen.dart';
import 'notes_screen.dart';
import 'party_screen.dart';
import 'reports_screen.dart';
import 'stock_screen.dart';

/// "Hisab" tab (Tallykhata style): customers, suppliers, balances,
/// cashbook, stock, notes, reports and group messages for the active business.
class HisabScreen extends StatelessWidget {
  const HisabScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) => DocsStream(
        query: Db.mine('businesses'),
        builder: (c, list) {
          if (list.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.store_mall_directory_outlined, size: 72),
                  const SizedBox(height: 12),
                  const Text('Create your first business / account book',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16)),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: () => addBusinessDialog(context, list),
                    icon: const Icon(Icons.add),
                    label: const Text('Create business'),
                  ),
                ]),
              ),
            );
          }
          list.sort((a, b) => a.dt('createdAt').compareTo(b.dt('createdAt')));
          final saved = appSettings.activeBusiness(Db.uid);
          final b = list.firstWhere((x) => x.id == saved, orElse: () => list.first);
          return HisabBody(key: ValueKey(b.id), biz: b, all: list);
        },
      ),
    );
  }
}

class HisabBody extends StatefulWidget {
  const HisabBody({super.key, required this.biz, required this.all});
  final Rec biz;
  final List<Rec> all;

  @override
  State<HisabBody> createState() => _HisabBodyState();
}

class _HisabBodyState extends State<HisabBody>
    with SingleTickerProviderStateMixin {
  late final TabController _tab = TabController(length: 2, vsync: this)
    ..addListener(() => setState(() {}));
  String _q = '';

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  void _push(Widget w) =>
      Navigator.push(context, MaterialPageRoute<void>(builder: (_) => w));

  Future<void> _addParty(Biz data) async {
    final type = _tab.index == 0 ? 'customer' : 'supplier';
    final r = await askFields(
      context,
      title: context.tr(type == 'customer' ? 'Add customer' : 'Add supplier'),
      fields: [
        FieldSpec('name', context.tr('Name'), required: true),
        FieldSpec('phone', context.tr('Phone'), phone: true),
        FieldSpec('address', context.tr('Address')),
      ],
    );
    if (r == null || !mounted) return;
    Db.run(
      context,
      Db.col('parties').add({
        'businessId': widget.biz.id,
        'type': type,
        'name': r['name'],
        'phone': r['phone'],
        'address': r['address'],
        ...Db.ownerStamp(),
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final biz = widget.biz;
    final scheme = Theme.of(context).colorScheme;
    return BizScope(
      businessId: biz.id,
      cols: const ['parties', 'txns'],
      builder: (context, data) {
        Widget summary(String label, double v, Color color) => Expanded(
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(label, style: TextStyle(fontSize: 12, color: color)),
                  const SizedBox(height: 2),
                  Text(money(v),
                      style: TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold, color: color)),
                ]),
              ),
            );

        Widget action(IconData icon, String label, Widget page) => InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => _push(page),
              child: SizedBox(
                width: 72,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  CircleAvatar(
                    backgroundColor: scheme.primaryContainer,
                    child: Icon(icon, color: scheme.onPrimaryContainer),
                  ),
                  const SizedBox(height: 4),
                  Text(label,
                      style: const TextStyle(fontSize: 11),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                ]),
              ),
            );

        final balances = data.balances;
        List<Rec> partiesOf(String type) => data.parties
            .where((p) =>
                (p.s('type').isEmpty ? 'customer' : p.s('type')) == type &&
                (_q.isEmpty ||
                    p.s('name').toLowerCase().contains(_q) ||
                    p.s('phone').contains(_q)))
            .toList()
          ..sort((a, b) =>
              a.s('name').toLowerCase().compareTo(b.s('name').toLowerCase()));

        Widget partyList(String type) {
          final list = partiesOf(type);
          if (list.isEmpty) {
            return EmptyState(
                type == 'customer'
                    ? 'No customers yet.\nTap the + button.'
                    : 'No suppliers yet.\nTap the + button.',
                icon: Icons.groups_outlined);
          }
          return ListView.separated(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            separatorBuilder: (c, i) => const Divider(height: 1),
            itemBuilder: (c, i) {
              final p = list[i];
              final bal = balances[p.id] ?? 0;
              final color = bal > 0
                  ? Colors.green.shade700
                  : bal < 0
                      ? Colors.red.shade700
                      : Colors.grey;
              return ListTile(
                leading: CircleAvatar(
                    child: Text(p.s('name').isEmpty
                        ? '?'
                        : p.s('name')[0].toUpperCase())),
                title: Text(p.s('name')),
                subtitle: Text(p.s('phone')),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(money(bal.abs()),
                        style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.bold,
                            fontSize: 15)),
                    Text(
                        bal > 0
                            ? context.tr("You'll get")
                            : bal < 0
                                ? context.tr("You'll give")
                                : 'Settled',
                        style: TextStyle(fontSize: 10, color: color)),
                  ],
                ),
                onTap: () => _push(PartyScreen(biz: biz, partyId: p.id)),
              );
            },
          );
        }

        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _addParty(data),
            icon: const Icon(Icons.person_add),
            label: Text(context.tr(
                _tab.index == 0 ? 'Add customer' : 'Add supplier')),
          ),
          body: Column(children: [
            // business switcher
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 4, 0),
              child: Row(children: [
                Icon(Icons.store, color: scheme.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(biz.s('name'),
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.bold),
                      overflow: TextOverflow.ellipsis),
                ),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.swap_horiz),
                  tooltip: 'Switch business',
                  onSelected: (v) {
                    if (v == '_manage') {
                      _push(const BusinessesScreen());
                    } else if (v == '_new') {
                      addBusinessDialog(context, widget.all);
                    } else {
                      appSettings.setActiveBusiness(Db.uid, v);
                    }
                  },
                  itemBuilder: (_) => [
                    for (final b in widget.all)
                      PopupMenuItem(
                        value: b.id,
                        child: Text(b.s('name') +
                            (Db.isAdmin ? '  (${b.s('ownerName')})' : '')),
                      ),
                    const PopupMenuDivider(),
                    const PopupMenuItem(value: '_new', child: Text('+ New business')),
                    PopupMenuItem(
                        value: '_manage',
                        child: Text(context.tr('Businesses'))),
                  ],
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Row(children: [
                summary(context.tr("You'll get"), data.toGet, Colors.green.shade700),
                const SizedBox(width: 10),
                summary(context.tr("You'll give"), data.toGive, Colors.red.shade700),
              ]),
            ),
            SizedBox(
              height: 78,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                children: [
                  action(Icons.account_balance_wallet, context.tr('Cashbook'),
                      CashbookScreen(biz: biz)),
                  action(Icons.inventory_2, context.tr('Stock'),
                      StockScreen(biz: biz)),
                  action(Icons.picture_as_pdf, context.tr('Reports'),
                      ReportsScreen(biz: biz)),
                  action(Icons.sms, context.tr('Messages'),
                      GroupMessageScreen(biz: biz)),
                  action(Icons.sticky_note_2, context.tr('Notes'),
                      NotesScreen(biz: biz)),
                ],
              ),
            ),
            SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase())),
            TabBar(controller: _tab, tabs: [
              Tab(text: '${context.tr('Customers')} (${partiesOf('customer').length})'),
              Tab(text: '${context.tr('Suppliers')} (${partiesOf('supplier').length})'),
            ]),
            Expanded(
              child: TabBarView(
                  controller: _tab,
                  children: [partyList('customer'), partyList('supplier')]),
            ),
          ]),
        );
      },
    );
  }
}
