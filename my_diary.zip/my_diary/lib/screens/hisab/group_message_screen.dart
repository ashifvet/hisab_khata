import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../widgets/common.dart';
import 'biz.dart';

/// Batch payment reminders: select many customers who owe money,
/// write one message template and send it to all of them.
///
/// Messages are sent through the phone's own SMS / WhatsApp app, so the cost
/// is whatever your SIM plan charges (free with an SMS bundle, free on
/// WhatsApp). {name}, {amount} and {business} are replaced for every person.
class GroupMessageScreen extends StatefulWidget {
  const GroupMessageScreen({super.key, required this.biz});
  final Rec biz;

  @override
  State<GroupMessageScreen> createState() => _GroupMessageScreenState();
}

class _GroupMessageScreenState extends State<GroupMessageScreen> {
  late final TextEditingController _msg = TextEditingController(
    text:
        'Dear {name}, your due amount with {business} is {amount}. Please pay it as soon as possible. Thank you.',
  );
  final Set<String> _selected = {};
  final Set<String> _sent = {};
  bool _init = false;

  @override
  void dispose() {
    _msg.dispose();
    super.dispose();
  }

  String _text(Rec p, double bal) => _msg.text
      .replaceAll('{name}', p.s('name'))
      .replaceAll('{amount}', money(bal))
      .replaceAll('{business}', widget.biz.s('name'));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${context.tr('Messages')} - ${widget.biz.s('name')}')),
      body: BizScope(
        businessId: widget.biz.id,
        cols: const ['parties', 'txns'],
        builder: (context, data) {
          final due = data.parties
              .where((p) => p.s('type') != 'supplier' && data.balance(p.id) > 0)
              .toList()
            ..sort((a, b) => data.balance(b.id).compareTo(data.balance(a.id)));
          if (!_init) {
            _init = true;
            _selected.addAll(due.where((p) => p.s('phone').isNotEmpty).map((p) => p.id));
          }
          final chosen = due.where((p) => _selected.contains(p.id)).toList();

          return Column(children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                controller: _msg,
                minLines: 3,
                maxLines: 5,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'Message  ({name} {amount} {business})',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Row(children: [
              const SizedBox(width: 8),
              Checkbox(
                value: due.isNotEmpty && chosen.length == due.length,
                onChanged: (v) => setState(() {
                  if (v == true) {
                    _selected.addAll(due.map((p) => p.id));
                  } else {
                    _selected.clear();
                  }
                }),
              ),
              Expanded(
                  child: Text('Select all  (${chosen.length}/${due.length} selected)')),
            ]),
            const Divider(height: 1),
            Expanded(
              child: due.isEmpty
                  ? const EmptyState('Nobody owes you money right now.',
                      icon: Icons.celebration_outlined)
                  : ListView.separated(
                      itemCount: due.length,
                      separatorBuilder: (c, i) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final p = due[i];
                        final bal = data.balance(p.id);
                        final hasPhone = p.s('phone').isNotEmpty;
                        return CheckboxListTile(
                          value: _selected.contains(p.id),
                          onChanged: (v) => setState(() {
                            if (v == true) {
                              _selected.add(p.id);
                            } else {
                              _selected.remove(p.id);
                            }
                          }),
                          title: Text(p.s('name')),
                          subtitle: Text(
                              '${hasPhone ? p.s('phone') : 'No phone number'}  •  ${money(bal)}'
                              '${_sent.contains(p.id) ? '  ✔ sent' : ''}'),
                          secondary: Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(
                              icon: const Icon(Icons.sms),
                              onPressed: hasPhone
                                  ? () {
                                      sendSms([p.s('phone')], _text(p, bal));
                                      setState(() => _sent.add(p.id));
                                    }
                                  : null,
                            ),
                            IconButton(
                              icon: const Icon(Icons.chat, color: Colors.green),
                              onPressed: hasPhone
                                  ? () {
                                      openWhatsApp(p.s('phone'), _text(p, bal));
                                      setState(() => _sent.add(p.id));
                                    }
                                  : null,
                            ),
                          ]),
                        );
                      },
                    ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: chosen.where((p) => p.s('phone').isNotEmpty).isEmpty
                          ? null
                          : () {
                              final withPhone =
                                  chosen.where((p) => p.s('phone').isNotEmpty).toList();
                              // one group message to everybody selected
                              sendSms(withPhone.map((p) => p.s('phone')).toList(),
                                  _msg.text
                                      .replaceAll('{name}', 'Sir/Madam')
                                      .replaceAll('{amount}', 'your due amount')
                                      .replaceAll('{business}', widget.biz.s('name')));
                              setState(() => _sent.addAll(withPhone.map((p) => p.id)));
                            },
                      icon: const Icon(Icons.group),
                      label: const Text('Send ONE group SMS to all selected'),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Tip: the group SMS has the same text for everybody. Use the SMS / WhatsApp buttons beside a name to send a personal message with that person\'s own name and amount.',
                    style: TextStyle(fontSize: 11, color: Colors.grey),
                  ),
                ]),
              ),
            ),
          ]);
        },
      ),
    );
  }
}
