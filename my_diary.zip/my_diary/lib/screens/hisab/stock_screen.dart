import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import 'package:intl/intl.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../widgets/common.dart';
import 'biz.dart';

/// Stock & inventory: quantity of every product and total stock value.
class StockScreen extends StatelessWidget {
  const StockScreen({super.key, required this.biz});
  final Rec biz;

  String _q(double v) => NumberFormat('#,##0.##').format(v);

  Future<void> _addProduct(BuildContext context) async {
    final r = await askFields(context, title: 'New product', fields: const [
      FieldSpec('name', 'Product name', required: true),
      FieldSpec('unit', 'Unit (pcs, kg, vial, bottle ...)', initial: 'pcs'),
      FieldSpec('qty', 'Opening quantity', number: true, initial: '0'),
      FieldSpec('buy', 'Buying price (per unit)', number: true, initial: '0'),
      FieldSpec('sell', 'Selling price (per unit)', number: true, initial: '0'),
    ]);
    if (r == null || !context.mounted) return;
    Db.run(
      context,
      Db.col('products').add({
        'businessId': biz.id,
        'name': r['name'],
        'unit': r['unit']!.isEmpty ? 'pcs' : r['unit'],
        'qty': double.tryParse(r['qty']!) ?? 0,
        'buyPrice': double.tryParse(r['buy']!) ?? 0,
        'sellPrice': double.tryParse(r['sell']!) ?? 0,
        ...Db.ownerStamp(),
      }),
    );
  }

  Future<void> _adjust(BuildContext context, Rec p, int sign) async {
    final r = await askFields(
      context,
      title: sign > 0 ? 'Stock in - ${p.s('name')}' : 'Stock out - ${p.s('name')}',
      fields: const [FieldSpec('qty', 'Quantity', number: true, required: true)],
    );
    if (r == null || !context.mounted) return;
    final q = double.tryParse(r['qty']!) ?? 0;
    if (q <= 0) return;
    // increment() is safe even when two devices edit at the same time / offline
    Db.run(context,
        Db.col('products').doc(p.id).update({'qty': FieldValue.increment(sign * q)}));
  }

  Future<void> _edit(BuildContext context, Rec p) async {
    final r = await askFields(context, title: context.tr('Edit'), fields: [
      FieldSpec('name', 'Product name', required: true, initial: p.s('name')),
      FieldSpec('unit', 'Unit', initial: p.s('unit')),
      FieldSpec('qty', 'Quantity', number: true, initial: '${p.d('qty')}'),
      FieldSpec('buy', 'Buying price', number: true, initial: '${p.d('buyPrice')}'),
      FieldSpec('sell', 'Selling price', number: true, initial: '${p.d('sellPrice')}'),
    ]);
    if (r == null || !context.mounted) return;
    Db.run(
      context,
      Db.col('products').doc(p.id).update({
        'name': r['name'],
        'unit': r['unit'],
        'qty': double.tryParse(r['qty']!) ?? 0,
        'buyPrice': double.tryParse(r['buy']!) ?? 0,
        'sellPrice': double.tryParse(r['sell']!) ?? 0,
      }),
    );
  }

  void _menu(BuildContext context, Rec p) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              title: Text(p.s('name'),
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          ListTile(
            leading: const Icon(Icons.add_box, color: Colors.green),
            title: const Text('Stock in (purchase)'),
            onTap: () {
              Navigator.pop(ctx);
              _adjust(context, p, 1);
            },
          ),
          ListTile(
            leading: const Icon(Icons.indeterminate_check_box, color: Colors.red),
            title: const Text('Stock out (sale / use)'),
            onTap: () {
              Navigator.pop(ctx);
              _adjust(context, p, -1);
            },
          ),
          ListTile(
            leading: const Icon(Icons.edit),
            title: Text(context.tr('Edit')),
            onTap: () {
              Navigator.pop(ctx);
              _edit(context, p);
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete),
            title: Text(context.tr('Delete')),
            onTap: () async {
              Navigator.pop(ctx);
              if (await confirm(context, context.tr('Delete'), p.s('name'))) {
                if (context.mounted) {
                  Db.run(context, Db.col('products').doc(p.id).delete());
                }
              }
            },
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${context.tr('Stock')} - ${biz.s('name')}')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addProduct(context),
        icon: const Icon(Icons.add),
        label: const Text('Product'),
      ),
      body: BizScope(
        businessId: biz.id,
        cols: const ['products'],
        builder: (context, data) {
          final list = [...data.products]
            ..sort((a, b) =>
                a.s('name').toLowerCase().compareTo(b.s('name').toLowerCase()));
          return Column(children: [
            Container(
              width: double.infinity,
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(children: [
                const Text('Total stock value (buying price)'),
                Text(money(data.stockValue),
                    style: const TextStyle(
                        fontSize: 26, fontWeight: FontWeight.bold)),
                Text('${list.length} products',
                    style: const TextStyle(fontSize: 12)),
              ]),
            ),
            Expanded(
              child: list.isEmpty
                  ? const EmptyState('No products yet.\nTap "Product" to add.',
                      icon: Icons.inventory_2_outlined)
                  : ListView.separated(
                      padding: const EdgeInsets.only(bottom: 90),
                      itemCount: list.length,
                      separatorBuilder: (c, i) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final p = list[i];
                        final low = p.d('qty') <= 0;
                        return ListTile(
                          title: Text(p.s('name')),
                          subtitle: Text(
                              'Buy ${money(p.d('buyPrice'))}  •  Sell ${money(p.d('sellPrice'))}'),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text('${_q(p.d('qty'))} ${p.s('unit')}',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: low ? Colors.red : null)),
                              Text(money(p.d('qty') * p.d('buyPrice')),
                                  style: const TextStyle(
                                      fontSize: 11, color: Colors.grey)),
                            ],
                          ),
                          onTap: () => _menu(context, p),
                        );
                      },
                    ),
            ),
          ]);
        },
      ),
    );
  }
}
