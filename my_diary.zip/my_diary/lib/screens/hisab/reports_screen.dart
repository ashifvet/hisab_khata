import 'dart:typed_data';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../widgets/common.dart';
import 'biz.dart';
import 'report_pdf.dart';

/// Downloadable / shareable PDF reports.
/// "Share" opens the phone share sheet (WhatsApp, imo, Messenger ...).
/// "Print / Save" lets you print or save the PDF to the phone.
class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key, required this.biz});
  final Rec biz;

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  String? _partyId;
  bool _onlyMonth = false;
  bool _busy = false;

  void _shift(int d) =>
      setState(() => _month = DateTime(_month.year, _month.month + d));

  Future<void> _go(
    Future<Uint8List> Function() build,
    String name, {
    required bool share,
  }) async {
    setState(() => _busy = true);
    try {
      final bytes = await build();
      if (share) {
        await sharePdf(bytes, name);
      } else {
        await printPdf(bytes, name);
      }
    } catch (e) {
      if (mounted) snack(context, 'Could not create the report: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _card({
    required IconData icon,
    required String title,
    required String subtitle,
    required Future<Uint8List> Function() build,
    required String file,
    Widget? extra,
    bool enabled = true,
  }) {
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 10),
            Expanded(
              child:
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(subtitle,
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ]),
            ),
          ]),
          ?extra,
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed:
                    (_busy || !enabled) ? null : () => _go(build, file, share: true),
                icon: const Icon(Icons.share, size: 18),
                label: Text(context.tr('Share')),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed:
                    (_busy || !enabled) ? null : () => _go(build, file, share: false),
                icon: const Icon(Icons.print, size: 18),
                label: Text(context.tr('Print / Save')),
              ),
            ),
          ]),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bizName = widget.biz.s('name');
    return Scaffold(
      appBar: AppBar(title: Text('${context.tr('Reports')} - $bizName')),
      body: BizScope(
        businessId: widget.biz.id,
        cols: const ['parties', 'txns', 'cash', 'products'],
        builder: (context, data) {
          final parties = [...data.parties]..sort((a, b) =>
              a.s('name').toLowerCase().compareTo(b.s('name').toLowerCase()));
          if (_partyId != null && !parties.any((p) => p.id == _partyId)) {
            _partyId = null;
          }
          final selected = parties.where((p) => p.id == _partyId).toList();
          final monthStart = _month;
          final monthEnd = DateTime(_month.year, _month.month + 1)
              .subtract(const Duration(milliseconds: 1));

          return Stack(children: [
            ListView(padding: const EdgeInsets.only(bottom: 24), children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(
                    onPressed: () => _shift(-1),
                    icon: const Icon(Icons.chevron_left)),
                Text(fmtMonth(_month),
                    style:
                        const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                IconButton(
                    onPressed: () => _shift(1),
                    icon: const Icon(Icons.chevron_right)),
              ]),
              _card(
                icon: Icons.person_search,
                title: 'Customer / Supplier statement',
                subtitle: 'Full account statement of one party',
                file: 'statement.pdf',
                enabled: selected.isNotEmpty,
                extra: Column(children: [
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: _partyId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                        labelText: 'Choose party', border: OutlineInputBorder()),
                    items: [
                      for (final p in parties)
                        DropdownMenuItem(
                            value: p.id,
                            child: Text(
                                '${p.s('name')} (${p.s('type') == 'supplier' ? 'supplier' : 'customer'})',
                                overflow: TextOverflow.ellipsis)),
                    ],
                    onChanged: (v) => setState(() => _partyId = v),
                  ),
                  SwitchListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    title: Text('Only ${fmtMonth(_month)}'),
                    value: _onlyMonth,
                    onChanged: (v) => setState(() => _onlyMonth = v),
                  ),
                ]),
                build: () => partyStatementPdf(
                  business: bizName,
                  party: selected.first,
                  txns: data.partyTxns(selected.first.id),
                  from: _onlyMonth ? monthStart : null,
                  to: _onlyMonth ? monthEnd : null,
                ),
              ),
              _card(
                icon: Icons.groups,
                title: 'All customers & suppliers',
                subtitle: 'Balance of everybody in one list',
                file: 'all_parties.pdf',
                build: () => allPartiesPdf(business: bizName, data: data),
              ),
              _card(
                icon: Icons.savings,
                title: 'Cost & Savings',
                subtitle: 'Income, cost by category and savings of ${fmtMonth(_month)}',
                file: 'cost_savings_${_month.year}_${_month.month}.pdf',
                build: () =>
                    costSavingsPdf(business: bizName, data: data, month: _month),
              ),
              _card(
                icon: Icons.calendar_month,
                title: 'Monthly report',
                subtitle: 'Cashbook + party transactions + stock of ${fmtMonth(_month)}',
                file: 'monthly_${_month.year}_${_month.month}.pdf',
                build: () =>
                    monthlyReportPdf(business: bizName, data: data, month: _month),
              ),
              _card(
                icon: Icons.inventory_2,
                title: 'Stock report',
                subtitle: 'Quantity and value of every product',
                file: 'stock.pdf',
                build: () => stockPdf(business: bizName, data: data),
              ),
            ]),
            if (_busy)
              const Positioned.fill(
                  child: ColoredBox(
                      color: Color(0x55000000),
                      child: Center(child: CircularProgressIndicator()))),
          ]);
        },
      ),
    );
  }
}
