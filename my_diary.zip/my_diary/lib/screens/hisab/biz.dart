import 'dart:async';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';

bool sameMonth(DateTime a, DateTime b) => a.year == b.year && a.month == b.month;

/// All data of ONE business, already filtered by businessId.
///
/// Collections:
///   parties  : customers & suppliers   {name, phone, address, type}
///   txns     : party transactions      {partyId, dir(+1 gave / -1 got), amount, note, date}
///   cash     : cashbook                {type in/out, amount, category, note, date}
///   products : stock                   {name, unit, qty, buyPrice, sellPrice}
///   notes    : business notes          {title, body}
class Biz {
  Biz(this._d);
  final Map<String, List<Rec>> _d;

  List<Rec> get parties => _d['parties'] ?? const [];
  List<Rec> get txns => _d['txns'] ?? const [];
  List<Rec> get cash => _d['cash'] ?? const [];
  List<Rec> get products => _d['products'] ?? const [];
  List<Rec> get notes => _d['notes'] ?? const [];

  /// > 0  : the party owes ME (I will get)
  /// < 0  : I owe the party (I will give)
  double balance(String partyId) {
    var t = 0.0;
    for (final x in txns) {
      if (x.s('partyId') == partyId) t += x.d('dir') * x.d('amount');
    }
    return t;
  }

  Map<String, double> get balances {
    final m = <String, double>{};
    for (final x in txns) {
      final id = x.s('partyId');
      m[id] = (m[id] ?? 0) + x.d('dir') * x.d('amount');
    }
    return m;
  }

  double get toGet {
    var t = 0.0;
    for (final p in parties) {
      final b = balance(p.id);
      if (b > 0) t += b;
    }
    return t;
  }

  double get toGive {
    var t = 0.0;
    for (final p in parties) {
      final b = balance(p.id);
      if (b < 0) t += -b;
    }
    return t;
  }

  List<Rec> partyTxns(String partyId) =>
      txns.where((x) => x.s('partyId') == partyId).toList()
        ..sort((a, b) => a.dt('date').compareTo(b.dt('date')));

  double get stockValue {
    var t = 0.0;
    for (final p in products) {
      t += p.d('qty') * p.d('buyPrice');
    }
    return t;
  }

  double cashIn([DateTime? month]) => _cash('in', month);
  double cashOut([DateTime? month]) => _cash('out', month);

  double _cash(String type, DateTime? month) {
    var t = 0.0;
    for (final c in cash) {
      if (c.s('type') != type) continue;
      if (month != null && !sameMonth(c.dt('date'), month)) continue;
      t += c.d('amount');
    }
    return t;
  }
}

/// Subscribes to the chosen collections of one business (offline friendly).
/// Give it `key: ValueKey(businessId)` so it is rebuilt when the business changes.
class BizScope extends StatefulWidget {
  const BizScope({
    super.key,
    required this.businessId,
    required this.cols,
    required this.builder,
  });
  final String businessId;
  final List<String> cols;
  final Widget Function(BuildContext, Biz) builder;

  @override
  State<BizScope> createState() => _BizScopeState();
}

class _BizScopeState extends State<BizScope> {
  final Map<String, List<Rec>> _data = {};
  final List<StreamSubscription<dynamic>> _subs = [];
  Object? _error;

  @override
  void initState() {
    super.initState();
    for (final c in widget.cols) {
      _subs.add(Db.mine(c).snapshots().listen((s) {
        if (!mounted) return;
        setState(() {
          _data[c] = s.docs
              .map(Rec.from)
              .where((r) => r.s('businessId') == widget.businessId)
              .toList();
        });
      }, onError: (Object e) {
        if (mounted) setState(() => _error = e);
      }));
    }
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Center(child: Text('Error: $_error'));
    }
    if (_data.length < widget.cols.length) {
      return const Center(child: CircularProgressIndicator());
    }
    return widget.builder(context, Biz(_data));
  }
}
