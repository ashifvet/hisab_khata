import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../core/settings.dart';
import '../../widgets/common.dart';

const maxBusinesses = 5;

/// Creates a new business (max 5 per user) and makes it the active one.
Future<void> addBusinessDialog(BuildContext context, List<Rec> all) async {
  final mine = all.where((b) => b.s('uid') == Db.uid).length;
  if (mine >= maxBusinesses) {
    snack(context, 'You can manage up to $maxBusinesses businesses.');
    return;
  }
  final r = await askFields(
    context,
    title: 'New business',
    fields: const [
      FieldSpec('name', 'Business name', required: true),
      FieldSpec('type', 'Type (shop, clinic, farm, personal ...)'),
    ],
  );
  if (r == null || !context.mounted) return;
  final ref = Db.col('businesses').doc();
  Db.run(context,
      ref.set({'name': r['name'], 'type': r['type'], ...Db.ownerStamp()}));
  await appSettings.setActiveBusiness(Db.uid, ref.id);
}

class BusinessesScreen extends StatelessWidget {
  const BusinessesScreen({super.key});

  Future<void> _delete(BuildContext context, Rec b) async {
    final ok = await confirm(context, context.tr('Delete'),
        '"${b.s('name')}" and ALL its customers, transactions, cashbook, stock and notes will be deleted.');
    if (!ok) return;
    for (final c in ['parties', 'txns', 'cash', 'products', 'notes']) {
      final snap = await Db.mine(c)
          .where('businessId', isEqualTo: b.id)
          .get(const GetOptions(source: Source.cache));
      final docs = snap.docs;
      for (var i = 0; i < docs.length; i += 400) {
        final batch = Db.fs.batch();
        for (final d in docs.skip(i).take(400)) {
          batch.delete(d.reference);
        }
        batch.commit().catchError((Object _) {});
      }
    }
    Db.col('businesses').doc(b.id).delete().catchError((Object _) {});
    if (appSettings.activeBusiness(Db.uid) == b.id) {
      await appSettings.setActiveBusiness(Db.uid, null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) => DocsStream(
        query: Db.mine('businesses'),
        builder: (c, list) {
          list.sort((a, b) => a.dt('createdAt').compareTo(b.dt('createdAt')));
          final active = appSettings.activeBusiness(Db.uid);
          return Scaffold(
            appBar: AppBar(title: Text(context.tr('Businesses'))),
            floatingActionButton: FloatingActionButton.extended(
              onPressed: () => addBusinessDialog(context, list),
              icon: const Icon(Icons.add),
              label: Text('New (${list.where((b) => b.s('uid') == Db.uid).length}/$maxBusinesses)'),
            ),
            body: ListView(
              padding: const EdgeInsets.only(bottom: 90),
              children: [
                for (final b in list)
                  ListTile(
                    leading: Icon(
                      (active == b.id || (active == null && b == list.first))
                          ? Icons.radio_button_checked
                          : Icons.radio_button_off,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    title: Text(b.s('name')),
                    subtitle: Text(
                        '${b.s('type')}${Db.isAdmin ? '  •  ${b.s('ownerName')}' : ''}'),
                    onTap: () {
                      appSettings.setActiveBusiness(Db.uid, b.id);
                      Navigator.pop(context);
                    },
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) async {
                        if (v == 'rename') {
                          final r = await askFields(context,
                              title: 'Rename',
                              fields: [
                                FieldSpec('name', 'Business name',
                                    required: true, initial: b.s('name')),
                                FieldSpec('type', 'Type', initial: b.s('type')),
                              ]);
                          if (r != null && context.mounted) {
                            Db.run(
                                context,
                                Db.col('businesses').doc(b.id).update(
                                    {'name': r['name'], 'type': r['type']}));
                          }
                        } else if (v == 'delete') {
                          await _delete(context, b);
                        }
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(value: 'rename', child: Text('Rename')),
                        PopupMenuItem(
                            value: 'delete', child: Text(context.tr('Delete'))),
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}
