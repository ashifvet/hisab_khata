import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../widgets/common.dart';
import 'biz.dart';

/// Digital notebook that replaces the paper notebook.
class NotesScreen extends StatelessWidget {
  const NotesScreen({super.key, required this.biz});
  final Rec biz;

  Future<void> _edit(BuildContext context, [Rec? n]) async {
    final r = await askFields(
      context,
      title: n == null ? 'New note' : context.tr('Edit'),
      fields: [
        FieldSpec('title', context.tr('Title'), required: true, initial: n?.s('title') ?? ''),
        FieldSpec('body', 'Note', lines: 6, initial: n?.s('body') ?? ''),
      ],
    );
    if (r == null || !context.mounted) return;
    final data = {'title': r['title'], 'body': r['body']};
    if (n == null) {
      Db.run(context,
          Db.col('notes').add({...data, 'businessId': biz.id, ...Db.ownerStamp()}));
    } else {
      Db.run(context, Db.col('notes').doc(n.id).update(data));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${context.tr('Notes')} - ${biz.s('name')}')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context),
        icon: const Icon(Icons.note_add),
        label: const Text('New note'),
      ),
      body: BizScope(
        businessId: biz.id,
        cols: const ['notes'],
        builder: (context, data) {
          final list = [...data.notes]
            ..sort((a, b) => b.dt('createdAt').compareTo(a.dt('createdAt')));
          if (list.isEmpty) {
            return const EmptyState('No notes yet.',
                icon: Icons.sticky_note_2_outlined);
          }
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            itemBuilder: (c, i) {
              final n = list[i];
              return Card(
                margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: ListTile(
                  title: Text(n.s('title'),
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(
                    '${n.s('body')}\n${fmtDate(n.dt('createdAt'))}',
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                  ),
                  onTap: () => _edit(context, n),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      if (await confirm(context, context.tr('Delete'), n.s('title'))) {
                        if (context.mounted) {
                          Db.run(context, Db.col('notes').doc(n.id).delete());
                        }
                      }
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
