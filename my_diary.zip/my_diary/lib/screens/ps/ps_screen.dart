import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../widgets/common.dart';
import '../../widgets/live_doc.dart';
import '../add/forms.dart';

/// P&S = Problem based Solutions (private to every user, admin sees all).
class PsScreen extends StatefulWidget {
  const PsScreen({super.key});

  @override
  State<PsScreen> createState() => _PsScreenState();
}

class _PsScreenState extends State<PsScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase())),
      Expanded(
        child: DocsStream(
          query: Db.mine('problems'),
          builder: (c, all) {
            final list = all
                .where((p) =>
                    _q.isEmpty ||
                    p.s('title').toLowerCase().contains(_q) ||
                    p.s('problem').toLowerCase().contains(_q))
                .toList()
              ..sort((a, b) => b.dt('createdAt').compareTo(a.dt('createdAt')));
            if (list.isEmpty) {
              return const EmptyState(
                  'No problems & solutions yet.\nUse the Add tab.',
                  icon: Icons.lightbulb_outline);
            }
            return ListView.separated(
              itemCount: list.length,
              separatorBuilder: (c, i) => const Divider(height: 1),
              itemBuilder: (c, i) {
                final p = list[i];
                return ListTile(
                  leading: const Icon(Icons.lightbulb_outline),
                  title: Text(p.s('title'),
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(
                    p.s('problem'),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                          builder: (_) => ProblemDetail(id: p.id))),
                );
              },
            );
          },
        ),
      ),
    ]);
  }
}

class ProblemDetail extends StatelessWidget {
  const ProblemDetail({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    return LiveDoc(
      collection: 'problems',
      id: id,
      builder: (context, p) {
        if (p == null) {
          return Scaffold(
              appBar: AppBar(),
              body: const EmptyState('This record was deleted.'));
        }
        return DetailPage(
          title: p.s('title'),
          actions: [
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (_) => EditPage(
                    title: context.tr('Edit'),
                    child: Builder(
                      builder: (c) =>
                          ProblemForm(edit: p, onSaved: () => Navigator.pop(c)),
                    ),
                  ),
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () async {
                if (await confirm(context, context.tr('Delete'), p.s('title'))) {
                  if (!context.mounted) return;
                  Db.run(context, Db.col('problems').doc(p.id).delete());
                  Navigator.pop(context);
                }
              },
            ),
          ],
          rows: [
            (context.tr('Problems'), p.s('problem')),
            (context.tr('Solutions'), p.s('solution')),
            (context.tr('Prognosis'), p.s('prognosis')),
            if (Db.isAdmin) ('Added by', p.s('ownerName')),
          ],
        );
      },
    );
  }
}
