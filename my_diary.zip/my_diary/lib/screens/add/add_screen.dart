import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../data/seed_data.dart';
import '../../widgets/common.dart';
import 'forms.dart';

/// "Add" tab: Company | Medicine | Disease | Problem & Solution
class AddScreen extends StatefulWidget {
  const AddScreen({super.key});

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  // Changing a counter re-creates the form = clears it after saving.
  final _n = [0, 0, 0, 0];
  bool _importing = false;

  void _reset(int i) => setState(() => _n[i]++);

  Future<void> _import() async {
    final ok = await confirm(
        context,
        'Import starter data?',
        'This adds the 13 companies from your list and about 150 ACME Laboratories veterinary brands (names, categories, components). Safe to press twice.');
    if (!ok || !mounted) return;
    setState(() => _importing = true);
    try {
      final n = await importStarterData();
      if (mounted) snack(context, '$n records imported');
    } catch (e) {
      if (mounted) {
        snack(context,
            'Import failed (maybe somebody already imported it): $e');
      }
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Column(children: [
        TabBar(
          isScrollable: false,
          labelPadding: EdgeInsets.zero,
          tabs: [
            Tab(icon: const Icon(Icons.business), text: context.tr('Company')),
            Tab(icon: const Icon(Icons.medication), text: context.tr('Medicine')),
            Tab(icon: const Icon(Icons.healing), text: context.tr('Disease')),
            Tab(
                icon: const Icon(Icons.lightbulb),
                text: context.tr('P&S')),
          ],
        ),
        Expanded(
          child: TabBarView(children: [
            // ---- company
            Column(children: [
              Expanded(
                  child: CompanyForm(
                      key: ValueKey('c${_n[0]}'), onSaved: () => _reset(0))),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: OutlinedButton.icon(
                  onPressed: _importing ? null : _import,
                  icon: _importing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.download),
                  label: const Text('Import starter companies & medicines'),
                ),
              ),
            ]),
            // ---- medicine
            DocsStream(
              query: Db.shared('companies'),
              builder: (c, companies) => MedicineForm(
                key: ValueKey('m${_n[1]}'),
                companies: companies,
                onSaved: () => _reset(1),
              ),
            ),
            // ---- disease
            DiseaseForm(key: ValueKey('d${_n[2]}'), onSaved: () => _reset(2)),
            // ---- problem & solution
            ProblemForm(key: ValueKey('p${_n[3]}'), onSaved: () => _reset(3)),
          ]),
        ),
      ]),
    );
  }
}
