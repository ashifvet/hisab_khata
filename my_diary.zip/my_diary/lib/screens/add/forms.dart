import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../core/launch.dart';
import '../../widgets/common.dart';

/// Choice buttons (Safe/Unsafe, Present/Absent, Good/Poor ...).
Widget segField(
  BuildContext c,
  String label,
  List<String> options,
  String? value,
  ValueChanged<String?> onChanged,
) {
  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
    const SizedBox(height: 4),
    SizedBox(
      width: double.infinity,
      child: SegmentedButton<String>(
        emptySelectionAllowed: true,
        showSelectedIcon: false,
        segments: [
          for (final o in options)
            ButtonSegment<String>(value: o, label: Text(c.tr(o))),
        ],
        selected: value == null ? <String>{} : <String>{value},
        onSelectionChanged: (s) => onChanged(s.isEmpty ? null : s.first),
      ),
    ),
  ]);
}

/// Wraps a form in a page (used for "Edit").
class EditPage extends StatelessWidget {
  const EditPage({super.key, required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) =>
      Scaffold(appBar: AppBar(title: Text(title)), body: child);
}

// =================================================================== COMPANY
class CompanyForm extends StatefulWidget {
  const CompanyForm({super.key, this.edit, this.onSaved});
  final Rec? edit;
  final VoidCallback? onSaved;

  @override
  State<CompanyForm> createState() => _CompanyFormState();
}

class _CompanyFormState extends State<CompanyForm> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.edit?.s('name') ?? '');
  late final _details =
      TextEditingController(text: widget.edit?.s('details') ?? '');

  @override
  void dispose() {
    _name.dispose();
    _details.dispose();
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final data = {'name': _name.text.trim(), 'details': _details.text.trim()};
    if (widget.edit == null) {
      Db.run(context, Db.col('companies').add({...data, ...Db.creatorStamp()}));
    } else {
      Db.run(context, Db.col('companies').doc(widget.edit!.id).update(data));
    }
    snack(context, context.tr('Saved'));
    widget.onSaved?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: spaced([
          Input(_name, context.tr('Company name'), required: true),
          Input(_details, 'Details (what this company is good for)', lines: 3),
          FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(context.tr('Save'))),
        ]),
      ),
    );
  }
}

// ================================================================== MEDICINE
class MedicineForm extends StatefulWidget {
  const MedicineForm({
    super.key,
    required this.companies,
    this.edit,
    this.companyId,
    this.onSaved,
  });
  final List<Rec> companies;
  final Rec? edit;
  final String? companyId;
  final VoidCallback? onSaved;

  @override
  State<MedicineForm> createState() => _MedicineFormState();
}

class _MedicineFormState extends State<MedicineForm> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.edit?.s('name') ?? '');
  late final _category =
      TextEditingController(text: widget.edit?.s('category') ?? '');
  late final _components =
      TextEditingController(text: widget.edit?.s('components') ?? '');
  late final _when =
      TextEditingController(text: widget.edit?.s('whenToUse') ?? '');
  late final _dose = TextEditingController(text: widget.edit?.s('dose') ?? '');
  late final _details =
      TextEditingController(text: widget.edit?.s('details') ?? '');
  String? _companyId;
  String? _pregnancy;
  String? _pet;
  bool _fav = false;

  @override
  void initState() {
    super.initState();
    final e = widget.edit;
    _companyId = e?.s('companyId') ?? widget.companyId;
    if (_companyId != null && !widget.companies.any((c) => c.id == _companyId)) {
      _companyId = null;
    }
    String? ok(String v) => (v == 'Safe' || v == 'Unsafe') ? v : null;
    _pregnancy = ok(e?.s('pregnancy') ?? '');
    _pet = ok(e?.s('petSafety') ?? '');
    _fav = e?.b('favourite') ?? false;
  }

  @override
  void dispose() {
    for (final c in [_name, _category, _components, _when, _dose, _details]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    if (_pregnancy == null || _pet == null) {
      snack(context, 'Please choose Pregnancy and Pet safety (Safe / Unsafe)');
      return;
    }
    final company = widget.companies.firstWhere((c) => c.id == _companyId);
    final data = {
      'name': _name.text.trim(),
      'companyId': company.id,
      'companyName': company.s('name'),
      'category': _category.text.trim(),
      'components': _components.text.trim(),
      'whenToUse': _when.text.trim(),
      'dose': _dose.text.trim(),
      'pregnancy': _pregnancy,
      'petSafety': _pet,
      'details': _details.text.trim(),
      'favourite': _fav,
    };
    if (widget.edit == null) {
      Db.run(context, Db.col('medicines').add({...data, ...Db.creatorStamp()}));
    } else {
      Db.run(context, Db.col('medicines').doc(widget.edit!.id).update(data));
    }
    snack(context, context.tr('Saved'));
    widget.onSaved?.call();
  }

  @override
  Widget build(BuildContext context) {
    final companies = [...widget.companies]
      ..sort((a, b) =>
          a.s('name').toLowerCase().compareTo(b.s('name').toLowerCase()));
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: spaced([
          if (companies.isEmpty)
            const Card(
                child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Text('Add a company first (Company tab).')))
          else
            DropdownButtonFormField<String>(
              initialValue: _companyId,
              isExpanded: true,
              decoration: InputDecoration(
                  labelText: context.tr('Company'),
                  border: const OutlineInputBorder()),
              items: [
                for (final c in companies)
                  DropdownMenuItem(
                      value: c.id,
                      child: Text(c.s('name'), overflow: TextOverflow.ellipsis)),
              ],
              onChanged: (v) => setState(() => _companyId = v),
              validator: (v) => v == null ? context.tr('Required') : null,
            ),
          Input(_name, context.tr('Medicine name'), required: true),
          Input(_category, 'Category (antibiotic, vitamin ...)'),
          Input(_components, context.tr('Components'), lines: 2),
          Input(_when, context.tr('When to use'), lines: 3),
          Input(_dose, context.tr('Dose'), lines: 2),
          segField(context, context.tr('Pregnancy'), const ['Safe', 'Unsafe'],
              _pregnancy, (v) => setState(() => _pregnancy = v)),
          segField(context, context.tr('Pet safety'), const ['Safe', 'Unsafe'],
              _pet, (v) => setState(() => _pet = v)),
          Input(_details, context.tr('Other details'), lines: 3),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            secondary: const Icon(Icons.star, color: Colors.amber),
            title: const Text('Favourite (gives me the best result)'),
            value: _fav,
            onChanged: (v) => setState(() => _fav = v),
          ),
          FilledButton.icon(
              onPressed: companies.isEmpty ? null : _save,
              icon: const Icon(Icons.save),
              label: Text(context.tr('Save'))),
        ]),
      ),
    );
  }
}

// =================================================================== DISEASE
class DiseaseForm extends StatefulWidget {
  const DiseaseForm({super.key, this.edit, this.onSaved});
  final Rec? edit;
  final VoidCallback? onSaved;

  @override
  State<DiseaseForm> createState() => _DiseaseFormState();
}

class _DiseaseFormState extends State<DiseaseForm> {
  final _form = GlobalKey<FormState>();
  late final _owner = TextEditingController(text: widget.edit?.s('owner') ?? '');
  late final _phone = TextEditingController(text: widget.edit?.s('phone') ?? '');
  late final _fee = TextEditingController(
      text: (widget.edit?.d('fee') ?? 0) > 0
          ? widget.edit!.d('fee').toString()
          : '');
  late final _title = TextEditingController(text: widget.edit?.s('title') ?? '');
  late final _temp = TextEditingController(text: widget.edit?.s('temperature') ?? '');
  late final _symptoms =
      TextEditingController(text: widget.edit?.s('symptoms') ?? '');
  late final _findings =
      TextEditingController(text: widget.edit?.s('findings') ?? '');
  late final _treatment =
      TextEditingController(text: widget.edit?.s('treatment') ?? '');
  late String _location = widget.edit?.s('location') == 'Private'
      ? 'Private'
      : 'Hospital';
  late String _parasite =
      widget.edit?.s('skinParasite') == 'Present' ? 'Present' : 'Absent';
  late String _prognosis =
      widget.edit?.s('prognosis') == 'Poor' ? 'Poor' : 'Good';

  @override
  void dispose() {
    for (final c in [
      _owner,
      _phone,
      _fee,
      _title,
      _temp,
      _symptoms,
      _findings,
      _treatment
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final edit = widget.edit;
    final id = edit?.id ?? Db.col('diseases').doc().id;
    final isPrivate = _location == 'Private';
    final fee = isPrivate ? (double.tryParse(_fee.text.trim()) ?? 0) : 0.0;
    final ownerUid =
        (edit != null && edit.s('uid').isNotEmpty) ? edit.s('uid') : Db.uid;
    var bizId = edit?.s('businessId') ?? '';
    if (isPrivate && fee > 0 && bizId.isEmpty) bizId = Db.ensureBusiness();

    final data = {
      'owner': _owner.text.trim(),
      'phone': _phone.text.trim(),
      'location': _location,
      'fee': fee,
      'businessId': bizId,
      'title': _title.text.trim(),
      'temperature': _temp.text.trim(),
      'symptoms': _symptoms.text.trim(),
      'findings': _findings.text.trim(),
      'skinParasite': _parasite,
      'treatment': _treatment.text.trim(),
      'prognosis': _prognosis,
    };
    final ref = Db.col('diseases').doc(id);
    Db.run(context,
        edit == null ? ref.set({...data, ...Db.ownerStamp()}) : ref.update(data));

    // Private visit + fee  ->  automatically becomes income in the cashbook.
    final cashRef = Db.col('cash').doc('dis_$id');
    if (isPrivate && fee > 0) {
      Db.run(
        context,
        cashRef.set({
          'uid': ownerUid,
          'businessId': bizId,
          'type': 'in',
          'amount': fee,
          'category': 'Treatment fee',
          'note': '${_title.text.trim()} - ${_owner.text.trim()}',
          'date': edit?.m['createdAt'] ?? Timestamp.now(),
          'createdAt': edit?.m['createdAt'] ?? Timestamp.now(),
          'source': 'disease',
        }, SetOptions(merge: true)),
      );
    } else if (edit != null && edit.d('fee') > 0) {
      Db.run(context, cashRef.delete());
    }
    snack(context, context.tr('Saved'));
    widget.onSaved?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: spaced([
          Input(_owner, context.tr('Owner name'), required: true),
          Input(_phone, context.tr('Phone number'),
              keyboard: TextInputType.phone, required: true),
          segField(context, context.tr('Location'), const ['Hospital', 'Private'],
              _location, (v) => setState(() => _location = v ?? 'Hospital')),
          if (_location == 'Private') ...[
            Input(_fee, context.tr('Fee taken'),
                keyboard: const TextInputType.numberWithOptions(decimal: true),
                suffix: '৳',
                required: true),
            const Text(
              'This amount is added to the Income of your Cashbook automatically.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
          Input(_title, context.tr('Title of the disease'), required: true),
          Input(_temp, context.tr('Temperature'),
              keyboard: const TextInputType.numberWithOptions(decimal: true),
              suffix: '°F'),
          Input(_symptoms, context.tr('Sign & symptoms told by owner'), lines: 3),
          Input(_findings, context.tr('Clinical findings'), lines: 3),
          segField(context, context.tr('Skin parasite'),
              const ['Present', 'Absent'], _parasite,
              (v) => setState(() => _parasite = v ?? 'Absent')),
          WordField(
              controller: _treatment,
              label: context.tr('Treatment'),
              maxWords: 1000,
              minLines: 5),
          segField(context, context.tr('Prognosis after 10 days of treatment'),
              const ['Good', 'Poor'], _prognosis,
              (v) => setState(() => _prognosis = v ?? 'Good')),
          FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(context.tr('Save'))),
        ]),
      ),
    );
  }
}

// ========================================================= PROBLEM & SOLUTION
class ProblemForm extends StatefulWidget {
  const ProblemForm({super.key, this.edit, this.onSaved});
  final Rec? edit;
  final VoidCallback? onSaved;

  @override
  State<ProblemForm> createState() => _ProblemFormState();
}

class _ProblemFormState extends State<ProblemForm> {
  final _form = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.edit?.s('title') ?? '');
  late final _problem =
      TextEditingController(text: widget.edit?.s('problem') ?? '');
  late final _solution =
      TextEditingController(text: widget.edit?.s('solution') ?? '');
  late final _prognosis =
      TextEditingController(text: widget.edit?.s('prognosis') ?? '');

  @override
  void dispose() {
    for (final c in [_title, _problem, _solution, _prognosis]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    final data = {
      'title': _title.text.trim(),
      'problem': _problem.text.trim(),
      'solution': _solution.text.trim(),
      'prognosis': _prognosis.text.trim(),
    };
    if (widget.edit == null) {
      Db.run(context, Db.col('problems').add({...data, ...Db.ownerStamp()}));
    } else {
      Db.run(context, Db.col('problems').doc(widget.edit!.id).update(data));
    }
    snack(context, context.tr('Saved'));
    widget.onSaved?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: spaced([
          Input(_title, context.tr('Title'), required: true),
          WordField(
              controller: _problem,
              label: context.tr('Problems'),
              maxWords: 1000,
              minLines: 4,
              required: true),
          WordField(
              controller: _solution,
              label: context.tr('Solutions'),
              maxWords: 2000,
              minLines: 6,
              required: true),
          WordField(
              controller: _prognosis,
              label: context.tr('Prognosis'),
              maxWords: 300,
              minLines: 3),
          FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(context.tr('Save'))),
        ]),
      ),
    );
  }
}
