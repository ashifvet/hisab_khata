import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../widgets/common.dart';
import '../../widgets/live_doc.dart';
import '../add/forms.dart';
import '../medicines/medicines_screen.dart';

class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase())),
      Expanded(
        child: DocsStream(
          query: Db.shared('companies'),
          builder: (c, companies) => DocsStream(
            query: Db.shared('medicines'),
            builder: (c, meds) {
              final count = <String, int>{};
              for (final m in meds) {
                count[m.s('companyId')] = (count[m.s('companyId')] ?? 0) + 1;
              }
              final list = companies
                  .where((x) => _q.isEmpty || x.s('name').toLowerCase().contains(_q))
                  .toList()
                ..sort((a, b) => a
                    .s('name')
                    .toLowerCase()
                    .compareTo(b.s('name').toLowerCase()));
              if (list.isEmpty) {
                return const EmptyState(
                    'No companies yet.\nUse the Add tab to add one.',
                    icon: Icons.business_outlined);
              }
              return ListView.separated(
                itemCount: list.length,
                separatorBuilder: (c, i) => const Divider(height: 1),
                itemBuilder: (c, i) {
                  final x = list[i];
                  return ListTile(
                    leading: CircleAvatar(
                        child: Text(x.s('name').isEmpty
                            ? '?'
                            : x.s('name')[0].toUpperCase())),
                    title: Text(x.s('name')),
                    subtitle: Text('${count[x.id] ?? 0} medicines'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute<void>(
                            builder: (_) => CompanyDetail(id: x.id))),
                  );
                },
              );
            },
          ),
        ),
      ),
    ]);
  }
}

class CompanyDetail extends StatelessWidget {
  const CompanyDetail({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    return LiveDoc(
      collection: 'companies',
      id: id,
      builder: (context, co) {
        if (co == null) {
          return Scaffold(
              appBar: AppBar(),
              body: const EmptyState('This company was deleted.'));
        }
        final canEdit = Db.canEdit(co);
        return Scaffold(
          appBar: AppBar(
            title: Text(co.s('name'), style: const TextStyle(fontSize: 16)),
            actions: [
              if (canEdit)
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => EditPage(
                        title: context.tr('Edit'),
                        child: Builder(
                          builder: (c) =>
                              CompanyForm(edit: co, onSaved: () => Navigator.pop(c)),
                        ),
                      ),
                    ),
                  ),
                ),
              if (canEdit)
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () async {
                    if (await confirm(context, context.tr('Delete'),
                        '${co.s('name')}\n(its medicines will stay in the Medicines list)')) {
                      if (!context.mounted) return;
                      Db.run(context, Db.col('companies').doc(co.id).delete());
                      Navigator.pop(context);
                    }
                  },
                ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            icon: const Icon(Icons.add),
            label: Text(context.tr('Medicine')),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute<void>(
                builder: (_) => EditPage(
                  title: '${context.tr('Add')} ${context.tr('Medicine')}',
                  child: DocsStream(
                    query: Db.shared('companies'),
                    builder: (c, companies) => MedicineForm(
                      companies: companies,
                      companyId: co.id,
                      onSaved: () => Navigator.pop(c),
                    ),
                  ),
                ),
              ),
            ),
          ),
          body: DocsStream(
            query: Db.shared('medicines').where('companyId', isEqualTo: co.id),
            builder: (c, meds) {
              meds.sort((a, b) {
                if (a.b('favourite') != b.b('favourite')) {
                  return a.b('favourite') ? -1 : 1;
                }
                return a.s('name').toLowerCase().compareTo(b.s('name').toLowerCase());
              });
              return ListView(
                padding: const EdgeInsets.only(bottom: 90),
                children: [
                  if (co.s('details').isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(co.s('details')),
                    ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                    child: Text('Medicines (${meds.length})  ⭐ = favourite',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.primary)),
                  ),
                  if (meds.isEmpty)
                    const Padding(
                        padding: EdgeInsets.all(24),
                        child: Text('No medicines added for this company yet.')),
                  for (final m in meds) ...[
                    MedicineTile(m, companyName: co.s('name')),
                    const Divider(height: 1),
                  ],
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text('Added by ${co.s('createdByName')}',
                        style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}
