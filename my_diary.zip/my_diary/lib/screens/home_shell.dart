import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:material_ui/material_ui.dart';
import '../core/db.dart';
import '../core/l10n.dart';
import '../services/announcement_service.dart';
import '../services/update_service.dart';
import 'add/add_screen.dart';
import 'companies/companies_screen.dart';
import 'diseases/diseases_screen.dart';
import 'drawer/app_drawer.dart';
import 'hisab/hisab_screen.dart';
import 'medicines/medicines_screen.dart';
import 'ps/ps_screen.dart';

/// Bottom tabs, left -> right:
/// Hisab > Companies > Medicines > Diseases > P&S > Add
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  bool _online = true;
  StreamSubscription<List<ConnectivityResult>>? _sub;

  static const _tabs = <(String, IconData, IconData)>[
    ('Hisab', Icons.menu_book_outlined, Icons.menu_book),
    ('Companies', Icons.business_outlined, Icons.business),
    ('Medicines', Icons.medication_outlined, Icons.medication),
    ('Diseases', Icons.healing_outlined, Icons.healing),
    ('P&S', Icons.lightbulb_outline, Icons.lightbulb),
    ('Add', Icons.add_circle_outline, Icons.add_circle),
  ];

  @override
  void initState() {
    super.initState();
    Db.startProfile();
    Connectivity().checkConnectivity().then(_setOnline);
    _sub = Connectivity().onConnectivityChanged.listen(_setOnline);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      await UpdateService.check(context); // force update / new version dialog
      if (!mounted) return;
      await AnnouncementService.showPending(context); // admin messages
    });
  }

  void _setOnline(List<ConnectivityResult> r) {
    final on = r.any((e) => e != ConnectivityResult.none);
    if (mounted && on != _online) setState(() => _online = on);
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Widget _page() {
    switch (_index) {
      case 0:
        return const HisabScreen();
      case 1:
        return const CompaniesScreen();
      case 2:
        return const MedicinesScreen();
      case 3:
        return const DiseasesScreen();
      case 4:
        return const PsScreen();
      default:
        return const AddScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr(_tabs[_index].$1 == 'P&S'
            ? 'Problems & Solutions'
            : _tabs[_index].$1)),
        actions: [
          Tooltip(
            message: _online ? 'Online' : 'Offline - data will sync later',
            child: Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Icon(_online ? Icons.cloud_done_outlined : Icons.cloud_off),
            ),
          ),
        ],
      ),
      drawer: const AppDrawer(),
      body: _page(),
      bottomNavigationBar: NavigationBarTheme(
        data: const NavigationBarThemeData(
          height: 68,
          labelTextStyle: WidgetStatePropertyAll(TextStyle(fontSize: 10.5)),
        ),
        child: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: [
            for (final t in _tabs)
              NavigationDestination(
                icon: Icon(t.$2),
                selectedIcon: Icon(t.$3),
                label: context.tr(t.$1),
              ),
          ],
        ),
      ),
    );
  }
}
