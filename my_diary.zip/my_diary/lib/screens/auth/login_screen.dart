import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _user = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _phone = TextEditingController();
  bool _register = false;
  bool _busy = false;
  bool _hide = true;
  String? _error;

  @override
  void dispose() {
    for (final c in [_user, _pass, _pass2, _first, _last, _phone]) {
      c.dispose();
    }
    super.dispose();
  }

  /// "admin" -> admin@mydiary.app. Real e-mails are used as they are.
  String _emailOf(String input) {
    final t = input.trim().toLowerCase();
    return t.contains('@') ? t : '$t@mydiary.app';
  }

  void _saveProfile(User u, {String first = '', String last = '', String phone = ''}) {
    // not awaited on purpose (works offline too)
    Db.fs.collection('users').doc(u.uid).set({
      'firstName': first,
      'lastName': last,
      'email': u.email ?? '',
      'phone': phone,
      'location': '',
      'createdAt': Timestamp.now(),
    }, SetOptions(merge: true)).catchError((Object _) {});
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final auth = FirebaseAuth.instance;
    final email = _emailOf(_user.text);
    try {
      if (_register) {
        if (email == Db.adminEmail) {
          throw FirebaseAuthException(
              code: 'reserved', message: 'This username is reserved.');
        }
        final cred = await auth.createUserWithEmailAndPassword(
            email: email, password: _pass.text);
        _saveProfile(cred.user!,
            first: _first.text.trim(),
            last: _last.text.trim(),
            phone: _phone.text.trim());
      } else {
        try {
          await auth.signInWithEmailAndPassword(email: email, password: _pass.text);
        } on FirebaseAuthException catch (e) {
          final adminTry = email == Db.adminEmail &&
              _pass.text == Db.adminDefaultPassword;
          const missing = [
            'user-not-found',
            'invalid-credential',
            'invalid-login-credentials',
            'wrong-password',
          ];
          if (adminTry && missing.contains(e.code)) {
            // First start: create the default administrator account.
            final cred = await auth.createUserWithEmailAndPassword(
                email: email, password: _pass.text);
            _saveProfile(cred.user!, first: 'Admin', last: '');
          } else {
            rethrow;
          }
        }
      }
    } on FirebaseAuthException catch (e) {
      setState(() => _error = _friendly(e, email));
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendly(FirebaseAuthException e, String email) {
    switch (e.code) {
      case 'email-already-in-use':
        return email == Db.adminEmail
            ? 'Wrong username or password.'
            : 'This email/username is already registered.';
      case 'invalid-credential':
      case 'invalid-login-credentials':
      case 'wrong-password':
      case 'user-not-found':
        return 'Wrong username or password.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'invalid-email':
        return 'Invalid email address.';
      case 'network-request-failed':
        return 'No internet. You need internet for the first login.';
      default:
        return e.message ?? e.code;
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _form,
                child: Column(children: [
                  Image.asset('asset/icon.png',
                      width: 96,
                      height: 96,
                      errorBuilder: (c, e, s) => Icon(Icons.menu_book_rounded,
                          size: 88, color: scheme.primary)),
                  const SizedBox(height: 8),
                  Text('My Diary',
                      style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: scheme.primary)),
                  const Text('Veterinary notes & business accounts',
                      style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 24),
                  if (_register) ...[
                    Row(children: [
                      Expanded(child: _field(_first, 'First name', required: true)),
                      const SizedBox(width: 8),
                      Expanded(child: _field(_last, 'Last name')),
                    ]),
                    const SizedBox(height: 12),
                    _field(_phone, 'Phone number', keyboard: TextInputType.phone),
                    const SizedBox(height: 12),
                  ],
                  _field(_user, _register ? 'Email' : 'Username or Email',
                      required: true, keyboard: TextInputType.emailAddress),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _pass,
                    obscureText: _hide,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                        onPressed: () => setState(() => _hide = !_hide),
                      ),
                    ),
                    validator: (v) => (v == null || v.length < 6)
                        ? 'At least 6 characters'
                        : null,
                  ),
                  if (_register) ...[
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _pass2,
                      obscureText: _hide,
                      decoration: const InputDecoration(
                          labelText: 'Confirm password',
                          border: OutlineInputBorder()),
                      validator: (v) =>
                          v != _pass.text ? 'Passwords do not match' : null,
                    ),
                  ],
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center),
                  ],
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: FilledButton(
                      onPressed: _busy ? null : _submit,
                      child: _busy
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : Text(_register ? 'Create account' : 'Login'),
                    ),
                  ),
                  TextButton(
                    onPressed: _busy
                        ? null
                        : () => setState(() {
                              _register = !_register;
                              _error = null;
                            }),
                    child: Text(_register
                        ? 'I already have an account'
                        : 'Create a new account'),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label,
      {bool required = false, TextInputType? keyboard}) {
    return TextFormField(
      controller: c,
      keyboardType: keyboard,
      decoration:
          InputDecoration(labelText: label, border: const OutlineInputBorder()),
      validator: required
          ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null
          : null,
    );
  }
}
