import 'package:material_ui/material_ui.dart';
import '../../core/db.dart';
import '../../core/l10n.dart';
import '../../widgets/common.dart';
import '../../widgets/live_doc.dart';
import '../add/forms.dart';

String _label(String v) =>
    (v == 'Safe' || v == 'Unsafe') ? v : 'Not set';

Color _color(String v) => v == 'Safe'
    ? Colors.green
    : v == 'Unsafe'
        ? Colors.red
        : Colors.grey;

class MedicineTile extends StatelessWidget {
  const MedicineTile(this.m, {super.key, this.companyName});
  final Rec m;
  final String? companyName;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: m.b('favourite')
          ? const Icon(Icons.star, color: Colors.amber)
          : const Icon(Icons.medication_outlined),
      title: Text(m.s('name'), style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(companyName ?? m.s('companyName'),
            maxLines: 1, overflow: TextOverflow.ellipsis),
        const SizedBox(height: 2),
        Wrap(children: [
          Tag('Preg: ${_label(m.s('pregnancy'))}', _color(m.s('pregnancy'))),
          Tag('Pet: ${_label(m.s('petSafety'))}', _color(m.s('petSafety'))),
        ]),
      ]),
      isThreeLine: true,
      onTap: () => Navigator.push(context,
          MaterialPageRoute<void>(builder: (_) => MedicineDetail(id: m.id))),
    );
  }
}

class MedicinesScreen extends StatefulWidget {
  const MedicinesScreen({super.key});

  @override
  State<MedicinesScreen> createState() => _MedicinesScreenState();
}

class _MedicinesScreenState extends State<MedicinesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(children: [
        TabBar(tabs: [
          Tab(text: context.tr('All')),
          Tab(text: context.tr('Pregnancy Safe')),
          Tab(text: context.tr('Pet Medicines')),
        ]),
        SearchBox(onChanged: (v) => setState(() => _q = v.toLowerCase())),
        Expanded(
          child: DocsStream(
            query: Db.shared('companies'),
            builder: (c, companies) {
              final names = {for (final x in companies) x.id: x.s('name')};
              return DocsStream(
                query: Db.shared('medicines'),
                builder: (c, all) {
                  final list = all
                      .where((m) =>
                          _q.isEmpty ||
                          m.s('name').toLowerCase().contains(_q) ||
                          m.s('components').toLowerCase().contains(_q) ||
                          m.s('category').toLowerCase().contains(_q))
                      .toList()
                    ..sort((a, b) => a
                        .s('name')
                        .toLowerCase()
                        .compareTo(b.s('name').toLowerCase()));
                  Widget view(List<Rec> items) {
                    if (items.isEmpty) {
                      return EmptyState(context.tr('Nothing here yet'));
                    }
                    return ListView.separated(
                      itemCount: items.length,
                      separatorBuilder: (c, i) => const Divider(height: 1),
                      itemBuilder: (c, i) => MedicineTile(items[i],
                          companyName: names[items[i].s('companyId')]),
                    );
                  }

                  return TabBarView(children: [
                    view(list),
                    view(list.where((m) => m.s('pregnancy') == 'Safe').toList()),
                    view(list.where((m) => m.s('petSafety') == 'Safe').toList()),
                  ]);
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}

class MedicineDetail extends StatelessWidget {
  const MedicineDetail({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    return LiveDoc(
      collection: 'medicines',
      id: id,
      builder: (context, m) {
        if (m == null) {
          return Scaffold(
              appBar: AppBar(),
              body: const EmptyState('This medicine was deleted.'));
        }
        return LiveDoc(
          collection: 'companies',
          id: m.s('companyId').isEmpty ? 'none' : m.s('companyId'),
          builder: (context, company) {
            final canEdit = Db.canEdit(m);
            return DetailPage(
              title: m.s('name'),
              actions: [
                if (canEdit)
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => EditPage(
                          title: '${context.tr('Edit')} - ${m.s('name')}',
                          child: DocsStream(
                            query: Db.shared('companies'),
                            builder: (c, companies) => MedicineForm(
                              companies: companies,
                              edit: m,
                              onSaved: () => Navigator.pop(c),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                if (canEdit)
                  IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () async {
                      if (await confirm(context, context.tr('Delete'), m.s('name'))) {
                        if (!context.mounted) return;
                        Db.run(context, Db.col('medicines').doc(m.id).delete());
                        Navigator.pop(context);
                      }
                    },
                  ),
              ],
              rows: [
                (context.tr('Company'),
                    company?.s('name') ?? m.s('companyName')),
                ('Category', m.s('category')),
                (context.tr('Components'), m.s('components')),
                (context.tr('When to use'), m.s('whenToUse')),
                (context.tr('Dose'), m.s('dose')),
                (context.tr('Pregnancy'), _label(m.s('pregnancy'))),
                (context.tr('Pet safety'), _label(m.s('petSafety'))),
                ('Favourite', m.b('favourite') ? 'Yes ⭐' : ''),
                (context.tr('Other details'), m.s('details')),
                ('Added by', m.s('createdByName')),
              ],
            );
          },
        );
      },
    );
  }
}
