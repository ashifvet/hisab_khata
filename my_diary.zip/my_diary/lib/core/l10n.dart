import 'package:material_ui/material_ui.dart';
import 'settings.dart';

/// Wrap the app with this so every widget using `context.tr()` rebuilds
/// when the language changes.
class LangScope extends InheritedNotifier<AppSettings> {
  const LangScope({super.key, required AppSettings settings, required super.child})
      : super(notifier: settings);
}

extension TrX on BuildContext {
  /// English text is used as the key. Bangla is looked up in [_bn].
  String tr(String key) {
    final s = dependOnInheritedWidgetOfExactType<LangScope>()?.notifier;
    if (s == null || s.lang != 'bn') return key;
    return _bn[key] ?? key;
  }
}

String greetingKey() {
  final h = DateTime.now().hour;
  if (h < 5) return 'Good night';
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  if (h < 20) return 'Good evening';
  return 'Good night';
}

const Map<String, String> _bn = {
  // tabs
  'Hisab': 'হিসাব',
  'Companies': 'কোম্পানি',
  'Medicines': 'ঔষধ',
  'Diseases': 'রোগ',
  'P&S': 'সমাধান',
  'Add': 'যোগ',
  'Problems & Solutions': 'সমস্যা ও সমাধান',
  // greetings
  'Good morning': 'শুভ সকাল',
  'Good afternoon': 'শুভ অপরাহ্ন',
  'Good evening': 'শুভ সন্ধ্যা',
  'Good night': 'শুভ রাত্রি',
  // drawer
  'Edit Profile': 'প্রোফাইল এডিট',
  'Settings': 'সেটিংস',
  'Announcements': 'ঘোষণা',
  'App Update': 'অ্যাপ আপডেট',
  'About Developer': 'ডেভেলপার সম্পর্কে',
  'Logout': 'লগআউট',
  'Version': 'ভার্সন',
  // settings
  'Dark mode': 'ডার্ক মোড',
  'Language': 'ভাষা',
  'Change password': 'পাসওয়ার্ড পরিবর্তন',
  'English': 'ইংরেজি',
  'Bangla': 'বাংলা',
  // common
  'Save': 'সংরক্ষণ',
  'Cancel': 'বাতিল',
  'Delete': 'মুছুন',
  'Edit': 'এডিট',
  'Search': 'খুঁজুন',
  'Required': 'আবশ্যক',
  'All': 'সব',
  'OK': 'ঠিক আছে',
  'Saved': 'সংরক্ষিত হয়েছে',
  'Share': 'শেয়ার',
  'Print / Save': 'প্রিন্ট / সেভ',
  'Nothing here yet': 'এখনও কিছু নেই',
  // hisab
  'Customers': 'কাস্টমার',
  'Suppliers': 'সাপ্লায়ার',
  "You'll get": 'পাবো',
  "You'll give": 'দেবো',
  'You gave': 'দিলাম',
  'You got': 'পেলাম',
  'Cashbook': 'ক্যাশবই',
  'Stock': 'স্টক',
  'Reports': 'রিপোর্ট',
  'Messages': 'মেসেজ',
  'Notes': 'নোট',
  'Add customer': 'কাস্টমার যোগ',
  'Add supplier': 'সাপ্লায়ার যোগ',
  'Cash in': 'ক্যাশ ইন',
  'Cash out': 'ক্যাশ আউট',
  'Income': 'আয়',
  'Expense': 'খরচ',
  'Savings': 'সঞ্চয়',
  'Balance': 'ব্যালান্স',
  'Businesses': 'ব্যবসা',
  'Name': 'নাম',
  'Phone': 'ফোন',
  'Address': 'ঠিকানা',
  // add
  'Company': 'কোম্পানি',
  'Medicine': 'ঔষধ',
  'Disease': 'রোগ',
  'Problem & Solution': 'সমস্যা ও সমাধান',
  'Company name': 'কোম্পানির নাম',
  'Medicine name': 'ঔষধের নাম',
  'Components': 'উপাদান',
  'When to use': 'কখন ব্যবহার করবেন',
  'Dose': 'ডোজ',
  'Pregnancy': 'গর্ভাবস্থা',
  'Pet safety': 'পোষা প্রাণীর নিরাপত্তা',
  'Safe': 'নিরাপদ',
  'Unsafe': 'অনিরাপদ',
  'Other details': 'অন্যান্য তথ্য',
  'Owner name': 'মালিকের নাম',
  'Phone number': 'ফোন নম্বর',
  'Location': 'স্থান',
  'Hospital': 'হাসপাতাল',
  'Private': 'প্রাইভেট',
  'Fee taken': 'ফি নেওয়া হয়েছে',
  'Title of the disease': 'রোগের শিরোনাম',
  'Temperature': 'তাপমাত্রা',
  'Sign & symptoms told by owner': 'মালিকের বলা লক্ষণসমূহ',
  'Clinical findings': 'ক্লিনিক্যাল ফাইন্ডিংস',
  'Skin parasite': 'ত্বকের পরজীবী',
  'Present': 'আছে',
  'Absent': 'নেই',
  'Treatment': 'চিকিৎসা',
  'Prognosis after 10 days of treatment': '১০ দিন চিকিৎসার পর প্রগনোসিস',
  'Good': 'ভালো',
  'Poor': 'খারাপ',
  'Title': 'শিরোনাম',
  'Problems': 'সমস্যা',
  'Solutions': 'সমাধান',
  'Prognosis': 'প্রগনোসিস',
  // lists
  'Pregnancy Safe': 'গর্ভাবস্থায় নিরাপদ',
  'Pet Medicines': 'পোষা প্রাণীর ঔষধ',
  'Good Prognosis': 'ভালো প্রগনোসিস',
  'Poor Prognosis': 'খারাপ প্রগনোসিস',
  // profile
  'First name': 'প্রথম নাম',
  'Last name': 'শেষ নাম',
  'Email': 'ইমেইল',
  // about
  'Developer': 'ডেভেলপার',
  'Hometown': 'নিজ জেলা',
};
