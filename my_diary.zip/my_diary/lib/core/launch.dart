import 'package:flutter/foundation.dart';
import 'package:material_ui/material_ui.dart';
import 'package:url_launcher/url_launcher.dart';

void snack(BuildContext c, String msg) {
  ScaffoldMessenger.maybeOf(c)
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<bool> _open(Uri u) async {
  try {
    return await launchUrl(u, mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}

Future<void> openUrl(BuildContext c, String url) async {
  var u = url.trim();
  if (u.isEmpty) return;
  if (!u.startsWith('http')) u = 'https://$u';
  final ok = await _open(Uri.parse(u));
  if (!ok && c.mounted) snack(c, 'Could not open $u');
}

/// 01711-989236 -> 8801711989236 (Bangladesh numbers, WhatsApp format).
String intlPhone(String p) {
  final d = p.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('880')) return d;
  if (d.startsWith('0')) return '880${d.substring(1)}';
  return d;
}

Future<bool> callPhone(String phone) =>
    _open(Uri.parse('tel:${phone.replaceAll(' ', '')}'));

/// Opens the SMS app with the message filled in. Several numbers = group SMS.
Future<bool> sendSms(List<String> phones, String body) {
  final sep = defaultTargetPlatform == TargetPlatform.iOS ? ';' : ',';
  final to = phones.map((e) => e.replaceAll(' ', '')).join(sep);
  return _open(Uri.parse('sms:$to?body=${Uri.encodeComponent(body)}'));
}

Future<bool> openWhatsApp(String phone, String text) {
  final n = intlPhone(phone);
  final base = n.isEmpty ? 'https://wa.me/' : 'https://wa.me/$n';
  return _open(Uri.parse('$base?text=${Uri.encodeComponent(text)}'));
}
