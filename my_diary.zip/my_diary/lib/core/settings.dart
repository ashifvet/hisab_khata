import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Global, locally stored app settings (dark mode, language, active business...).
late AppSettings appSettings;

class AppSettings extends ChangeNotifier {
  AppSettings._(this._p);
  final SharedPreferences _p;

  static Future<AppSettings> load() async =>
      AppSettings._(await SharedPreferences.getInstance());

  bool get dark => _p.getBool('dark') ?? false;
  String get lang => _p.getString('lang') ?? 'en';

  Future<void> setDark(bool v) async {
    await _p.setBool('dark', v);
    notifyListeners();
  }

  Future<void> setLang(String v) async {
    await _p.setString('lang', v);
    notifyListeners();
  }

  String? activeBusiness(String uid) => _p.getString('activeBusiness_$uid');

  Future<void> setActiveBusiness(String uid, String? id) async {
    if (id == null) {
      await _p.remove('activeBusiness_$uid');
    } else {
      await _p.setString('activeBusiness_$uid', id);
    }
    notifyListeners();
  }

  // How many times an announcement dialog was already shown on this phone.
  int announcementSeen(String id) => _p.getInt('ann_$id') ?? 0;
  Future<void> announcementShown(String id) =>
      _p.setInt('ann_$id', announcementSeen(id) + 1);
}
