import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:material_ui/material_ui.dart';
import 'settings.dart';

/// A tiny wrapper around a Firestore document (id + data map).
class Rec {
  Rec(this.id, this.m);
  final String id;
  final Map<String, dynamic> m;

  factory Rec.from(QueryDocumentSnapshot<Map<String, dynamic>> d) =>
      Rec(d.id, d.data());

  String s(String k) => (m[k] ?? '').toString();

  double d(String k) {
    final v = m[k];
    if (v is num) return v.toDouble();
    return double.tryParse('${v ?? ''}') ?? 0;
  }

  bool b(String k) => m[k] == true;

  DateTime dt(String k) {
    final v = m[k];
    if (v is Timestamp) return v.toDate();
    return DateTime.fromMillisecondsSinceEpoch(0);
  }
}

/// All Firestore / Auth helpers in one place.
class Db {
  Db._();

  static const adminEmail = 'admin@mydiary.app';
  static const adminUsername = 'admin';
  static const adminDefaultPassword = 'Solution2@';

  static FirebaseFirestore get fs => FirebaseFirestore.instance;
  static User? get user => FirebaseAuth.instance.currentUser;
  static String get uid => user?.uid ?? '';
  static bool get isAdmin => (user?.email ?? '').toLowerCase() == adminEmail;

  static CollectionReference<Map<String, dynamic>> col(String name) =>
      fs.collection(name);

  /// Private data: a normal user only sees his own documents,
  /// the administrator sees everything.
  static Query<Map<String, dynamic>> mine(String name) =>
      isAdmin ? col(name) : col(name).where('uid', isEqualTo: uid);

  /// Shared data (companies, medicines): everybody can read.
  static Query<Map<String, dynamic>> shared(String name) => col(name);

  // ---------------------------------------------------------------- profile
  static final ValueNotifier<Map<String, dynamic>> profile = ValueNotifier({});
  static StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _ps;

  static void startProfile() {
    _ps?.cancel();
    final u = user;
    if (u == null) return;
    _ps = fs.collection('users').doc(u.uid).snapshots().listen((s) {
      profile.value = s.data() ?? {};
    }, onError: (_) {});
  }

  static void stopProfile() {
    _ps?.cancel();
    _ps = null;
    profile.value = {};
  }

  static String get displayName {
    if (isAdmin) return 'Administrator';
    final p = profile.value;
    final n = '${p['firstName'] ?? ''} ${p['lastName'] ?? ''}'.trim();
    if (n.isNotEmpty) return n;
    return (user?.email ?? 'User').split('@').first;
  }

  // ---------------------------------------------------------------- helpers
  /// Fields added to every private record.
  static Map<String, dynamic> ownerStamp() =>
      {'uid': uid, 'ownerName': displayName, 'createdAt': Timestamp.now()};

  /// Fields added to every shared record (company / medicine).
  static Map<String, dynamic> creatorStamp() => {
        'createdBy': uid,
        'createdByName': displayName,
        'createdAt': Timestamp.now(),
      };

  /// Only the creator or the administrator may edit / delete.
  static bool canEdit(Rec r) {
    if (isAdmin) return true;
    if (r.s('createdBy').isNotEmpty) return r.s('createdBy') == uid;
    return r.s('uid') == uid;
  }

  /// Firestore keeps working offline: a write is queued locally and is
  /// uploaded when the internet comes back. Because of that we NEVER await
  /// writes in the UI. We only report an error if the server rejects it.
  static void run(BuildContext context, Future<void> f) {
    final messenger = ScaffoldMessenger.maybeOf(context);
    f.catchError((Object e) {
      messenger?.showSnackBar(SnackBar(content: Text('Could not save: $e')));
    });
  }

  /// Returns the id of the active business; creates a default one if the
  /// user has none yet (used by the disease fee -> cashbook link).
  static String ensureBusiness() {
    final cur = appSettings.activeBusiness(uid);
    if (cur != null && cur.isNotEmpty) return cur;
    final id = 'default_$uid';
    unawaited(col('businesses').doc(id).set({
      'name': 'My Business',
      'type': 'General',
      ...ownerStamp(),
    }, SetOptions(merge: true)).catchError((Object _) {}));
    appSettings.setActiveBusiness(uid, id);
    return id;
  }
}
