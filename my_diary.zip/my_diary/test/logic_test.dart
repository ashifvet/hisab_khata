import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:my_diary/core/db.dart';
import 'package:my_diary/screens/hisab/biz.dart';
import 'package:my_diary/screens/hisab/report_pdf.dart';

Rec t(String id, String party, int dir, double amt, DateTime d) => Rec(id, {
      'partyId': party, 'dir': dir, 'amount': amt, 'date': Timestamp.fromDate(d), 'note': 'n$id'});

void main() {
  final now = DateTime.now();
  final data = Biz({
    'parties': [Rec('a', {'name': 'Karim', 'type': 'customer', 'phone': '01711'}), Rec('b', {'name': 'Supplier', 'type': 'supplier'})],
    'txns': [t('1', 'a', 1, 1000, now), t('2', 'a', -1, 400, now), t('3', 'b', -1, 700, now)],
    'cash': [Rec('c1', {'type': 'in', 'amount': 500, 'category': 'Fee', 'date': Timestamp.fromDate(now)}), Rec('c2', {'type': 'out', 'amount': 200, 'category': 'Feed', 'date': Timestamp.fromDate(now)})],
    'products': [Rec('p', {'name': 'Vial', 'unit': 'pcs', 'qty': 10, 'buyPrice': 25.5, 'sellPrice': 30})],
  });
  test('balances', () {
    expect(data.balance('a'), 600);
    expect(data.balance('b'), -700);
    expect(data.toGet, 600);
    expect(data.toGive, 700);
    expect(data.cashIn(now), 500);
    expect(data.cashOut(now), 200);
    expect(data.stockValue, 255);
  });
  test('pdfs build', () async {
    final p = data.parties.first;
    expect((await partyStatementPdf(business: 'B', party: p, txns: data.partyTxns('a'))).length, greaterThan(500));
    expect((await partyStatementPdf(business: 'B', party: p, txns: data.partyTxns('a'), from: DateTime(now.year, now.month), to: now.add(const Duration(days: 1)))).length, greaterThan(500));
    expect((await allPartiesPdf(business: 'B', data: data)).length, greaterThan(500));
    expect((await costSavingsPdf(business: 'B', data: data, month: now)).length, greaterThan(500));
    expect((await monthlyReportPdf(business: 'B', data: data, month: now)).length, greaterThan(500));
    expect((await stockPdf(business: 'B', data: data)).length, greaterThan(500));
  });
}
