import 'package:flutter/material.dart';

import '../core/strings.dart';
import '../services/update_service.dart';
import '../widgets/common.dart';
import 'app_drawer.dart';
import 'hisab/hisab_home.dart';
import 'vet/add_screen.dart';
import 'vet/companies_screen.dart';
import 'vet/medicines_screen.dart';
import 'vet/notes_screens.dart';

/// Main screen: bottom tabs + app drawer.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  static const _titles = ['app_name', 'companies', 'medicines', 'notes', 'add'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) UpdateService.check(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr(_titles[_index])),
        actions: const [SyncIndicator()],
      ),
      drawer: const AppDrawer(),
      body: IndexedStack(
        index: _index,
        children: const [
          HisabHome(),
          CompaniesScreen(),
          MedicinesScreen(),
          VetNotesTab(),
          AddScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.account_balance_wallet_outlined),
            selectedIcon: const Icon(Icons.account_balance_wallet),
            label: context.tr('nav_hisab'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.business_outlined),
            selectedIcon: const Icon(Icons.business),
            label: context.tr('companies'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.medication_outlined),
            selectedIcon: const Icon(Icons.medication),
            label: context.tr('medicines'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.sticky_note_2_outlined),
            selectedIcon: const Icon(Icons.sticky_note_2),
            label: context.tr('notes'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.add_circle_outline),
            selectedIcon: const Icon(Icons.add_circle),
            label: context.tr('add'),
          ),
        ],
      ),
    );
  }
}
