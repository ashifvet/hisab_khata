import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';

const int kMaxNoteWords = 1000;

/// Form: Title + Body (up to 1000 words). Used for medicine notes AND business notes.
class NoteForm extends StatefulWidget {
  const NoteForm({super.key, required this.col, this.note, this.onDone});
  final Col col;
  final NoteItem? note;
  final VoidCallback? onDone;

  @override
  State<NoteForm> createState() => _NoteFormState();
}

class _NoteFormState extends State<NoteForm> with AutomaticKeepAliveClientMixin {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _title = TextEditingController(text: widget.note?.title ?? '');
  late final TextEditingController _body = TextEditingController(text: widget.note?.body ?? '');
  int _words = 0;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _words = wordCount(_body.text);
    _body.addListener(() {
      final w = wordCount(_body.text);
      if (w != _words) setState(() => _words = w);
    });
  }

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    Db.save(widget.col, widget.note?.id, {
      'title': _title.text.trim(),
      'body': _body.text.trim(),
    });
    toast(context, context.tr('saved'));
    if (widget.note == null) {
      _title.clear();
      _body.clear();
    }
    widget.onDone?.call();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final over = _words > kMaxNoteWords;
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextFormField(
            controller: _title,
            textCapitalization: TextCapitalization.sentences,
            decoration: deco(context.tr('note_title'), icon: Icons.title),
            validator: (v) => (v == null || v.trim().isEmpty) ? context.tr('required') : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _body,
            minLines: 8,
            maxLines: 20,
            keyboardType: TextInputType.multiline,
            textCapitalization: TextCapitalization.sentences,
            decoration: deco(context.tr('note_body')),
            validator: (v) => wordCount(v ?? '') > kMaxNoteWords ? context.tr('note_too_long') : null,
          ),
          Align(
            alignment: Alignment.centerRight,
            child: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                '$_words / $kMaxNoteWords ${context.tr('words')}',
                style: TextStyle(color: over ? Theme.of(context).colorScheme.error : null),
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: Text(context.tr('save_note')),
            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
          ),
        ],
      ),
    );
  }
}

class NoteEditScreen extends StatelessWidget {
  const NoteEditScreen({super.key, required this.col, this.note});
  final Col col;
  final NoteItem? note;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(note == null ? context.tr('add_note') : context.tr('edit_note'))),
      body: NoteForm(col: col, note: note, onDone: () => Navigator.pop(context)),
    );
  }
}

class NoteDetailScreen extends StatelessWidget {
  const NoteDetailScreen({super.key, required this.col, required this.noteId});
  final Col col;
  final String noteId;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: col.doc(noteId).snapshots(),
      builder: (context, snap) {
        final doc = snap.data;
        if (doc == null || !doc.exists) {
          return Scaffold(
            appBar: AppBar(title: Text(context.tr('notes'))),
            body: snap.connectionState == ConnectionState.waiting
                ? const Center(child: CircularProgressIndicator())
                : EmptyState(icon: Icons.sticky_note_2_outlined, text: context.tr('not_found')),
          );
        }
        final note = NoteItem.fromDoc(doc);
        return Scaffold(
          appBar: AppBar(
            title: Text(note.title),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => NoteEditScreen(col: col, note: note)),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  final nav = Navigator.of(context);
                  final ok = await confirmDialog(context, context.tr('delete'), context.tr('delete_confirm'));
                  if (ok) {
                    Db.remove(col.doc(note.id));
                    nav.pop();
                  }
                },
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(note.title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              if (note.createdAt.millisecondsSinceEpoch > 0)
                Text(fmtDate(note.createdAt), style: Theme.of(context).textTheme.bodySmall),
              const Divider(height: 24),
              SelectableText(note.body, style: const TextStyle(fontSize: 16, height: 1.5)),
            ],
          ),
        );
      },
    );
  }
}

/// List of note titles. Tap a title to read the note.
class NotesView extends StatefulWidget {
  const NotesView({super.key, required this.col});
  final Col col;

  @override
  State<NotesView> createState() => _NotesViewState();
}

class _NotesViewState extends State<NotesView> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute<void>(builder: (_) => NoteEditScreen(col: widget.col)),
        ),
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
          Expanded(
            child: StreamBuilder(
              stream: widget.col.snapshots(),
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final list = snap.data!.docs.map(NoteItem.fromDoc).where((n) {
                  return _q.isEmpty || n.title.toLowerCase().contains(_q) || n.body.toLowerCase().contains(_q);
                }).toList()
                  ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
                if (list.isEmpty) {
                  return EmptyState(icon: Icons.sticky_note_2_outlined, text: context.tr('no_notes'));
                }
                return ListView.separated(
                  padding: const EdgeInsets.only(bottom: 90),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final n = list[i];
                    return ListTile(
                      leading: const Icon(Icons.sticky_note_2_outlined),
                      title: Text(n.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: n.createdAt.millisecondsSinceEpoch > 0 ? Text(fmtDate(n.createdAt)) : null,
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute<void>(builder: (_) => NoteDetailScreen(col: widget.col, noteId: n.id)),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// "Notes" tab of the bottom bar (medicine / doctor notes).
class VetNotesTab extends StatelessWidget {
  const VetNotesTab({super.key});

  @override
  Widget build(BuildContext context) => NotesView(col: Db.col('notes'));
}
