import 'package:flutter/material.dart';

import '../../core/constants.dart';
import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';
import 'medicines_screen.dart';
import 'vet_forms.dart';

/// "Companies" tab: list of companies. Tap a company -> its favourite medicines.
class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Db.col('companies').snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final all = snap.data!.docs.map(Company.fromDoc).toList()
          ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        final list = all.where((c) => _q.isEmpty || c.name.toLowerCase().contains(_q)).toList();

        return Column(
          children: [
            Row(
              children: [
                Expanded(child: SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase()))),
                Padding(
                  padding: const EdgeInsets.only(top: 8, right: 4),
                  child: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'import') {
                        final ok = await confirmDialog(context, context.tr('import_companies'), context.tr('import_companies_msg'));
                        if (ok) {
                          Db.importCompanies(kDefaultCompanies, all.map((c) => c.name.toLowerCase()).toSet());
                          if (context.mounted) toast(context, context.tr('saved'));
                        }
                      }
                    },
                    itemBuilder: (ctx) => [
                      PopupMenuItem(value: 'import', child: Text(ctx.tr('import_companies'))),
                    ],
                  ),
                ),
              ],
            ),
            Expanded(
              child: list.isEmpty
                  ? EmptyState(
                      icon: Icons.business_outlined,
                      text: context.tr('no_companies_yet'),
                      action: all.isEmpty
                          ? FilledButton.icon(
                              onPressed: () => Db.importCompanies(kDefaultCompanies, {}),
                              icon: const Icon(Icons.download),
                              label: Text(context.tr('import_companies')),
                            )
                          : null,
                    )
                  : StreamBuilder(
                      stream: Db.col('medicines').snapshots(),
                      builder: (context, msnap) {
                        final meds = msnap.data?.docs.map(Medicine.fromDoc).toList() ?? <Medicine>[];
                        return ListView.separated(
                          padding: const EdgeInsets.only(bottom: 16),
                          itemCount: list.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, i) {
                            final c = list[i];
                            final mine = meds.where((m) => m.companyId == c.id).toList();
                            final favs = mine.where((m) => m.favourite).length;
                            return ListTile(
                              leading: CircleAvatar(child: Text(c.name.isEmpty ? '?' : c.name[0].toUpperCase())),
                              title: Text(c.name),
                              subtitle: Text('${context.tr('favourites')}: $favs  •  ${context.tr('medicines')}: ${mine.length}'),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute<void>(builder: (_) => CompanyDetailScreen(company: c)),
                              ),
                            );
                          },
                        );
                      },
                    ),
            ),
          ],
        );
      },
    );
  }
}

class CompanyDetailScreen extends StatefulWidget {
  const CompanyDetailScreen({super.key, required this.company});
  final Company company;

  @override
  State<CompanyDetailScreen> createState() => _CompanyDetailScreenState();
}

class _CompanyDetailScreenState extends State<CompanyDetailScreen> {
  bool _onlyFav = true;

  @override
  Widget build(BuildContext context) {
    // listen to the company document so edits show immediately
    return StreamBuilder(
      stream: Db.col('companies').doc(widget.company.id).snapshots(),
      builder: (context, csnap) {
        final cdoc = csnap.data;
        final company = (cdoc != null && cdoc.exists) ? Company.fromDoc(cdoc) : widget.company;
        return Scaffold(
          appBar: AppBar(
            title: Text(company.name, maxLines: 2, style: const TextStyle(fontSize: 17)),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => CompanyEditScreen(company: company)),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  final nav = Navigator.of(context);
                  final ok = await confirmDialog(context, context.tr('delete'), context.tr('delete_company_confirm'));
                  if (ok) {
                    Db.deleteCompany(company.id);
                    nav.pop();
                  }
                },
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute<void>(builder: (_) => MedicineEditScreen(presetCompany: company)),
            ),
            icon: const Icon(Icons.add),
            label: Text(context.tr('add_medicine')),
          ),
          body: Column(
            children: [
              if (company.phone.isNotEmpty || company.details.isNotEmpty)
                Card(
                  margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (company.phone.isNotEmpty)
                          InkWell(
                            onTap: () => callPhone(context, company.phone),
                            child: Row(children: [
                              const Icon(Icons.phone, size: 18),
                              const SizedBox(width: 8),
                              Text(company.phone),
                            ]),
                          ),
                        if (company.details.isNotEmpty) ...[
                          if (company.phone.isNotEmpty) const SizedBox(height: 8),
                          Text(company.details),
                        ],
                      ],
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: SegmentedButton<bool>(
                  segments: [
                    ButtonSegment(value: true, icon: const Icon(Icons.star), label: Text(context.tr('favourites'))),
                    ButtonSegment(value: false, icon: const Icon(Icons.list), label: Text(context.tr('all_medicines'))),
                  ],
                  selected: {_onlyFav},
                  onSelectionChanged: (s) => setState(() => _onlyFav = s.first),
                ),
              ),
              Expanded(
                child: StreamBuilder(
                  stream: Db.col('medicines').snapshots(),
                  builder: (context, snap) {
                    if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                    final meds = snap.data!.docs
                        .map(Medicine.fromDoc)
                        .where((m) => m.companyId == company.id && (!_onlyFav || m.favourite))
                        .toList()
                      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
                    if (meds.isEmpty) {
                      return EmptyState(icon: Icons.medication_outlined, text: context.tr('no_medicines_company'));
                    }
                    return ListView.separated(
                      padding: const EdgeInsets.only(bottom: 90),
                      itemCount: meds.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) => MedicineTile(medicine: meds[i], showCompany: false),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
