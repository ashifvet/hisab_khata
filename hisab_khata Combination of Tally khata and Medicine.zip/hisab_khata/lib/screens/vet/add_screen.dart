import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../services/db.dart';
import 'notes_screens.dart';
import 'vet_forms.dart';

/// "Add" tab:  1. Company   2. Medicine   3. Note
class AddScreen extends StatelessWidget {
  const AddScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          Material(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: TabBar(
              tabs: [
                Tab(icon: const Icon(Icons.business), text: context.tr('company')),
                Tab(icon: const Icon(Icons.medication), text: context.tr('medicine')),
                Tab(icon: const Icon(Icons.sticky_note_2), text: context.tr('note')),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              children: [
                const CompanyForm(),
                const MedicineForm(),
                NoteForm(col: Db.col('notes')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
