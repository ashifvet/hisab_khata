import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';
import 'vet_forms.dart';

class MedicineTile extends StatelessWidget {
  const MedicineTile({super.key, required this.medicine, this.showCompany = true});
  final Medicine medicine;
  final bool showCompany;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const CircleAvatar(child: Icon(Icons.medication, size: 20)),
      title: Text(medicine.name),
      subtitle: showCompany && medicine.companyName.isNotEmpty ? Text(medicine.companyName) : null,
      trailing: medicine.favourite
          ? const Icon(Icons.star, color: Colors.amber)
          : const Icon(Icons.chevron_right),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => MedicineDetailScreen(medicineId: medicine.id)),
      ),
    );
  }
}

/// "Medicines" tab: all medicines, A-Z.
class MedicinesScreen extends StatefulWidget {
  const MedicinesScreen({super.key});

  @override
  State<MedicinesScreen> createState() => _MedicinesScreenState();
}

class _MedicinesScreenState extends State<MedicinesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
        Expanded(
          child: StreamBuilder(
            stream: Db.col('medicines').snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = snap.data!.docs.map(Medicine.fromDoc).where((m) {
                return _q.isEmpty ||
                    m.name.toLowerCase().contains(_q) ||
                    m.companyName.toLowerCase().contains(_q) ||
                    m.components.toLowerCase().contains(_q);
              }).toList()
                ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
              if (list.isEmpty) {
                return EmptyState(icon: Icons.medication_outlined, text: context.tr('no_medicines'));
              }
              final children = <Widget>[];
              String last = '';
              for (final m in list) {
                final letter = m.name.isEmpty ? '#' : m.name[0].toUpperCase();
                if (letter != last) {
                  last = letter;
                  children.add(Container(
                    width: double.infinity,
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: Text(letter, style: const TextStyle(fontWeight: FontWeight.bold)),
                  ));
                }
                children.add(MedicineTile(medicine: m));
              }
              return ListView(padding: const EdgeInsets.only(bottom: 16), children: children);
            },
          ),
        ),
      ],
    );
  }
}

class MedicineDetailScreen extends StatelessWidget {
  const MedicineDetailScreen({super.key, required this.medicineId});
  final String medicineId;

  Widget _section(BuildContext context, IconData icon, String title, String text) {
    if (text.trim().isEmpty) return const SizedBox.shrink();
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
              const SizedBox(width: 8),
              Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
            ]),
            const SizedBox(height: 8),
            SelectableText(text, style: const TextStyle(fontSize: 16, height: 1.4)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Db.col('medicines').doc(medicineId).snapshots(),
      builder: (context, snap) {
        final doc = snap.data;
        if (doc == null || !doc.exists) {
          return Scaffold(
            appBar: AppBar(title: Text(context.tr('medicine'))),
            body: snap.connectionState == ConnectionState.waiting
                ? const Center(child: CircularProgressIndicator())
                : EmptyState(icon: Icons.medication_outlined, text: context.tr('not_found')),
          );
        }
        final m = Medicine.fromDoc(doc);
        return Scaffold(
          appBar: AppBar(
            title: Text(m.name),
            actions: [
              IconButton(
                tooltip: context.tr('favourite_medicine'),
                icon: Icon(m.favourite ? Icons.star : Icons.star_border, color: m.favourite ? Colors.amber : null),
                onPressed: () => Db.save(Db.col('medicines'), m.id, {'favourite': !m.favourite}),
              ),
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => MedicineEditScreen(medicine: m)),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  final nav = Navigator.of(context);
                  final ok = await confirmDialog(context, context.tr('delete'), context.tr('delete_confirm'));
                  if (ok) {
                    Db.remove(Db.col('medicines').doc(m.id));
                    nav.pop();
                  }
                },
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              Text(m.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
              if (m.companyName.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6, bottom: 12),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Chip(avatar: const Icon(Icons.business, size: 18), label: Text(m.companyName)),
                  ),
                ),
              const SizedBox(height: 4),
              _section(context, Icons.science_outlined, context.tr('components'), m.components),
              _section(context, Icons.help_outline, context.tr('when_to_use'), m.whenToUse),
              _section(context, Icons.colorize, context.tr('dose'), m.dose),
              _section(context, Icons.pregnant_woman, context.tr('pregnancy'), m.pregnancy),
              _section(context, Icons.notes, context.tr('other_details'), m.details),
            ],
          ),
        );
      },
    );
  }
}
