import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';

// ============================================================ COMPANY FORM

class CompanyForm extends StatefulWidget {
  const CompanyForm({super.key, this.company, this.onDone});
  final Company? company;
  final VoidCallback? onDone;

  @override
  State<CompanyForm> createState() => _CompanyFormState();
}

class _CompanyFormState extends State<CompanyForm> with AutomaticKeepAliveClientMixin {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name = TextEditingController(text: widget.company?.name ?? '');
  late final TextEditingController _phone = TextEditingController(text: widget.company?.phone ?? '');
  late final TextEditingController _details = TextEditingController(text: widget.company?.details ?? '');

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _details.dispose();
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    final name = _name.text.trim();
    final id = Db.save(Db.col('companies'), widget.company?.id, {
      'name': name,
      'phone': _phone.text.trim(),
      'details': _details.text.trim(),
    });
    if (widget.company != null && widget.company!.name != name) {
      Db.renameCompanyOnMedicines(id, name);
    }
    toast(context, context.tr('saved'));
    if (widget.company == null) {
      _name.clear();
      _phone.clear();
      _details.clear();
    }
    widget.onDone?.call();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextFormField(
            controller: _name,
            textCapitalization: TextCapitalization.words,
            decoration: deco(context.tr('company_name'), icon: Icons.business),
            validator: (v) => (v == null || v.trim().isEmpty) ? context.tr('required') : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: deco(context.tr('company_phone'), icon: Icons.phone),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _details,
            minLines: 2,
            maxLines: 5,
            decoration: deco(context.tr('other_details'), icon: Icons.notes),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: Text(context.tr('save_company')),
            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
          ),
        ],
      ),
    );
  }
}

// ============================================================ MEDICINE FORM

class MedicineForm extends StatefulWidget {
  const MedicineForm({super.key, this.medicine, this.presetCompany, this.onDone});
  final Medicine? medicine;
  final Company? presetCompany;
  final VoidCallback? onDone;

  @override
  State<MedicineForm> createState() => _MedicineFormState();
}

class _MedicineFormState extends State<MedicineForm> with AutomaticKeepAliveClientMixin {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name = TextEditingController(text: widget.medicine?.name ?? '');
  late final TextEditingController _components = TextEditingController(text: widget.medicine?.components ?? '');
  late final TextEditingController _when = TextEditingController(text: widget.medicine?.whenToUse ?? '');
  late final TextEditingController _dose = TextEditingController(text: widget.medicine?.dose ?? '');
  late final TextEditingController _pregnancy = TextEditingController(text: widget.medicine?.pregnancy ?? '');
  late final TextEditingController _details = TextEditingController(text: widget.medicine?.details ?? '');
  late String _companyId = widget.medicine?.companyId ?? widget.presetCompany?.id ?? '';
  late String _companyName = widget.medicine?.companyName ?? widget.presetCompany?.name ?? '';
  late bool _favourite = widget.medicine?.favourite ?? true;

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _name.dispose();
    _components.dispose();
    _when.dispose();
    _dose.dispose();
    _pregnancy.dispose();
    _details.dispose();
    super.dispose();
  }

  Future<void> _pickCompany() async {
    final res = await showModalBottomSheet<Object>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _CompanyPicker(),
    );
    if (res == null) return;
    setState(() {
      if (res is Company) {
        _companyId = res.id;
        _companyName = res.name;
      } else {
        _companyId = '';
        _companyName = '';
      }
    });
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    Db.save(Db.col('medicines'), widget.medicine?.id, {
      'name': _name.text.trim(),
      'companyId': _companyId,
      'companyName': _companyName,
      'components': _components.text.trim(),
      'whenToUse': _when.text.trim(),
      'dose': _dose.text.trim(),
      'pregnancy': _pregnancy.text.trim(),
      'details': _details.text.trim(),
      'favourite': _favourite,
    });
    toast(context, context.tr('saved'));
    if (widget.medicine == null) {
      _name.clear();
      _components.clear();
      _when.clear();
      _dose.clear();
      _pregnancy.clear();
      _details.clear();
      setState(() => _favourite = true);
    }
    widget.onDone?.call();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextFormField(
            controller: _name,
            textCapitalization: TextCapitalization.words,
            decoration: deco(context.tr('medicine_name'), icon: Icons.medication),
            validator: (v) => (v == null || v.trim().isEmpty) ? context.tr('required') : null,
          ),
          const SizedBox(height: 12),
          InkWell(
            onTap: _pickCompany,
            borderRadius: BorderRadius.circular(12),
            child: InputDecorator(
              decoration: deco(context.tr('company'), icon: Icons.business).copyWith(
                suffixIcon: const Icon(Icons.arrow_drop_down),
              ),
              child: Text(_companyName.isEmpty ? context.tr('select_company') : _companyName),
            ),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(context.tr('favourite_medicine')),
            subtitle: Text(context.tr('favourite_hint')),
            value: _favourite,
            onChanged: (v) => setState(() => _favourite = v),
          ),
          const SizedBox(height: 4),
          TextFormField(
            controller: _components,
            minLines: 1,
            maxLines: 4,
            decoration: deco(context.tr('components'), icon: Icons.science_outlined),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _when,
            minLines: 2,
            maxLines: 6,
            decoration: deco(context.tr('when_to_use'), icon: Icons.help_outline),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _dose,
            minLines: 2,
            maxLines: 6,
            decoration: deco(context.tr('dose'), icon: Icons.colorize),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _pregnancy,
            minLines: 1,
            maxLines: 4,
            decoration: deco(context.tr('pregnancy'), icon: Icons.pregnant_woman),
          ),
          Wrap(
            spacing: 8,
            children: [
              for (final k in const ['preg_safe', 'preg_caution', 'preg_avoid'])
                ActionChip(label: Text(context.tr(k)), onPressed: () => setState(() => _pregnancy.text = context.tr(k))),
            ],
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _details,
            minLines: 2,
            maxLines: 8,
            decoration: deco(context.tr('other_details'), icon: Icons.notes),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: Text(context.tr('save_medicine')),
            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
          ),
        ],
      ),
    );
  }
}

class _CompanyPicker extends StatelessWidget {
  const _CompanyPicker();

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      maxChildSize: 0.95,
      builder: (context, scroll) {
        return StreamBuilder(
          stream: Db.col('companies').snapshots(),
          builder: (context, snap) {
            final list = (snap.data?.docs.map(Company.fromDoc).toList() ?? <Company>[])
              ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
            return ListView(
              controller: scroll,
              children: [
                ListTile(
                  title: Text(context.tr('select_company'), style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
                ListTile(
                  leading: const Icon(Icons.block),
                  title: Text(context.tr('no_company')),
                  onTap: () => Navigator.pop(context, 'none'),
                ),
                for (final c in list)
                  ListTile(
                    leading: const Icon(Icons.business),
                    title: Text(c.name),
                    onTap: () => Navigator.pop(context, c),
                  ),
                if (list.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Text(context.tr('no_companies_yet'))),
              ],
            );
          },
        );
      },
    );
  }
}

/// Full page used to edit an existing medicine or to add one for a company.
class MedicineEditScreen extends StatelessWidget {
  const MedicineEditScreen({super.key, this.medicine, this.presetCompany});
  final Medicine? medicine;
  final Company? presetCompany;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(medicine == null ? context.tr('add_medicine') : context.tr('edit_medicine'))),
      body: MedicineForm(
        medicine: medicine,
        presetCompany: presetCompany,
        onDone: () => Navigator.pop(context),
      ),
    );
  }
}

class CompanyEditScreen extends StatelessWidget {
  const CompanyEditScreen({super.key, required this.company});
  final Company company;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('edit_company'))),
      body: CompanyForm(company: company, onDone: () => Navigator.pop(context)),
    );
  }
}
