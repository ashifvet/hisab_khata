import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../core/helpers.dart';
import '../core/strings.dart';
import '../services/db.dart';
import 'drawer/about_screen.dart';
import 'drawer/profile_screen.dart';
import 'drawer/settings_screen.dart';
import 'hisab/businesses_screen.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  void _go(BuildContext context, Widget page) {
    final nav = Navigator.of(context);
    nav.pop(); // close the drawer
    nav.push(MaterialPageRoute<void>(builder: (_) => page));
  }

  Future<void> _logout(BuildContext context) async {
    if (!await confirmDialog(context, context.tr('logout'), context.tr('logout_confirm'))) return;
    if (!context.mounted) return;
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    // make sure everything saved offline is uploaded before we log out
    var synced = true;
    try {
      await Db.fs.waitForPendingWrites().timeout(const Duration(seconds: 6));
    } catch (_) {
      synced = false;
    }
    if (!context.mounted) return;
    Navigator.of(context, rootNavigator: true).pop();
    if (!synced) {
      final go = await confirmDialog(context, context.tr('unsynced_title'), context.tr('unsynced_msg'));
      if (!go) return;
    }
    await FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final user = FirebaseAuth.instance.currentUser;
    return Drawer(
      child: Column(
        children: [
          StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: Db.userDoc.snapshots(),
            builder: (context, snap) {
              final m = snap.data?.data() ?? <String, dynamic>{};
              final name = '${m['firstName'] ?? ''} ${m['lastName'] ?? ''}'.trim();
              final email = (m['email'] ?? user?.email ?? '').toString();
              final initial = (name.isNotEmpty ? name : email).isEmpty
                  ? '?'
                  : (name.isNotEmpty ? name : email)[0].toUpperCase();
              return UserAccountsDrawerHeader(
                decoration: BoxDecoration(color: scheme.primary),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: scheme.onPrimary,
                  child: Text(initial, style: TextStyle(fontSize: 28, color: scheme.primary)),
                ),
                accountName: Text(name.isEmpty ? context.tr('app_name') : name,
                    style: TextStyle(color: scheme.onPrimary, fontWeight: FontWeight.bold)),
                accountEmail: Text(email, style: TextStyle(color: scheme.onPrimary)),
              );
            },
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                  leading: const Icon(Icons.person_outline),
                  title: Text(context.tr('edit_profile')),
                  onTap: () => _go(context, const ProfileScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.store_outlined),
                  title: Text(context.tr('my_businesses')),
                  onTap: () => _go(context, const BusinessesScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.settings_outlined),
                  title: Text(context.tr('settings')),
                  onTap: () => _go(context, const SettingsScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(context.tr('about_developer')),
                  onTap: () => _go(context, const AboutScreen()),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          ListTile(
            leading: Icon(Icons.logout, color: scheme.error),
            title: Text(context.tr('logout'), style: TextStyle(color: scheme.error)),
            onTap: () => _logout(context),
          ),
          FutureBuilder<PackageInfo>(
            future: PackageInfo.fromPlatform(),
            builder: (context, snap) => Padding(
              padding: const EdgeInsets.only(bottom: 14, top: 2),
              child: Text(
                '${context.tr('version')} ${snap.data?.version ?? ''}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
