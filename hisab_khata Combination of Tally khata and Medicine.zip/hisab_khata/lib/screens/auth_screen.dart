import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/helpers.dart';
import '../core/strings.dart';
import '../providers/settings_provider.dart';
import '../services/db.dart';
import '../widgets/common.dart';

/// Login + Register + Forgot password in one screen.
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _phone = TextEditingController();
  bool _register = false;
  bool _busy = false;
  bool _hide = true;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    _first.dispose();
    _last.dispose();
    _phone.dispose();
    super.dispose();
  }

  String _message(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-credential':
      case 'user-not-found':
      case 'wrong-password':
        return context.tr('err_wrong_login');
      case 'email-already-in-use':
        return context.tr('err_email_used');
      case 'weak-password':
        return context.tr('err_weak_password');
      case 'invalid-email':
        return context.tr('err_invalid_email');
      case 'network-request-failed':
        return context.tr('err_network');
      case 'too-many-requests':
        return context.tr('err_too_many');
      default:
        return e.message ?? context.tr('err_generic');
    }
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    setState(() => _busy = true);
    try {
      final auth = FirebaseAuth.instance;
      if (_register) {
        final cred = await auth.createUserWithEmailAndPassword(
          email: _email.text.trim(),
          password: _pass.text,
        );
        Db.fire(Db.fs.collection('users').doc(cred.user!.uid).set({
          'firstName': _first.text.trim(),
          'lastName': _last.text.trim(),
          'email': _email.text.trim(),
          'phone': _phone.text.trim(),
          'location': '',
          'designation': '',
        }));
      } else {
        await auth.signInWithEmailAndPassword(email: _email.text.trim(), password: _pass.text);
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) toast(context, _message(e));
    } catch (_) {
      if (mounted) toast(context, context.tr('err_generic'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _forgot() async {
    final email = _email.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      toast(context, context.tr('enter_email_first'));
      return;
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      if (mounted) toast(context, context.tr('reset_sent'));
    } on FirebaseAuthException catch (e) {
      if (mounted) toast(context, _message(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _form,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.centerRight,
                      child: SegmentedButton<String>(
                        showSelectedIcon: false,
                        segments: const [
                          ButtonSegment(value: 'en', label: Text('EN')),
                          ButtonSegment(value: 'bn', label: Text('বাংলা')),
                        ],
                        selected: {settings.lang},
                        onSelectionChanged: (s) => settings.setLang(s.first),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Icon(Icons.menu_book_rounded, size: 72, color: scheme.primary),
                    const SizedBox(height: 8),
                    Text(
                      context.tr('app_name'),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    Text(context.tr('tagline'), textAlign: TextAlign.center),
                    const SizedBox(height: 24),
                    if (_register) ...[
                      Row(children: [
                        Expanded(
                          child: TextFormField(
                            controller: _first,
                            decoration: deco(context.tr('first_name')),
                            validator: (v) => (v == null || v.trim().isEmpty) ? context.tr('required') : null,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: _last,
                            decoration: deco(context.tr('last_name')),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _phone,
                        keyboardType: TextInputType.phone,
                        decoration: deco(context.tr('phone'), icon: Icons.phone),
                      ),
                      const SizedBox(height: 12),
                    ],
                    TextFormField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      decoration: deco(context.tr('email'), icon: Icons.email_outlined),
                      validator: (v) =>
                          (v == null || !v.contains('@') || !v.contains('.')) ? context.tr('err_invalid_email') : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _pass,
                      obscureText: _hide,
                      decoration: deco(context.tr('password'), icon: Icons.lock_outline).copyWith(
                        suffixIcon: IconButton(
                          icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => setState(() => _hide = !_hide),
                        ),
                      ),
                      validator: (v) => (v == null || v.length < 6) ? context.tr('err_weak_password') : null,
                    ),
                    if (!_register)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(onPressed: _forgot, child: Text(context.tr('forgot_password'))),
                      ),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: _busy ? null : _submit,
                      style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
                      child: _busy
                          ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                          : Text(_register ? context.tr('register') : context.tr('login')),
                    ),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: _busy ? null : () => setState(() => _register = !_register),
                      child: Text(_register ? context.tr('have_account') : context.tr('no_account')),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      context.tr('need_internet_first'),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
