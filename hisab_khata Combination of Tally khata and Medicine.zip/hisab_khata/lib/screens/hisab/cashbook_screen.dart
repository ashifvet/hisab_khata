import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../core/constants.dart';
import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';

/// Daily income and expense (your cost & savings).
class CashBookScreen extends StatefulWidget {
  const CashBookScreen({super.key, required this.biz});
  final Business biz;

  @override
  State<CashBookScreen> createState() => _CashBookScreenState();
}

class _CashBookScreenState extends State<CashBookScreen> {
  DateTime _month = monthStart(DateTime.now());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('cash_book'))),
      body: Column(
        children: [
          MonthSwitcher(month: _month, onChanged: (m) => setState(() => _month = m)),
          Expanded(
            child: StreamBuilder(
              stream: Db.bcol(widget.biz.id, 'entries').snapshots(),
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final list = snap.data!.docs.map(CashEntry.fromDoc).where((e) => sameMonth(e.date, _month)).toList()
                  ..sort((a, b) => b.date.compareTo(a.date));
                double inc = 0, exp = 0;
                for (final e in list) {
                  if (e.isIncome) {
                    inc += e.amount;
                  } else {
                    exp += e.amount;
                  }
                }
                final sav = inc - exp;
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Row(
                        children: [
                          Expanded(child: StatCard(label: context.tr('income'), value: money(inc), color: Colors.green.shade700)),
                          Expanded(child: StatCard(label: context.tr('expense'), value: money(exp), color: Colors.red.shade700)),
                          Expanded(
                            child: StatCard(
                              label: context.tr('savings'),
                              value: money(sav),
                              color: sav >= 0 ? Colors.blue.shade700 : Colors.red.shade700,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: list.isEmpty
                          ? EmptyState(icon: Icons.menu_book_outlined, text: context.tr('no_entries'))
                          : ListView.separated(
                              padding: const EdgeInsets.only(bottom: 8),
                              itemCount: list.length,
                              separatorBuilder: (_, __) => const Divider(height: 1),
                              itemBuilder: (context, i) {
                                final e = list[i];
                                final color = e.isIncome ? Colors.green.shade700 : Colors.red.shade700;
                                return ListTile(
                                  leading: CircleAvatar(
                                    backgroundColor: color.withValues(alpha: 0.12),
                                    child: Icon(e.isIncome ? Icons.south_west : Icons.north_east, color: color, size: 20),
                                  ),
                                  title: Text(e.category.isEmpty ? (e.isIncome ? context.tr('income') : context.tr('expense')) : context.tr(e.category)),
                                  subtitle: Text([fmtDate(e.date), if (e.note.isNotEmpty) e.note].join(' • ')),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '${e.isIncome ? '+' : '-'}${money(e.amount)}',
                                        style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete_outline, size: 20),
                                        onPressed: () async {
                                          final ok = await confirmDialog(context, context.tr('delete'), context.tr('delete_confirm'));
                                          if (ok) Db.remove(Db.bcol(widget.biz.id, 'entries').doc(e.id));
                                        },
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      onPressed: () => _showEntrySheet(context, 'income'),
                      icon: const Icon(Icons.add),
                      label: Text(context.tr('add_income')),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.red.shade700,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      onPressed: () => _showEntrySheet(context, 'expense'),
                      icon: const Icon(Icons.remove),
                      label: Text(context.tr('add_expense')),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showEntrySheet(BuildContext context, String type) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _EntrySheet(biz: widget.biz, type: type),
    );
  }
}

class _EntrySheet extends StatefulWidget {
  const _EntrySheet({required this.biz, required this.type});
  final Business biz;
  final String type;

  @override
  State<_EntrySheet> createState() => _EntrySheetState();
}

class _EntrySheetState extends State<_EntrySheet> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  DateTime _date = DateTime.now();
  String _category = '';

  bool get _income => widget.type == 'income';

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  void _save() {
    final a = parseNum(_amount.text);
    if (a == null || a <= 0) {
      toast(context, context.tr('enter_amount'));
      return;
    }
    Db.save(Db.bcol(widget.biz.id, 'entries'), null, {
      'type': widget.type,
      'amount': a,
      'category': _category,
      'note': _note.text.trim(),
      'date': Timestamp.fromDate(_date),
    });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final color = _income ? Colors.green.shade700 : Colors.red.shade700;
    final cats = _income ? kIncomeCategories : kExpenseCategories;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              _income ? context.tr('add_income') : context.tr('add_expense'),
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _amount,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: deco(context.tr('amount'), prefix: '৳ '),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final c in cats)
                  ChoiceChip(
                    label: Text(context.tr(c)),
                    selected: _category == c,
                    onSelected: (v) => setState(() => _category = v ? c : ''),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(controller: _note, decoration: deco(context.tr('details'), icon: Icons.notes)),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () async {
                final d = await pickDate(context, _date);
                if (d != null) setState(() => _date = d);
              },
              icon: const Icon(Icons.calendar_today, size: 18),
              label: Text(fmtDate(_date)),
            ),
            const SizedBox(height: 14),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: color, padding: const EdgeInsets.symmetric(vertical: 14)),
              onPressed: _save,
              child: Text(context.tr('save')),
            ),
          ],
        ),
      ),
    );
  }
}
