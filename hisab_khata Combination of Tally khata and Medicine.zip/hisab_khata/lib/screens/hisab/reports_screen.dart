import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../services/pdf_service.dart';
import '../../widgets/common.dart';
import '../../widgets/report_buttons.dart';
import 'stock_screen.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key, required this.biz});
  final Business biz;

  void _open(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final items = <(IconData, String, String, Color, Widget)>[
      (Icons.people, 'customer_report', 'customer_report_desc', Colors.teal, PartiesReportScreen(biz: biz, type: 'customer')),
      (Icons.local_shipping, 'supplier_report', 'supplier_report_desc', Colors.indigo, PartiesReportScreen(biz: biz, type: 'supplier')),
      (Icons.savings, 'cost_savings', 'cost_savings_desc', Colors.green, CostSavingsScreen(biz: biz)),
      (Icons.calendar_month, 'monthly_report', 'monthly_report_desc', Colors.orange, MonthlyReportScreen(biz: biz)),
      (Icons.inventory_2, 'stock_report', 'stock_report_desc', Colors.brown, StockScreen(biz: biz)),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('reports'))),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          for (final it in items)
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: it.$4.withValues(alpha: 0.15),
                  child: Icon(it.$1, color: it.$4),
                ),
                title: Text(context.tr(it.$2), style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(context.tr(it.$3)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _open(context, it.$5),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(context.tr('reports_hint'), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
          ),
        ],
      ),
    );
  }
}

// ======================================================= CUSTOMER / SUPPLIER

class PartiesReportScreen extends StatelessWidget {
  const PartiesReportScreen({super.key, required this.biz, required this.type});
  final Business biz;
  final String type;

  @override
  Widget build(BuildContext context) {
    final isCustomer = type == 'customer';
    return Scaffold(
      appBar: AppBar(title: Text(isCustomer ? context.tr('customer_report') : context.tr('supplier_report'))),
      body: StreamBuilder(
        stream: Db.bcol(biz.id, 'parties').snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!.docs.map(Party.fromDoc).where((p) => p.type == type).toList()
            ..sort((a, b) => b.balance.abs().compareTo(a.balance.abs()));
          double toGet = 0, toGive = 0;
          for (final p in list) {
            if (p.balance > 0) {
              toGet += p.balance;
            } else {
              toGive += -p.balance;
            }
          }
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                child: Row(
                  children: [
                    Expanded(child: StatCard(label: context.tr('you_will_get'), value: money(toGet), color: Colors.green.shade700)),
                    Expanded(child: StatCard(label: context.tr('you_will_give'), value: money(toGive), color: Colors.red.shade700)),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                child: ReportButtons(
                  filename: '${type}_report.pdf',
                  builder: () => PdfService.build(
                    title: isCustomer ? context.tr('customer_report') : context.tr('supplier_report'),
                    business: biz.name,
                    subtitle: fmtDate(DateTime.now()),
                    summary: [
                      [context.tr('you_will_get'), money(toGet)],
                      [context.tr('you_will_give'), money(toGive)],
                    ],
                    headers: ['#', context.tr('name'), context.tr('phone'), context.tr('you_will_get'), context.tr('you_will_give')],
                    rows: [
                      for (var i = 0; i < list.length; i++)
                        [
                          '${i + 1}',
                          list[i].name,
                          list[i].phone,
                          list[i].balance > 0 ? fmtNum(list[i].balance) : '',
                          list[i].balance < 0 ? fmtNum(-list[i].balance) : '',
                        ],
                    ],
                    rightCols: {3, 4},
                    noDataText: context.tr('no_data'),
                  ),
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? EmptyState(icon: Icons.people_outline, text: context.tr('no_data'))
                    : ListView.separated(
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final p = list[i];
                          return ListTile(
                            leading: CircleAvatar(child: Text(p.name.isEmpty ? '?' : p.name[0].toUpperCase())),
                            title: Text(p.name),
                            subtitle: p.phone.isEmpty ? null : Text(p.phone),
                            trailing: BalanceText(balance: p.balance),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ======================================================= COST & SAVINGS

class CostSavingsScreen extends StatefulWidget {
  const CostSavingsScreen({super.key, required this.biz});
  final Business biz;

  @override
  State<CostSavingsScreen> createState() => _CostSavingsScreenState();
}

class _CostSavingsScreenState extends State<CostSavingsScreen> {
  String _period = 'this_month'; // this_month | last_month | this_year | all_time

  bool _inPeriod(DateTime d) {
    final now = DateTime.now();
    switch (_period) {
      case 'this_month':
        return sameMonth(d, now);
      case 'last_month':
        return sameMonth(d, DateTime(now.year, now.month - 1));
      case 'this_year':
        return d.year == now.year;
      default:
        return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('cost_savings'))),
      body: StreamBuilder(
        stream: Db.bcol(widget.biz.id, 'entries').snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!.docs.map(CashEntry.fromDoc).where((e) => _inPeriod(e.date)).toList();
          double inc = 0, exp = 0;
          final expByCat = <String, double>{};
          final incByCat = <String, double>{};
          for (final e in list) {
            final cat = e.category.isEmpty ? (e.isIncome ? 'cat_other_income' : 'cat_other_expense') : e.category;
            if (e.isIncome) {
              inc += e.amount;
              incByCat[cat] = (incByCat[cat] ?? 0) + e.amount;
            } else {
              exp += e.amount;
              expByCat[cat] = (expByCat[cat] ?? 0) + e.amount;
            }
          }
          final sav = inc - exp;
          final rate = inc > 0 ? (sav / inc * 100) : 0.0;
          final expList = expByCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
          final incList = incByCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
          final periods = ['this_month', 'last_month', 'this_year', 'all_time'];

          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Wrap(
                spacing: 8,
                children: [
                  for (final p in periods)
                    ChoiceChip(
                      label: Text(context.tr(p)),
                      selected: _period == p,
                      onSelected: (_) => setState(() => _period = p),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: StatCard(label: context.tr('income'), value: money(inc), color: Colors.green.shade700)),
                  Expanded(child: StatCard(label: context.tr('expense'), value: money(exp), color: Colors.red.shade700)),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      label: context.tr('savings'),
                      value: money(sav),
                      color: sav >= 0 ? Colors.blue.shade700 : Colors.red.shade700,
                      icon: Icons.savings,
                    ),
                  ),
                  Expanded(
                    child: StatCard(label: context.tr('savings_rate'), value: '${rate.toStringAsFixed(1)}%', color: Colors.purple),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ReportButtons(
                filename: 'cost_savings_report.pdf',
                builder: () => PdfService.build(
                  title: '${context.tr('cost_savings')} - ${context.tr(_period)}',
                  business: widget.biz.name,
                  subtitle: fmtDate(DateTime.now()),
                  summary: [
                    [context.tr('income'), money(inc)],
                    [context.tr('expense'), money(exp)],
                    [context.tr('savings'), money(sav)],
                    [context.tr('savings_rate'), '${rate.toStringAsFixed(1)}%'],
                  ],
                  headers: [context.tr('type'), context.tr('category'), context.tr('amount'), '%'],
                  rows: [
                    for (final e in incList)
                      [context.tr('income'), context.tr(e.key), fmtNum(e.value), '${(inc > 0 ? e.value / inc * 100 : 0).toStringAsFixed(1)}%'],
                    for (final e in expList)
                      [context.tr('expense'), context.tr(e.key), fmtNum(e.value), '${(exp > 0 ? e.value / exp * 100 : 0).toStringAsFixed(1)}%'],
                  ],
                  rightCols: {2, 3},
                  noDataText: context.tr('no_data'),
                ),
              ),
              const SizedBox(height: 16),
              Text(context.tr('expense_breakdown'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 6),
              if (expList.isEmpty) Text(context.tr('no_data')),
              for (final e in expList)
                _BarRow(label: context.tr(e.key), value: e.value, total: exp, color: Colors.red.shade400),
              const SizedBox(height: 16),
              Text(context.tr('income_breakdown'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 6),
              if (incList.isEmpty) Text(context.tr('no_data')),
              for (final e in incList)
                _BarRow(label: context.tr(e.key), value: e.value, total: inc, color: Colors.green.shade400),
            ],
          );
        },
      ),
    );
  }
}

class _BarRow extends StatelessWidget {
  const _BarRow({required this.label, required this.value, required this.total, required this.color});
  final String label;
  final double value;
  final double total;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final frac = total > 0 ? (value / total).clamp(0.0, 1.0) : 0.0;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(label),
              Text('${money(value)}  (${(frac * 100).toStringAsFixed(0)}%)', style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 3),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(value: frac, minHeight: 8, color: color),
          ),
        ],
      ),
    );
  }
}

// ======================================================= MONTHLY REPORT

class MonthlyReportScreen extends StatefulWidget {
  const MonthlyReportScreen({super.key, required this.biz});
  final Business biz;

  @override
  State<MonthlyReportScreen> createState() => _MonthlyReportScreenState();
}

class _MonthlyReportScreenState extends State<MonthlyReportScreen> {
  DateTime _month = monthStart(DateTime.now());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('monthly_report'))),
      body: Column(
        children: [
          MonthSwitcher(month: _month, onChanged: (m) => setState(() => _month = m)),
          Expanded(
            child: StreamBuilder(
              stream: Db.bcol(widget.biz.id, 'entries').snapshots(),
              builder: (context, esnap) {
                return StreamBuilder(
                  stream: Db.bcol(widget.biz.id, 'transactions').snapshots(),
                  builder: (context, tsnap) {
                    if (!esnap.hasData || !tsnap.hasData) return const Center(child: CircularProgressIndicator());
                    final entries = esnap.data!.docs.map(CashEntry.fromDoc).where((e) => sameMonth(e.date, _month)).toList();
                    final txns = tsnap.data!.docs.map(PartyTxn.fromDoc).where((t) => sameMonth(t.date, _month)).toList();

                    double inc = 0, exp = 0, gave = 0, got = 0;
                    // day -> [income, expense, gave, got]
                    final days = <int, List<double>>{};
                    List<double> row(int d) => days.putIfAbsent(d, () => [0, 0, 0, 0]);
                    for (final e in entries) {
                      if (e.isIncome) {
                        inc += e.amount;
                        row(e.date.day)[0] += e.amount;
                      } else {
                        exp += e.amount;
                        row(e.date.day)[1] += e.amount;
                      }
                    }
                    for (final t in txns) {
                      if (t.isGave) {
                        gave += t.amount;
                        row(t.date.day)[2] += t.amount;
                      } else {
                        got += t.amount;
                        row(t.date.day)[3] += t.amount;
                      }
                    }
                    final sav = inc - exp;
                    final dayKeys = days.keys.toList()..sort();
                    String dstr(int d) => fmtDate(DateTime(_month.year, _month.month, d));
                    String cell(double v) => v == 0 ? '' : fmtNum(v);

                    return ListView(
                      padding: const EdgeInsets.all(12),
                      children: [
                        Row(
                          children: [
                            Expanded(child: StatCard(label: context.tr('income'), value: money(inc), color: Colors.green.shade700)),
                            Expanded(child: StatCard(label: context.tr('expense'), value: money(exp), color: Colors.red.shade700)),
                            Expanded(
                              child: StatCard(
                                label: context.tr('savings'),
                                value: money(sav),
                                color: sav >= 0 ? Colors.blue.shade700 : Colors.red.shade700,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Expanded(child: StatCard(label: context.tr('total_gave'), value: money(gave), color: Colors.red.shade700)),
                            Expanded(child: StatCard(label: context.tr('total_got'), value: money(got), color: Colors.green.shade700)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ReportButtons(
                          filename: 'monthly_report_${_month.year}_${_month.month}.pdf',
                          builder: () => PdfService.build(
                            title: '${context.tr('monthly_report')} - ${fmtMonth(_month)}',
                            business: widget.biz.name,
                            subtitle: fmtDate(DateTime.now()),
                            summary: [
                              [context.tr('income'), money(inc)],
                              [context.tr('expense'), money(exp)],
                              [context.tr('savings'), money(sav)],
                              [context.tr('total_gave'), money(gave)],
                              [context.tr('total_got'), money(got)],
                            ],
                            headers: [
                              context.tr('date'),
                              context.tr('income'),
                              context.tr('expense'),
                              context.tr('you_gave'),
                              context.tr('you_got'),
                            ],
                            rows: [
                              for (final d in dayKeys)
                                [dstr(d), cell(days[d]![0]), cell(days[d]![1]), cell(days[d]![2]), cell(days[d]![3])],
                            ],
                            rightCols: {1, 2, 3, 4},
                            noDataText: context.tr('no_data'),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(context.tr('daily_summary'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        const SizedBox(height: 6),
                        if (dayKeys.isEmpty) Text(context.tr('no_data')),
                        for (final d in dayKeys)
                          Card(
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(dstr(d), style: const TextStyle(fontWeight: FontWeight.bold)),
                                  const SizedBox(height: 4),
                                  Wrap(
                                    spacing: 14,
                                    runSpacing: 2,
                                    children: [
                                      if (days[d]![0] > 0)
                                        Text('${context.tr('income')}: ${money(days[d]![0])}', style: TextStyle(color: Colors.green.shade700)),
                                      if (days[d]![1] > 0)
                                        Text('${context.tr('expense')}: ${money(days[d]![1])}', style: TextStyle(color: Colors.red.shade700)),
                                      if (days[d]![2] > 0)
                                        Text('${context.tr('you_gave')}: ${money(days[d]![2])}'),
                                      if (days[d]![3] > 0)
                                        Text('${context.tr('you_got')}: ${money(days[d]![3])}'),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
