import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../providers/business_provider.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';
import '../vet/notes_screens.dart';
import 'businesses_screen.dart';
import 'cashbook_screen.dart';
import 'parties_screen.dart';
import 'reports_screen.dart';
import 'stock_screen.dart';
import 'tagada_screen.dart';

/// First tab: the Tallykhata-style dashboard of the selected business.
class HisabHome extends StatelessWidget {
  const HisabHome({super.key});

  @override
  Widget build(BuildContext context) {
    final bp = context.watch<BusinessProvider>();
    if (!bp.loaded) return const Center(child: CircularProgressIndicator());
    final biz = bp.active;
    if (biz == null) {
      return EmptyState(
        icon: Icons.store_outlined,
        text: context.tr('no_business'),
        action: FilledButton.icon(
          onPressed: () => Db.saveBusiness('main', {'name': 'My Business', 'phone': '', 'address': ''}),
          icon: const Icon(Icons.add),
          label: Text(context.tr('add_business')),
        ),
      );
    }
    return _Dashboard(biz: biz);
  }
}

class _Dashboard extends StatelessWidget {
  const _Dashboard({required this.biz});
  final Business biz;

  void _open(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final now = DateTime.now();

    final tiles = <_Tile>[
      _Tile(Icons.people, 'customers', Colors.teal, () => _open(context, PartiesScreen(biz: biz, type: 'customer'))),
      _Tile(Icons.local_shipping, 'suppliers', Colors.indigo, () => _open(context, PartiesScreen(biz: biz, type: 'supplier'))),
      _Tile(Icons.menu_book, 'cash_book', Colors.orange, () => _open(context, CashBookScreen(biz: biz))),
      _Tile(Icons.inventory_2, 'stock', Colors.brown, () => _open(context, StockScreen(biz: biz))),
      _Tile(Icons.campaign, 'group_tagada', Colors.red, () => _open(context, TagadaScreen(biz: biz))),
      _Tile(Icons.bar_chart, 'reports', Colors.purple, () => _open(context, ReportsScreen(biz: biz))),
      _Tile(
        Icons.edit_note,
        'business_notes',
        Colors.blueGrey,
        () => _open(
          context,
          Scaffold(
            appBar: AppBar(title: Text(context.tr('business_notes'))),
            body: NotesView(col: Db.bcol(biz.id, 'notes')),
          ),
        ),
      ),
    ];

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          color: scheme.primaryContainer,
          child: ListTile(
            leading: Icon(Icons.store, color: scheme.primary),
            title: Text(biz.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            subtitle: Text(context.tr('tap_to_switch')),
            trailing: const Icon(Icons.swap_horiz),
            onTap: () => _open(context, const BusinessesScreen()),
          ),
        ),
        // ---- receivable / payable
        StreamBuilder(
          stream: Db.bcol(biz.id, 'parties').snapshots(),
          builder: (context, snap) {
            double toGet = 0, toGive = 0;
            for (final d in snap.data?.docs ?? const []) {
              final p = Party.fromDoc(d);
              if (p.balance > 0) {
                toGet += p.balance;
              } else {
                toGive += -p.balance;
              }
            }
            return Row(
              children: [
                Expanded(
                  child: StatCard(
                    label: context.tr('you_will_get'),
                    value: money(toGet),
                    color: Colors.green.shade700,
                    icon: Icons.south_west,
                  ),
                ),
                Expanded(
                  child: StatCard(
                    label: context.tr('you_will_give'),
                    value: money(toGive),
                    color: Colors.red.shade700,
                    icon: Icons.north_east,
                  ),
                ),
              ],
            );
          },
        ),
        // ---- this month's cash book
        StreamBuilder(
          stream: Db.bcol(biz.id, 'entries').snapshots(),
          builder: (context, snap) {
            double inc = 0, exp = 0;
            for (final d in snap.data?.docs ?? const []) {
              final e = CashEntry.fromDoc(d);
              if (!sameMonth(e.date, now)) continue;
              if (e.isIncome) {
                inc += e.amount;
              } else {
                exp += e.amount;
              }
            }
            final sav = inc - exp;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(4, 8, 4, 0),
                  child: Text('${context.tr('this_month')} (${fmtMonth(now)})',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
                Row(
                  children: [
                    Expanded(child: StatCard(label: context.tr('income'), value: money(inc), color: Colors.green.shade700)),
                    Expanded(child: StatCard(label: context.tr('expense'), value: money(exp), color: Colors.red.shade700)),
                    Expanded(
                      child: StatCard(
                        label: context.tr('savings'),
                        value: money(sav),
                        color: sav >= 0 ? Colors.blue.shade700 : Colors.red.shade700,
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 8),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 1.05,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          children: [for (final t in tiles) _TileCard(tile: t)],
        ),
      ],
    );
  }
}

class _Tile {
  _Tile(this.icon, this.labelKey, this.color, this.onTap);
  final IconData icon;
  final String labelKey;
  final Color color;
  final VoidCallback onTap;
}

class _TileCard extends StatelessWidget {
  const _TileCard({required this.tile});
  final _Tile tile;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: tile.onTap,
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: tile.color.withValues(alpha: 0.15),
                child: Icon(tile.icon, color: tile.color, size: 26),
              ),
              const SizedBox(height: 8),
              Text(
                context.tr(tile.labelKey),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
