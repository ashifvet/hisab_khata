import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../services/pdf_service.dart';
import '../../widgets/common.dart';
import '../../widgets/report_buttons.dart';

/// Stock & inventory: quantity of every product and the total value of the stock.
class StockScreen extends StatefulWidget {
  const StockScreen({super.key, required this.biz});
  final Business biz;

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  String _q = '';

  Future<void> _productDialog(Product? p) async {
    final name = TextEditingController(text: p?.name ?? '');
    final unit = TextEditingController(text: p?.unit ?? 'pcs');
    final qty = TextEditingController(text: p == null ? '' : fmtNum(p.qty).replaceAll(',', ''));
    final buy = TextEditingController(text: p == null ? '' : fmtNum(p.buyPrice).replaceAll(',', ''));
    final sell = TextEditingController(text: p == null ? '' : fmtNum(p.sellPrice).replaceAll(',', ''));
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(p == null ? ctx.tr('add_product') : ctx.tr('edit')),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: name,
                textCapitalization: TextCapitalization.words,
                decoration: deco(ctx.tr('product_name'), icon: Icons.inventory_2_outlined),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: TextField(controller: unit, decoration: deco(ctx.tr('unit')))),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: qty,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: deco(ctx.tr('quantity')),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: buy,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: deco(ctx.tr('buy_price'), prefix: '৳ '),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: sell,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: deco(ctx.tr('sell_price'), prefix: '৳ '),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('save'))),
        ],
      ),
    );
    final n = name.text.trim();
    final u = unit.text.trim().isEmpty ? 'pcs' : unit.text.trim();
    final q = parseNum(qty.text) ?? 0;
    final b = parseNum(buy.text) ?? 0;
    final s = parseNum(sell.text) ?? 0;
    name.dispose();
    unit.dispose();
    qty.dispose();
    buy.dispose();
    sell.dispose();
    if (ok != true || n.isEmpty) return;
    Db.save(Db.bcol(widget.biz.id, 'products'), p?.id, {
      'name': n,
      'unit': u,
      'qty': q,
      'buyPrice': b,
      'sellPrice': s,
    });
  }

  Future<void> _moveDialog(Product p, bool stockIn) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${stockIn ? ctx.tr('stock_in') : ctx.tr('stock_out')} - ${p.name}'),
        content: TextField(
          controller: c,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: deco(ctx.tr('quantity'), suffix: p.unit),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('save'))),
        ],
      ),
    );
    final q = parseNum(c.text);
    c.dispose();
    if (ok != true || q == null || q <= 0) return;
    if (!stockIn && q > p.qty) {
      if (mounted) toast(context, context.tr('not_enough_stock'));
      return;
    }
    Db.adjustStock(widget.biz.id, p.id, stockIn ? q : -q);
  }

  void _productSheet(Product p) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(p.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('${context.tr('in_stock')}: ${fmtNum(p.qty)} ${p.unit}'),
              Text('${context.tr('buy_price')}: ${money(p.buyPrice)}   •   ${context.tr('sell_price')}: ${money(p.sellPrice)}'),
              Text('${context.tr('stock_value')}: ${money(p.stockValue)}'),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: Colors.green.shade700),
                      onPressed: () {
                        Navigator.pop(ctx);
                        _moveDialog(p, true);
                      },
                      icon: const Icon(Icons.add),
                      label: Text(ctx.tr('stock_in')),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
                      onPressed: () {
                        Navigator.pop(ctx);
                        _moveDialog(p, false);
                      },
                      icon: const Icon(Icons.remove),
                      label: Text(ctx.tr('stock_out')),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _productDialog(p);
                      },
                      icon: const Icon(Icons.edit),
                      label: Text(ctx.tr('edit')),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        Navigator.pop(ctx);
                        final ok = await confirmDialog(context, context.tr('delete'), context.tr('delete_confirm'));
                        if (ok) Db.remove(Db.bcol(widget.biz.id, 'products').doc(p.id));
                      },
                      icon: const Icon(Icons.delete_outline),
                      label: Text(ctx.tr('delete')),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('stock'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _productDialog(null),
        icon: const Icon(Icons.add),
        label: Text(context.tr('add_product')),
      ),
      body: StreamBuilder(
        stream: Db.bcol(widget.biz.id, 'products').snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final all = snap.data!.docs.map(Product.fromDoc).toList()
            ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
          double stockValue = 0, saleValue = 0;
          for (final p in all) {
            stockValue += p.stockValue;
            saleValue += p.saleValue;
          }
          final list = all.where((p) => _q.isEmpty || p.name.toLowerCase().contains(_q)).toList();
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                child: Row(
                  children: [
                    Expanded(child: StatCard(label: context.tr('stock_value'), value: money(stockValue), color: Colors.brown)),
                    Expanded(child: StatCard(label: context.tr('sale_value'), value: money(saleValue), color: Colors.green.shade700)),
                    Expanded(child: StatCard(label: context.tr('items'), value: '${all.length}', color: Colors.blue.shade700)),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                child: ReportButtons(
                  filename: 'stock_report.pdf',
                  builder: () => PdfService.build(
                    title: context.tr('stock_report'),
                    business: widget.biz.name,
                    subtitle: fmtDate(DateTime.now()),
                    summary: [
                      [context.tr('stock_value'), money(stockValue)],
                      [context.tr('sale_value'), money(saleValue)],
                      [context.tr('items'), '${all.length}'],
                    ],
                    headers: [
                      context.tr('product_name'),
                      context.tr('quantity'),
                      context.tr('buy_price'),
                      context.tr('sell_price'),
                      context.tr('stock_value'),
                    ],
                    rows: [
                      for (final p in all)
                        [
                          p.name,
                          '${fmtNum(p.qty)} ${p.unit}',
                          fmtNum(p.buyPrice),
                          fmtNum(p.sellPrice),
                          fmtNum(p.stockValue),
                        ],
                    ],
                    rightCols: {1, 2, 3, 4},
                    noDataText: context.tr('no_data'),
                  ),
                ),
              ),
              SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
              Expanded(
                child: list.isEmpty
                    ? EmptyState(icon: Icons.inventory_2_outlined, text: context.tr('no_products'))
                    : ListView.separated(
                        padding: const EdgeInsets.only(bottom: 90),
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final p = list[i];
                          return ListTile(
                            leading: const CircleAvatar(child: Icon(Icons.inventory_2, size: 20)),
                            title: Text(p.name),
                            subtitle: Text('${context.tr('buy_price')}: ${money(p.buyPrice)}'),
                            trailing: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  '${fmtNum(p.qty)} ${p.unit}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: p.qty <= 0 ? Colors.red.shade700 : null,
                                  ),
                                ),
                                Text(money(p.stockValue), style: const TextStyle(fontSize: 12)),
                              ],
                            ),
                            onTap: () => _productSheet(p),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
