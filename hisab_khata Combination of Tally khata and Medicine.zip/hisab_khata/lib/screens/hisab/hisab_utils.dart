import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';

/// Builds the payment reminder text in the current app language.
String remindText(BuildContext context, String name, double amount, String business) {
  return context
      .tr('remind_msg')
      .replaceAll('{name}', name)
      .replaceAll('{amount}', money(amount))
      .replaceAll('{business}', business);
}

/// Bottom sheet to send a text by SMS or WhatsApp to one person.
Future<void> showSendSheet(BuildContext context, {required String phone, required String text}) {
  return showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(text, style: const TextStyle(fontSize: 15)),
          ),
          if (phone.trim().isEmpty)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(ctx.tr('no_phone')),
            )
          else ...[
            ListTile(
              leading: const Icon(Icons.sms, color: Colors.blue),
              title: Text(ctx.tr('send_sms')),
              onTap: () {
                Navigator.pop(ctx);
                openUrl(context, smsUrl([phone], text));
              },
            ),
            ListTile(
              leading: const Icon(Icons.chat, color: Colors.green),
              title: Text(ctx.tr('send_whatsapp')),
              onTap: () {
                Navigator.pop(ctx);
                openUrl(context, waUrl(phone, text));
              },
            ),
          ],
        ],
      ),
    ),
  );
}
