import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../providers/business_provider.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';

/// Manage up to 5 businesses / personal accounts.
class BusinessesScreen extends StatelessWidget {
  const BusinessesScreen({super.key});

  Future<void> _edit(BuildContext context, Business? b) async {
    final name = TextEditingController(text: b?.name ?? '');
    final phone = TextEditingController(text: b?.phone ?? '');
    final address = TextEditingController(text: b?.address ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(b == null ? ctx.tr('add_business') : ctx.tr('edit_business')),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: name, decoration: deco(ctx.tr('business_name'))),
              const SizedBox(height: 10),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: deco(ctx.tr('phone'))),
              const SizedBox(height: 10),
              TextField(controller: address, decoration: deco(ctx.tr('address'))),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('save'))),
        ],
      ),
    );
    final n = name.text.trim();
    final p = phone.text.trim();
    final a = address.text.trim();
    name.dispose();
    phone.dispose();
    address.dispose();
    if (ok != true || n.isEmpty) return;
    final id = Db.saveBusiness(b?.id, {'name': n, 'phone': p, 'address': a});
    if (b == null && context.mounted) {
      context.read<BusinessProvider>().setActive(id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bp = context.watch<BusinessProvider>();
    final canAdd = bp.businesses.length < kMaxBusinesses;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('my_businesses'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          if (!canAdd) {
            toast(context, context.tr('max_businesses'));
            return;
          }
          _edit(context, null);
        },
        icon: const Icon(Icons.add),
        label: Text(context.tr('add_business')),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
        children: [
          Text('${bp.businesses.length} / $kMaxBusinesses', textAlign: TextAlign.center),
          const SizedBox(height: 8),
          for (final b in bp.businesses)
            Card(
              child: ListTile(
                leading: Icon(
                  b.id == bp.activeId ? Icons.check_circle : Icons.circle_outlined,
                  color: b.id == bp.activeId ? Theme.of(context).colorScheme.primary : null,
                ),
                title: Text(b.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text([b.phone, b.address].where((e) => e.isNotEmpty).join(' • ')),
                onTap: () {
                  bp.setActive(b.id);
                  Navigator.pop(context);
                },
                trailing: PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'edit') {
                      _edit(context, b);
                    } else if (v == 'delete') {
                      if (bp.businesses.length <= 1) {
                        toast(context, context.tr('cannot_delete_last'));
                        return;
                      }
                      final ok = await confirmDialog(context, context.tr('delete'), context.tr('delete_business_confirm'));
                      if (ok) {
                        if (bp.activeId == b.id) {
                          final other = bp.businesses.firstWhere((x) => x.id != b.id);
                          await bp.setActive(other.id);
                        }
                        Db.deleteBusiness(b.id);
                      }
                    }
                  },
                  itemBuilder: (ctx) => [
                    PopupMenuItem(value: 'edit', child: Text(ctx.tr('edit'))),
                    PopupMenuItem(value: 'delete', child: Text(ctx.tr('delete'))),
                  ],
                ),
              ),
            ),
          if (bp.businesses.isEmpty)
            EmptyState(icon: Icons.store_outlined, text: context.tr('no_business')),
        ],
      ),
    );
  }
}
