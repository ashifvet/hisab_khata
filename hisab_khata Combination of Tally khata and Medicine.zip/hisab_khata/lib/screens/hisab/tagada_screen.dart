import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';

/// Group Tagada: send payment reminders to many customers.
///  - "One by one"  : a personal message (name + amount) for each customer, one tap each.
///  - "Group SMS"   : ONE SMS to all selected customers at the same time.
/// Messages are sent from the phone itself (SIM SMS or WhatsApp) - no extra cost for the app.
class TagadaScreen extends StatefulWidget {
  const TagadaScreen({super.key, required this.biz});
  final Business biz;

  @override
  State<TagadaScreen> createState() => _TagadaScreenState();
}

class _TagadaScreenState extends State<TagadaScreen> {
  final _personal = TextEditingController();
  final _group = TextEditingController();
  bool _inited = false;
  String _mode = 'personal'; // personal | group
  String _channel = 'sms'; // sms | whatsapp
  final Set<String> _selected = {};
  final Set<String> _sent = {};
  List<Party> _queue = [];
  int _qi = 0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_inited) {
      _inited = true;
      _personal.text = context.tr('remind_msg');
      _group.text = context.tr('tagada_group_msg').replaceAll('{business}', widget.biz.name);
    }
  }

  @override
  void dispose() {
    _personal.dispose();
    _group.dispose();
    super.dispose();
  }

  String _text(Party p) => _personal.text
      .replaceAll('{name}', p.name)
      .replaceAll('{amount}', money(p.balance))
      .replaceAll('{business}', widget.biz.name);

  Future<void> _open(Party p) async {
    final url = _channel == 'sms' ? smsUrl([p.phone], _text(p)) : waUrl(p.phone, _text(p));
    setState(() => _sent.add(p.id));
    await openUrl(context, url);
  }

  Future<void> _startQueue(List<Party> chosen) async {
    final withPhone = chosen.where((p) => p.phone.trim().isNotEmpty).toList();
    if (withPhone.isEmpty) {
      toast(context, context.tr('no_phone'));
      return;
    }
    setState(() {
      _queue = withPhone;
      _qi = 0;
    });
    await _next();
  }

  Future<void> _next() async {
    if (_qi >= _queue.length) {
      setState(() {
        _queue = [];
        _qi = 0;
      });
      toast(context, context.tr('tagada_done'));
      return;
    }
    final p = _queue[_qi];
    setState(() => _qi++);
    await _open(p);
  }

  Future<void> _sendGroup(List<Party> chosen) async {
    final phones = chosen.map((p) => p.phone.trim()).where((p) => p.isNotEmpty).toList();
    if (phones.isEmpty) {
      toast(context, context.tr('no_phone'));
      return;
    }
    setState(() => _sent.addAll(chosen.map((p) => p.id)));
    await openUrl(context, smsUrl(phones, _group.text));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('group_tagada'))),
      body: StreamBuilder(
        stream: Db.bcol(widget.biz.id, 'parties').snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final due = snap.data!.docs.map(Party.fromDoc).where((p) => p.type == 'customer' && p.balance > 0.004).toList()
            ..sort((a, b) => b.balance.compareTo(a.balance));
          final chosen = due.where((p) => _selected.contains(p.id)).toList();
          final allSelected = due.isNotEmpty && chosen.length == due.length;
          final queueActive = _queue.isNotEmpty && _qi < _queue.length;

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SegmentedButton<String>(
                      segments: [
                        ButtonSegment(value: 'personal', icon: const Icon(Icons.person), label: Text(context.tr('one_by_one'))),
                        ButtonSegment(value: 'group', icon: const Icon(Icons.groups), label: Text(context.tr('group_sms'))),
                      ],
                      selected: {_mode},
                      onSelectionChanged: (s) => setState(() => _mode = s.first),
                    ),
                    const SizedBox(height: 10),
                    if (_mode == 'personal') ...[
                      SegmentedButton<String>(
                        segments: const [
                          ButtonSegment(value: 'sms', icon: Icon(Icons.sms), label: Text('SMS')),
                          ButtonSegment(value: 'whatsapp', icon: Icon(Icons.chat), label: Text('WhatsApp')),
                        ],
                        selected: {_channel},
                        onSelectionChanged: (s) => setState(() => _channel = s.first),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _personal,
                        minLines: 2,
                        maxLines: 4,
                        decoration: deco(context.tr('message')),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(context.tr('tagada_hint'), style: Theme.of(context).textTheme.bodySmall),
                      ),
                    ] else
                      TextField(
                        controller: _group,
                        minLines: 2,
                        maxLines: 4,
                        decoration: deco(context.tr('message')),
                      ),
                  ],
                ),
              ),
              CheckboxListTile(
                dense: true,
                value: allSelected,
                title: Text('${context.tr('select_all')}  (${chosen.length}/${due.length})'),
                onChanged: due.isEmpty
                    ? null
                    : (v) => setState(() {
                          if (v == true) {
                            _selected.addAll(due.map((p) => p.id));
                          } else {
                            _selected.clear();
                          }
                        }),
              ),
              const Divider(height: 1),
              Expanded(
                child: due.isEmpty
                    ? EmptyState(icon: Icons.celebration_outlined, text: context.tr('no_dues'))
                    : ListView.separated(
                        itemCount: due.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final p = due[i];
                          return CheckboxListTile(
                            value: _selected.contains(p.id),
                            onChanged: (v) => setState(() {
                              if (v == true) {
                                _selected.add(p.id);
                              } else {
                                _selected.remove(p.id);
                              }
                            }),
                            title: Text(p.name),
                            subtitle: Text(p.phone.isEmpty ? context.tr('no_phone') : p.phone),
                            secondary: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(money(p.balance),
                                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green.shade700)),
                                if (_sent.contains(p.id))
                                  Row(mainAxisSize: MainAxisSize.min, children: [
                                    const Icon(Icons.check_circle, size: 14, color: Colors.green),
                                    const SizedBox(width: 3),
                                    Text(context.tr('sent'), style: const TextStyle(fontSize: 11)),
                                  ]),
                              ],
                            ),
                          );
                        },
                      ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: queueActive
                      ? Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${context.tr('next')}: ${_queue[_qi].name}  (${_qi + 1}/${_queue.length})',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ),
                            TextButton(
                              onPressed: () => setState(() {
                                _queue = [];
                                _qi = 0;
                              }),
                              child: Text(context.tr('stop')),
                            ),
                            FilledButton.icon(
                              onPressed: _next,
                              icon: const Icon(Icons.send),
                              label: Text(context.tr('send_next')),
                            ),
                          ],
                        )
                      : SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
                            onPressed: chosen.isEmpty
                                ? null
                                : () => _mode == 'personal' ? _startQueue(chosen) : _sendGroup(chosen),
                            icon: const Icon(Icons.campaign),
                            label: Text('${context.tr('send_reminders')} (${chosen.length})'),
                          ),
                        ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
