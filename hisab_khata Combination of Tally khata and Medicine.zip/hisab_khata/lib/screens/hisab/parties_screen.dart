import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/db.dart';
import '../../services/pdf_service.dart';
import '../../widgets/common.dart';
import '../../widgets/report_buttons.dart';
import 'hisab_utils.dart';

/// Add / edit a customer or supplier.
Future<void> showPartyDialog(BuildContext context, Business biz, String type, {Party? party}) async {
  final name = TextEditingController(text: party?.name ?? '');
  final phone = TextEditingController(text: party?.phone ?? '');
  final address = TextEditingController(text: party?.address ?? '');
  final isCustomer = type == 'customer';
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(party == null
          ? (isCustomer ? ctx.tr('add_customer') : ctx.tr('add_supplier'))
          : ctx.tr('edit')),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              textCapitalization: TextCapitalization.words,
              decoration: deco(ctx.tr('name'), icon: Icons.person),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: deco(ctx.tr('phone'), icon: Icons.phone),
            ),
            const SizedBox(height: 10),
            TextField(controller: address, decoration: deco(ctx.tr('address'), icon: Icons.location_on_outlined)),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('save'))),
      ],
    ),
  );
  final n = name.text.trim();
  final p = phone.text.trim();
  final a = address.text.trim();
  name.dispose();
  phone.dispose();
  address.dispose();
  if (ok != true || n.isEmpty) return;
  final data = <String, dynamic>{'name': n, 'phone': p, 'address': a, 'type': type};
  if (party == null) data['balance'] = 0.0;
  Db.save(Db.bcol(biz.id, 'parties'), party?.id, data);
}

/// List of customers OR suppliers.
class PartiesScreen extends StatefulWidget {
  const PartiesScreen({super.key, required this.biz, required this.type});
  final Business biz;
  final String type;

  @override
  State<PartiesScreen> createState() => _PartiesScreenState();
}

class _PartiesScreenState extends State<PartiesScreen> {
  String _q = '';

  bool get _isCustomer => widget.type == 'customer';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isCustomer ? context.tr('customers') : context.tr('suppliers'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showPartyDialog(context, widget.biz, widget.type),
        icon: const Icon(Icons.person_add),
        label: Text(_isCustomer ? context.tr('add_customer') : context.tr('add_supplier')),
      ),
      body: StreamBuilder(
        stream: Db.bcol(widget.biz.id, 'parties').snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final all = snap.data!.docs.map(Party.fromDoc).where((p) => p.type == widget.type).toList()
            ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
          double toGet = 0, toGive = 0;
          for (final p in all) {
            if (p.balance > 0) {
              toGet += p.balance;
            } else {
              toGive += -p.balance;
            }
          }
          final list = all.where((p) => _q.isEmpty || p.name.toLowerCase().contains(_q) || p.phone.contains(_q)).toList();
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: StatCard(label: context.tr('you_will_get'), value: money(toGet), color: Colors.green.shade700),
                    ),
                    Expanded(
                      child: StatCard(label: context.tr('you_will_give'), value: money(toGive), color: Colors.red.shade700),
                    ),
                  ],
                ),
              ),
              SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
              Expanded(
                child: list.isEmpty
                    ? EmptyState(
                        icon: _isCustomer ? Icons.people_outline : Icons.local_shipping_outlined,
                        text: _isCustomer ? context.tr('no_customers') : context.tr('no_suppliers'),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.only(bottom: 90),
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final p = list[i];
                          return ListTile(
                            leading: CircleAvatar(child: Text(p.name.isEmpty ? '?' : p.name[0].toUpperCase())),
                            title: Text(p.name),
                            subtitle: p.phone.isEmpty ? null : Text(p.phone),
                            trailing: BalanceText(balance: p.balance),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute<void>(
                                builder: (_) => PartyDetailScreen(biz: widget.biz, partyId: p.id),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Ledger of one customer / supplier.
class PartyDetailScreen extends StatelessWidget {
  const PartyDetailScreen({super.key, required this.biz, required this.partyId});
  final Business biz;
  final String partyId;

  Future<Uint8List> _buildPdf(BuildContext context, Party party, List<PartyTxn> txns) {
    final asc = [...txns]..sort((a, b) => a.date.compareTo(b.date));
    double run = 0;
    final rows = <List<String>>[];
    double gave = 0, got = 0;
    for (final t in asc) {
      if (t.isGave) {
        run += t.amount;
        gave += t.amount;
      } else {
        run -= t.amount;
        got += t.amount;
      }
      rows.add([
        fmtDate(t.date),
        t.note,
        t.isGave ? fmtNum(t.amount) : '',
        t.isGave ? '' : fmtNum(t.amount),
        '${fmtNum(run.abs())} ${run > 0.004 ? 'Dr' : run < -0.004 ? 'Cr' : ''}'.trim(),
      ]);
    }
    final bal = party.balance;
    return PdfService.build(
      title: '${context.tr('statement')}: ${party.name}',
      business: biz.name,
      subtitle: '${party.phone}   ${fmtDate(DateTime.now())}',
      summary: [
        [context.tr('total_gave'), money(gave)],
        [context.tr('total_got'), money(got)],
        [bal >= 0 ? context.tr('will_get') : context.tr('will_give'), money(bal.abs())],
      ],
      headers: [
        context.tr('date'),
        context.tr('details'),
        context.tr('you_gave'),
        context.tr('you_got'),
        context.tr('balance'),
      ],
      rows: rows,
      rightCols: {2, 3, 4},
      noDataText: context.tr('no_data'),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Db.bcol(biz.id, 'parties').doc(partyId).snapshots(),
      builder: (context, psnap) {
        final pdoc = psnap.data;
        if (pdoc == null || !pdoc.exists) {
          return Scaffold(
            appBar: AppBar(),
            body: psnap.connectionState == ConnectionState.waiting
                ? const Center(child: CircularProgressIndicator())
                : EmptyState(icon: Icons.person_off_outlined, text: context.tr('not_found')),
          );
        }
        final party = Party.fromDoc(pdoc);
        return StreamBuilder(
          stream: Db.bcol(biz.id, 'transactions').where('partyId', isEqualTo: partyId).snapshots(),
          builder: (context, tsnap) {
            final txns = (tsnap.data?.docs.map(PartyTxn.fromDoc).toList() ?? <PartyTxn>[])
              ..sort((a, b) => b.date.compareTo(a.date));
            return Scaffold(
              appBar: AppBar(
                title: Text(party.name),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () => showPartyDialog(context, biz, party.type, party: party),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      final nav = Navigator.of(context);
                      final ok = await confirmDialog(context, context.tr('delete'), context.tr('delete_party_confirm'));
                      if (ok) {
                        Db.deleteParty(biz.id, party.id);
                        nav.pop();
                      }
                    },
                  ),
                ],
              ),
              body: Column(
                children: [
                  Card(
                    margin: const EdgeInsets.all(12),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    if (party.phone.isNotEmpty) Text(party.phone),
                                    if (party.address.isNotEmpty) Text(party.address, style: Theme.of(context).textTheme.bodySmall),
                                  ],
                                ),
                              ),
                              BalanceText(balance: party.balance, big: true),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: party.phone.isEmpty ? null : () => callPhone(context, party.phone),
                                  icon: const Icon(Icons.call, size: 18),
                                  label: Text(context.tr('call')),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: () => showSendSheet(
                                    context,
                                    phone: party.phone,
                                    text: remindText(context, party.name, party.balance.abs(), biz.name),
                                  ),
                                  icon: const Icon(Icons.notifications_active_outlined, size: 18),
                                  label: Text(context.tr('remind')),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          ReportButtons(
                            builder: () => _buildPdf(context, party, txns),
                            filename: 'statement_${party.name.replaceAll(RegExp(r'[^A-Za-z0-9]'), '_')}.pdf',
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: txns.isEmpty
                        ? EmptyState(icon: Icons.receipt_long_outlined, text: context.tr('no_transactions'))
                        : ListView.separated(
                            itemCount: txns.length,
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemBuilder: (context, i) {
                              final t = txns[i];
                              final color = t.isGave ? Colors.red.shade700 : Colors.green.shade700;
                              return ListTile(
                                title: Text(t.note.isEmpty ? (t.isGave ? context.tr('you_gave') : context.tr('you_got')) : t.note),
                                subtitle: Text(fmtDate(t.date)),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text(money(t.amount),
                                            style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16)),
                                        Text(t.isGave ? context.tr('you_gave') : context.tr('you_got'),
                                            style: TextStyle(color: color, fontSize: 11)),
                                      ],
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete_outline, size: 20),
                                      onPressed: () async {
                                        final ok = await confirmDialog(context, context.tr('delete'), context.tr('delete_confirm'));
                                        if (ok) Db.deletePartyTxn(biz.id, t);
                                      },
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                  SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          Expanded(
                            child: FilledButton(
                              style: FilledButton.styleFrom(
                                backgroundColor: Colors.red.shade700,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                              ),
                              onPressed: () => showTxnSheet(context, biz, party, 'gave'),
                              child: Text(context.tr('you_gave')),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: FilledButton(
                              style: FilledButton.styleFrom(
                                backgroundColor: Colors.green.shade700,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                              ),
                              onPressed: () => showTxnSheet(context, biz, party, 'got'),
                              child: Text(context.tr('you_got')),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

Future<void> showTxnSheet(BuildContext context, Business biz, Party party, String type) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => _TxnSheet(biz: biz, party: party, type: type),
  );
}

class _TxnSheet extends StatefulWidget {
  const _TxnSheet({required this.biz, required this.party, required this.type});
  final Business biz;
  final Party party;
  final String type;

  @override
  State<_TxnSheet> createState() => _TxnSheetState();
}

class _TxnSheetState extends State<_TxnSheet> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  DateTime _date = DateTime.now();

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  void _save() {
    final a = parseNum(_amount.text);
    if (a == null || a <= 0) {
      toast(context, context.tr('enter_amount'));
      return;
    }
    Db.addPartyTxn(
      widget.biz.id,
      partyId: widget.party.id,
      type: widget.type,
      amount: a,
      note: _note.text.trim(),
      date: _date,
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final gave = widget.type == 'gave';
    final color = gave ? Colors.red.shade700 : Colors.green.shade700;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              '${gave ? context.tr('you_gave') : context.tr('you_got')} - ${widget.party.name}',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _amount,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: deco(context.tr('amount'), prefix: '৳ '),
            ),
            const SizedBox(height: 12),
            TextField(controller: _note, decoration: deco(context.tr('details'), icon: Icons.notes)),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () async {
                final d = await pickDate(context, _date);
                if (d != null) setState(() => _date = d);
              },
              icon: const Icon(Icons.calendar_today, size: 18),
              label: Text(fmtDate(_date)),
            ),
            const SizedBox(height: 14),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: color, padding: const EdgeInsets.symmetric(vertical: 14)),
              onPressed: _save,
              child: Text(context.tr('save')),
            ),
          ],
        ),
      ),
    );
  }
}
