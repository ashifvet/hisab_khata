import 'package:cloud_firestore/cloud_firestore.dart' show SetOptions;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../services/db.dart';
import '../../widgets/common.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _form = GlobalKey<FormState>();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _location = TextEditingController();
  final _designation = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final snap = await Db.userDoc.get();
      final m = snap.data() ?? <String, dynamic>{};
      _first.text = (m['firstName'] ?? '').toString();
      _last.text = (m['lastName'] ?? '').toString();
      _email.text = (m['email'] ?? FirebaseAuth.instance.currentUser?.email ?? '').toString();
      _phone.text = (m['phone'] ?? '').toString();
      _location.text = (m['location'] ?? '').toString();
      _designation.text = (m['designation'] ?? '').toString();
    } catch (_) {
      _email.text = FirebaseAuth.instance.currentUser?.email ?? '';
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  void dispose() {
    _first.dispose();
    _last.dispose();
    _email.dispose();
    _phone.dispose();
    _location.dispose();
    _designation.dispose();
    super.dispose();
  }

  void _save() {
    if (!_form.currentState!.validate()) return;
    Db.fire(Db.userDoc.set({
      'firstName': _first.text.trim(),
      'lastName': _last.text.trim(),
      'email': _email.text.trim(),
      'phone': _phone.text.trim(),
      'location': _location.text.trim(),
      'designation': _designation.text.trim(),
    }, SetOptions(merge: true)));
    toast(context, context.tr('saved'));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('edit_profile'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _form,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  TextFormField(
                    controller: _first,
                    decoration: deco(context.tr('first_name'), icon: Icons.person),
                    validator: (v) => (v == null || v.trim().isEmpty) ? context.tr('required') : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(controller: _last, decoration: deco(context.tr('last_name'), icon: Icons.person_outline)),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: deco(context.tr('email'), icon: Icons.email_outlined),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _phone,
                    keyboardType: TextInputType.phone,
                    decoration: deco(context.tr('phone'), icon: Icons.phone),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(controller: _location, decoration: deco(context.tr('location'), icon: Icons.location_on_outlined)),
                  const SizedBox(height: 12),
                  TextFormField(controller: _designation, decoration: deco(context.tr('designation'), icon: Icons.badge_outlined)),
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: _save,
                    icon: const Icon(Icons.save),
                    label: Text(context.tr('save')),
                    style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
                  ),
                ],
              ),
            ),
    );
  }
}
