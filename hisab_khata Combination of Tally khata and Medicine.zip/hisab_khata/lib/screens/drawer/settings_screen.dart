import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/helpers.dart';
import '../../core/strings.dart';
import '../../providers/settings_provider.dart';
import '../../widgets/common.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsProvider>();
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('settings'))),
      body: ListView(
        children: [
          SwitchListTile(
            secondary: const Icon(Icons.dark_mode_outlined),
            title: Text(context.tr('dark_mode')),
            subtitle: Text(s.dark ? context.tr('enabled') : context.tr('disabled')),
            value: s.dark,
            onChanged: (v) => s.setDark(v),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.language),
            title: Text(context.tr('language')),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 8),
              child: SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'en', label: Text('English')),
                  ButtonSegment(value: 'bn', label: Text('বাংলা')),
                ],
                selected: {s.lang},
                onSelectionChanged: (v) => s.setLang(v.first),
              ),
            ),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.lock_outline),
            title: Text(context.tr('change_password')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => showDialog<void>(context: context, builder: (_) => const _ChangePasswordDialog()),
          ),
        ],
      ),
    );
  }
}

class _ChangePasswordDialog extends StatefulWidget {
  const _ChangePasswordDialog();

  @override
  State<_ChangePasswordDialog> createState() => _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _form = GlobalKey<FormState>();
  final _old = TextEditingController();
  final _new = TextEditingController();
  final _confirm = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _old.dispose();
    _new.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      final user = FirebaseAuth.instance.currentUser!;
      final cred = EmailAuthProvider.credential(email: user.email!, password: _old.text);
      await user.reauthenticateWithCredential(cred);
      await user.updatePassword(_new.text);
      if (!mounted) return;
      Navigator.pop(context);
      toast(context, context.tr('password_changed'));
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      final key = (e.code == 'wrong-password' || e.code == 'invalid-credential')
          ? 'err_old_password'
          : e.code == 'network-request-failed'
              ? 'err_network'
              : 'err_generic';
      toast(context, context.tr(key));
    } catch (_) {
      if (mounted) toast(context, context.tr('err_generic'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(context.tr('change_password')),
      content: Form(
        key: _form,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _old,
                obscureText: true,
                decoration: deco(context.tr('old_password')),
                validator: (v) => (v == null || v.isEmpty) ? context.tr('required') : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _new,
                obscureText: true,
                decoration: deco(context.tr('new_password')),
                validator: (v) => (v == null || v.length < 6) ? context.tr('err_weak_password') : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _confirm,
                obscureText: true,
                decoration: deco(context.tr('confirm_password')),
                validator: (v) => v != _new.text ? context.tr('err_password_match') : null,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: Text(context.tr('cancel'))),
        FilledButton(
          onPressed: _busy ? null : _submit,
          child: _busy
              ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : Text(context.tr('save')),
        ),
      ],
    );
  }
}
