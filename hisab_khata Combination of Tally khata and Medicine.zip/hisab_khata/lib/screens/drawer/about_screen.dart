import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../core/constants.dart';
import '../../core/helpers.dart';
import '../../core/strings.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('about_developer'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 8),
          Center(
            child: CircleAvatar(
              radius: 48,
              backgroundColor: scheme.primaryContainer,
              child: Icon(Icons.person, size: 56, color: scheme.primary),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            kDevName,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(kDevTitle, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 20),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.phone),
                  title: Text(context.tr('phone')),
                  subtitle: const Text(kDevPhone),
                  trailing: const Icon(Icons.call),
                  onTap: () => callPhone(context, kDevPhone),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.home_outlined),
                  title: Text(context.tr('hometown')),
                  subtitle: const Text(kDevHometown),
                ),
                const Divider(height: 1),
                FutureBuilder<PackageInfo>(
                  future: PackageInfo.fromPlatform(),
                  builder: (context, snap) => ListTile(
                    leading: const Icon(Icons.verified_outlined),
                    title: Text(context.tr('version_name')),
                    subtitle: Text(snap.hasData ? '${snap.data!.version} (${snap.data!.buildNumber})' : '...'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text(context.tr('about_app'), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
