import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../core/helpers.dart';
import '../core/strings.dart';
import '../services/pdf_service.dart';

/// Two buttons: "Share / Save PDF"  (WhatsApp, imo, Messenger, Drive ...)  and  "Print".
class ReportButtons extends StatefulWidget {
  const ReportButtons({super.key, required this.builder, required this.filename});
  final Future<Uint8List> Function() builder;
  final String filename;

  @override
  State<ReportButtons> createState() => _ReportButtonsState();
}

class _ReportButtonsState extends State<ReportButtons> {
  bool _busy = false;

  Future<void> _run(bool share) async {
    setState(() => _busy = true);
    try {
      final bytes = await widget.builder();
      if (share) {
        await PdfService.share(bytes, widget.filename);
      } else {
        await PdfService.printDoc(bytes, widget.filename);
      }
    } catch (_) {
      if (mounted) toast(context, context.tr('err_generic'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: FilledButton.icon(
            onPressed: _busy ? null : () => _run(true),
            icon: _busy
                ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.share),
            label: Text(context.tr('share_pdf')),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: _busy ? null : () => _run(false),
            icon: const Icon(Icons.print),
            label: Text(context.tr('print')),
          ),
        ),
      ],
    );
  }
}
