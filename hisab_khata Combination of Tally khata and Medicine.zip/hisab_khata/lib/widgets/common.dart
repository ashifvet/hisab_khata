import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../core/helpers.dart';
import '../core/strings.dart';
import '../services/db.dart';

InputDecoration deco(String label, {IconData? icon, String? hint, String? prefix, String? suffix}) {
  return InputDecoration(
    labelText: label,
    hintText: hint,
    prefixText: prefix,
    suffixText: suffix,
    prefixIcon: icon == null ? null : Icon(icon),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
  );
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.text, this.action});
  final IconData icon;
  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
            if (action != null) ...[const SizedBox(height: 16), action!],
          ],
        ),
      ),
    );
  }
}

class SearchBox extends StatelessWidget {
  const SearchBox({super.key, required this.onChanged, this.hint});
  final ValueChanged<String> onChanged;
  final String? hint;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
      child: TextField(
        onChanged: onChanged,
        decoration: deco(hint ?? context.tr('search'), icon: Icons.search),
      ),
    );
  }
}

/// Small cloud icon in the app bar: shows if the data is synced or only on the phone.
class SyncIndicator extends StatelessWidget {
  const SyncIndicator({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: Db.userDoc.snapshots(includeMetadataChanges: true),
      builder: (context, snap) {
        final meta = snap.data?.metadata;
        final offline = meta?.isFromCache ?? true;
        final pending = meta?.hasPendingWrites ?? false;
        IconData icon = Icons.cloud_done_outlined;
        String tip = context.tr('sync_ok');
        if (offline) {
          icon = Icons.cloud_off_outlined;
          tip = context.tr('sync_offline');
        } else if (pending) {
          icon = Icons.cloud_upload_outlined;
          tip = context.tr('sync_pending');
        }
        return IconButton(
          tooltip: tip,
          icon: Icon(icon),
          onPressed: () => toast(context, tip),
        );
      },
    );
  }
}

/// Shows "You will get ৳500" / "You will give ৳200" / "Settled".
class BalanceText extends StatelessWidget {
  const BalanceText({super.key, required this.balance, this.big = false});
  final double balance;
  final bool big;

  @override
  Widget build(BuildContext context) {
    final style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: big ? 22 : 15,
      color: balance > 0.004
          ? Colors.green.shade700
          : balance < -0.004
              ? Colors.red.shade700
              : Theme.of(context).colorScheme.outline,
    );
    final label = balance > 0.004
        ? context.tr('will_get')
        : balance < -0.004
            ? context.tr('will_give')
            : context.tr('settled');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(money(balance.abs()), style: style),
        Text(label, style: TextStyle(fontSize: big ? 13 : 11, color: style.color)),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.label, required this.value, required this.color, this.icon});
  final String label;
  final String value;
  final Color color;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              if (icon != null) ...[Icon(icon, size: 16, color: color), const SizedBox(width: 4)],
              Expanded(child: Text(label, style: const TextStyle(fontSize: 12), maxLines: 2)),
            ]),
            const SizedBox(height: 6),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
            ),
          ],
        ),
      ),
    );
  }
}

/// Month selector  < May 2025 >
class MonthSwitcher extends StatelessWidget {
  const MonthSwitcher({super.key, required this.month, required this.onChanged});
  final DateTime month;
  final ValueChanged<DateTime> onChanged;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final isCurrent = sameMonth(month, now);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: () => onChanged(DateTime(month.year, month.month - 1)),
        ),
        Text(fmtMonth(month), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        IconButton(
          icon: const Icon(Icons.chevron_right),
          onPressed: isCurrent ? null : () => onChanged(DateTime(month.year, month.month + 1)),
        ),
      ],
    );
  }
}

Future<DateTime?> pickDate(BuildContext context, DateTime initial) {
  return showDatePicker(
    context: context,
    initialDate: initial,
    firstDate: DateTime(2000),
    lastDate: DateTime(2100),
  );
}
