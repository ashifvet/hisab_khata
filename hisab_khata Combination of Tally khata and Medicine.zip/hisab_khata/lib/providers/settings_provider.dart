import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Dark mode + language (saved on the phone).
class SettingsProvider extends ChangeNotifier {
  bool dark = false;
  String lang = 'en'; // 'en' or 'bn'

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    dark = p.getBool('dark') ?? false;
    lang = p.getString('lang') ?? 'en';
  }

  Future<void> setDark(bool v) async {
    dark = v;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setBool('dark', v);
  }

  Future<void> setLang(String v) async {
    lang = v;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setString('lang', v);
  }
}
