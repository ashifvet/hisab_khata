import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/models.dart';
import '../services/db.dart';

/// Keeps the list of the user's businesses (max 5) and the selected one.
class BusinessProvider extends ChangeNotifier {
  List<Business> businesses = [];
  String? activeId;
  bool loaded = false;

  StreamSubscription? _sub;
  String? _uid;
  bool _creating = false;

  Business? get active {
    for (final b in businesses) {
      if (b.id == activeId) return b;
    }
    return null;
  }

  Future<void> start(String uid) async {
    if (_uid == uid) return;
    _uid = uid;
    final prefs = await SharedPreferences.getInstance();
    activeId = prefs.getString('active_business_$uid');
    await _sub?.cancel();
    _sub = Db.businesses.snapshots(includeMetadataChanges: true).listen((snap) {
      final list = snap.docs.map(Business.fromDoc).toList();
      list.sort((a, b) => a.createdAt.compareTo(b.createdAt));
      businesses = list;
      loaded = true;
      if (list.isEmpty && !snap.metadata.isFromCache && !_creating) {
        // first login: create the default business
        _creating = true;
        Db.saveBusiness('main', {'name': 'My Business', 'phone': '', 'address': ''});
      }
      if (list.isNotEmpty) _creating = false;
      if (activeId == null || !list.any((b) => b.id == activeId)) {
        activeId = list.isEmpty ? null : list.first.id;
      }
      notifyListeners();
    }, onError: (Object _) {
      loaded = true;
      notifyListeners();
    });
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
    _uid = null;
    businesses = [];
    activeId = null;
    loaded = false;
    _creating = false;
    notifyListeners();
  }

  Future<void> setActive(String id) async {
    activeId = id;
    notifyListeners();
    if (_uid != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('active_business_$_uid', id);
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
