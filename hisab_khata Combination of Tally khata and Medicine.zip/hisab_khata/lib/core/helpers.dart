import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'strings.dart';

const List<String> _months = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

/// 12345.5 -> 12,345.50   (no decimals when the number is whole)
String fmtNum(double v) {
  final a = v.abs();
  if (a < 0.005) return '0';
  final fixed = (a % 1 == 0) ? a.toStringAsFixed(0) : a.toStringAsFixed(2);
  final parts = fixed.split('.');
  final s = parts[0];
  final buf = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
    buf.write(s[i]);
  }
  final res = parts.length > 1 ? '$buf.${parts[1]}' : buf.toString();
  return v < 0 ? '-$res' : res;
}

String money(double v) => '৳${fmtNum(v)}';

/// Parses numbers typed with English or Bangla digits.
double? parseNum(String input) {
  const bn = '০১২৩৪৫৬৭৮৯';
  final t = input.trim().replaceAll(',', '');
  final sb = StringBuffer();
  for (final r in t.runes) {
    final ch = String.fromCharCode(r);
    final i = bn.indexOf(ch);
    sb.write(i >= 0 ? '$i' : ch);
  }
  return double.tryParse(sb.toString());
}

String fmtDate(DateTime d) => '${d.day.toString().padLeft(2, '0')} ${_months[d.month - 1]} ${d.year}';
String fmtMonth(DateTime d) => '${_months[d.month - 1]} ${d.year}';
DateTime monthStart(DateTime d) => DateTime(d.year, d.month);
bool sameMonth(DateTime a, DateTime b) => a.year == b.year && a.month == b.month;

int wordCount(String s) {
  final t = s.trim();
  if (t.isEmpty) return 0;
  return t.split(RegExp(r'\s+')).length;
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<bool> confirmDialog(BuildContext context, String title, String message) async {
  final res = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('ok'))),
      ],
    ),
  );
  return res ?? false;
}

/// Keeps digits and a leading plus sign.
String cleanPhone(String p) => p.replaceAll(RegExp(r'[^0-9+]'), '');

/// Bangladesh number -> international format without plus (for wa.me)
String waPhone(String p) {
  var d = p.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('880')) return d;
  if (d.startsWith('0')) return '88$d';
  return '880$d';
}

String smsUrl(List<String> phones, String body) =>
    'sms:${phones.map(cleanPhone).join(',')}?body=${Uri.encodeComponent(body)}';

String waUrl(String phone, String body) =>
    'https://wa.me/${waPhone(phone)}?text=${Uri.encodeComponent(body)}';

Future<void> openUrl(BuildContext context, String url) async {
  var ok = false;
  try {
    ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {
    ok = false;
  }
  if (!ok && context.mounted) toast(context, context.tr('err_cannot_open'));
}

Future<void> callPhone(BuildContext context, String phone) => openUrl(context, 'tel:${cleanPhone(phone)}');
