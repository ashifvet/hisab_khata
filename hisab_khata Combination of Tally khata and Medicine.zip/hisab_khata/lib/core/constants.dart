/// Common veterinary medicine companies of Bangladesh.
/// The user can import them with one tap from the Companies tab.
const List<String> kDefaultCompanies = [
  'Renata PLC (Animal Health)',
  'The ACME Laboratories Ltd (Veterinary Unit)',
  'ACI Limited / ACI Animal Health',
  'Square Pharmaceuticals PLC (Veterinary Division)',
  'Opsonin Pharma Limited (Agrovet)',
  'Eskayef Pharmaceuticals Ltd. (Animal Health)',
  'Incepta Pharmaceuticals Ltd (Animal Health)',
  'Popular Pharmaceuticals PLC (Agrovet)',
  'Navana Pharmaceuticals PLC (Veterinary)',
  'Aristopharma Ltd (Animal Health Division)',
  'Everest Agrogenics Ltd.',
  'Eon Animal Health Products Ltd.',
  'Kemiko Pharmaceuticals Ltd (Veterinary Division)',
  'Techno Drugs Ltd',
  'Vision Drugs Ltd.',
  'One Pharma Ltd. (Animal Health Division)',
  'Gentry Pharmaceuticals Ltd.',
  'Agrovet Pharma',
  'Super Power Pharmaceuticals Ltd.',
  'Advance Animal Science Co. Ltd.',
];

const int kMaxBusinesses = 5;

const String kDevName = 'Dr. MD. ASHIF IQBAL, DVM, MSc, BCS';
const String kDevTitle = 'Veterinary Surgeon, Maheshpur';
const String kDevPhone = '01711989236';
const String kDevHometown = 'Kushtia';

const List<String> kIncomeCategories = ['cat_sale', 'cat_service', 'cat_other_income'];
const List<String> kExpenseCategories = [
  'cat_purchase',
  'cat_rent',
  'cat_salary',
  'cat_transport',
  'cat_food',
  'cat_utility',
  'cat_medicine',
  'cat_other_expense',
];
