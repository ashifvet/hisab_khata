import 'package:flutter/widgets.dart';

/// Every text of the app in English [0] and Bangla [1].
/// To add a new text: add a line here and use  context.tr('your_key')  in the screen.
const Map<String, List<String>> _t = {
  // ---- general
  'app_name': ['Hisab Khata', 'হিসাব খাতা'],
  'tagline': ['Your business ledger & vet medicine guide', 'আপনার ব্যবসার হিসাব ও ভেট মেডিসিন গাইড'],
  'ok': ['OK', 'ঠিক আছে'],
  'cancel': ['Cancel', 'বাতিল'],
  'save': ['Save', 'সংরক্ষণ'],
  'saved': ['Saved', 'সংরক্ষিত হয়েছে'],
  'edit': ['Edit', 'এডিট'],
  'delete': ['Delete', 'মুছুন'],
  'delete_confirm': ['Do you really want to delete this?', 'আপনি কি সত্যিই এটি মুছে ফেলতে চান?'],
  'search': ['Search', 'খুঁজুন'],
  'required': ['Required', 'আবশ্যক'],
  'name': ['Name', 'নাম'],
  'phone': ['Phone', 'ফোন'],
  'email': ['Email', 'ইমেইল'],
  'address': ['Address', 'ঠিকানা'],
  'details': ['Details', 'বিবরণ'],
  'date': ['Date', 'তারিখ'],
  'amount': ['Amount', 'টাকার পরিমাণ'],
  'type': ['Type', 'ধরন'],
  'category': ['Category', 'ক্যাটাগরি'],
  'balance': ['Balance', 'ব্যালেন্স'],
  'call': ['Call', 'কল'],
  'message': ['Message', 'বার্তা'],
  'next': ['Next', 'পরবর্তী'],
  'stop': ['Stop', 'থামান'],
  'sent': ['Sent', 'পাঠানো হয়েছে'],
  'no_data': ['No data', 'কোনো তথ্য নেই'],
  'not_found': ['Not found', 'পাওয়া যায়নি'],
  'words': ['words', 'শব্দ'],
  'version': ['Version', 'ভার্সন'],

  // ---- navigation
  'nav_hisab': ['Hisab', 'হিসাব'],
  'companies': ['Companies', 'কোম্পানি'],
  'medicines': ['Medicines', 'ঔষধ'],
  'notes': ['Notes', 'নোট'],
  'add': ['Add', 'যোগ করুন'],
  'company': ['Company', 'কোম্পানি'],
  'medicine': ['Medicine', 'ঔষধ'],
  'note': ['Note', 'নোট'],

  // ---- auth
  'login': ['Login', 'লগইন'],
  'register': ['Create account', 'অ্যাকাউন্ট খুলুন'],
  'password': ['Password', 'পাসওয়ার্ড'],
  'forgot_password': ['Forgot password?', 'পাসওয়ার্ড ভুলে গেছেন?'],
  'have_account': ['I already have an account', 'আমার অ্যাকাউন্ট আছে'],
  'no_account': ['New here? Create account', 'নতুন? অ্যাকাউন্ট খুলুন'],
  'need_internet_first': [
    'Internet is needed only for the first login. After that the app works offline and syncs automatically.',
    'শুধু প্রথমবার লগইনের জন্য ইন্টারনেট লাগবে। এরপর অ্যাপ অফলাইনে চলবে এবং নিজে থেকেই সিঙ্ক হবে।'
  ],
  'enter_email_first': ['Type your email first', 'আগে আপনার ইমেইল লিখুন'],
  'reset_sent': ['Password reset link sent to your email', 'পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে'],
  'err_wrong_login': ['Wrong email or password', 'ইমেইল বা পাসওয়ার্ড ভুল'],
  'err_email_used': ['This email is already registered', 'এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট খোলা হয়েছে'],
  'err_weak_password': ['Password must be at least 6 characters', 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে'],
  'err_invalid_email': ['Enter a valid email', 'সঠিক ইমেইল দিন'],
  'err_network': ['No internet connection', 'ইন্টারনেট সংযোগ নেই'],
  'err_too_many': ['Too many attempts, try later', 'অনেকবার চেষ্টা করেছেন, পরে চেষ্টা করুন'],
  'err_generic': ['Something went wrong', 'কিছু একটা সমস্যা হয়েছে'],
  'err_old_password': ['Old password is wrong', 'পুরনো পাসওয়ার্ড ভুল'],
  'err_password_match': ['Passwords do not match', 'পাসওয়ার্ড মিলছে না'],
  'err_cannot_open': ['Could not open the app', 'অ্যাপটি খোলা যায়নি'],

  // ---- drawer
  'edit_profile': ['Edit Profile', 'প্রোফাইল এডিট'],
  'settings': ['Settings', 'সেটিংস'],
  'about_developer': ['About Developer', 'ডেভেলপার সম্পর্কে'],
  'logout': ['Logout', 'লগআউট'],
  'logout_confirm': ['Do you want to logout?', 'আপনি কি লগআউট করতে চান?'],
  'unsynced_title': ['Data not synced', 'ডাটা সিঙ্ক হয়নি'],
  'unsynced_msg': [
    'Some data is not uploaded yet (no internet). If you logout now it may be lost. Logout anyway?',
    'কিছু ডাটা এখনো আপলোড হয়নি (ইন্টারনেট নেই)। এখন লগআউট করলে তা হারিয়ে যেতে পারে। তবুও লগআউট করবেন?'
  ],
  'my_businesses': ['My Businesses', 'আমার ব্যবসা সমূহ'],
  'first_name': ['First name', 'প্রথম নাম'],
  'last_name': ['Last name', 'শেষ নাম'],
  'location': ['Location', 'ঠিকানা / এলাকা'],
  'designation': ['Designation / Work', 'পদবি / পেশা'],
  'dark_mode': ['Dark mode', 'ডার্ক মোড'],
  'enabled': ['Enabled', 'চালু'],
  'disabled': ['Disabled', 'বন্ধ'],
  'language': ['App language', 'অ্যাপের ভাষা'],
  'change_password': ['Change password', 'পাসওয়ার্ড পরিবর্তন'],
  'old_password': ['Old password', 'পুরনো পাসওয়ার্ড'],
  'new_password': ['New password', 'নতুন পাসওয়ার্ড'],
  'confirm_password': ['Confirm new password', 'নতুন পাসওয়ার্ড আবার লিখুন'],
  'password_changed': ['Password changed', 'পাসওয়ার্ড পরিবর্তন হয়েছে'],
  'hometown': ['Hometown', 'নিজ জেলা'],
  'version_name': ['Version name', 'ভার্সন নাম'],
  'about_app': [
    'Hisab Khata helps you keep business accounts and remember veterinary medicines.',
    'হিসাব খাতা অ্যাপ আপনাকে ব্যবসার হিসাব রাখতে এবং ভেটেরিনারি ঔষধ মনে রাখতে সাহায্য করে।'
  ],

  // ---- sync / update
  'sync_ok': ['All data is synced', 'সব ডাটা সিঙ্ক হয়েছে'],
  'sync_offline': ['Offline - data is saved on the phone and will sync when internet comes', 'অফলাইন - ডাটা ফোনে সেভ হচ্ছে, ইন্টারনেট এলে সিঙ্ক হবে'],
  'sync_pending': ['Syncing...', 'সিঙ্ক হচ্ছে...'],
  'update_available': ['New update available', 'নতুন আপডেট এসেছে'],
  'update_required': ['Update required', 'আপডেট আবশ্যক'],
  'update_force_msg': ['Please update the app to continue.', 'চালিয়ে যেতে অ্যাপটি আপডেট করুন।'],
  'update_now': ['Update now', 'এখনই আপডেট'],
  'later': ['Later', 'পরে'],
  'current_version': ['Your version', 'আপনার ভার্সন'],
  'new_version': ['New version', 'নতুন ভার্সন'],

  // ---- veterinary: company
  'company_name': ['Company name', 'কোম্পানির নাম'],
  'company_phone': ['Company / MPO phone', 'কোম্পানি / এমপিও ফোন'],
  'other_details': ['Other details', 'অন্যান্য তথ্য'],
  'save_company': ['Save company', 'কোম্পানি সংরক্ষণ'],
  'edit_company': ['Edit company', 'কোম্পানি এডিট'],
  'no_companies_yet': ['No company added yet', 'এখনো কোনো কোম্পানি যোগ করা হয়নি'],
  'import_companies': ['Import common companies', 'পরিচিত কোম্পানিগুলো যোগ করুন'],
  'import_companies_msg': [
    'Add the 20 common veterinary companies of Bangladesh to your list? (Existing ones are skipped)',
    'বাংলাদেশের ২০টি পরিচিত ভেটেরিনারি কোম্পানি আপনার তালিকায় যোগ করবেন? (আগে থেকে থাকলে বাদ যাবে)'
  ],
  'delete_company_confirm': [
    'Delete this company? Its medicines will stay in your medicine list.',
    'কোম্পানিটি মুছবেন? এর ঔষধগুলো আপনার ঔষধ তালিকায় থেকে যাবে।'
  ],
  'favourites': ['Favourites', 'ফেভারিট'],
  'all_medicines': ['All medicines', 'সব ঔষধ'],
  'no_medicines_company': ['No medicine here yet. Tap "Add medicine".', 'এখানে এখনো ঔষধ নেই। "ঔষধ যোগ করুন" চাপুন।'],

  // ---- veterinary: medicine
  'medicine_name': ['Medicine name', 'ঔষধের নাম'],
  'select_company': ['Select company', 'কোম্পানি বাছাই করুন'],
  'no_company': ['No company', 'কোনো কোম্পানি নয়'],
  'favourite_medicine': ['Favourite medicine', 'ফেভারিট ঔষধ'],
  'favourite_hint': ['Favourite medicines are shown first inside the company', 'ফেভারিট ঔষধ কোম্পানির ভেতরে প্রথমে দেখানো হয়'],
  'components': ['Components (generic)', 'উপাদান (জেনেরিক)'],
  'when_to_use': ['When to use', 'কখন ব্যবহার করবেন'],
  'dose': ['Dose', 'মাত্রা'],
  'pregnancy': ['Pregnancy indication', 'গর্ভাবস্থায় ব্যবহার'],
  'preg_safe': ['Safe in pregnancy', 'গর্ভাবস্থায় নিরাপদ'],
  'preg_caution': ['Use with caution', 'সতর্কতার সাথে ব্যবহার'],
  'preg_avoid': ['Avoid in pregnancy', 'গর্ভাবস্থায় নিষিদ্ধ'],
  'save_medicine': ['Save medicine', 'ঔষধ সংরক্ষণ'],
  'add_medicine': ['Add medicine', 'ঔষধ যোগ করুন'],
  'edit_medicine': ['Edit medicine', 'ঔষধ এডিট'],
  'no_medicines': ['No medicine found', 'কোনো ঔষধ পাওয়া যায়নি'],

  // ---- notes
  'note_title': ['Title of the note', 'নোটের শিরোনাম'],
  'note_body': ['Body (up to 1000 words)', 'বিস্তারিত (সর্বোচ্চ ১০০০ শব্দ)'],
  'note_too_long': ['Note is longer than 1000 words', 'নোট ১০০০ শব্দের বেশি হয়ে গেছে'],
  'save_note': ['Save note', 'নোট সংরক্ষণ'],
  'add_note': ['Add note', 'নোট যোগ করুন'],
  'edit_note': ['Edit note', 'নোট এডিট'],
  'no_notes': ['No notes yet. Tap + to write one.', 'এখনো কোনো নোট নেই। লিখতে + চাপুন।'],
  'business_notes': ['Business Notes', 'ব্যবসার নোট'],

  // ---- hisab: general
  'customers': ['Customers', 'কাস্টমার'],
  'suppliers': ['Suppliers', 'সাপ্লায়ার'],
  'customer': ['Customer', 'কাস্টমার'],
  'supplier': ['Supplier', 'সাপ্লায়ার'],
  'cash_book': ['Cash Book', 'ক্যাশ বুক'],
  'stock': ['Stock', 'স্টক'],
  'group_tagada': ['Group Tagada', 'গ্রুপ তাগাদা'],
  'reports': ['Reports', 'রিপোর্ট'],
  'tap_to_switch': ['Tap to switch / add business', 'ব্যবসা বদলাতে / যোগ করতে চাপুন'],
  'you_will_get': ['You will get', 'আপনি পাবেন'],
  'you_will_give': ['You will give', 'আপনি দেবেন'],
  'will_get': ['You will get', 'পাবেন'],
  'will_give': ['You will give', 'দেবেন'],
  'settled': ['Settled', 'পরিষ্কার'],
  'you_gave': ['You gave', 'আমি দিলাম'],
  'you_got': ['You got', 'আমি পেলাম'],
  'total_gave': ['Total You gave', 'মোট দিয়েছি'],
  'total_got': ['Total You got', 'মোট পেয়েছি'],
  'income': ['Income', 'আয়'],
  'expense': ['Expense', 'খরচ'],
  'savings': ['Savings', 'সঞ্চয়'],
  'this_month': ['This month', 'এই মাস'],
  'enter_amount': ['Enter a valid amount', 'সঠিক টাকার পরিমাণ দিন'],

  // ---- hisab: businesses
  'business_name': ['Business name', 'ব্যবসার নাম'],
  'add_business': ['Add business', 'ব্যবসা যোগ করুন'],
  'edit_business': ['Edit business', 'ব্যবসা এডিট'],
  'max_businesses': ['You can add up to 5 businesses', 'আপনি সর্বোচ্চ ৫টি ব্যবসা যোগ করতে পারবেন'],
  'cannot_delete_last': ['You cannot delete your only business', 'আপনার একমাত্র ব্যবসাটি মুছতে পারবেন না'],
  'delete_business_confirm': [
    'Delete this business and ALL its data (customers, transactions, stock, notes)?',
    'এই ব্যবসা এবং এর সব তথ্য (কাস্টমার, লেনদেন, স্টক, নোট) মুছে ফেলবেন?'
  ],
  'no_business': ['No business yet', 'এখনো কোনো ব্যবসা নেই'],

  // ---- hisab: parties
  'add_customer': ['Add customer', 'কাস্টমার যোগ করুন'],
  'add_supplier': ['Add supplier', 'সাপ্লায়ার যোগ করুন'],
  'no_customers': ['No customer yet', 'এখনো কোনো কাস্টমার নেই'],
  'no_suppliers': ['No supplier yet', 'এখনো কোনো সাপ্লায়ার নেই'],
  'no_transactions': ['No transaction yet', 'এখনো কোনো লেনদেন নেই'],
  'delete_party_confirm': [
    'Delete this person and all of his transactions?',
    'এই ব্যক্তি এবং তার সব লেনদেন মুছে ফেলবেন?'
  ],
  'remind': ['Remind', 'তাগাদা'],
  'statement': ['Statement', 'স্টেটমেন্ট'],
  'remind_msg': [
    'Dear {name}, your outstanding balance with {business} is {amount}. Please pay at your earliest convenience. Thank you.',
    'প্রিয় {name}, {business} এ আপনার বকেয়া {amount}। অনুগ্রহ করে দ্রুত পরিশোধ করুন। ধন্যবাদ।'
  ],
  'send_sms': ['Send SMS', 'এসএমএস পাঠান'],
  'send_whatsapp': ['Send on WhatsApp', 'হোয়াটসঅ্যাপে পাঠান'],
  'no_phone': ['No phone number', 'ফোন নম্বর নেই'],

  // ---- hisab: cash book
  'add_income': ['Add income', 'আয় যোগ'],
  'add_expense': ['Add expense', 'খরচ যোগ'],
  'no_entries': ['No entries this month', 'এই মাসে কোনো এন্ট্রি নেই'],
  'cat_sale': ['Sale', 'বিক্রি'],
  'cat_service': ['Service / Treatment fee', 'সেবা / চিকিৎসা ফি'],
  'cat_other_income': ['Other income', 'অন্যান্য আয়'],
  'cat_purchase': ['Purchase', 'ক্রয়'],
  'cat_rent': ['Rent', 'ভাড়া'],
  'cat_salary': ['Salary', 'বেতন'],
  'cat_transport': ['Transport', 'যাতায়াত'],
  'cat_food': ['Food', 'খাবার'],
  'cat_utility': ['Bills', 'বিল'],
  'cat_medicine': ['Medicine', 'ঔষধ'],
  'cat_other_expense': ['Other expense', 'অন্যান্য খরচ'],

  // ---- hisab: stock
  'add_product': ['Add product', 'পণ্য যোগ করুন'],
  'product_name': ['Product name', 'পণ্যের নাম'],
  'unit': ['Unit', 'একক'],
  'quantity': ['Quantity', 'পরিমাণ'],
  'buy_price': ['Buying price', 'ক্রয়মূল্য'],
  'sell_price': ['Selling price', 'বিক্রয়মূল্য'],
  'stock_value': ['Stock value', 'স্টকের মূল্য'],
  'sale_value': ['Sale value', 'বিক্রয় মূল্য'],
  'items': ['Items', 'আইটেম'],
  'in_stock': ['In stock', 'স্টকে আছে'],
  'stock_in': ['Stock in', 'স্টক ইন'],
  'stock_out': ['Stock out', 'স্টক আউট'],
  'not_enough_stock': ['Not enough stock', 'যথেষ্ট স্টক নেই'],
  'no_products': ['No product yet', 'এখনো কোনো পণ্য নেই'],

  // ---- hisab: tagada
  'one_by_one': ['One by one', 'একে একে'],
  'group_sms': ['Group SMS', 'গ্রুপ এসএমএস'],
  'tagada_hint': [
    'You can use {name}, {amount} and {business} in the message.',
    'বার্তায় {name}, {amount} এবং {business} ব্যবহার করতে পারেন।'
  ],
  'tagada_group_msg': [
    'Dear customer, please clear your outstanding dues of {business}. Thank you.',
    'প্রিয় গ্রাহক, {business} এর বকেয়া অনুগ্রহ করে পরিশোধ করুন। ধন্যবাদ।'
  ],
  'select_all': ['Select all', 'সবাইকে বাছাই করুন'],
  'send_reminders': ['Send reminders', 'তাগাদা পাঠান'],
  'send_next': ['Send next', 'পরেরজনকে পাঠান'],
  'tagada_done': ['All reminders sent', 'সবাইকে তাগাদা পাঠানো হয়েছে'],
  'no_dues': ['Nobody owes you money', 'কেউ আপনার কাছে বকেয়া নেই'],

  // ---- reports
  'share_pdf': ['Share / Save PDF', 'PDF শেয়ার / সেভ'],
  'print': ['Print', 'প্রিন্ট'],
  'customer_report': ['Customer report', 'কাস্টমার রিপোর্ট'],
  'customer_report_desc': ['Who will pay you and how much', 'কে কত টাকা দেবে'],
  'supplier_report': ['Supplier report', 'সাপ্লায়ার রিপোর্ট'],
  'supplier_report_desc': ['How much you have to pay suppliers', 'সাপ্লায়ারকে কত টাকা দিতে হবে'],
  'cost_savings': ['Cost & Savings', 'খরচ ও সঞ্চয়'],
  'cost_savings_desc': ['Income, expense and savings', 'আয়, খরচ ও সঞ্চয়'],
  'monthly_report': ['Monthly report', 'মাসিক রিপোর্ট'],
  'monthly_report_desc': ['Day by day summary of a month', 'মাসের দিনভিত্তিক সারাংশ'],
  'stock_report': ['Stock report', 'স্টক রিপোর্ট'],
  'stock_report_desc': ['Quantity and total value of stock', 'স্টকের পরিমাণ ও মোট মূল্য'],
  'reports_hint': [
    'Every report can be shared as PDF on WhatsApp, imo, Messenger or printed.',
    'প্রতিটি রিপোর্ট PDF আকারে হোয়াটসঅ্যাপ, ইমো, মেসেঞ্জারে শেয়ার বা প্রিন্ট করা যায়।'
  ],
  'last_month': ['Last month', 'গত মাস'],
  'this_year': ['This year', 'এই বছর'],
  'all_time': ['All time', 'সব সময়'],
  'savings_rate': ['Savings rate', 'সঞ্চয়ের হার'],
  'expense_breakdown': ['Where the money went (expense)', 'খরচের খাত'],
  'income_breakdown': ['Where the money came from (income)', 'আয়ের খাত'],
  'daily_summary': ['Daily summary', 'দৈনিক সারাংশ'],
};

String translate(String lang, String key) {
  final v = _t[key];
  if (v == null) return key;
  return lang == 'bn' ? v[1] : v[0];
}

/// Placed above the whole app: when the language changes every screen rebuilds.
class LangScope extends InheritedWidget {
  const LangScope({super.key, required this.lang, required super.child});
  final String lang;

  static String of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<LangScope>()?.lang ?? 'en';

  @override
  bool updateShouldNotify(LangScope oldWidget) => oldWidget.lang != lang;
}

extension TrX on BuildContext {
  String tr(String key) => translate(LangScope.of(this), key);
}
