import 'package:cloud_firestore/cloud_firestore.dart';

typedef Doc = DocumentSnapshot<Map<String, dynamic>>;

double _num(Object? v) => v is num ? v.toDouble() : 0.0;
String _str(Object? v) => v == null ? '' : v.toString();
DateTime _date(Object? v) =>
    v is Timestamp ? v.toDate() : DateTime.fromMillisecondsSinceEpoch(0);

Map<String, dynamic> _data(Doc d) => d.data() ?? <String, dynamic>{};

class Company {
  Company({required this.id, required this.name, this.phone = '', this.details = ''});
  final String id;
  final String name;
  final String phone;
  final String details;

  factory Company.fromDoc(Doc d) {
    final m = _data(d);
    return Company(
      id: d.id,
      name: _str(m['name']),
      phone: _str(m['phone']),
      details: _str(m['details']),
    );
  }
}

class Medicine {
  Medicine({
    required this.id,
    required this.name,
    this.companyId = '',
    this.companyName = '',
    this.components = '',
    this.whenToUse = '',
    this.dose = '',
    this.pregnancy = '',
    this.details = '',
    this.favourite = true,
  });
  final String id;
  final String name;
  final String companyId;
  final String companyName;
  final String components;
  final String whenToUse;
  final String dose;
  final String pregnancy;
  final String details;
  final bool favourite;

  factory Medicine.fromDoc(Doc d) {
    final m = _data(d);
    return Medicine(
      id: d.id,
      name: _str(m['name']),
      companyId: _str(m['companyId']),
      companyName: _str(m['companyName']),
      components: _str(m['components']),
      whenToUse: _str(m['whenToUse']),
      dose: _str(m['dose']),
      pregnancy: _str(m['pregnancy']),
      details: _str(m['details']),
      favourite: m['favourite'] is bool ? m['favourite'] as bool : true,
    );
  }
}

class NoteItem {
  NoteItem({required this.id, required this.title, required this.body, required this.createdAt});
  final String id;
  final String title;
  final String body;
  final DateTime createdAt;

  factory NoteItem.fromDoc(Doc d) {
    final m = _data(d);
    return NoteItem(
      id: d.id,
      title: _str(m['title']),
      body: _str(m['body']),
      createdAt: _date(m['createdAt']),
    );
  }
}

class Business {
  Business({required this.id, required this.name, this.phone = '', this.address = '', required this.createdAt});
  final String id;
  final String name;
  final String phone;
  final String address;
  final DateTime createdAt;

  factory Business.fromDoc(Doc d) {
    final m = _data(d);
    return Business(
      id: d.id,
      name: _str(m['name']),
      phone: _str(m['phone']),
      address: _str(m['address']),
      createdAt: _date(m['createdAt']),
    );
  }
}

/// type = 'customer' or 'supplier'.
/// balance = (total You Gave) - (total You Got)
/// balance > 0  => you will GET money, balance < 0 => you will GIVE money.
class Party {
  Party({
    required this.id,
    required this.name,
    required this.type,
    this.phone = '',
    this.address = '',
    this.balance = 0,
  });
  final String id;
  final String name;
  final String type;
  final String phone;
  final String address;
  final double balance;

  factory Party.fromDoc(Doc d) {
    final m = _data(d);
    return Party(
      id: d.id,
      name: _str(m['name']),
      type: _str(m['type']).isEmpty ? 'customer' : _str(m['type']),
      phone: _str(m['phone']),
      address: _str(m['address']),
      balance: _num(m['balance']),
    );
  }
}

/// type = 'gave' (you gave goods / money) or 'got' (you received money / goods)
class PartyTxn {
  PartyTxn({
    required this.id,
    required this.partyId,
    required this.type,
    required this.amount,
    required this.note,
    required this.date,
  });
  final String id;
  final String partyId;
  final String type;
  final double amount;
  final String note;
  final DateTime date;

  bool get isGave => type == 'gave';

  factory PartyTxn.fromDoc(Doc d) {
    final m = _data(d);
    return PartyTxn(
      id: d.id,
      partyId: _str(m['partyId']),
      type: _str(m['type']),
      amount: _num(m['amount']),
      note: _str(m['note']),
      date: _date(m['date']),
    );
  }
}

class Product {
  Product({
    required this.id,
    required this.name,
    this.unit = 'pcs',
    this.qty = 0,
    this.buyPrice = 0,
    this.sellPrice = 0,
  });
  final String id;
  final String name;
  final String unit;
  final double qty;
  final double buyPrice;
  final double sellPrice;

  double get stockValue => qty * buyPrice;
  double get saleValue => qty * sellPrice;

  factory Product.fromDoc(Doc d) {
    final m = _data(d);
    return Product(
      id: d.id,
      name: _str(m['name']),
      unit: _str(m['unit']).isEmpty ? 'pcs' : _str(m['unit']),
      qty: _num(m['qty']),
      buyPrice: _num(m['buyPrice']),
      sellPrice: _num(m['sellPrice']),
    );
  }
}

/// Cash book entry. type = 'income' or 'expense'
class CashEntry {
  CashEntry({
    required this.id,
    required this.type,
    required this.amount,
    required this.category,
    required this.note,
    required this.date,
  });
  final String id;
  final String type;
  final double amount;
  final String category;
  final String note;
  final DateTime date;

  bool get isIncome => type == 'income';

  factory CashEntry.fromDoc(Doc d) {
    final m = _data(d);
    return CashEntry(
      id: d.id,
      type: _str(m['type']),
      amount: _num(m['amount']),
      category: _str(m['category']),
      note: _str(m['note']),
      date: _date(m['date']),
    );
  }
}
