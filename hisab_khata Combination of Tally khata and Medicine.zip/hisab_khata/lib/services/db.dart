import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/models.dart';

typedef Col = CollectionReference<Map<String, dynamic>>;
typedef DocRef = DocumentReference<Map<String, dynamic>>;

/// All database paths and write operations live here.
///
/// IMPORTANT (offline mode): Firestore keeps a local copy of the data. When the
/// phone is offline a write is saved on the phone and is uploaded automatically
/// when the internet comes back. Because of that we NEVER `await` a write in the
/// UI (the future would only finish after the server confirms) - we "fire" it.
class Db {
  static FirebaseFirestore get fs => FirebaseFirestore.instance;
  static String get uid => FirebaseAuth.instance.currentUser!.uid;

  static DocRef get userDoc => fs.collection('users').doc(uid);
  static Col col(String name) => userDoc.collection(name);
  static Col get businesses => userDoc.collection('businesses');
  static DocRef bizDoc(String bid) => businesses.doc(bid);
  static Col bcol(String bid, String name) => bizDoc(bid).collection(name);

  static void fire(Future<void> f) {
    f.catchError((Object _) {});
  }

  /// Creates (id == null) or updates (merge) a document. Returns the document id.
  static String save(Col c, String? id, Map<String, dynamic> data) {
    final ref = id == null ? c.doc() : c.doc(id);
    if (id == null) data['createdAt'] = Timestamp.now();
    fire(ref.set(data, SetOptions(merge: true)));
    return ref.id;
  }

  static void remove(DocRef ref) => fire(ref.delete());

  // ---------------------------------------------------------------- veterinary

  static void importCompanies(List<String> names, Set<String> existingLower) {
    final batch = fs.batch();
    var n = 0;
    for (final name in names) {
      if (existingLower.contains(name.toLowerCase())) continue;
      batch.set(col('companies').doc(), {
        'name': name,
        'phone': '',
        'details': '',
        'createdAt': Timestamp.now(),
      });
      n++;
    }
    if (n > 0) fire(batch.commit());
  }

  static Future<void> renameCompanyOnMedicines(String companyId, String newName) async {
    try {
      final snap = await col('medicines').where('companyId', isEqualTo: companyId).get();
      if (snap.docs.isEmpty) return;
      final batch = fs.batch();
      for (final d in snap.docs) {
        batch.update(d.reference, {'companyName': newName});
      }
      fire(batch.commit());
    } catch (_) {}
  }

  static Future<void> deleteCompany(String companyId) async {
    // the medicines are kept, they just lose their company
    remove(col('companies').doc(companyId));
    try {
      final snap = await col('medicines').where('companyId', isEqualTo: companyId).get();
      if (snap.docs.isEmpty) return;
      final batch = fs.batch();
      for (final d in snap.docs) {
        batch.update(d.reference, {'companyId': '', 'companyName': ''});
      }
      fire(batch.commit());
    } catch (_) {}
  }

  // ------------------------------------------------------------------- hisab

  static String saveBusiness(String? id, Map<String, dynamic> data) => save(businesses, id, data);

  static Future<void> deleteBusiness(String bid) async {
    for (final c in ['parties', 'transactions', 'products', 'entries', 'notes']) {
      await _deleteAll(bcol(bid, c));
    }
    remove(bizDoc(bid));
  }

  static Future<void> _deleteAll(Col c) async {
    try {
      final snap = await c.get();
      for (var i = 0; i < snap.docs.length; i += 400) {
        final batch = fs.batch();
        final end = (i + 400 < snap.docs.length) ? i + 400 : snap.docs.length;
        for (final d in snap.docs.sublist(i, end)) {
          batch.delete(d.reference);
        }
        fire(batch.commit());
      }
    } catch (_) {}
  }

  static void addPartyTxn(
    String bid, {
    required String partyId,
    required String type,
    required double amount,
    required String note,
    required DateTime date,
  }) {
    final batch = fs.batch();
    batch.set(bcol(bid, 'transactions').doc(), {
      'partyId': partyId,
      'type': type,
      'amount': amount,
      'note': note,
      'date': Timestamp.fromDate(date),
      'createdAt': Timestamp.now(),
    });
    batch.update(bcol(bid, 'parties').doc(partyId), {
      'balance': FieldValue.increment(type == 'gave' ? amount : -amount),
    });
    fire(batch.commit());
  }

  static void deletePartyTxn(String bid, PartyTxn t) {
    final batch = fs.batch();
    batch.delete(bcol(bid, 'transactions').doc(t.id));
    batch.update(bcol(bid, 'parties').doc(t.partyId), {
      'balance': FieldValue.increment(t.isGave ? -t.amount : t.amount),
    });
    fire(batch.commit());
  }

  static Future<void> deleteParty(String bid, String partyId) async {
    remove(bcol(bid, 'parties').doc(partyId));
    try {
      final snap = await bcol(bid, 'transactions').where('partyId', isEqualTo: partyId).get();
      for (var i = 0; i < snap.docs.length; i += 400) {
        final batch = fs.batch();
        final end = (i + 400 < snap.docs.length) ? i + 400 : snap.docs.length;
        for (final d in snap.docs.sublist(i, end)) {
          batch.delete(d.reference);
        }
        fire(batch.commit());
      }
    } catch (_) {}
  }

  static void adjustStock(String bid, String productId, double delta) {
    fire(bcol(bid, 'products').doc(productId).update({'qty': FieldValue.increment(delta)}));
  }
}
