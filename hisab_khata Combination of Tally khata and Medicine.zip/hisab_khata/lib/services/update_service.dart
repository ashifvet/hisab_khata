import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../core/helpers.dart';
import '../core/strings.dart';

/// Reads  app_config/android  (or  app_config/ios)  from Firestore:
///   latestVersion : "1.0.2"   -> newest version (optional update dialog)
///   minVersion    : "1.0.1"   -> older apps MUST update (force update, cannot be closed)
///   updateUrl     : "https://..."  (Play Store / download link)
///   message       : "What's new ..." (optional)
///   forceUpdate   : true      -> (optional) force everybody who is not on latestVersion
class UpdateService {
  static bool _shown = false;

  static int compare(String a, String b) {
    List<int> parse(String s) =>
        s.split('+').first.split('.').map((e) => int.tryParse(e.trim()) ?? 0).toList();
    final x = parse(a);
    final y = parse(b);
    for (var i = 0; i < 3; i++) {
      final xi = i < x.length ? x[i] : 0;
      final yi = i < y.length ? y[i] : 0;
      if (xi != yi) return xi.compareTo(yi);
    }
    return 0;
  }

  static Future<void> check(BuildContext context) async {
    if (_shown) return;
    try {
      final info = await PackageInfo.fromPlatform();
      final platform = defaultTargetPlatform == TargetPlatform.iOS ? 'ios' : 'android';
      final snap = await FirebaseFirestore.instance
          .collection('app_config')
          .doc(platform)
          .get()
          .timeout(const Duration(seconds: 8));
      final d = snap.data();
      if (d == null) return;

      final latest = (d['latestVersion'] ?? '').toString();
      final minV = (d['minVersion'] ?? '').toString();
      final url = (d['updateUrl'] ?? '').toString();
      final msg = (d['message'] ?? '').toString();
      final forceAll = d['forceUpdate'] == true;
      final cur = info.version;

      final mustUpdate = (minV.isNotEmpty && compare(cur, minV) < 0) ||
          (forceAll && latest.isNotEmpty && compare(cur, latest) < 0);
      final canUpdate = latest.isNotEmpty && compare(cur, latest) < 0;
      if (!mustUpdate && !canUpdate) return;
      if (!context.mounted) return;
      _shown = true;

      await showDialog<void>(
        context: context,
        barrierDismissible: !mustUpdate,
        builder: (ctx) => PopScope(
          canPop: !mustUpdate,
          child: AlertDialog(
            icon: const Icon(Icons.system_update, size: 40),
            title: Text(mustUpdate ? ctx.tr('update_required') : ctx.tr('update_available')),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${ctx.tr('current_version')}: $cur'),
                if (latest.isNotEmpty) Text('${ctx.tr('new_version')}: $latest'),
                if (msg.isNotEmpty) ...[const SizedBox(height: 10), Text(msg)],
                if (mustUpdate) ...[
                  const SizedBox(height: 10),
                  Text(ctx.tr('update_force_msg'), style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ],
            ),
            actions: [
              if (!mustUpdate)
                TextButton(onPressed: () => Navigator.pop(ctx), child: Text(ctx.tr('later'))),
              FilledButton(
                onPressed: () {
                  if (url.isNotEmpty) openUrl(ctx, url);
                },
                child: Text(ctx.tr('update_now')),
              ),
            ],
          ),
        ),
      );
    } catch (_) {
      // offline or no config document yet -> just continue
    }
  }
}
