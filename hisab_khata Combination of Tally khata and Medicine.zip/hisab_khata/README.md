# Hisab Khata - Step by step guide

Hisab Khata = **Tallykhata-style business ledger** + **Veterinary medicine guide** (companies, medicines, notes), one Flutter app, data in Firebase, works offline.

## What you get

- Login / Register / Forgot password (Firebase Auth)
- 5 bottom tabs: **Hisab**, **Companies**, **Medicines**, **Notes**, **Add** (Add has 3 tabs: Company, Medicine, Note)
- Companies: tap a company to see its favourite medicines, tap a medicine to see every detail
- Medicines: A-Z list with search and letter headers
- Notes: title + body (up to 1000 words, live word counter)
- App drawer: Edit Profile, My Businesses, Settings (dark mode, change password, language Bangla/English), About Developer (with version), Logout at the bottom
- Hisab (Tallykhata style): unlimited customers, suppliers and transactions ("You gave" / "You got"), automatic balances
- Multi-business: up to 5 separate businesses or personal accounts
- Stock and inventory: quantity, stock in / out, total stock value in real time
- Cash book: daily income and expense, month by month
- Group Tagada: send reminders to many customers (one by one with name and amount, or one group SMS)
- Business notes (separate for every business)
- Reports (all can be shared as PDF on WhatsApp, imo, Messenger or printed): customer report, supplier report, cost and savings, monthly report, stock report, customer / supplier statement
- Offline first: works without internet, syncs to Firebase automatically when internet comes back
- Version control from Firebase: update notification and **force update**

## Folder map (what goes where)

```
hisab_khata/                      <- the project folder created by "flutter create"
  pubspec.yaml                    <- REPLACE
  assets/fonts/*.ttf              <- COPY (PDF fonts, English + Bangla)
  android/app/build.gradle.kts    <- REPLACE
  android/app/src/main/AndroidManifest.xml   <- REPLACE
  lib/                            <- DELETE the old lib folder, COPY the new one
    main.dart
    firebase_options.dart         <- placeholder, "flutterfire configure" overwrites it
    core/ models/ providers/ services/ widgets/ screens/
  test/app_test.dart              <- optional (run with: flutter test)
  firebase/firestore.rules        <- paste into Firebase console (Step 4)
```

---

## Step 1 - Install the tools (one time only)

1. Install **Flutter SDK** (latest stable, the code was checked with Flutter 3.50.1 / Dart 3.14): https://docs.flutter.dev/get-started/install (choose your computer: Windows / macOS / Linux, then Android). If you already have Flutter run `flutter upgrade`.
2. Install **Android Studio** (it installs the Android SDK). Open it once and accept all licences.
3. Install **VS Code** (optional, but easy) and its "Flutter" extension.
4. Install **Node.js** (needed for the Firebase tool): https://nodejs.org
5. Open a terminal and run:

```
flutter doctor
flutter doctor --android-licenses
```

Everything should have a green tick (Chrome / Visual Studio are only for web / Windows apps).

## Step 2 - Create the project

Use exactly this command (the package name `com.ashif.hisab_khata` must match the files in this guide):

```
flutter create --org com.ashif --project-name hisab_khata hisab_khata
cd hisab_khata
```

## Step 3 - Replace the files

1. **Delete** `lib/main.dart` and `test/widget_test.dart`.
2. **Delete the whole old `lib` folder** and copy the new `lib` folder from this package.
3. Copy the new `assets` folder (it has the 4 font files for PDF reports) into the project root.
4. **Replace** `pubspec.yaml` with the new one.
5. **Replace** `android/app/build.gradle.kts` with the new one. (It is written for the current stable Flutter, 3.50. If you prefer to keep your own file, the only change that is really needed is `minSdk = flutter.minSdkVersion` -> `minSdk = 24`.)
6. **Replace** `android/app/src/main/AndroidManifest.xml` with the new one.
7. (optional) copy the `test` folder.

Then run:

```
flutter pub get
```

If it says your Dart / Flutter version is too old, run `flutter upgrade` and try again.

## Step 4 - Create the Firebase project

1. Go to https://console.firebase.google.com and click **Add project** (name: Hisab Khata). Google Analytics is not needed.
2. **Authentication** -> Get started -> **Sign-in method** -> enable **Email/Password**.
3. **Firestore Database** -> Create database -> choose a location near you (for Bangladesh `asia-south1 (Mumbai)` or `asia-southeast1 (Singapore)`) -> start in **production mode**.
4. Firestore -> **Rules** tab -> delete everything -> paste the content of `firebase/firestore.rules` -> **Publish**.

These rules mean: every user can read and write only his own data, and everybody can read (but nobody can write) the `app_config` update information.

## Step 5 - Install the Firebase tools (one time only)

```
npm install -g firebase-tools
firebase login
dart pub global activate flutterfire_cli
```

If the terminal says `flutterfire` is not found, add the Dart global bin folder to your PATH (Windows: `%LOCALAPPDATA%\Pub\Cache\bin`, macOS / Linux: `$HOME/.pub-cache/bin`) and open a new terminal.

## Step 6 - Connect the app with Firebase

Inside the project folder run:

```
flutterfire configure
```

- Select your Firebase project.
- Select the platforms you want (Android is enough to start; you can run it again later for iOS / web).
- It creates `lib/firebase_options.dart` (replacing the placeholder), `android/app/google-services.json` and adds the `google-services` plugin to the Gradle files automatically.

Check (only if the build fails with a Firebase / Google services error):

- `android/settings.gradle.kts` -> inside `plugins { ... }` there must be a line like  
  `id("com.google.gms.google-services") version "4.4.2" apply false`
- `android/app/build.gradle.kts` -> inside `plugins { ... }` there must be  
  `id("com.google.gms.google-services")`

## Step 7 - Run the app

Connect an Android phone (USB debugging on) or start an emulator, then:

```
flutter run
```

1. Tap **Create account**, fill the form, register.
2. The app opens with a default business called "My Business".
3. Go to **Companies** tab -> menu (three dots) -> **Import common companies** to add the 20 Bangladeshi veterinary companies in one tap.

## Step 8 - How offline mode works

- Firestore keeps a copy of all your data on the phone. You can add / edit / delete everything without internet.
- When internet is back the app uploads the changes automatically. The little cloud icon at the top right shows the state (cloud with a line = offline, cloud with arrow = syncing, tick = synced).
- The very first login / registration needs internet. After that you stay logged in even when offline.
- Before **Logout** the app waits a few seconds to upload pending data and warns you if something is not synced yet.

## Step 9 - Update notification and force update

Create this in the Firebase console: Firestore -> **Start collection** -> Collection ID `app_config` -> Document ID `android` (use `ios` for iPhone) -> add fields:

| Field | Type | Example | Meaning |
|---|---|---|---|
| `latestVersion` | string | `1.0.2` | newest version. Older apps see an "Update available" dialog (can press Later) |
| `minVersion` | string | `1.0.1` | apps older than this **must update** (dialog cannot be closed) |
| `updateUrl` | string | `https://play.google.com/store/apps/details?id=com.ashif.hisab_khata` | opened when the user presses "Update now" (Play Store link or your own APK download link) |
| `message` | string | `Bug fixes and new reports` | optional text shown in the dialog |
| `forceUpdate` | boolean | `false` | optional: `true` = everybody who is not on `latestVersion` must update |

How to publish a new version:

1. In `pubspec.yaml` change `version: 1.0.0+1` to `version: 1.0.1+2` (name+build number, the build number must always grow).
2. Build the APK: `flutter build apk --release` (file: `build/app/outputs/flutter-apk/app-release.apk`).
3. Upload it to Play Store (or your own link).
4. Change `latestVersion` (and `minVersion` if you want to force) in the `app_config/android` document. Users get the dialog next time they open the app (with internet).

## Step 10 - Build for release / other platforms

- Android APK: `flutter build apk --release`   - Play Store bundle: `flutter build appbundle --release`
- Before publishing to Play Store create your own signing key: https://docs.flutter.dev/deployment/android#sign-the-app
- Web: run `flutterfire configure` again and select Web, then `flutter build web`.
- iPhone (needs a Mac): `flutterfire configure` with iOS, then open `ios/Runner/Info.plist` and add inside the main `<dict>`:

```
<key>LSApplicationQueriesSchemes</key>
<array>
  <string>sms</string>
  <string>tel</string>
  <string>https</string>
  <string>whatsapp</string>
</array>
```

## How the data is saved in Firebase

```
users/{uid}                         profile (first name, last name, email, phone, location ...)
users/{uid}/companies/{id}          veterinary companies
users/{uid}/medicines/{id}          medicines (companyId, favourite, dose, pregnancy ...)
users/{uid}/notes/{id}              medicine / doctor notes
users/{uid}/businesses/{id}         up to 5 businesses
   .../parties/{id}                 customers and suppliers (with running balance)
   .../transactions/{id}            "You gave" / "You got" entries
   .../entries/{id}                 cash book income / expense
   .../products/{id}                stock items
   .../notes/{id}                   business notes
app_config/android                  version information (you edit it)
```

## How balances work (same idea as Tallykhata)

- **You gave** = you gave goods / money to the person -> his balance goes up (you will get).
- **You got** = you received money / goods -> his balance goes down.
- Positive balance = **You will get**, negative balance = **You will give**. It is the same for customers and suppliers.

## Group Tagada and "free messages" - please read

The app sends messages **through your own phone**: normal SMS from your SIM (your SIM package decides the cost) and WhatsApp. This way the app has no per-message cost and no monthly limit.

- **One by one**: choose customers, write the message (`{name}`, `{amount}`, `{business}` are replaced automatically), press *Send reminders*. The SMS / WhatsApp app opens with the text ready; press send there, come back and press *Send next*.
- **Group SMS**: one SMS to all selected customers.
- A real "send SMS from the server without the phone" service (bulk SMS gateway such as SSL Wireless, Alpha SMS, BulkSMSBD) needs a paid account and a server (Firebase Cloud Function). It can be added later if you need it.

## Things you can customise

- Texts / translations: `lib/core/strings.dart`
- Colour of the app: `lib/main.dart` -> `seedColor`
- Developer information: `lib/core/constants.dart`
- Default company list: `lib/core/constants.dart` -> `kDefaultCompanies`

## Troubleshooting

| Problem | Solution |
|---|---|
| `[core/no-app]` or `apiKey` / `PASTE_API_KEY` error | You did not run `flutterfire configure` (Step 6) |
| `permission-denied` | Firestore rules not published (Step 4) or you are logged out |
| `minSdkVersion` error | use the provided `android/app/build.gradle.kts` (minSdk 24) |
| Gradle takes very long on first build | normal, it downloads files once |
| Flutter says `package:flutter/material.dart` is deprecated | only a hint on the newest Flutter; the app still works |
| Phone does not open SMS / WhatsApp | use the provided `AndroidManifest.xml` (it has the `queries` block) |
| PDF share does nothing | stop the app completely and run `flutter run` again (a plugin was added) |
