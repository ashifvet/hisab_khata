import 'package:flutter_test/flutter_test.dart';
import 'package:hisab_khata/core/helpers.dart';
import 'package:hisab_khata/core/strings.dart';
import 'package:hisab_khata/services/pdf_service.dart';
import 'package:hisab_khata/services/update_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('number formatting', () {
    expect(fmtNum(1234567), '1,234,567');
    expect(fmtNum(1234.5), '1,234.50');
    expect(fmtNum(0), '0');
    expect(fmtNum(-250), '-250');
    expect(money(500), '৳500');
  });

  test('parse numbers with Bangla digits', () {
    expect(parseNum('১২৩'), 123);
    expect(parseNum('1,500.5'), 1500.5);
    expect(parseNum('abc'), null);
  });

  test('word count', () {
    expect(wordCount(''), 0);
    expect(wordCount('a b  c\nd'), 4);
  });

  test('version compare', () {
    expect(UpdateService.compare('1.0.0', '1.0.1') < 0, true);
    expect(UpdateService.compare('1.10.0', '1.9.9') > 0, true);
    expect(UpdateService.compare('1.0.0+3', '1.0.0'), 0);
  });

  test('phone helpers', () {
    expect(waPhone('01711989236'), '8801711989236');
    expect(waPhone('+8801711989236'), '8801711989236');
    expect(cleanPhone('017-119 89236'), '01711989236');
  });

  test('translations', () {
    expect(translate('bn', 'login'), 'লগইন');
    expect(translate('en', 'login'), 'Login');
    expect(translate('en', 'unknown_key'), 'unknown_key');
  });

  test('pdf is generated (English + Bangla text)', () async {
    final bytes = await PdfService.build(
      title: 'স্টেটমেন্ট: রহিম',
      business: 'আমার ব্যবসা',
      summary: [
        ['মোট', '৳500']
      ],
      headers: ['Date', 'Details', 'Balance'],
      rows: [
        ['01 Jan 2025', 'চাল বিক্রি', '500'],
      ],
      rightCols: {2},
    );
    expect(bytes.length > 1000, true);
    expect(String.fromCharCodes(bytes.sublist(0, 4)), '%PDF');
  });
}
