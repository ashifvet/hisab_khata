# My Diary – Flutter setup (step by step)

> IMPORTANT: these Flutter files were written without a Flutter SDK available, so they have **not been compiled or run**.
> Expect to fix a few small things (package versions, deprecation warnings). Run `flutter analyze` and send me any error text.
> The Next.js web app in the parent project is the tested version of the same features.

## 1. Create the project
```bash
flutter create my_diary --org com.ashif --platforms=android,ios,web
cd my_diary
```
Delete `lib/main.dart` and `test/widget_test.dart`, then copy from this folder:

| From `flutter_app/`                                | To (in your `my_diary/`)                         |
|-----------------------------------------------------|--------------------------------------------------|
| `pubspec.yaml`                                      | `pubspec.yaml` (replace)                         |
| `lib/main.dart, core.dart, library.dart, hisab.dart, home.dart` | `lib/`                              |
| `android/app/src/main/AndroidManifest.xml`          | same path (replace)                              |
| `assets/data/medicines.json`                        | `assets/data/medicines.json`                     |
| **your** icon                                       | `assets/icon.png`                                |
| `firestore.rules`                                   | used in step 3                                   |

## 2. Firebase (free "Spark" plan is enough)
1. https://console.firebase.google.com → **Add project** → "My Diary".
2. **Authentication → Sign-in method → Email/Password → Enable.**
   (The app turns a username into `username@mydiary.app`, so users never type an email.)
3. **Firestore Database → Create database** (production mode, region `asia-south1` or nearest).
4. Install tools once:
   ```bash
   npm install -g firebase-tools
   dart pub global activate flutterfire_cli
   firebase login
   flutterfire configure        # pick your project + android/ios/web
   ```
   This generates `lib/firebase_options.dart` and wires the Android Gradle files (google-services plugin) automatically.
5. Android: in `android/app/build.gradle(.kts)` make sure `minSdk` is **23** or higher (`minSdk = 23`).

## 3. Security rules
Firebase console → Firestore → **Rules** → paste the whole content of `firestore.rules` → **Publish**.
They enforce: everyone reads Company/Medicine/Disease/P&S, only the creator or an admin edits; Hisab data is private
to its owner (admins see everything); the private visit **fee** of a disease is readable only by its creator and admins.

## 4. Run
```bash
flutter pub get
dart run flutter_launcher_icons     # applies assets/icon.png as the app icon
flutter run
```
**First launch ever:** log in with `admin` / `Solution2@` – the app creates the administrator account on the spot
(do this yourself *before* distributing the app). Change the password in Drawer → Settings.

## 5. Importing the medicines
Add tab → "Import medicines from local database". It writes ~1,179 medicines + 51 companies once; afterwards
the button is permanently disabled for everybody (flag document `meta/medicineImport`).

## 6. Publishing a new version / forced update
Drawer → Announcements → **App version & forced update**.
* `latestVersion` newer than the installed one → users see an "Update available" dialog.
* `minVersion` newer than the installed one → users are blocked by an "Update required" screen until they update.
* `updateUrl` = Play Store link or direct APK link.
Also bump `version:` in `pubspec.yaml` (e.g. `1.1.0+2`) for every release you build.
(Background push notifications would need Firebase Cloud Messaging; the in-app prompt above appears when the app is opened.)

## 7. Offline & sync
Firestore offline persistence is switched on in `main.dart`. Everything works without internet (entries are
stored on the phone) and is uploaded automatically when the connection returns. The very first login needs internet.

## 8. Build
```bash
flutter build apk --release        # Android
flutter build appbundle --release  # Play Store
flutter build ios --release        # needs a Mac
flutter build web --release        # web
```

## Known limits
* "Free messages" / group reminders open WhatsApp or the SMS app on the phone with the text prefilled (one tap per
  customer, "Send next" button). Truly automatic bulk SMS needs a paid SMS gateway.
* PDF reports use the default PDF font: Bengali text inside PDFs will not render unless you embed a Bengali font.
* Imported medicines come from public online listings (arogga.com): pregnancy / pet-safety flags are left
  *unclassified* on purpose; please verify dosage on the product leaflet and classify them yourself.
