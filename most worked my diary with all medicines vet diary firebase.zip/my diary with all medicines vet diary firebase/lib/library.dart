import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core.dart';
import 'forms.dart';

// ======================================================================= generic detail page
class DetailPage extends StatelessWidget {
  final DocumentReference<Json> ref;
  final String kind;
  final String Function(Json) titleOf;
  final Widget Function(BuildContext, Json) body;
  final Widget Function(DocumentSnapshot<Json>) editForm;
  final List<Widget> Function(BuildContext, Json)? extraActions;
  final Future<void> Function()? onDeleted;

  const DetailPage({
    super.key,
    required this.ref,
    required this.kind,
    required this.titleOf,
    required this.body,
    required this.editForm,
    this.extraActions,
    this.onDeleted,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: ref.snapshots(),
      builder: (c, s) {
        if (s.hasError) return Scaffold(appBar: AppBar(), body: Center(child: Text('${s.error}')));
        if (!s.hasData) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        if (!s.data!.exists) return Scaffold(appBar: AppBar(), body: const EmptyView('This record was deleted.'));
        final d = s.data!.data()!;
        final st = Provider.of<AppState>(c);
        final ok = canEdit(st, d);
        return Scaffold(
          appBar: AppBar(
            title: Text(titleOf(d)),
            actions: [
              ...?extraActions?.call(c, d),
              if (ok)
                IconButton(
                  tooltip: 'Edit',
                  icon: const Icon(Icons.edit),
                  onPressed: () => Navigator.push(
                    c,
                    MaterialPageRoute(
                      builder: (_) => Scaffold(appBar: AppBar(title: Text('Edit $kind')), body: editForm(s.data!)),
                    ),
                  ),
                ),
              if (ok)
                IconButton(
                  tooltip: 'Delete',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await confirmDlg(c, 'Delete this $kind?')) {
                      await fast(ref.delete());
                      await onDeleted?.call();
                      if (c.mounted) Navigator.pop(c);
                    }
                  },
                ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              body(c, d),
              const Divider(),
              Text(
                'Added by ${d['createdByName'] ?? 'unknown'}${ok ? '' : '  (only the creator or admin can edit)'}',
                style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor),
              ),
            ],
          ),
        );
      },
    );
  }
}

String _status(dynamic v, {String safe = 'Safe', String unsafe = 'Unsafe'}) =>
    v == 'safe' ? safe : (v == 'unsafe' ? unsafe : 'Not set');
Color _statusColor(dynamic v) => v == 'safe' ? Colors.green : (v == 'unsafe' ? Colors.red : Colors.grey);

// ======================================================================= COMPANIES
class CompaniesPage extends StatelessWidget {
  const CompaniesPage({super.key});
  @override
  Widget build(BuildContext context) {
    return DocStream(
      query: fs.collection('companies'),
      builder: (c, docs) => SearchableList(
        docs: docs,
        empty: 'No company yet. Add one from the "Add" tab or import the medicine database.',
        titleOf: (d) => '${d['name']}',
        subtitleOf: (d) => '${d['note'] ?? ''}',
        trailing: (d) => const Icon(Icons.chevron_right),
        onTap: (d) => Navigator.push(c, MaterialPageRoute(builder: (_) => CompanyDetailPage(id: d.id))),
      ),
    );
  }
}

class CompanyDetailPage extends StatelessWidget {
  final String id;
  const CompanyDetailPage({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return DetailPage(
      ref: fs.collection('companies').doc(id),
      kind: 'company',
      titleOf: (d) => '${d['name']}',
      editForm: (snap) => CompanyForm(existing: snap),
      body: (c, d) {
        final favs = Provider.of<AppState>(c).favorites;
        return DocStream(
          query: fs.collection('medicines').where('companyId', isEqualTo: id),
          builder: (c, docs) {
            if (docs.isEmpty) return const EmptyView('No medicine added for this company yet.');
            final list = docs.toList()
              ..sort((a, b) => '${a.data()['name']}'.toLowerCase().compareTo('${b.data()['name']}'.toLowerCase()));
            final fav = list.where((e) => favs.contains(e.id)).toList();
            Widget tile(QueryDocumentSnapshot<Json> e) => ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(favs.contains(e.id) ? Icons.star : Icons.medication_outlined,
                      color: favs.contains(e.id) ? Colors.amber : null),
                  title: Text('${e.data()['name']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('${e.data()['components'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis),
                  onTap: () => openMedicine(c, e.id),
                );
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (fav.isNotEmpty) ...[
                  const Text('★ Favourite medicines', style: TextStyle(fontWeight: FontWeight.bold)),
                  ...fav.map(tile),
                  const Divider(),
                ],
                Text('All medicines (${list.length})', style: const TextStyle(fontWeight: FontWeight.bold)),
                ...list.map(tile),
              ],
            );
          },
        );
      },
    );
  }
}

// ======================================================================= MEDICINES
void openMedicine(BuildContext c, String id) =>
    Navigator.push(c, MaterialPageRoute(builder: (_) => MedicineDetailPage(id: id)));

class MedicinesPage extends StatelessWidget {
  const MedicinesPage({super.key});

  Widget _list(BuildContext c, List<QueryDocumentSnapshot<Json>> docs, String empty) => SearchableList(
        docs: docs,
        empty: empty,
        titleOf: (d) => '${d['name']}',
        subtitleOf: (d) => '${d['companyName'] ?? ''}  •  ${d['components'] ?? ''}',
        searchOf: (d) => '${d['name']} ${d['companyName']} ${d['components']} ${d['indications']}',
        trailing: (d) => Row(mainAxisSize: MainAxisSize.min, children: [
          if (d['pregnancySafe'] == 'safe') const Icon(Icons.pregnant_woman, color: Colors.green, size: 20),
          if (d['petSafety'] == 'safe') const Icon(Icons.pets, color: Colors.green, size: 18),
          if (d['petSafety'] == 'unsafe') const Icon(Icons.pets, color: Colors.red, size: 18),
        ]),
        onTap: (d) => openMedicine(c, d.id),
      );

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          TabBar(tabs: [
            Tab(text: t(context, 'All')),
            Tab(text: t(context, 'Pregnancy Safe')),
            Tab(text: t(context, 'Pet Medicines')),
          ]),
          Expanded(
            child: DocStream(
              query: fs.collection('medicines'),
              builder: (c, docs) => TabBarView(children: [
                _list(c, docs, 'No medicines yet.'),
                _list(c, docs.where((d) => d.data()['pregnancySafe'] == 'safe').toList(),
                    'No medicine is marked "Pregnancy safe" yet.'),
                _list(c, docs.where((d) => d.data()['petSafety'] == 'safe').toList(),
                    'No medicine is marked "Safe for pets" yet.'),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class MedicineDetailPage extends StatelessWidget {
  final String id;
  const MedicineDetailPage({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return DetailPage(
      ref: fs.collection('medicines').doc(id),
      kind: 'medicine',
      titleOf: (d) => '${d['name']}',
      editForm: (snap) => MedicineForm(existing: snap),
      extraActions: (c, d) {
        final st = Provider.of<AppState>(c);
        final fav = st.favorites.contains(id);
        return [
          IconButton(
            tooltip: 'Favourite',
            icon: Icon(fav ? Icons.star : Icons.star_border, color: fav ? Colors.amber : null),
            onPressed: () => st.toggleFavorite(id),
          ),
        ];
      },
      body: (c, d) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Badge2('Pregnancy: ${_status(d['pregnancySafe'])}', _statusColor(d['pregnancySafe'])),
            Badge2('Pet: ${_status(d['petSafety'])}', _statusColor(d['petSafety'])),
          ]),
          const SizedBox(height: 12),
          Section('Company', '${d['companyName'] ?? ''}'),
          Section('Components', d['components']),
          Section('When to use', d['indications']),
          Section('Dose', d['dose']),
          Section('Pregnancy / lactation', d['pregnancy']),
          Section('Other details', d['details']),
        ],
      ),
    );
  }
}

// ======================================================================= DISEASES
class DiseasesPage extends StatelessWidget {
  const DiseasesPage({super.key});

  Widget _list(BuildContext c, List<QueryDocumentSnapshot<Json>> docs, String empty) => SearchableList(
        docs: docs,
        empty: empty,
        titleOf: (d) => '${d['title']}',
        subtitleOf: (d) => '${d['ownerName'] ?? ''}  •  ${d['phone'] ?? ''}',
        searchOf: (d) => '${d['title']} ${d['ownerName']} ${d['phone']}',
        trailing: (d) => Icon(d['prognosis'] == 'good' ? Icons.thumb_up_alt_outlined : Icons.thumb_down_alt_outlined,
            size: 18, color: d['prognosis'] == 'good' ? Colors.green : Colors.red),
        onTap: (d) => Navigator.push(c, MaterialPageRoute(builder: (_) => DiseaseDetailPage(id: d.id))),
      );

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          TabBar(tabs: [
            Tab(text: t(context, 'All')),
            Tab(text: t(context, 'Good Prognosis')),
            Tab(text: t(context, 'Poor Prognosis')),
          ]),
          Expanded(
            child: DocStream(
              query: fs.collection('diseases'),
              builder: (c, docs) => TabBarView(children: [
                _list(c, docs, 'No disease added yet.'),
                _list(c, docs.where((d) => d.data()['prognosis'] == 'good').toList(), 'No case with good prognosis.'),
                _list(c, docs.where((d) => d.data()['prognosis'] == 'poor').toList(), 'No case with poor prognosis.'),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class DiseaseDetailPage extends StatelessWidget {
  final String id;
  const DiseaseDetailPage({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return DetailPage(
      ref: fs.collection('diseases').doc(id),
      kind: 'disease record',
      titleOf: (d) => '${d['title']}',
      editForm: (snap) => DiseaseForm(existing: snap),
      onDeleted: () => fast(fs.collection('diseaseFees').doc(id).delete()),
      body: (c, d) {
        final st = Provider.of<AppState>(c);
        final mine = canEdit(st, d);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Section('Owner', '${d['ownerName']}'),
            Section('Phone', '${d['phone']}'),
            Section('Location', '${d['location']}'),
            // The visit fee is stored in a separate protected document:
            // only the entry user and the administrator can read it.
            if (d['location'] == 'Private' && mine)
              StreamBuilder<DocumentSnapshot<Json>>(
                stream: fs.collection('diseaseFees').doc(id).snapshots(),
                builder: (c, s) {
                  final fee = s.data?.data()?['fee'];
                  if (fee == null) return const SizedBox.shrink();
                  return Section('Fee taken (private - visible only to you & admin)', 'Tk ${money(toD(fee))}');
                },
              ),
            Section('Title of the disease', '${d['title']}'),
            Section('Temperature', '${d['temperature'] ?? ''}'),
            Section('Signs & symptoms told by the owner', d['symptoms']),
            Section('Clinical findings', d['findings']),
            Section('Skin parasite', d['skinParasite'] == 'present' ? 'Present' : 'Absent'),
            Section('Treatment', d['treatment']),
            Row(children: [
              Badge2('Prognosis after 10 days: ${d['prognosis'] == 'good' ? 'Good' : 'Poor'}',
                  d['prognosis'] == 'good' ? Colors.green : Colors.red),
            ]),
          ],
        );
      },
    );
  }
}

// ======================================================================= PROBLEMS & SOLUTIONS
class ProblemsPage extends StatelessWidget {
  const ProblemsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return DocStream(
      query: fs.collection('problems'),
      builder: (c, docs) => SearchableList(
        docs: docs,
        empty: 'No problem & solution added yet.',
        titleOf: (d) => '${d['title']}',
        subtitleOf: (d) => '${d['problem'] ?? ''}',
        searchOf: (d) => '${d['title']} ${d['problem']} ${d['solution']}',
        trailing: (d) => const Icon(Icons.chevron_right),
        onTap: (d) => Navigator.push(c, MaterialPageRoute(builder: (_) => ProblemDetailPage(id: d.id))),
      ),
    );
  }
}

class ProblemDetailPage extends StatelessWidget {
  final String id;
  const ProblemDetailPage({super.key, required this.id});
  @override
  Widget build(BuildContext context) {
    return DetailPage(
      ref: fs.collection('problems').doc(id),
      kind: 'problem',
      titleOf: (d) => '${d['title']}',
      editForm: (snap) => ProblemForm(existing: snap),
      body: (c, d) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Section('Problem', d['problem']),
          Section('Solution', d['solution']),
          Section('Prognosis', d['prognosis']),
        ],
      ),
    );
  }
}
