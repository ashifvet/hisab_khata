import 'dart:typed_data';

import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import 'core.dart';

/// All builders receive plain maps (already loaded from Firestore), so they also work offline.

Future<Uint8List> _build(String title, String biz, String sub, List<pw.Widget> body) async {
  pw.ThemeData? theme;
  try {
    // Roboto for English + Noto Sans Bengali as fallback (needs internet once; cached afterwards)
    final base = await PdfGoogleFonts.robotoRegular();
    final bold = await PdfGoogleFonts.robotoBold();
    final bn = await PdfGoogleFonts.notoSansBengaliRegular();
    theme = pw.ThemeData.withFont(base: base, bold: bold, fontFallback: [bn]);
  } catch (_) {
    theme = null; // offline & fonts not cached: default font (Bangla text may not display)
  }
  final doc = pw.Document(theme: theme);
  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      header: (c) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Text(biz, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.Text(title, style: const pw.TextStyle(fontSize: 13)),
        if (sub.isNotEmpty) pw.Text(sub, style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
        pw.Divider(),
      ]),
      footer: (c) => pw.Align(
        alignment: pw.Alignment.centerRight,
        child: pw.Text('My Diary  |  ${DateFormat('dd MMM yyyy hh:mm a').format(DateTime.now())}  |  Page ${c.pageNumber}/${c.pagesCount}',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
      ),
      build: (c) => body,
    ),
  );
  return doc.save();
}

pw.Widget _table(List<String> headers, List<List<String>> rows, {Set<int> right = const {}}) {
  return pw.TableHelper.fromTextArray(
    headers: headers,
    data: rows,
    cellStyle: const pw.TextStyle(fontSize: 9),
    headerStyle: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold),
    headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
    cellAlignments: {for (final i in right) i: pw.Alignment.centerRight},
    headerAlignments: {for (final i in right) i: pw.Alignment.centerRight},
    cellPadding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3),
  );
}

pw.Widget _kv(String k, String v, {PdfColor? color}) => pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2),
      child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
        pw.Text(k, style: const pw.TextStyle(fontSize: 11)),
        pw.Text(v, style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold, color: color)),
      ]),
    );

String _d(dynamic v) => dateStr(toDate(v));
bool _inMonth(dynamic v, DateTime m) {
  final d = toDate(v);
  return d.year == m.year && d.month == m.month;
}

// ------------------------------------------------------------------ customer / supplier statement
Future<Uint8List> partyReport(String biz, Json party, List<Json> txns) {
  final list = [...txns]..sort((a, b) => toDate(a['date']).compareTo(toDate(b['date'])));
  double run = 0, gave = 0, got = 0;
  final rows = <List<String>>[];
  for (final t in list) {
    final a = toD(t['amount']);
    final isGave = t['type'] == 'gave';
    run += isGave ? a : -a;
    if (isGave) {
      gave += a;
    } else {
      got += a;
    }
    rows.add([_d(t['date']), '${t['note'] ?? ''}', isGave ? money(a) : '', isGave ? '' : money(a), money(run)]);
  }
  final bal = gave - got;
  return _build('Account statement - ${party['name']}', biz,
      '${party['type'] == 'supplier' ? 'Supplier' : 'Customer'}  |  Phone: ${party['phone'] ?? ''}', [
    _table(['Date', 'Details', 'You gave', 'You got', 'Balance'], rows, right: {2, 3, 4}),
    pw.SizedBox(height: 12),
    _kv('Total you gave', 'Tk ${money(gave)}'),
    _kv('Total you got', 'Tk ${money(got)}'),
    pw.Divider(),
    _kv(bal >= 0 ? 'You will get' : 'You will give', 'Tk ${money(bal.abs())}',
        color: bal >= 0 ? PdfColors.green800 : PdfColors.red800),
  ]);
}

// ------------------------------------------------------------------ all parties summary
Future<Uint8List> partiesSummaryReport(String biz, List<Json> parties) {
  double toGet = 0, toGive = 0;
  final rows = <List<String>>[];
  final sorted = [...parties]..sort((a, b) => '${a['name']}'.compareTo('${b['name']}'));
  for (final p in sorted) {
    final b = toD(p['balance']);
    if (b > 0) {
      toGet += b;
    } else {
      toGive += -b;
    }
    rows.add(['${p['name']}', '${p['type'] == 'supplier' ? 'Supplier' : 'Customer'}', '${p['phone'] ?? ''}',
      b > 0 ? money(b) : '', b < 0 ? money(-b) : '']);
  }
  return _build('Customers & suppliers summary', biz, 'As of ${dateStr(DateTime.now())}', [
    _table(['Name', 'Type', 'Phone', 'You will get', 'You will give'], rows, right: {3, 4}),
    pw.SizedBox(height: 12),
    _kv('Total you will get', 'Tk ${money(toGet)}', color: PdfColors.green800),
    _kv('Total you will give', 'Tk ${money(toGive)}', color: PdfColors.red800),
  ]);
}

// ------------------------------------------------------------------ stock & inventory
Future<Uint8List> stockReport(String biz, List<Json> products, List<Json> outs) {
  double value = 0;
  final rows = <List<String>>[];
  final ps = [...products]..sort((a, b) => '${a['name']}'.toLowerCase().compareTo('${b['name']}'.toLowerCase()));
  for (final p in ps) {
    final q = toD(p['qty']), c = toD(p['unitCost']);
    value += q * c;
    final sold = outs.where((o) => o['productId'] == p['id']).toList()
      ..sort((a, b) => toDate(b['date']).compareTo(toDate(a['date'])));
    final soldQty = sold.fold<double>(0, (s, o) => s + toD(o['qty']));
    rows.add([
      '${p['name']}',
      _d(p['addedAt']),
      money(q),
      money(c),
      money(q * c),
      money(soldQty),
      sold.isEmpty ? '-' : _d(sold.first['date']),
    ]);
  }
  final outRows = [...outs]..sort((a, b) => toDate(b['date']).compareTo(toDate(a['date'])));
  return _build('Stock & inventory report', biz, 'As of ${dateStr(DateTime.now())}', [
    _table(['Product', 'Date entered', 'In stock', 'Unit cost', 'Value', 'Sold qty', 'Last sold'], rows, right: {2, 3, 4, 5}),
    pw.SizedBox(height: 8),
    _kv('Total stock valuation', 'Tk ${money(value)}'),
    pw.SizedBox(height: 14),
    pw.Text('Sales (stock out) history', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
    pw.SizedBox(height: 4),
    _table(
      ['Date sold', 'Product', 'Qty', 'Sold to', 'Phone', 'Amount'],
      outRows
          .map((o) => [_d(o['date']), '${o['productName']}', money(toD(o['qty'])), '${o['buyerName'] ?? ''}',
                '${o['buyerPhone'] ?? ''}', money(toD(o['qty']) * toD(o['price']))])
          .toList(),
      right: {2, 5},
    ),
  ]);
}

// ------------------------------------------------------------------ cost & savings
Future<Uint8List> costSavingReport(String biz, DateTime month, List<Json> cash) {
  final list = cash.where((c) => c['type'] != 'in' && _inMonth(c['date'], month)).toList()
    ..sort((a, b) => toDate(a['date']).compareTo(toDate(b['date'])));
  double cost = 0, save = 0;
  for (final c in list) {
    if (c['type'] == 'saving') {
      save += toD(c['amount']);
    } else {
      cost += toD(c['amount']);
    }
  }
  return _build('Cost & savings report', biz, DateFormat('MMMM yyyy').format(month), [
    _table(['Date', 'Type', 'Category', 'Note', 'Amount'],
        list.map((c) => [_d(c['date']), c['type'] == 'saving' ? 'Saving' : 'Cost', '${c['category'] ?? ''}', '${c['note'] ?? ''}', money(toD(c['amount']))]).toList(),
        right: {4}),
    pw.SizedBox(height: 12),
    _kv('Total cost', 'Tk ${money(cost)}', color: PdfColors.red800),
    _kv('Total savings', 'Tk ${money(save)}', color: PdfColors.green800),
  ]);
}

// ------------------------------------------------------------------ monthly report
Future<Uint8List> monthlyReport(String biz, DateTime month, List<Json> cash, List<Json> txns, List<Json> outs) {
  final m = cash.where((c) => _inMonth(c['date'], month)).toList()
    ..sort((a, b) => toDate(a['date']).compareTo(toDate(b['date'])));
  double inc = 0, cost = 0, save = 0;
  for (final c in m) {
    final a = toD(c['amount']);
    if (c['type'] == 'in') {
      inc += a;
    } else if (c['type'] == 'saving') {
      save += a;
    } else {
      cost += a;
    }
  }
  final t = txns.where((x) => _inMonth(x['date'], month)).toList();
  final gave = t.where((x) => x['type'] == 'gave').fold<double>(0, (s, x) => s + toD(x['amount']));
  final got = t.where((x) => x['type'] == 'got').fold<double>(0, (s, x) => s + toD(x['amount']));
  final sales = outs.where((o) => _inMonth(o['date'], month)).fold<double>(0, (s, o) => s + toD(o['qty']) * toD(o['price']));
  return _build('Monthly report', biz, DateFormat('MMMM yyyy').format(month), [
    pw.Text('Summary', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
    _kv('Total income (cashbook)', 'Tk ${money(inc)}', color: PdfColors.green800),
    _kv('Total cost', 'Tk ${money(cost)}', color: PdfColors.red800),
    _kv('Total savings', 'Tk ${money(save)}'),
    _kv('Net (income - cost - savings)', 'Tk ${money(inc - cost - save)}'),
    pw.Divider(),
    _kv('Credit given to parties (You gave)', 'Tk ${money(gave)}'),
    _kv('Payments received (You got)', 'Tk ${money(got)}'),
    _kv('Stock sales value', 'Tk ${money(sales)}'),
    pw.SizedBox(height: 14),
    pw.Text('Cashbook entries', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
    pw.SizedBox(height: 4),
    _table(['Date', 'Type', 'Category', 'Note', 'Amount'],
        m.map((c) => [_d(c['date']), c['type'] == 'in' ? 'Income' : (c['type'] == 'saving' ? 'Saving' : 'Cost'), '${c['category'] ?? ''}', '${c['note'] ?? ''}', money(toD(c['amount']))]).toList(),
        right: {4}),
    pw.SizedBox(height: 14),
    pw.Text('Customer / supplier transactions', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
    pw.SizedBox(height: 4),
    _table(['Date', 'Party', 'Type', 'Note', 'Amount'],
        (t..sort((a, b) => toDate(a['date']).compareTo(toDate(b['date']))))
            .map((x) => [_d(x['date']), '${x['partyName'] ?? ''}', x['type'] == 'gave' ? 'You gave' : 'You got', '${x['note'] ?? ''}', money(toD(x['amount']))])
            .toList(),
        right: {4}),
  ]);
}
