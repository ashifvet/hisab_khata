import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import 'core.dart';
import 'drawer_pages.dart';
import 'forms.dart';
import 'hisab.dart';
import 'library.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;
  final Set<int> _built = {0};
  late final List<Widget> _pages;

  static const _keys = ['Hisab', 'Companies', 'Medicines', 'Diseases', 'P&S', 'Add'];
  static const _icons = [
    Icons.account_balance_wallet,
    Icons.apartment,
    Icons.medication,
    Icons.healing,
    Icons.tips_and_updates,
    Icons.add_circle,
  ];

  @override
  void initState() {
    super.initState();
    final uid = context.read<AppState>().uid!;
    _pages = [
      HisabScreen(uid: uid),
      const CompaniesPage(),
      const MedicinesPage(),
      const DiseasesPage(),
      const ProblemsPage(),
      const AddPage(),
    ];
    WidgetsBinding.instance.addPostFrameCallback((_) => _startupChecks());
  }

  // ------------------------------------------------ update check + announcements
  int _cmp(String a, String b) {
    List<int> p(String s) => s.split('+').first.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final x = p(a), y = p(b);
    for (var i = 0; i < 3; i++) {
      final xi = i < x.length ? x[i] : 0, yi = i < y.length ? y[i] : 0;
      if (xi != yi) return xi.compareTo(yi);
    }
    return 0;
  }

  Future<void> _startupChecks() async {
    await _checkUpdate();
    if (!mounted) return;
    await _showAnnouncements();
  }

  Future<void> _checkUpdate() async {
    try {
      final snap = await fs.collection('config').doc('app').get();
      if (!snap.exists || !mounted) return;
      final d = snap.data()!;
      final cur = (await PackageInfo.fromPlatform()).version;
      final latest = '${d['latestVersion'] ?? cur}';
      final min = '${d['minVersion'] ?? '0.0.0'}';
      final url = '${d['updateUrl'] ?? ''}';
      final msg = '${d['message'] ?? 'A new version of My Diary is available.'}';
      if (_cmp(cur, min) < 0) {
        if (!mounted) return;
        // FORCE UPDATE: dialog cannot be dismissed
        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => PopScope(
            canPop: false,
            child: AlertDialog(
              title: const Text('Update required'),
              content: Text('$msg\n\nYour version: $cur\nRequired version: $min'),
              actions: [FilledButton(onPressed: () => openUrl(url), child: const Text('Update now'))],
            ),
          ),
        );
      } else if (_cmp(cur, latest) < 0) {
        if (!mounted) return;
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('New version available'),
            content: Text('$msg\n\nYour version: $cur\nLatest version: $latest'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Later')),
              FilledButton(
                  onPressed: () {
                    openUrl(url);
                    Navigator.pop(ctx);
                  },
                  child: const Text('Update')),
            ],
          ),
        );
      }
    } catch (_) {}
  }

  Future<void> _showAnnouncements() async {
    try {
      final prefs = context.read<AppState>().prefs;
      final q = await fs.collection('announcements').where('active', isEqualTo: true).get();
      final docs = q.docs.toList()
        ..sort((a, b) => toDate(a.data()['createdAt']).compareTo(toDate(b.data()['createdAt'])));
      for (final doc in docs) {
        if (!mounted) return;
        final d = doc.data();
        final key = 'ann_${doc.id}';
        final seen = prefs?.getInt(key) ?? 0;
        final times = (d['times'] is num ? (d['times'] as num).toInt() : 1).clamp(1, 1000);
        if (seen >= times) continue;
        await prefs?.setInt(key, seen + 1);
        final tg = '${d['telegram'] ?? ''}'.trim();
        final web = '${d['website'] ?? ''}'.trim();
        // never trap the user: if there are no links, cancel must be possible
        final cancelOk = d['cancelAllowed'] == true || (tg.isEmpty && web.isEmpty);
        if (!mounted) return;
        await showDialog<void>(
          context: context,
          barrierDismissible: cancelOk,
          builder: (ctx) => PopScope(
            canPop: cancelOk,
            child: AlertDialog(
              title: Text('${d['title'] ?? ''}'),
              content: SingleChildScrollView(child: Text('${d['content'] ?? ''}')),
              actions: [
                if (tg.isNotEmpty)
                  FilledButton.icon(
                    icon: const Icon(Icons.telegram),
                    label: const Text('Join Telegram'),
                    onPressed: () {
                      openUrl(tg);
                      Navigator.pop(ctx);
                    },
                  ),
                if (web.isNotEmpty)
                  FilledButton.tonalIcon(
                    icon: const Icon(Icons.public),
                    label: const Text('Visit Web'),
                    onPressed: () {
                      openUrl(web);
                      Navigator.pop(ctx);
                    },
                  ),
                if (cancelOk) TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
              ],
            ),
          ),
        );
      }
    } catch (_) {}
  }

  // ------------------------------------------------ UI
  @override
  Widget build(BuildContext context) {
    final s = Provider.of<AppState>(context);
    final title = _i == 4 ? t(context, 'Problem based Solutions') : t(context, _keys[_i]);
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      drawer: AppDrawer(state: s),
      body: IndexedStack(
        index: _i,
        children: List.generate(6, (i) => _built.contains(i) ? _pages[i] : const SizedBox.shrink()),
      ),
      bottomNavigationBar: _NavBar(
        index: _i,
        labels: _keys.map((k) => t(context, k)).toList(),
        icons: _icons,
        onTap: (i) => setState(() {
          _i = i;
          _built.add(i);
        }),
      ),
    );
  }
}

/// Bottom bar that scales icons / text to the screen width (small phone -> small, tablet -> large).
class _NavBar extends StatelessWidget {
  final int index;
  final List<String> labels;
  final List<IconData> icons;
  final ValueChanged<int> onTap;
  const _NavBar({required this.index, required this.labels, required this.icons, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      elevation: 12,
      color: cs.surface,
      child: SafeArea(
        top: false,
        child: LayoutBuilder(builder: (context, c) {
          final itemW = c.maxWidth / labels.length;
          final iconSize = (itemW * 0.40).clamp(18.0, 36.0);
          final font = (itemW * 0.16).clamp(8.5, 15.0);
          final h = (itemW * 0.85).clamp(54.0, 84.0);
          return SizedBox(
            height: h,
            child: Row(
              children: List.generate(labels.length, (i) {
                final sel = i == index;
                final color = sel ? cs.primary : cs.onSurfaceVariant;
                return Expanded(
                  child: InkWell(
                    onTap: () => onTap(i),
                    child: Container(
                      decoration: BoxDecoration(
                        color: sel ? cs.primary.withOpacity(0.10) : null,
                        border: Border(top: BorderSide(color: sel ? cs.primary : Colors.transparent, width: 3)),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(icons[i], size: iconSize, color: color),
                          const SizedBox(height: 2),
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(labels[i],
                                maxLines: 1,
                                style: TextStyle(fontSize: font, color: color, fontWeight: sel ? FontWeight.bold : FontWeight.normal)),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          );
        }),
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  final AppState state;
  const AppDrawer({super.key, required this.state});

  void _go(BuildContext c, Widget page, String title) {
    Navigator.pop(c);
    pushPage(c, title, page);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Drawer(
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 20, 16, 18),
            color: cs.primary,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CircleAvatar(radius: 28, child: Icon(Icons.person, size: 32)),
                const SizedBox(height: 12),
                Text('${t(context, greetingKey())},',
                    style: TextStyle(color: cs.onPrimary.withOpacity(0.85), fontSize: 14)),
                Text(state.fullName,
                    style: TextStyle(color: cs.onPrimary, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                Text(state.isAdmin ? 'Administrator' : '@${state.profile['username'] ?? ''}',
                    style: TextStyle(color: cs.onPrimary.withOpacity(0.8), fontSize: 12)),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                    leading: const Icon(Icons.person_outline),
                    title: Text(t(context, 'Edit Profile')),
                    onTap: () => _go(context, const EditProfilePage(), t(context, 'Edit Profile'))),
                ListTile(
                    leading: const Icon(Icons.settings_outlined),
                    title: Text(t(context, 'Settings')),
                    onTap: () => _go(context, const SettingsPage(), t(context, 'Settings'))),
                if (state.isAdmin) ...[
                  const Divider(),
                  const Padding(
                    padding: EdgeInsets.only(left: 16, top: 4),
                    child: Text('ADMIN', style: TextStyle(fontSize: 11, letterSpacing: 1.5)),
                  ),
                  ListTile(
                      leading: const Icon(Icons.campaign_outlined),
                      title: Text(t(context, 'Announcements')),
                      onTap: () => _go(context, const AnnouncementsAdminPage(), t(context, 'Announcements'))),
                  ListTile(
                      leading: const Icon(Icons.system_update_outlined),
                      title: const Text('App Update (Firebase)'),
                      onTap: () => _go(context, const AppUpdateAdminPage(), 'App Update')),
                  ListTile(
                      leading: const Icon(Icons.admin_panel_settings_outlined),
                      title: const Text('Users & Admins'),
                      onTap: () => _go(context, const UsersAdminPage(), 'Users & Admins')),
                  const Divider(),
                ],
                ListTile(
                    leading: const Icon(Icons.info_outline),
                    title: Text(t(context, 'About Developer')),
                    onTap: () => _go(context, const AboutPage(), t(context, 'About Developer'))),
              ],
            ),
          ),
          const Divider(height: 1),
          FutureBuilder<PackageInfo>(
            future: PackageInfo.fromPlatform(),
            builder: (c, s) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text('${t(context, 'Version')} ${s.data?.version ?? kAppVersionName}',
                  style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
            ),
          ),
          SafeArea(
            top: false,
            child: ListTile(
              leading: Icon(Icons.logout, color: cs.error),
              title: Text(t(context, 'Logout'), style: TextStyle(color: cs.error)),
              onTap: () async {
                Navigator.pop(context);
                await FirebaseAuth.instance.signOut();
              },
            ),
          ),
        ],
      ),
    );
  }
}
