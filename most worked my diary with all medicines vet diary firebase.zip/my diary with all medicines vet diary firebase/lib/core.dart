import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

// ---------------------------------------------------------------- constants
const kAdminUsername = 'admin';
const kAdminPassword = 'Solution2@'; // default admin. Change it from Settings after first login.
const kEmailDomain = 'mydiary.app';
const kBrand = Color(0xFF0B6E4F);
const kAppVersionName = '1.0.0';

String usernameToEmail(String u) => '${u.trim().toLowerCase()}@$kEmailDomain';

typedef Json = Map<String, dynamic>;
final FirebaseFirestore fs = FirebaseFirestore.instance;

// ---------------------------------------------------------------- app state
class AppState extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.light;
  String lang = 'en';
  SharedPreferences? prefs;
  String? uid;
  Json profile = {};
  bool profileLoaded = false;
  Set<String> favorites = {};
  StreamSubscription<dynamic>? _sub;
  StreamSubscription<dynamic>? _favSub;

  Future<void> loadPrefs() async {
    prefs = await SharedPreferences.getInstance();
    themeMode = (prefs!.getBool('dark') ?? false) ? ThemeMode.dark : ThemeMode.light;
    lang = prefs!.getString('lang') ?? 'en';
  }

  void setDark(bool v) {
    themeMode = v ? ThemeMode.dark : ThemeMode.light;
    prefs?.setBool('dark', v);
    notifyListeners();
  }

  void setLang(String l) {
    lang = l;
    prefs?.setString('lang', l);
    notifyListeners();
  }

  bool get isAdmin => profile['role'] == 'admin';

  String get fullName {
    final n = '${profile['firstName'] ?? ''} ${profile['lastName'] ?? ''}'.trim();
    if (n.isNotEmpty) return n;
    return (profile['username'] ?? 'User').toString();
  }

  void attach(User u) {
    if (uid == u.uid) return;
    _detachSilently();
    uid = u.uid;
    final ref = fs.collection('users').doc(u.uid);
    _sub = ref.snapshots().listen((s) async {
      if (!s.exists) {
        if (s.metadata.isFromCache) return;
        final email = u.email ?? '';
        await ref.set({
          'username': email.split('@').first,
          'firstName': '',
          'lastName': '',
          'email': '',
          'phone': '',
          'location': '',
          'role': email == usernameToEmail(kAdminUsername) ? 'admin' : 'user',
          'createdAt': FieldValue.serverTimestamp(),
        });
        return;
      }
      profile = s.data()!;
      profileLoaded = true;
      notifyListeners();
    });
    _favSub = ref.collection('favorites').snapshots().listen((s) {
      favorites = s.docs.map((d) => d.id).toSet();
      notifyListeners();
    });
  }

  void detach() {
    if (uid == null) return;
    _detachSilently();
    scheduleMicrotask(notifyListeners);
  }

  void _detachSilently() {
    _sub?.cancel();
    _favSub?.cancel();
    uid = null;
    profile = {};
    profileLoaded = false;
    favorites = {};
  }

  Future<void> toggleFavorite(String medId) async {
    final r = fs.collection('users').doc(uid).collection('favorites').doc(medId);
    if (favorites.contains(medId)) {
      await fast(r.delete());
    } else {
      await fast(r.set({'at': FieldValue.serverTimestamp()}));
    }
  }
}

bool canEdit(AppState s, Json d) => s.isAdmin || d['createdBy'] == s.uid;

// ---------------------------------------------------------------- translation
const Map<String, String> _bn = {
  'Hisab': 'হিসাব',
  'Companies': 'কোম্পানি',
  'Medicines': 'ঔষধ',
  'Diseases': 'রোগ',
  'P&S': 'সমস্যা',
  'Add': 'যোগ',
  'Problem based Solutions': 'সমস্যা ও সমাধান',
  'Edit Profile': 'প্রোফাইল এডিট',
  'Settings': 'সেটিংস',
  'About Developer': 'ডেভেলপার সম্পর্কে',
  'Logout': 'লগআউট',
  'Announcements': 'ঘোষণা',
  'Dark mode': 'ডার্ক মোড',
  'Change password': 'পাসওয়ার্ড পরিবর্তন',
  'Language': 'ভাষা',
  'Good morning': 'শুভ সকাল',
  'Good afternoon': 'শুভ অপরাহ্ন',
  'Good evening': 'শুভ সন্ধ্যা',
  'Good night': 'শুভ রাত্রি',
  'Save': 'সংরক্ষণ',
  'Cancel': 'বাতিল',
  'Company': 'কোম্পানি',
  'Medicine': 'ঔষধ',
  'Disease': 'রোগ',
  'All': 'সব',
  'Pregnancy Safe': 'গর্ভাবস্থায় নিরাপদ',
  'Pet Medicines': 'পোষা প্রাণীর ঔষধ',
  'Good Prognosis': 'ভালো প্রগনোসিস',
  'Poor Prognosis': 'খারাপ প্রগনোসিস',
  'Search': 'খুঁজুন',
  'You will get': 'আপনি পাবেন',
  'You will give': 'আপনি দেবেন',
  'Cash balance': 'ক্যাশ ব্যালেন্স',
  'Customers': 'কাস্টমার',
  'Suppliers': 'সাপ্লায়ার',
  'Cashbook': 'ক্যাশবুক',
  'Stock': 'স্টক',
  'Notes': 'নোট',
  'Reports': 'রিপোর্ট',
  'You gave': 'আপনি দিলেন',
  'You got': 'আপনি পেলেন',
  'Version': 'ভার্সন',
};

/// Use only inside build() methods.
String t(BuildContext c, String key) {
  final l = Provider.of<AppState>(c).lang;
  return l == 'bn' ? (_bn[key] ?? key) : key;
}

String greetingKey() {
  final h = DateTime.now().hour;
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  if (h < 20) return 'Good evening';
  return 'Good night';
}

// ---------------------------------------------------------------- helpers
int wordCount(String s) => s.trim().isEmpty ? 0 : s.trim().split(RegExp(r'\s+')).length;
String money(num v) => NumberFormat('#,##0.##').format(v);
String dateStr(DateTime d) => DateFormat('dd MMM yyyy').format(d);
DateTime toDate(dynamic v) => v is Timestamp ? v.toDate() : DateTime.now();
double toD(dynamic v) => v is num ? v.toDouble() : (double.tryParse('$v') ?? 0);

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
}

/// Firestore writes only complete when the server acknowledges them. When the phone is
/// offline the write is queued locally and synchronised later, so we must not wait forever.
Future<void> fast(Future<void> f) async {
  try {
    await f.timeout(const Duration(seconds: 4));
  } on TimeoutException {
    // queued locally, will sync when online
  }
}

Future<bool> confirmDlg(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Yes')),
      ],
    ),
  );
  return r ?? false;
}

Future<void> openUrl(String url) async {
  final s = url.trim();
  if (s.isEmpty) return;
  final u = Uri.tryParse(s.contains('://') ? s : 'https://$s');
  if (u != null) {
    try {
      await launchUrl(u, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }
}

/// Returns the id of the user's currently selected business (creates one if none).
Future<String> ensureBusiness(String uid, SharedPreferences? p) async {
  final saved = p?.getString('bid_$uid');
  if (saved != null) return saved;
  final col = fs.collection('users').doc(uid).collection('businesses');
  try {
    final q = await col.limit(1).get();
    if (q.docs.isNotEmpty) {
      await p?.setString('bid_$uid', q.docs.first.id);
      return q.docs.first.id;
    }
  } catch (_) {}
  final r = col.doc();
  await fast(r.set({'name': 'My Business', 'createdAt': FieldValue.serverTimestamp()}));
  await p?.setString('bid_$uid', r.id);
  return r.id;
}

// ---------------------------------------------------------------- shared widgets
Widget tf(
  TextEditingController c,
  String label, {
  int lines = 1,
  TextInputType? type,
  bool req = false,
  int? maxWords,
  bool obscure = false,
  String? hint,
  bool numeric = false,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: TextFormField(
      controller: c,
      minLines: lines,
      maxLines: obscure ? 1 : (lines == 1 ? 1 : lines + 4),
      keyboardType: type ?? (lines > 1 ? TextInputType.multiline : TextInputType.text),
      obscureText: obscure,
      decoration: InputDecoration(
        labelText: req ? '$label *' : label,
        hintText: hint,
        border: const OutlineInputBorder(),
        alignLabelWithHint: lines > 1,
      ),
      validator: (v) {
        final s = (v ?? '').trim();
        if (req && s.isEmpty) return 'Required';
        if (numeric && s.isNotEmpty && ((double.tryParse(s) ?? -1) <= 0)) return 'Enter a number greater than 0';
        if (maxWords != null && wordCount(s) > maxWords) {
          return 'Maximum $maxWords words (now ${wordCount(s)})';
        }
        return null;
      },
    ),
  );
}

class DocStream extends StatelessWidget {
  final Query<Json> query;
  final Widget Function(BuildContext, List<QueryDocumentSnapshot<Json>>) builder;
  const DocStream({super.key, required this.query, required this.builder});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Json>>(
      stream: query.snapshots(),
      builder: (c, s) {
        if (s.hasError) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        return builder(c, s.data!.docs);
      },
    );
  }
}

class EmptyView extends StatelessWidget {
  final String text;
  const EmptyView(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(text, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).hintColor)),
        ),
      );
}

class SearchableList extends StatefulWidget {
  final List<QueryDocumentSnapshot<Json>> docs;
  final String Function(Json) titleOf;
  final String Function(Json)? subtitleOf;
  final String Function(Json)? searchOf;
  final Widget? Function(Json)? trailing;
  final void Function(QueryDocumentSnapshot<Json>) onTap;
  final String empty;
  const SearchableList({
    super.key,
    required this.docs,
    required this.titleOf,
    required this.onTap,
    this.subtitleOf,
    this.searchOf,
    this.trailing,
    this.empty = 'Nothing here yet.',
  });
  @override
  State<SearchableList> createState() => _SearchableListState();
}

class _SearchableListState extends State<SearchableList> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final list = widget.docs.where((d) {
      if (q.isEmpty) return true;
      final data = d.data();
      final s = widget.searchOf?.call(data) ??
          '${widget.titleOf(data)} ${widget.subtitleOf?.call(data) ?? ''}';
      return s.toLowerCase().contains(q.toLowerCase());
    }).toList()
      ..sort((a, b) => widget.titleOf(a.data()).toLowerCase().compareTo(widget.titleOf(b.data()).toLowerCase()));
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          child: TextField(
            decoration: InputDecoration(
              hintText: '${t(context, 'Search')}...',
              prefixIcon: const Icon(Icons.search),
              isDense: true,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
            ),
            onChanged: (v) => setState(() => q = v),
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? EmptyView(widget.empty)
              : ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (c, i) {
                    final d = list[i];
                    final data = d.data();
                    final sub = widget.subtitleOf?.call(data);
                    return ListTile(
                      title: Text(widget.titleOf(data), style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: sub == null || sub.isEmpty
                          ? null
                          : Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                      trailing: widget.trailing?.call(data),
                      onTap: () => widget.onTap(d),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class Section extends StatelessWidget {
  final String title;
  final String? text;
  const Section(this.title, this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    if (text == null || text!.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
          const SizedBox(height: 4),
          SelectableText(text!),
        ],
      ),
    );
  }
}

class Badge2 extends StatelessWidget {
  final String text;
  final Color color;
  const Badge2(this.text, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(right: 6),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
      );
}

Future<void> pushPage(BuildContext c, String title, Widget body) {
  return Navigator.push(
    c,
    MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: Text(title)), body: body)),
  );
}
