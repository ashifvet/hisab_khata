import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'core.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _user = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _first = TextEditingController();
  final _last = TextEditingController();
  bool register = false;
  bool busy = false;
  String? error;

  String _msg(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
      case 'invalid-login-credentials':
        return 'Wrong username or password.';
      case 'email-already-in-use':
        return 'This username is already taken.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'network-request-failed':
        return 'No internet connection. You need internet for the first login.';
      case 'operation-not-allowed':
        return 'Enable Email/Password sign-in in Firebase Console > Authentication.';
      default:
        return e.message ?? e.code;
    }
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      busy = true;
      error = null;
    });
    final uname = _user.text.trim().toLowerCase();
    final pass = _pass.text;
    final auth = FirebaseAuth.instance;
    final email = usernameToEmail(uname);
    try {
      if (register) {
        final cred = await auth.createUserWithEmailAndPassword(email: email, password: pass);
        await fs.collection('users').doc(cred.user!.uid).set({
          'username': uname,
          'firstName': _first.text.trim(),
          'lastName': _last.text.trim(),
          'email': '',
          'phone': '',
          'location': '',
          'role': 'user',
          'createdAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      } else {
        try {
          await auth.signInWithEmailAndPassword(email: email, password: pass);
        } on FirebaseAuthException catch (e) {
          // First start of the whole system: create the default administrator.
          final isDefaultAdmin = uname == kAdminUsername && pass == kAdminPassword;
          final missing = e.code == 'user-not-found' ||
              e.code == 'invalid-credential' ||
              e.code == 'invalid-login-credentials';
          if (isDefaultAdmin && missing) {
            final cred = await auth.createUserWithEmailAndPassword(email: email, password: pass);
            await fs.collection('users').doc(cred.user!.uid).set({
              'username': kAdminUsername,
              'firstName': 'Admin',
              'lastName': '',
              'email': '',
              'phone': '',
              'location': '',
              'role': 'admin',
              'createdAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
          } else {
            rethrow;
          }
        }
      }
    } on FirebaseAuthException catch (e) {
      error = _msg(e);
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _form,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.asset('assets/icon.png', width: 96, height: 96,
                          errorBuilder: (_, __, ___) => Icon(Icons.menu_book, size: 80, color: cs.primary)),
                    ),
                    const SizedBox(height: 12),
                    Text('My Diary', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(register ? 'Create a new account' : 'Login to continue',
                        style: TextStyle(color: Theme.of(context).hintColor)),
                    const SizedBox(height: 18),
                    if (register) ...[
                      Row(children: [
                        Expanded(child: tf(_first, 'First name', req: true)),
                        const SizedBox(width: 8),
                        Expanded(child: tf(_last, 'Last name')),
                      ]),
                    ],
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: TextFormField(
                        controller: _user,
                        autocorrect: false,
                        decoration: const InputDecoration(
                            labelText: 'Username', prefixIcon: Icon(Icons.person), border: OutlineInputBorder()),
                        validator: (v) {
                          final s = (v ?? '').trim().toLowerCase();
                          if (s.isEmpty) return 'Required';
                          if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(s)) {
                            return '3-20 letters, numbers or _';
                          }
                          if (register && s == kAdminUsername) return 'This username is reserved';
                          return null;
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: TextFormField(
                        controller: _pass,
                        obscureText: true,
                        decoration: const InputDecoration(
                            labelText: 'Password', prefixIcon: Icon(Icons.lock), border: OutlineInputBorder()),
                        validator: (v) => (v ?? '').length < 6 ? 'At least 6 characters' : null,
                      ),
                    ),
                    if (register)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: TextFormField(
                          controller: _pass2,
                          obscureText: true,
                          decoration: const InputDecoration(
                              labelText: 'Confirm password', prefixIcon: Icon(Icons.lock_outline), border: OutlineInputBorder()),
                          validator: (v) => v != _pass.text ? 'Passwords do not match' : null,
                        ),
                      ),
                    if (error != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(error!, style: TextStyle(color: cs.error), textAlign: TextAlign.center),
                      ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: FilledButton(
                        onPressed: busy ? null : _submit,
                        child: busy
                            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                            : Text(register ? 'Register' : 'Login'),
                      ),
                    ),
                    TextButton(
                      onPressed: busy ? null : () => setState(() {
                        register = !register;
                        error = null;
                      }),
                      child: Text(register ? 'Already have an account? Login' : 'New user? Create account'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
