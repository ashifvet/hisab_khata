import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:provider/provider.dart';

import 'core.dart';

typedef Snap = DocumentSnapshot<Json>;

/// Creates (or updates) a record in a shared collection.
Future<void> saveDoc(BuildContext c, String coll, Snap? existing, Json data) async {
  final st = c.read<AppState>();
  if (existing != null) {
    await fast(existing.reference.update(data));
    return;
  }
  final ref = fs.collection(coll).doc();
  await fast(ref.set({
    ...data,
    'createdBy': st.uid,
    'createdByName': st.fullName,
    'createdAt': FieldValue.serverTimestamp(),
  }));
}

class Choice extends StatelessWidget {
  final String label;
  final Map<String, String> options;
  final String? value;
  final ValueChanged<String?> onChanged;
  final bool showError;
  const Choice({
    super.key,
    required this.label,
    required this.options,
    required this.value,
    required this.onChanged,
    this.showError = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<String>(
              emptySelectionAllowed: true,
              showSelectedIcon: false,
              segments: options.entries.map((e) => ButtonSegment<String>(value: e.key, label: Text(e.value))).toList(),
              selected: value == null ? <String>{} : <String>{value!},
              onSelectionChanged: (s) => onChanged(s.isEmpty ? null : s.first),
            ),
          ),
          if (showError && value == null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('Please choose one', style: TextStyle(color: Theme.of(context).colorScheme.error, fontSize: 12)),
            ),
        ],
      ),
    );
  }
}

Widget _saveBtn(VoidCallback onTap, bool edit, bool busy) => Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 24),
      child: FilledButton.icon(
        onPressed: busy ? null : onTap,
        icon: busy
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.save),
        label: Text(edit ? 'Update' : 'Save'),
      ),
    );

String _v(Snap? s, String k) => '${s?.data()?[k] ?? ''}';

// ======================================================================= ADD PAGE
class AddPage extends StatelessWidget {
  const AddPage({super.key});
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Column(
        children: [
          TabBar(tabs: [
            Tab(text: t(context, 'Company')),
            Tab(text: t(context, 'Medicine')),
            Tab(text: t(context, 'Disease')),
            Tab(text: t(context, 'P&S')),
          ]),
          const Expanded(
            child: TabBarView(children: [
              CompanyForm(),
              MedicineForm(header: ImportCard()),
              DiseaseForm(),
              ProblemForm(),
            ]),
          ),
        ],
      ),
    );
  }
}

// ======================================================================= COMPANY
class CompanyForm extends StatefulWidget {
  final Snap? existing;
  const CompanyForm({super.key, this.existing});
  @override
  State<CompanyForm> createState() => _CompanyFormState();
}

class _CompanyFormState extends State<CompanyForm> with AutomaticKeepAliveClientMixin {
  final _key = GlobalKey<FormState>();
  late final name = TextEditingController(text: _v(widget.existing, 'name'));
  late final note = TextEditingController(text: _v(widget.existing, 'note'));
  bool busy = false;
  @override
  bool get wantKeepAlive => true;

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    setState(() => busy = true);
    final n = name.text.trim();
    if (widget.existing == null) {
      try {
        final dup = await fs.collection('companies').where('name', isEqualTo: n).limit(1).get();
        if (dup.docs.isNotEmpty) {
          if (mounted) snack(context, 'This company already exists.');
          setState(() => busy = false);
          return;
        }
      } catch (_) {}
    }
    if (!mounted) return;
    await saveDoc(context, 'companies', widget.existing, {'name': n, 'note': note.text.trim()});
    if (!mounted) return;
    setState(() => busy = false);
    if (widget.existing != null) {
      Navigator.pop(context);
    } else {
      name.clear();
      note.clear();
      snack(context, 'Company saved');
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _key,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        tf(name, 'Company name', req: true),
        tf(note, 'Note (optional)', lines: 2),
        _saveBtn(_save, widget.existing != null, busy),
      ]),
    );
  }
}

// ======================================================================= MEDICINE
class MedicineForm extends StatefulWidget {
  final Snap? existing;
  final Widget? header;
  const MedicineForm({super.key, this.existing, this.header});
  @override
  State<MedicineForm> createState() => _MedicineFormState();
}

class _MedicineFormState extends State<MedicineForm> with AutomaticKeepAliveClientMixin {
  final _key = GlobalKey<FormState>();
  late final name = TextEditingController(text: _v(widget.existing, 'name'));
  late final components = TextEditingController(text: _v(widget.existing, 'components'));
  late final indications = TextEditingController(text: _v(widget.existing, 'indications'));
  late final dose = TextEditingController(text: _v(widget.existing, 'dose'));
  late final pregnancy = TextEditingController(text: _v(widget.existing, 'pregnancy'));
  late final details = TextEditingController(text: _v(widget.existing, 'details'));
  late String? companyId = widget.existing?.data()?['companyId'] as String?;
  late String? preg = widget.existing?.data()?['pregnancySafe'] as String?;
  late String? pet = (widget.existing?.data()?['petSafety'] == 'unknown') ? null : widget.existing?.data()?['petSafety'] as String?;
  final Map<String, String> _names = {};
  bool busy = false, tried = false;
  @override
  bool get wantKeepAlive => true;

  Future<void> _save() async {
    setState(() => tried = true);
    if (!_key.currentState!.validate() || pet == null || companyId == null) return;
    setState(() => busy = true);
    await saveDoc(context, 'medicines', widget.existing, {
      'name': name.text.trim(),
      'companyId': companyId,
      'companyName': _names[companyId] ?? '',
      'components': components.text.trim(),
      'indications': indications.text.trim(),
      'dose': dose.text.trim(),
      'pregnancy': pregnancy.text.trim(),
      'pregnancySafe': preg ?? 'unknown',
      'petSafety': pet,
      'details': details.text.trim(),
    });
    if (!mounted) return;
    setState(() => busy = false);
    if (widget.existing != null) {
      Navigator.pop(context);
    } else {
      for (final c in [name, components, indications, dose, pregnancy, details]) {
        c.clear();
      }
      setState(() {
        preg = null;
        pet = null;
        tried = false;
      });
      snack(context, 'Medicine saved');
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _key,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        if (widget.header != null) widget.header!,
        StreamBuilder<QuerySnapshot<Json>>(
          stream: fs.collection('companies').snapshots(),
          builder: (c, s) {
            final docs = (s.data?.docs ?? []).toList()
              ..sort((a, b) => '${a.data()['name']}'.toLowerCase().compareTo('${b.data()['name']}'.toLowerCase()));
            for (final d in docs) {
              _names[d.id] = '${d.data()['name']}';
            }
            final value = docs.any((d) => d.id == companyId) ? companyId : null;
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: DropdownButtonFormField<String>(
                value: value,
                isExpanded: true,
                decoration: InputDecoration(
                  labelText: 'Company *',
                  border: const OutlineInputBorder(),
                  helperText: docs.isEmpty ? 'Add a company first (Company tab)' : null,
                ),
                items: docs
                    .map((d) => DropdownMenuItem(value: d.id, child: Text('${d.data()['name']}', overflow: TextOverflow.ellipsis)))
                    .toList(),
                onChanged: (v) => setState(() => companyId = v),
                validator: (v) => v == null ? 'Choose a company' : null,
              ),
            );
          },
        ),
        tf(name, 'Medicine name', req: true),
        tf(components, 'Components (generic names & strength)', lines: 2),
        tf(indications, 'When to use', lines: 3),
        tf(dose, 'Dose', lines: 3),
        Choice(
          label: 'Pregnancy',
          options: const {'safe': 'Safe', 'unsafe': 'Unsafe', 'unknown': 'Not sure'},
          value: preg,
          onChanged: (v) => setState(() => preg = v),
        ),
        tf(pregnancy, 'Pregnancy / lactation note', lines: 2),
        Choice(
          label: 'Pet safety',
          options: const {'safe': 'Safe', 'unsafe': 'Unsafe'},
          value: pet,
          showError: tried,
          onChanged: (v) => setState(() => pet = v),
        ),
        tf(details, 'Any other details', lines: 4),
        _saveBtn(_save, widget.existing != null, busy),
      ]),
    );
  }
}

// ======================================================================= DISEASE
class DiseaseForm extends StatefulWidget {
  final Snap? existing;
  const DiseaseForm({super.key, this.existing});
  @override
  State<DiseaseForm> createState() => _DiseaseFormState();
}

class _DiseaseFormState extends State<DiseaseForm> with AutomaticKeepAliveClientMixin {
  final _key = GlobalKey<FormState>();
  late final owner = TextEditingController(text: _v(widget.existing, 'ownerName'));
  late final phone = TextEditingController(text: _v(widget.existing, 'phone'));
  final fee = TextEditingController();
  late final title = TextEditingController(text: _v(widget.existing, 'title'));
  late final temp = TextEditingController(text: _v(widget.existing, 'temperature'));
  late final symptoms = TextEditingController(text: _v(widget.existing, 'symptoms'));
  late final findings = TextEditingController(text: _v(widget.existing, 'findings'));
  late final treatment = TextEditingController(text: _v(widget.existing, 'treatment'));
  late String? location = widget.existing?.data()?['location'] as String?;
  late String? skin = widget.existing?.data()?['skinParasite'] as String?;
  late String? prog = widget.existing?.data()?['prognosis'] as String?;
  bool busy = false, tried = false;
  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    // load the (protected) fee when the creator/admin edits a private record
    final e = widget.existing;
    if (e != null && e.data()?['location'] == 'Private') {
      fs.collection('diseaseFees').doc(e.id).get().then((s) {
        final f = s.data()?['fee'];
        if (f != null && mounted) fee.text = '$f';
      }).catchError((_) {});
    }
  }

  Future<void> _save() async {
    setState(() => tried = true);
    if (!_key.currentState!.validate() || location == null || skin == null || prog == null) return;
    setState(() => busy = true);
    final st = context.read<AppState>();
    final data = <String, dynamic>{
      'ownerName': owner.text.trim(),
      'phone': phone.text.trim(),
      'location': location,
      'title': title.text.trim(),
      'temperature': temp.text.trim(),
      'symptoms': symptoms.text.trim(),
      'findings': findings.text.trim(),
      'skinParasite': skin,
      'treatment': treatment.text.trim(),
      'prognosis': prog,
    };
    final ex = widget.existing;
    final ref = ex?.reference ?? fs.collection('diseases').doc();
    final ownerUid = (ex?.data()?['createdBy'] as String?) ?? st.uid!;
    final batch = fs.batch();
    if (ex == null) {
      batch.set(ref, {
        ...data,
        'createdBy': st.uid,
        'createdByName': st.fullName,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      batch.update(ref, data);
    }
    final feeRef = fs.collection('diseaseFees').doc(ref.id);
    String? bizId;
    if (location == 'Private') {
      final amount = double.tryParse(fee.text.trim()) ?? 0;
      bizId = await ensureBusiness(ownerUid, st.prefs);
      batch.set(feeRef, {'fee': amount, 'createdBy': ownerUid});
      // The private fee is added to the INCOME section of the creator's cashbook.
      final cashRef = fs.collection('users').doc(ownerUid).collection('businesses').doc(bizId).collection('cash').doc('disease_${ref.id}');
      batch.set(
        cashRef,
        {
          'type': 'in',
          'amount': amount,
          'category': 'Private visit fee',
          'note': '${title.text.trim()} (${owner.text.trim()})',
          if (ex == null) 'date': Timestamp.now(),
          'createdAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
    } else if (ex != null && ex.data()?['location'] == 'Private') {
      // changed from Private to Hospital: remove the fee + the cashbook income
      batch.delete(feeRef);
      final b = await ensureBusiness(ownerUid, st.prefs);
      batch.delete(fs.collection('users').doc(ownerUid).collection('businesses').doc(b).collection('cash').doc('disease_${ref.id}'));
    }
    await fast(batch.commit());
    if (!mounted) return;
    setState(() => busy = false);
    if (ex != null) {
      Navigator.pop(context);
    } else {
      for (final c in [owner, phone, fee, title, temp, symptoms, findings, treatment]) {
        c.clear();
      }
      setState(() {
        location = null;
        skin = null;
        prog = null;
        tried = false;
      });
      snack(context, bizId != null ? 'Saved. Fee added to your cashbook income.' : 'Disease saved');
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _key,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        tf(owner, 'Name of the owner', req: true),
        tf(phone, 'Phone number', type: TextInputType.phone, req: true),
        Choice(
          label: 'Location',
          options: const {'Hospital': 'Hospital', 'Private': 'Private'},
          value: location,
          showError: tried,
          onChanged: (v) => setState(() => location = v),
        ),
        if (location == 'Private') ...[
          tf(fee, 'Fee taken (Tk)', type: TextInputType.number, req: true, numeric: true, hint: 'Visible only to you and the admin'),
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text('This amount is added to the Income of your Cashbook and is hidden from other users.',
                style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
          ),
        ],
        tf(title, 'Title of the disease', req: true),
        tf(temp, 'Temperature', type: TextInputType.text, hint: 'e.g. 103.5 °F'),
        tf(symptoms, 'Signs & symptoms told by the owner', lines: 3),
        tf(findings, 'Clinical findings', lines: 3),
        Choice(
          label: 'Skin parasite',
          options: const {'present': 'Present', 'absent': 'Absent'},
          value: skin,
          showError: tried,
          onChanged: (v) => setState(() => skin = v),
        ),
        tf(treatment, 'Treatment (max 1000 words)', lines: 6, maxWords: 1000),
        Choice(
          label: 'Prognosis after 10 days of treatment',
          options: const {'good': 'Good', 'poor': 'Poor'},
          value: prog,
          showError: tried,
          onChanged: (v) => setState(() => prog = v),
        ),
        _saveBtn(_save, widget.existing != null, busy),
      ]),
    );
  }
}

// ======================================================================= PROBLEM & SOLUTION
class ProblemForm extends StatefulWidget {
  final Snap? existing;
  const ProblemForm({super.key, this.existing});
  @override
  State<ProblemForm> createState() => _ProblemFormState();
}

class _ProblemFormState extends State<ProblemForm> with AutomaticKeepAliveClientMixin {
  final _key = GlobalKey<FormState>();
  late final title = TextEditingController(text: _v(widget.existing, 'title'));
  late final problem = TextEditingController(text: _v(widget.existing, 'problem'));
  late final solution = TextEditingController(text: _v(widget.existing, 'solution'));
  late final prognosis = TextEditingController(text: _v(widget.existing, 'prognosis'));
  bool busy = false;
  @override
  bool get wantKeepAlive => true;

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    setState(() => busy = true);
    await saveDoc(context, 'problems', widget.existing, {
      'title': title.text.trim(),
      'problem': problem.text.trim(),
      'solution': solution.text.trim(),
      'prognosis': prognosis.text.trim(),
    });
    if (!mounted) return;
    setState(() => busy = false);
    if (widget.existing != null) {
      Navigator.pop(context);
    } else {
      for (final c in [title, problem, solution, prognosis]) {
        c.clear();
      }
      snack(context, 'Saved');
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Form(
      key: _key,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        tf(title, 'Title', req: true),
        tf(problem, 'Problems (max 1000 words)', lines: 6, maxWords: 1000, req: true),
        tf(solution, 'Solutions (max 2000 words)', lines: 8, maxWords: 2000, req: true),
        tf(prognosis, 'Prognosis (max 300 words)', lines: 4, maxWords: 300),
        _saveBtn(_save, widget.existing != null, busy),
      ]),
    );
  }
}

// ======================================================================= IMPORT bundled medicine database
class ImportCard extends StatefulWidget {
  const ImportCard({super.key});
  @override
  State<ImportCard> createState() => _ImportCardState();
}

class _ImportCardState extends State<ImportCard> {
  bool busy = false;
  String progress = '';

  String _slug(String s) => s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_');

  Future<void> _import() async {
    setState(() {
      busy = true;
      progress = 'Checking connection...';
    });
    try {
      // must be online: also protects against two users importing at once
      final seed = await fs.collection('meta').doc('seed').get(const GetOptions(source: Source.server));
      if (seed.exists && seed.data()?['done'] == true) {
        if (mounted) snack(context, 'Already imported by another user.');
        return;
      }
      final raw = await rootBundle.loadString('assets/data/medicines.json');
      final data = jsonDecode(raw) as Map<String, dynamic>;
      final comps = (data['companies'] as List).cast<Map<String, dynamic>>();
      final meds = (data['medicines'] as List).cast<Map<String, dynamic>>();
      var batch = fs.batch();
      var n = 0, written = 0;
      final total = comps.length + meds.length;
      Future<void> flush() async {
        await batch.commit();
        batch = fs.batch();
        n = 0;
        if (mounted) setState(() => progress = 'Importing... $written / $total');
      }

      for (final c in comps) {
        batch.set(fs.collection('companies').doc('c_${_slug('${c['name']}')}'), {
          'name': c['name'],
          'note': c['listed'] == true ? '' : 'Listed veterinary company - no medicine imported yet',
          'createdBy': 'system',
          'createdByName': 'Imported database',
          'createdAt': FieldValue.serverTimestamp(),
        });
        n++;
        written++;
        if (n >= 400) await flush();
      }
      for (var i = 0; i < meds.length; i++) {
        final m = meds[i];
        batch.set(fs.collection('medicines').doc('m_${i.toString().padLeft(5, '0')}'), {
          'name': m['name'],
          'companyId': 'c_${_slug('${m['company']}')}',
          'companyName': m['company'],
          'components': m['components'],
          'indications': m['indications'],
          'dose': m['dose'],
          'pregnancy': m['pregnancy'],
          'pregnancySafe': m['pregnancySafe'],
          'petSafety': m['petSafety'],
          'details': m['details'],
          'createdBy': 'system',
          'createdByName': 'Imported database',
          'createdAt': FieldValue.serverTimestamp(),
        });
        n++;
        written++;
        if (n >= 400) await flush();
      }
      if (n > 0) await flush();
      await fs.collection('meta').doc('seed').set({
        'done': true,
        'medicines': meds.length,
        'companies': comps.length,
        'by': context.mounted ? context.read<AppState>().uid : '',
        'at': FieldValue.serverTimestamp(),
      });
      if (mounted) snack(context, 'Imported ${meds.length} medicines and ${comps.length} companies.');
    } catch (e) {
      if (mounted) snack(context, 'Import failed (internet needed): $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: fs.collection('meta').doc('seed').snapshots(),
      builder: (c, s) {
        final done = s.data?.data()?['done'] == true;
        return Card(
          margin: const EdgeInsets.only(bottom: 14),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Medicine database', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(
                  done
                      ? 'The built-in veterinary medicine database has already been imported (${s.data?.data()?['medicines'] ?? ''} medicines). This option is now disabled.'
                      : 'Import the built-in database of Bangladeshi veterinary medicines (collected from MedEx & Arogga). It can be imported only once and becomes visible to all users.',
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: (done || busy || !s.hasData) ? null : _import,
                  icon: busy
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.download),
                  label: Text(done ? 'Already imported' : (busy ? progress : 'Import medicines')),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
