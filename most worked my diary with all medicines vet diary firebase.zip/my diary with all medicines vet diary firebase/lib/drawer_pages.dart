import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import 'core.dart';
import 'hisab.dart';

// ======================================================================= Edit profile
class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});
  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController first, last, email, phone, location;

  @override
  void initState() {
    super.initState();
    final p = context.read<AppState>().profile;
    first = TextEditingController(text: '${p['firstName'] ?? ''}');
    last = TextEditingController(text: '${p['lastName'] ?? ''}');
    email = TextEditingController(text: '${p['email'] ?? ''}');
    phone = TextEditingController(text: '${p['phone'] ?? ''}');
    location = TextEditingController(text: '${p['location'] ?? ''}');
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final uid = context.read<AppState>().uid;
    await fast(fs.collection('users').doc(uid).update({
      'firstName': first.text.trim(),
      'lastName': last.text.trim(),
      'email': email.text.trim(),
      'phone': phone.text.trim(),
      'location': location.text.trim(),
    }));
    if (mounted) {
      snack(context, 'Profile saved');
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          tf(first, 'First name', req: true),
          tf(last, 'Last name'),
          tf(email, 'Email', type: TextInputType.emailAddress),
          tf(phone, 'Phone number', type: TextInputType.phone),
          tf(location, 'Location'),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: Text(t(context, 'Save'))),
        ],
      ),
    );
  }
}

// ======================================================================= Settings
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<void> _changePassword(BuildContext context) async {
    final old = TextEditingController(), nw = TextEditingController(), cf = TextEditingController();
    final key = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t(ctx, 'Change password')),
        content: Form(
          key: key,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              tf(old, 'Current password', obscure: true, req: true),
              tf(nw, 'New password', obscure: true, req: true),
              tf(cf, 'Confirm new password', obscure: true, req: true),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                if (key.currentState!.validate()) {
                  if (nw.text != cf.text) return;
                  if (nw.text.length < 6) return;
                  Navigator.pop(ctx, true);
                }
              },
              child: const Text('Change')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    try {
      final user = FirebaseAuth.instance.currentUser!;
      await user.reauthenticateWithCredential(EmailAuthProvider.credential(email: user.email!, password: old.text));
      await user.updatePassword(nw.text);
      if (context.mounted) snack(context, 'Password changed');
    } on FirebaseAuthException catch (e) {
      if (context.mounted) snack(context, e.message ?? e.code);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = Provider.of<AppState>(context);
    return ListView(
      children: [
        SwitchListTile(
          secondary: const Icon(Icons.dark_mode_outlined),
          title: Text(t(context, 'Dark mode')),
          value: s.themeMode == ThemeMode.dark,
          onChanged: s.setDark,
        ),
        ListTile(
          leading: const Icon(Icons.language),
          title: Text(t(context, 'Language')),
          trailing: DropdownButton<String>(
            value: s.lang,
            underline: const SizedBox.shrink(),
            items: const [
              DropdownMenuItem(value: 'en', child: Text('English')),
              DropdownMenuItem(value: 'bn', child: Text('বাংলা')),
            ],
            onChanged: (v) => s.setLang(v ?? 'en'),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.lock_outline),
          title: Text(t(context, 'Change password')),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _changePassword(context),
        ),
      ],
    );
  }
}

// ======================================================================= About
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  Widget _row(IconData i, String k, String v, {VoidCallback? onTap}) => ListTile(
        leading: Icon(i),
        title: Text(k, style: const TextStyle(fontSize: 12)),
        subtitle: Text(v, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        onTap: onTap,
      );

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const SizedBox(height: 20),
        const Center(child: CircleAvatar(radius: 44, child: Icon(Icons.medical_services, size: 44))),
        const SizedBox(height: 12),
        const Center(child: Text('My Diary', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        FutureBuilder<PackageInfo>(
          future: PackageInfo.fromPlatform(),
          builder: (c, s) => Center(child: Text('${t(context, 'Version')} ${s.data?.version ?? kAppVersionName}')),
        ),
        const SizedBox(height: 16),
        _row(Icons.badge_outlined, 'Name', 'Dr. MD. ASHIF IQBAL'),
        _row(Icons.school_outlined, 'Degrees', 'DVM, MSc, BCS'),
        _row(Icons.work_outline, 'Designation', 'Veterinary Surgeon, Maheshpur'),
        _row(Icons.phone, 'Phone', '01711989236', onTap: () => launchUrl(Uri.parse('tel:01711989236'))),
        _row(Icons.home_outlined, 'Hometown', 'Kushtia'),
      ],
    );
  }
}

// ======================================================================= Announcements (admin)
class AnnouncementsAdminPage extends StatefulWidget {
  const AnnouncementsAdminPage({super.key});
  @override
  State<AnnouncementsAdminPage> createState() => _AnnouncementsAdminPageState();
}

class _AnnouncementsAdminPageState extends State<AnnouncementsAdminPage> {
  final _form = GlobalKey<FormState>();
  final title = TextEditingController(),
      content = TextEditingController(),
      telegram = TextEditingController(),
      website = TextEditingController(),
      times = TextEditingController(text: '1');
  bool cancelAllowed = true;

  Future<void> _send() async {
    if (!_form.currentState!.validate()) return;
    await fast(fs.collection('announcements').add({
      'title': title.text.trim(),
      'content': content.text.trim(),
      'telegram': telegram.text.trim(),
      'website': website.text.trim(),
      'cancelAllowed': cancelAllowed,
      'times': int.tryParse(times.text.trim()) ?? 1,
      'active': true,
      'createdAt': FieldValue.serverTimestamp(),
    }));
    title.clear();
    content.clear();
    telegram.clear();
    website.clear();
    times.text = '1';
    if (mounted) snack(context, 'Announcement published');
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Form(
          key: _form,
          child: Column(children: [
            tf(title, 'Title of the dialog box', req: true),
            tf(content, 'Content of the dialog box', lines: 4, req: true),
            tf(telegram, 'Telegram link', hint: 'https://t.me/yourchannel'),
            tf(website, 'Website link', hint: 'https://example.com'),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Cancel allowed'),
              subtitle: Text(cancelAllowed ? 'Yes - user can close the dialog' : 'No - user must use Telegram / Web button'),
              value: cancelAllowed,
              onChanged: (v) => setState(() => cancelAllowed = v),
            ),
            tf(times, 'How many times will the user see it?', type: TextInputType.number, req: true),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(onPressed: _send, icon: const Icon(Icons.send), label: const Text('Publish')),
            ),
          ]),
        ),
        const Divider(height: 32),
        const Text('Published announcements', style: TextStyle(fontWeight: FontWeight.bold)),
        StreamBuilder<QuerySnapshot<Json>>(
          stream: fs.collection('announcements').snapshots(),
          builder: (c, s) {
            if (!s.hasData) return const Padding(padding: EdgeInsets.all(16), child: LinearProgressIndicator());
            final docs = s.data!.docs.toList()
              ..sort((a, b) => toDate(b.data()['createdAt']).compareTo(toDate(a.data()['createdAt'])));
            if (docs.isEmpty) return const EmptyView('No announcements yet.');
            return Column(
              children: docs.map((d) {
                final m = d.data();
                return Card(
                  child: ListTile(
                    title: Text('${m['title']}'),
                    subtitle: Text('${m['content']}\nShown ${m['times']}x  |  Cancel: ${m['cancelAllowed'] == true ? 'Yes' : 'No'}',
                        maxLines: 4, overflow: TextOverflow.ellipsis),
                    isThreeLine: true,
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Switch(
                          value: m['active'] == true,
                          onChanged: (v) => fast(d.reference.update({'active': v}))),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          if (await confirmDlg(context, 'Delete this announcement?')) {
                            await fast(d.reference.delete());
                          }
                        },
                      ),
                    ]),
                  ),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}

// ======================================================================= App update (admin)
class AppUpdateAdminPage extends StatefulWidget {
  const AppUpdateAdminPage({super.key});
  @override
  State<AppUpdateAdminPage> createState() => _AppUpdateAdminPageState();
}

class _AppUpdateAdminPageState extends State<AppUpdateAdminPage> {
  final latest = TextEditingController(),
      min = TextEditingController(),
      url = TextEditingController(),
      msg = TextEditingController();
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    fs.collection('config').doc('app').get().then((s) {
      final d = s.data() ?? {};
      latest.text = '${d['latestVersion'] ?? kAppVersionName}';
      min.text = '${d['minVersion'] ?? '1.0.0'}';
      url.text = '${d['updateUrl'] ?? ''}';
      msg.text = '${d['message'] ?? 'A new version of My Diary is available.'}';
      if (mounted) setState(() => loaded = true);
    }).catchError((_) {
      if (mounted) setState(() => loaded = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!loaded) return const Center(child: CircularProgressIndicator());
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Users compare their installed version with these values every time they open the app.\n'
          '• Latest version higher than installed  ->  "Update" dialog (user may skip)\n'
          '• Minimum version higher than installed ->  FORCE update (user cannot enter the app)',
        ),
        const SizedBox(height: 12),
        tf(latest, 'Latest version (e.g. 1.0.3)', req: true),
        tf(min, 'Minimum allowed version (force update below this)', req: true),
        tf(url, 'Download / Play Store link', req: true),
        tf(msg, 'Message shown to users', lines: 3),
        FilledButton.icon(
          icon: const Icon(Icons.cloud_upload),
          label: const Text('Publish to Firebase'),
          onPressed: () async {
            await fast(fs.collection('config').doc('app').set({
              'latestVersion': latest.text.trim(),
              'minVersion': min.text.trim(),
              'updateUrl': url.text.trim(),
              'message': msg.text.trim(),
              'updatedAt': FieldValue.serverTimestamp(),
            }));
            if (context.mounted) snack(context, 'Published');
          },
        ),
      ],
    );
  }
}

// ======================================================================= Users & admins (admin)
class UsersAdminPage extends StatelessWidget {
  const UsersAdminPage({super.key});

  Future<void> _newAdmin(BuildContext context) async {
    final u = TextEditingController(), p = TextEditingController(), n = TextEditingController();
    final key = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Create new administrator'),
        content: Form(
          key: key,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              tf(n, 'Full name', req: true),
              tf(u, 'Username', req: true),
              tf(p, 'Password (min 6)', req: true, obscure: true),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                if (key.currentState!.validate() && p.text.length >= 6) Navigator.pop(ctx, true);
              },
              child: const Text('Create')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    try {
      // a second Firebase app instance is used so the current admin stays logged in
      FirebaseApp app;
      try {
        app = Firebase.app('secondary');
      } catch (_) {
        app = await Firebase.initializeApp(name: 'secondary', options: Firebase.app().options);
      }
      final auth2 = FirebaseAuth.instanceFor(app: app);
      final uname = u.text.trim().toLowerCase();
      final cred = await auth2.createUserWithEmailAndPassword(email: usernameToEmail(uname), password: p.text);
      await fast(fs.collection('users').doc(cred.user!.uid).set({
        'username': uname,
        'firstName': n.text.trim(),
        'lastName': '',
        'email': '',
        'phone': '',
        'location': '',
        'role': 'admin',
        'createdAt': FieldValue.serverTimestamp(),
      }));
      await auth2.signOut();
      if (context.mounted) snack(context, 'New admin created');
    } on FirebaseAuthException catch (e) {
      if (context.mounted) snack(context, e.message ?? e.code);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = context.read<AppState>();
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _newAdmin(context),
        icon: const Icon(Icons.person_add),
        label: const Text('New admin'),
      ),
      body: DocStream(
        query: fs.collection('users'),
        builder: (c, docs) {
          final list = docs.toList()
            ..sort((a, b) => '${a.data()['username']}'.compareTo('${b.data()['username']}'));
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (c, i) {
              final d = list[i];
              final m = d.data();
              final isAdm = m['role'] == 'admin';
              final name = '${m['firstName'] ?? ''} ${m['lastName'] ?? ''}'.trim();
              return ListTile(
                leading: CircleAvatar(child: Icon(isAdm ? Icons.shield : Icons.person)),
                title: Text(name.isEmpty ? '${m['username']}' : name),
                subtitle: Text('@${m['username']}  ${m['phone'] ?? ''}'),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'role') {
                      await fast(d.reference.update({'role': isAdm ? 'user' : 'admin'}));
                    } else if (v == 'hisab') {
                      if (!context.mounted) return;
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => Scaffold(
                                  appBar: AppBar(title: Text('Hisab of ${name.isEmpty ? m['username'] : name}')),
                                  body: HisabScreen(uid: d.id))));
                    }
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'hisab', child: Text('View Hisab data')),
                    if (d.id != me.uid)
                      PopupMenuItem(value: 'role', child: Text(isAdm ? 'Remove admin' : 'Make admin')),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
