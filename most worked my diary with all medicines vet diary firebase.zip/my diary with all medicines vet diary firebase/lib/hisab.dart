import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import 'core.dart';
import 'pdf_reports.dart';

const _green = Color(0xFF1B8A4B);
const _red = Color(0xFFD32F2F);

class Biz {
  final String uid, bid, name;
  const Biz(this.uid, this.bid, this.name);
  DocumentReference<Json> get ref => fs.collection('users').doc(uid).collection('businesses').doc(bid);
  CollectionReference<Json> c(String n) => ref.collection(n);
}

Future<List<Json>> _all(Query<Json> c) async =>
    (await c.get()).docs.map((d) => <String, dynamic>{...d.data(), 'id': d.id}).toList();

String _waNumber(String p) {
  final d = p.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('880')) return d;
  if (d.startsWith('0')) return '88$d';
  return d;
}

Future<void> _sms(String phones, String msg) =>
    launchUrl(Uri.parse('sms:$phones?body=${Uri.encodeComponent(msg)}'));
Future<void> _whatsapp(String phone, String msg) => launchUrl(
    Uri.parse('https://wa.me/${_waNumber(phone)}?text=${Uri.encodeComponent(msg)}'),
    mode: LaunchMode.externalApplication);

Future<DateTime?> _pickDate(BuildContext c, DateTime initial, {String? help}) => showDatePicker(
    context: c, initialDate: initial, firstDate: DateTime(2000), lastDate: DateTime(2100), helpText: help);

Future<String?> _textDialog(BuildContext c, String title, {String initial = ''}) async {
  final ctl = TextEditingController(text: initial);
  final key = GlobalKey<FormState>();
  return showDialog<String>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Form(key: key, child: tf(ctl, 'Name', req: true)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(
            onPressed: () {
              if (key.currentState!.validate()) Navigator.pop(ctx, ctl.text.trim());
            },
            child: const Text('OK')),
      ],
    ),
  );
}

// ======================================================================= HISAB ROOT
class HisabScreen extends StatefulWidget {
  final String uid;
  const HisabScreen({super.key, required this.uid});
  @override
  State<HisabScreen> createState() => _HisabScreenState();
}

class _HisabScreenState extends State<HisabScreen> {
  String? _bid;
  bool _creating = false;

  CollectionReference<Json> get _col => fs.collection('users').doc(widget.uid).collection('businesses');
  bool get _mine => widget.uid == context.read<AppState>().uid;

  void _select(String id) {
    setState(() => _bid = id);
    context.read<AppState>().prefs?.setString('bid_${widget.uid}', id);
  }

  Future<void> _add() async {
    final n = await _textDialog(context, 'New business / account');
    if (n == null) return;
    final r = _col.doc();
    await fast(r.set({'name': n, 'createdAt': FieldValue.serverTimestamp()}));
    _select(r.id);
  }

  Future<void> _delete(String id, String name) async {
    if (!await confirmDlg(context, 'Delete "$name" and ALL its data (customers, cashbook, stock, notes)?')) return;
    for (final sub in ['parties', 'txns', 'cash', 'products', 'stockOut', 'notes']) {
      final q = await _col.doc(id).collection(sub).get();
      final b = fs.batch();
      for (final d in q.docs) {
        b.delete(d.reference);
      }
      await fast(b.commit());
    }
    await fast(_col.doc(id).delete());
    if (!mounted) return;
    final p = context.read<AppState>().prefs;
    if (p?.getString('bid_${widget.uid}') == id) await p?.remove('bid_${widget.uid}');
    setState(() => _bid = null);
  }

  @override
  Widget build(BuildContext context) {
    final prefs = context.read<AppState>().prefs;
    return StreamBuilder<QuerySnapshot<Json>>(
      stream: _col.snapshots(),
      builder: (c, s) {
        if (s.hasError) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final docs = s.data!.docs.toList()
          ..sort((a, b) => toDate(a.data()['createdAt']).compareTo(toDate(b.data()['createdAt'])));
        if (docs.isEmpty) {
          if (_mine && !_creating) {
            _creating = true;
            WidgetsBinding.instance.addPostFrameCallback((_) async {
              await fast(_col.doc().set({'name': 'My Business', 'createdAt': FieldValue.serverTimestamp()}));
              _creating = false;
            });
          }
          return _mine ? const Center(child: CircularProgressIndicator()) : const EmptyView('This user has no business yet.');
        }
        final saved = prefs?.getString('bid_${widget.uid}');
        final cur = docs.any((d) => d.id == _bid)
            ? _bid!
            : (docs.any((d) => d.id == saved) ? saved! : docs.first.id);
        _bid = cur;
        final curDoc = docs.firstWhere((d) => d.id == cur);
        final biz = Biz(widget.uid, cur, '${curDoc.data()['name']}');
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 4, 0),
              child: Row(children: [
                const Icon(Icons.store),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: cur,
                      isExpanded: true,
                      items: docs
                          .map((d) => DropdownMenuItem(value: d.id, child: Text('${d.data()['name']}', overflow: TextOverflow.ellipsis)))
                          .toList(),
                      onChanged: (v) => _select(v!),
                    ),
                  ),
                ),
                if (docs.length < 5)
                  IconButton(tooltip: 'Add business (max 5)', icon: const Icon(Icons.add_business), onPressed: _add),
                PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'rename') {
                      final n = await _textDialog(context, 'Rename business', initial: biz.name);
                      if (n != null) await fast(biz.ref.update({'name': n}));
                    } else if (v == 'delete') {
                      await _delete(cur, biz.name);
                    }
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'rename', child: Text('Rename')),
                    if (docs.length > 1) const PopupMenuItem(value: 'delete', child: Text('Delete this business')),
                  ],
                ),
              ]),
            ),
            Expanded(child: _HisabBody(key: ValueKey('${widget.uid}/$cur'), biz: biz)),
          ],
        );
      },
    );
  }
}

class _HisabBody extends StatelessWidget {
  final Biz biz;
  const _HisabBody({super.key, required this.biz});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Column(
        children: [
          _Summary(biz: biz),
          TabBar(isScrollable: true, tabAlignment: TabAlignment.start, tabs: [
            Tab(text: '${t(context, 'Customers')} / ${t(context, 'Suppliers')}'),
            Tab(text: t(context, 'Cashbook')),
            Tab(text: t(context, 'Stock')),
            Tab(text: t(context, 'Notes')),
            Tab(text: t(context, 'Reports')),
          ]),
          Expanded(
            child: TabBarView(children: [
              PartiesTab(biz: biz),
              CashbookTab(biz: biz),
              StockTab(biz: biz),
              NotesTab(biz: biz),
              ReportsTab(biz: biz),
            ]),
          ),
        ],
      ),
    );
  }
}

class _Summary extends StatelessWidget {
  final Biz biz;
  const _Summary({required this.biz});

  Widget _card(String label, double v, Color color) => Expanded(
        child: Card(
          margin: const EdgeInsets.all(4),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
            child: Column(children: [
              FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: const TextStyle(fontSize: 11))),
              const SizedBox(height: 2),
              FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text('Tk ${money(v)}', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color))),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return DocStream(
      query: biz.c('parties'),
      builder: (c, pd) {
        double toGet = 0, give = 0;
        for (final d in pd) {
          final b = toD(d.data()['balance']);
          if (b > 0) {
            toGet += b;
          } else {
            give += -b;
          }
        }
        return DocStream(
          query: biz.c('cash'),
          builder: (c, cd) {
            double bal = 0;
            for (final d in cd) {
              final m = d.data();
              bal += m['type'] == 'in' ? toD(m['amount']) : -toD(m['amount']);
            }
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Row(children: [
                _card(t(context, 'You will get'), toGet, _green),
                _card(t(context, 'You will give'), give, _red),
                _card(t(context, 'Cash balance'), bal, bal >= 0 ? _green : _red),
              ]),
            );
          },
        );
      },
    );
  }
}

// ======================================================================= PARTIES
class PartiesTab extends StatefulWidget {
  final Biz biz;
  const PartiesTab({super.key, required this.biz});
  @override
  State<PartiesTab> createState() => _PartiesTabState();
}

class _PartiesTabState extends State<PartiesTab> with AutomaticKeepAliveClientMixin {
  String type = 'customer';
  @override
  bool get wantKeepAlive => true;

  Future<void> _addParty() async {
    final name = TextEditingController(), phone = TextEditingController();
    final key = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(type == 'customer' ? 'Add customer' : 'Add supplier'),
        content: Form(
          key: key,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            tf(name, 'Name', req: true),
            tf(phone, 'Phone number', type: TextInputType.phone),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                if (key.currentState!.validate()) Navigator.pop(ctx, true);
              },
              child: const Text('Save')),
        ],
      ),
    );
    if (ok != true) return;
    await fast(widget.biz.c('parties').doc().set({
      'name': name.text.trim(),
      'phone': phone.text.trim(),
      'type': type,
      'balance': 0,
      'createdAt': FieldValue.serverTimestamp(),
    }));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final biz = widget.biz;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addParty,
        icon: const Icon(Icons.person_add),
        label: Text(type == 'customer' ? 'Add customer' : 'Add supplier'),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 4, 0),
          child: Row(children: [
            Expanded(
              child: SegmentedButton<String>(
                showSelectedIcon: false,
                segments: [
                  ButtonSegment(value: 'customer', label: Text(t(context, 'Customers'))),
                  ButtonSegment(value: 'supplier', label: Text(t(context, 'Suppliers'))),
                ],
                selected: {type},
                onSelectionChanged: (s) => setState(() => type = s.first),
              ),
            ),
            IconButton(
              tooltip: 'Group reminder (batch SMS)',
              icon: const Icon(Icons.campaign),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReminderPage(biz: biz))),
            ),
          ]),
        ),
        Expanded(
          child: DocStream(
            query: biz.c('parties'),
            builder: (c, docs) => SearchableList(
              docs: docs.where((d) => (d.data()['type'] ?? 'customer') == type).toList(),
              empty: 'No ${type}s yet. Tap the button below to add.',
              titleOf: (d) => '${d['name']}',
              subtitleOf: (d) => '${d['phone'] ?? ''}',
              trailing: (d) {
                final b = toD(d['balance']);
                if (b == 0) return const Text('Settled', style: TextStyle(color: Colors.grey));
                return Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('Tk ${money(b.abs())}', style: TextStyle(fontWeight: FontWeight.bold, color: b > 0 ? _green : _red)),
                  Text(b > 0 ? 'You will get' : 'You will give', style: const TextStyle(fontSize: 10)),
                ]);
              },
              onTap: (d) => Navigator.push(
                  c, MaterialPageRoute(builder: (_) => PartyPage(biz: biz, partyId: d.id))),
            ),
          ),
        ),
      ]),
    );
  }
}

Future<void> _txnDialog(BuildContext context, Biz biz, String partyId, String partyName, bool gave) async {
  final amount = TextEditingController(), note = TextEditingController();
  var date = DateTime.now();
  final key = GlobalKey<FormState>();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: Text(gave ? 'You gave' : 'You got', style: TextStyle(color: gave ? _red : _green)),
        content: Form(
          key: key,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              tf(amount, 'Amount (Tk)', type: TextInputType.number, req: true, numeric: true),
              tf(note, 'Details (optional)'),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_today),
                title: Text(dateStr(date)),
                onTap: () async {
                  final p = await _pickDate(ctx, date);
                  if (p != null) setS(() => date = p);
                },
              ),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                if (key.currentState!.validate()) Navigator.pop(ctx, true);
              },
              child: const Text('Save')),
        ],
      ),
    ),
  );
  if (ok != true) return;
  final a = double.parse(amount.text.trim());
  final b = fs.batch();
  b.set(biz.c('txns').doc(), {
    'partyId': partyId,
    'partyName': partyName,
    'type': gave ? 'gave' : 'got',
    'amount': a,
    'note': note.text.trim(),
    'date': Timestamp.fromDate(date),
    'createdAt': FieldValue.serverTimestamp(),
  });
  b.update(biz.c('parties').doc(partyId), {'balance': FieldValue.increment(gave ? a : -a)});
  await fast(b.commit());
}

class PartyPage extends StatelessWidget {
  final Biz biz;
  final String partyId;
  const PartyPage({super.key, required this.biz, required this.partyId});

  String _msg(String name, double bal) =>
      'Dear $name, your due balance with ${biz.name} is Tk ${money(bal)}. Please pay at your earliest convenience. Thank you.';

  @override
  Widget build(BuildContext context) {
    final ref = biz.c('parties').doc(partyId);
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: ref.snapshots(),
      builder: (c, s) {
        if (!s.hasData) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        if (!s.data!.exists) return Scaffold(appBar: AppBar(), body: const EmptyView('Deleted'));
        final p = s.data!.data()!;
        final name = '${p['name']}';
        final phone = '${p['phone'] ?? ''}';
        final bal = toD(p['balance']);
        return Scaffold(
          appBar: AppBar(
            title: Text(name),
            actions: [
              if (phone.isNotEmpty)
                IconButton(icon: const Icon(Icons.call), onPressed: () => launchUrl(Uri.parse('tel:$phone'))),
              PopupMenuButton<String>(
                onSelected: (v) async {
                  if (v == 'sms') {
                    await _sms(phone, _msg(name, bal));
                  } else if (v == 'wa') {
                    await _whatsapp(phone, _msg(name, bal));
                  } else if (v == 'pdf') {
                    final tx = await _all(biz.c('txns').where('partyId', isEqualTo: partyId));
                    if (!c.mounted) return;
                    await presentPdf(c, 'Statement-$name', () => partyReport(biz.name, p, tx));
                  } else if (v == 'del') {
                    if (await confirmDlg(c, 'Delete $name and all transactions?')) {
                      final q = await biz.c('txns').where('partyId', isEqualTo: partyId).get();
                      final b = fs.batch();
                      for (final d in q.docs) {
                        b.delete(d.reference);
                      }
                      b.delete(ref);
                      await fast(b.commit());
                      if (c.mounted) Navigator.pop(c);
                    }
                  }
                },
                itemBuilder: (_) => [
                  if (phone.isNotEmpty && bal > 0) const PopupMenuItem(value: 'sms', child: Text('Send SMS reminder')),
                  if (phone.isNotEmpty && bal > 0) const PopupMenuItem(value: 'wa', child: Text('Send WhatsApp reminder')),
                  const PopupMenuItem(value: 'pdf', child: Text('Statement (PDF)')),
                  const PopupMenuItem(value: 'del', child: Text('Delete')),
                ],
              ),
            ],
          ),
          body: Column(children: [
            Container(
              width: double.infinity,
              color: (bal >= 0 ? _green : _red).withOpacity(0.10),
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                Text(bal == 0 ? 'Settled' : (bal > 0 ? 'You will get' : 'You will give')),
                Text('Tk ${money(bal.abs())}',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: bal >= 0 ? _green : _red)),
                if (phone.isNotEmpty) Text(phone, style: const TextStyle(fontSize: 12)),
              ]),
            ),
            Expanded(
              child: DocStream(
                query: biz.c('txns').where('partyId', isEqualTo: partyId),
                builder: (c, docs) {
                  final list = docs.toList()..sort((a, b) => toDate(b.data()['date']).compareTo(toDate(a.data()['date'])));
                  if (list.isEmpty) return const EmptyView('No transaction yet.');
                  return ListView.separated(
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (c, i) {
                      final m = list[i].data();
                      final gave = m['type'] == 'gave';
                      return ListTile(
                        leading: Icon(gave ? Icons.north_east : Icons.south_west, color: gave ? _red : _green),
                        title: Text(gave ? 'You gave' : 'You got'),
                        subtitle: Text('${dateStr(toDate(m['date']))}${(m['note'] ?? '').toString().isEmpty ? '' : '  •  ${m['note']}'}'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text('Tk ${money(toD(m['amount']))}',
                              style: TextStyle(fontWeight: FontWeight.bold, color: gave ? _red : _green)),
                          IconButton(
                            icon: const Icon(Icons.delete_outline, size: 20),
                            onPressed: () async {
                              if (!await confirmDlg(c, 'Delete this entry?')) return;
                              final a = toD(m['amount']);
                              final b = fs.batch();
                              b.delete(list[i].reference);
                              b.update(ref, {'balance': FieldValue.increment(gave ? -a : a)});
                              await fast(b.commit());
                            },
                          ),
                        ]),
                      );
                    },
                  );
                },
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(children: [
                  Expanded(
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: _red, minimumSize: const Size.fromHeight(48)),
                      onPressed: () => _txnDialog(c, biz, partyId, name, true),
                      child: Text(t(c, 'You gave')),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: _green, minimumSize: const Size.fromHeight(48)),
                      onPressed: () => _txnDialog(c, biz, partyId, name, false),
                      child: Text(t(c, 'You got')),
                    ),
                  ),
                ]),
              ),
            ),
          ]),
        );
      },
    );
  }
}

// ======================================================================= GROUP REMINDERS
class ReminderPage extends StatefulWidget {
  final Biz biz;
  const ReminderPage({super.key, required this.biz});
  @override
  State<ReminderPage> createState() => _ReminderPageState();
}

class _ReminderPageState extends State<ReminderPage> {
  final selected = <String>{};
  late final msg = TextEditingController(
      text: 'Dear {name}, your due balance with ${widget.biz.name} is Tk {amount}. Please pay at your earliest convenience. Thank you.');

  String _text(Json p) => msg.text.replaceAll('{name}', '${p['name']}').replaceAll('{amount}', money(toD(p['balance'])));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Group reminder')),
      body: DocStream(
        query: widget.biz.c('parties'),
        builder: (c, docs) {
          final due = docs.where((d) => toD(d.data()['balance']) > 0 && '${d.data()['phone'] ?? ''}'.trim().isNotEmpty).toList()
            ..sort((a, b) => toD(b.data()['balance']).compareTo(toD(a.data()['balance'])));
          if (due.isEmpty) return const EmptyView('Nobody with a due balance and a phone number.');
          final chosen = due.where((d) => selected.contains(d.id)).toList();
          return Column(children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: tf(msg, 'Message ({name} and {amount} are replaced automatically)', lines: 3),
            ),
            CheckboxListTile(
              dense: true,
              title: Text('Select all (${due.length})'),
              value: chosen.length == due.length,
              onChanged: (v) => setState(() {
                if (v == true) {
                  selected.addAll(due.map((d) => d.id));
                } else {
                  selected.clear();
                }
              }),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                children: due.map((d) {
                  final p = d.data();
                  return CheckboxListTile(
                    value: selected.contains(d.id),
                    onChanged: (v) => setState(() => v == true ? selected.add(d.id) : selected.remove(d.id)),
                    title: Text('${p['name']}'),
                    subtitle: Text('${p['phone']}  •  Tk ${money(toD(p['balance']))}'),
                    secondary: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.sms_outlined), onPressed: () => _sms('${p['phone']}', _text(p))),
                      IconButton(icon: const Icon(Icons.chat_outlined), onPressed: () => _whatsapp('${p['phone']}', _text(p))),
                    ]),
                  );
                }).toList(),
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(children: [
                  FilledButton.icon(
                    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                    onPressed: chosen.isEmpty
                        ? null
                        : () => _sms(chosen.map((d) => '${d.data()['phone']}'.trim()).join(','), msg.text.replaceAll('{name}', 'Sir/Madam').replaceAll('{amount}', 'due')),
                    icon: const Icon(Icons.group),
                    label: Text('One group SMS to ${chosen.length} selected'),
                  ),
                  const SizedBox(height: 4),
                  Text('Tip: the sms/WhatsApp icons on each row send a personal message with the exact amount.',
                      style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor), textAlign: TextAlign.center),
                ]),
              ),
            ),
          ]);
        },
      ),
    );
  }
}

// ======================================================================= CASHBOOK
class CashbookTab extends StatefulWidget {
  final Biz biz;
  const CashbookTab({super.key, required this.biz});
  @override
  State<CashbookTab> createState() => _CashbookTabState();
}

class _CashbookTabState extends State<CashbookTab> with AutomaticKeepAliveClientMixin {
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  @override
  bool get wantKeepAlive => true;

  Future<void> _add() async {
    final amount = TextEditingController(), cat = TextEditingController(), note = TextEditingController();
    var type = 'in';
    var date = DateTime.now();
    final key = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Cashbook entry'),
          content: Form(
            key: key,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                SegmentedButton<String>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: 'in', label: Text('Income')),
                    ButtonSegment(value: 'cost', label: Text('Cost')),
                    ButtonSegment(value: 'saving', label: Text('Saving')),
                  ],
                  selected: {type},
                  onSelectionChanged: (s) => setS(() => type = s.first),
                ),
                tf(amount, 'Amount (Tk)', type: TextInputType.number, req: true, numeric: true),
                tf(cat, 'Category', hint: 'e.g. Medicine purchase, Salary, Rent'),
                tf(note, 'Note'),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.calendar_today),
                  title: Text(dateStr(date)),
                  onTap: () async {
                    final p = await _pickDate(ctx, date);
                    if (p != null) setS(() => date = p);
                  },
                ),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(
                onPressed: () {
                  if (key.currentState!.validate()) Navigator.pop(ctx, true);
                },
                child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await fast(widget.biz.c('cash').doc().set({
      'type': type,
      'amount': double.parse(amount.text.trim()),
      'category': cat.text.trim(),
      'note': note.text.trim(),
      'date': Timestamp.fromDate(date),
      'createdAt': FieldValue.serverTimestamp(),
    }));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Add entry')),
      body: DocStream(
        query: widget.biz.c('cash'),
        builder: (c, docs) {
          final list = docs.where((d) {
            final dt = toDate(d.data()['date']);
            return dt.year == month.year && dt.month == month.month;
          }).toList()
            ..sort((a, b) => toDate(b.data()['date']).compareTo(toDate(a.data()['date'])));
          double inc = 0, cost = 0, save = 0;
          for (final d in list) {
            final m = d.data();
            final a = toD(m['amount']);
            if (m['type'] == 'in') {
              inc += a;
            } else if (m['type'] == 'saving') {
              save += a;
            } else {
              cost += a;
            }
          }
          return Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => setState(() => month = DateTime(month.year, month.month - 1))),
              Text(DateFormat('MMMM yyyy').format(month), style: const TextStyle(fontWeight: FontWeight.bold)),
              IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => setState(() => month = DateTime(month.year, month.month + 1))),
            ]),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(children: [
                _mini('Income', inc, _green),
                _mini('Cost', cost, _red),
                _mini('Savings', save, Colors.blue),
                _mini('Net', inc - cost - save, inc - cost - save >= 0 ? _green : _red),
              ]),
            ),
            const Divider(),
            Expanded(
              child: list.isEmpty
                  ? const EmptyView('No entries in this month.')
                  : ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (c, i) {
                        final m = list[i].data();
                        final type = m['type'];
                        final color = type == 'in' ? _green : (type == 'saving' ? Colors.blue : _red);
                        return ListTile(
                          dense: true,
                          leading: Icon(type == 'in' ? Icons.arrow_downward : (type == 'saving' ? Icons.savings : Icons.arrow_upward), color: color),
                          title: Text('${(m['category'] ?? '').toString().isEmpty ? (type == 'in' ? 'Income' : type == 'saving' ? 'Saving' : 'Cost') : m['category']}'),
                          subtitle: Text('${dateStr(toDate(m['date']))}  ${m['note'] ?? ''}'),
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            Text('Tk ${money(toD(m['amount']))}', style: TextStyle(color: color, fontWeight: FontWeight.bold)),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 20),
                              onPressed: () async {
                                if (await confirmDlg(c, 'Delete this entry?')) await fast(list[i].reference.delete());
                              },
                            ),
                          ]),
                        );
                      },
                    ),
            ),
          ]);
        },
      ),
    );
  }

  Widget _mini(String l, double v, Color col) => Expanded(
        child: Column(children: [
          Text(l, style: const TextStyle(fontSize: 11)),
          FittedBox(fit: BoxFit.scaleDown, child: Text(money(v), style: TextStyle(fontWeight: FontWeight.bold, color: col))),
        ]),
      );
}

// ======================================================================= STOCK
class StockTab extends StatefulWidget {
  final Biz biz;
  const StockTab({super.key, required this.biz});
  @override
  State<StockTab> createState() => _StockTabState();
}

class _StockTabState extends State<StockTab> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  Future<void> _addProduct() async {
    final name = TextEditingController(), qty = TextEditingController(), cost = TextEditingController(), price = TextEditingController();
    final key = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add product to stock'),
        content: Form(
          key: key,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              tf(name, 'Product name', req: true),
              tf(qty, 'Quantity', type: TextInputType.number, req: true, numeric: true),
              tf(cost, 'Purchase cost per unit (Tk)', type: TextInputType.number, req: true, numeric: true),
              tf(price, 'Selling price per unit (Tk)', type: TextInputType.number),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                if (key.currentState!.validate()) Navigator.pop(ctx, true);
              },
              child: const Text('Save')),
        ],
      ),
    );
    if (ok != true) return;
    await fast(widget.biz.c('products').doc().set({
      'name': name.text.trim(),
      'qty': double.parse(qty.text.trim()),
      'unitCost': double.parse(cost.text.trim()),
      'salePrice': double.tryParse(price.text.trim()) ?? 0,
      'addedAt': Timestamp.now(),
      'lastRestockAt': Timestamp.now(),
    }));
  }

  Future<void> _restock(QueryDocumentSnapshot<Json> p) async {
    final qty = TextEditingController(), cost = TextEditingController(text: '${p.data()['unitCost'] ?? ''}');
    final key = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Add stock: ${p.data()['name']}'),
        content: Form(
          key: key,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            tf(qty, 'Quantity added', type: TextInputType.number, req: true, numeric: true),
            tf(cost, 'Purchase cost per unit (Tk)', type: TextInputType.number, req: true, numeric: true),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                if (key.currentState!.validate()) Navigator.pop(ctx, true);
              },
              child: const Text('Save')),
        ],
      ),
    );
    if (ok != true) return;
    final q = double.parse(qty.text.trim()), c = double.parse(cost.text.trim());
    final oldQ = toD(p.data()['qty']), oldC = toD(p.data()['unitCost']);
    final avg = oldQ <= 0 ? c : ((oldQ * oldC) + (q * c)) / (oldQ + q); // weighted-average cost
    await fast(p.reference.update({'qty': FieldValue.increment(q), 'unitCost': avg, 'lastRestockAt': Timestamp.now()}));
  }

  Future<void> _stockOut(QueryDocumentSnapshot<Json> p) async {
    final m = p.data();
    final available = toD(m['qty']);
    final qty = TextEditingController(),
        buyer = TextEditingController(),
        phone = TextEditingController(),
        price = TextEditingController(text: toD(m['salePrice']) > 0 ? '${m['salePrice']}' : '');
    var date = DateTime.now();
    var toCash = true;
    String? err;
    final key = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text('Stock out: ${m['name']}'),
          content: Form(
            key: key,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('Available: ${money(available)}'),
                tf(qty, 'Quantity', type: TextInputType.number, req: true, numeric: true),
                tf(buyer, 'Sold to (name of buyer)', req: true),
                tf(phone, 'Phone number of buyer', type: TextInputType.phone),
                tf(price, 'Selling price per unit (Tk)', type: TextInputType.number, req: true, numeric: true),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.calendar_today),
                  title: Text(dateStr(date)),
                  onTap: () async {
                    final d = await _pickDate(ctx, date);
                    if (d != null) setS(() => date = d);
                  },
                ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Add sale amount to cashbook income'),
                  value: toCash,
                  onChanged: (v) => setS(() => toCash = v ?? true),
                ),
                if (err != null) Text(err!, style: const TextStyle(color: Colors.red)),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(
                onPressed: () {
                  if (!key.currentState!.validate()) return;
                  if (double.parse(qty.text.trim()) > available) {
                    setS(() => err = 'Not enough stock (available ${money(available)}).');
                    return;
                  }
                  Navigator.pop(ctx, true);
                },
                child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final q = double.parse(qty.text.trim()), pr = double.parse(price.text.trim());
    final b = fs.batch();
    final out = widget.biz.c('stockOut').doc();
    final ts = Timestamp.fromDate(date);
    b.set(out, {
      'productId': p.id,
      'productName': m['name'],
      'qty': q,
      'price': pr,
      'buyerName': buyer.text.trim(),
      'buyerPhone': phone.text.trim(),
      'date': ts,
      'createdAt': FieldValue.serverTimestamp(),
    });
    b.update(p.reference, {'qty': FieldValue.increment(-q), 'lastSoldAt': ts});
    if (toCash) {
      b.set(widget.biz.c('cash').doc('sale_${out.id}'), {
        'type': 'in',
        'amount': q * pr,
        'category': 'Stock sale',
        'note': '${m['name']} x${money(q)} to ${buyer.text.trim()}',
        'date': ts,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
    await fast(b.commit());
  }

  void _actions(QueryDocumentSnapshot<Json> p) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(title: Text('${p.data()['name']}', style: const TextStyle(fontWeight: FontWeight.bold))),
          ListTile(
              leading: const Icon(Icons.output),
              title: const Text('Stock out (sell)'),
              onTap: () {
                Navigator.pop(ctx);
                _stockOut(p);
              }),
          ListTile(
              leading: const Icon(Icons.input),
              title: const Text('Add stock'),
              onTap: () {
                Navigator.pop(ctx);
                _restock(p);
              }),
          ListTile(
              leading: const Icon(Icons.history),
              title: const Text('Sales history of this product'),
              onTap: () {
                Navigator.pop(ctx);
                Navigator.push(context, MaterialPageRoute(builder: (_) => StockOutHistory(biz: widget.biz, productId: p.id)));
              }),
          ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('Delete product'),
              onTap: () async {
                Navigator.pop(ctx);
                if (await confirmDlg(context, 'Delete this product?')) await fast(p.reference.delete());
              }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: _addProduct, icon: const Icon(Icons.add), label: const Text('Add product')),
      body: DocStream(
        query: widget.biz.c('products'),
        builder: (c, docs) {
          double value = 0;
          for (final d in docs) {
            value += toD(d.data()['qty']) * toD(d.data()['unitCost']);
          }
          return Column(children: [
            Card(
              margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: ListTile(
                leading: const Icon(Icons.inventory_2),
                title: const Text('Total stock valuation'),
                subtitle: Text('${docs.length} products'),
                trailing: Text('Tk ${money(value)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Sales history')), body: StockOutHistory(biz: widget.biz)))),
              ),
            ),
            Expanded(
              child: SearchableList(
                docs: docs,
                empty: 'No product yet. Tap "Add product".',
                titleOf: (d) => '${d['name']}',
                subtitleOf: (d) => 'Qty ${money(toD(d['qty']))}  •  Cost Tk ${money(toD(d['unitCost']))}  •  Added ${dateStr(toDate(d['addedAt']))}',
                trailing: (d) => Text('Tk ${money(toD(d['qty']) * toD(d['unitCost']))}', style: const TextStyle(fontWeight: FontWeight.bold)),
                onTap: _actions,
              ),
            ),
          ]);
        },
      ),
    );
  }
}

class StockOutHistory extends StatelessWidget {
  final Biz biz;
  final String? productId;
  const StockOutHistory({super.key, required this.biz, this.productId});

  @override
  Widget build(BuildContext context) {
    final q = productId == null ? biz.c('stockOut') : biz.c('stockOut').where('productId', isEqualTo: productId);
    final body = DocStream(
      query: q,
      builder: (c, docs) {
        final list = docs.toList()..sort((a, b) => toDate(b.data()['date']).compareTo(toDate(a.data()['date'])));
        if (list.isEmpty) return const EmptyView('No stock-out record yet.');
        return ListView.separated(
          itemCount: list.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (c, i) {
            final m = list[i].data();
            return ListTile(
              title: Text('${m['productName']}  x${money(toD(m['qty']))}'),
              subtitle: Text('${m['buyerName']}  ${m['buyerPhone'] ?? ''}\n${dateStr(toDate(m['date']))}'),
              isThreeLine: true,
              trailing: Text('Tk ${money(toD(m['qty']) * toD(m['price']))}', style: const TextStyle(fontWeight: FontWeight.bold)),
            );
          },
        );
      },
    );
    return productId == null ? body : Scaffold(appBar: AppBar(title: const Text('Sales history')), body: body);
  }
}

// ======================================================================= NOTES
class NotesTab extends StatefulWidget {
  final Biz biz;
  const NotesTab({super.key, required this.biz});
  @override
  State<NotesTab> createState() => _NotesTabState();
}

class _NotesTabState extends State<NotesTab> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  Future<void> _edit([QueryDocumentSnapshot<Json>? n]) async {
    final title = TextEditingController(text: '${n?.data()['title'] ?? ''}');
    final body = TextEditingController(text: '${n?.data()['body'] ?? ''}');
    final key = GlobalKey<FormState>();
    final r = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(n == null ? 'New note' : 'Edit note'),
        content: Form(
          key: key,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              tf(title, 'Title', req: true),
              tf(body, 'Note', lines: 6),
            ]),
          ),
        ),
        actions: [
          if (n != null) TextButton(onPressed: () => Navigator.pop(ctx, 'del'), child: const Text('Delete', style: TextStyle(color: Colors.red))),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                if (key.currentState!.validate()) Navigator.pop(ctx, 'save');
              },
              child: const Text('Save')),
        ],
      ),
    );
    if (r == 'del' && n != null) {
      await fast(n.reference.delete());
    } else if (r == 'save') {
      final data = {'title': title.text.trim(), 'body': body.text.trim(), 'updatedAt': FieldValue.serverTimestamp()};
      if (n == null) {
        await fast(widget.biz.c('notes').doc().set(data));
      } else {
        await fast(n.reference.update(data));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _edit(), icon: const Icon(Icons.note_add), label: const Text('New note')),
      body: DocStream(
        query: widget.biz.c('notes'),
        builder: (c, docs) {
          final list = docs.toList()..sort((a, b) => toDate(b.data()['updatedAt']).compareTo(toDate(a.data()['updatedAt'])));
          if (list.isEmpty) return const EmptyView('Write your business notes here instead of a paper notebook.');
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 80),
            itemCount: list.length,
            itemBuilder: (c, i) {
              final m = list[i].data();
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                child: ListTile(
                  title: Text('${m['title']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${m['body']}', maxLines: 3, overflow: TextOverflow.ellipsis),
                  onTap: () => _edit(list[i]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// ======================================================================= REPORTS
Future<void> presentPdf(BuildContext context, String name, Future<Uint8List> Function() make) async {
  showDialog<void>(context: context, barrierDismissible: false, builder: (_) => const Center(child: CircularProgressIndicator()));
  Uint8List bytes;
  try {
    bytes = await make();
  } catch (e) {
    if (context.mounted) {
      Navigator.pop(context);
      snack(context, 'Could not create the report: $e');
    }
    return;
  }
  if (!context.mounted) return;
  Navigator.pop(context);
  final file = name.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold))),
        ListTile(
          leading: const Icon(Icons.share),
          title: const Text('Share (WhatsApp, imo, email ...)'),
          onTap: () async {
            Navigator.pop(ctx);
            await Printing.sharePdf(bytes: bytes, filename: '$file.pdf');
          },
        ),
        ListTile(
          leading: const Icon(Icons.print),
          title: const Text('Print / Save as PDF'),
          onTap: () async {
            Navigator.pop(ctx);
            await Printing.layoutPdf(name: file, onLayout: (_) async => bytes);
          },
        ),
      ]),
    ),
  );
}

class ReportsTab extends StatelessWidget {
  final Biz biz;
  const ReportsTab({super.key, required this.biz});

  Future<DateTime?> _month(BuildContext c) => _pickDate(c, DateTime.now(), help: 'Pick any day of the month');

  Future<void> _partyReport(BuildContext c) async {
    final parties = await _all(biz.c('parties'));
    if (!c.mounted) return;
    if (parties.isEmpty) {
      snack(c, 'No customer / supplier yet.');
      return;
    }
    parties.sort((a, b) => '${a['name']}'.toLowerCase().compareTo('${b['name']}'.toLowerCase()));
    final p = await showDialog<Json>(
      context: c,
      builder: (ctx) => SimpleDialog(
        title: const Text('Choose customer / supplier'),
        children: parties
            .map((e) => SimpleDialogOption(
                onPressed: () => Navigator.pop(ctx, e),
                child: Text('${e['name']}  (${e['type'] == 'supplier' ? 'Supplier' : 'Customer'})')))
            .toList(),
      ),
    );
    if (p == null || !c.mounted) return;
    final tx = await _all(biz.c('txns').where('partyId', isEqualTo: p['id']));
    if (!c.mounted) return;
    await presentPdf(c, 'Statement-${p['name']}', () => partyReport(biz.name, p, tx));
  }

  Widget _tile(IconData i, String title, String sub, VoidCallback onTap) =>
      Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), child: ListTile(leading: Icon(i), title: Text(title), subtitle: Text(sub), trailing: const Icon(Icons.picture_as_pdf), onTap: onTap));

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        _tile(Icons.person_search, 'Customer / supplier report', 'Full statement of one party', () => _partyReport(context)),
        _tile(Icons.groups, 'All customers & suppliers', 'Who owes you / whom you owe', () async {
          final p = await _all(biz.c('parties'));
          if (!context.mounted) return;
          await presentPdf(context, 'Parties-summary', () => partiesSummaryReport(biz.name, p));
        }),
        _tile(Icons.inventory, 'Stock & inventory report', 'Every product: date entered, date sold, valuation', () async {
          final p = await _all(biz.c('products')), o = await _all(biz.c('stockOut'));
          if (!context.mounted) return;
          await presentPdf(context, 'Stock-report', () => stockReport(biz.name, p, o));
        }),
        _tile(Icons.savings, 'Cost & savings report', 'Pick a month', () async {
          final m = await _month(context);
          if (m == null || !context.mounted) return;
          final cash = await _all(biz.c('cash'));
          if (!context.mounted) return;
          await presentPdf(context, 'Cost-savings-${DateFormat('yyyy-MM').format(m)}', () => costSavingReport(biz.name, m, cash));
        }),
        _tile(Icons.calendar_month, 'Monthly report', 'Income, cost, savings, credit, sales', () async {
          final m = await _month(context);
          if (m == null || !context.mounted) return;
          final cash = await _all(biz.c('cash')), tx = await _all(biz.c('txns')), o = await _all(biz.c('stockOut'));
          if (!context.mounted) return;
          await presentPdf(context, 'Monthly-${DateFormat('yyyy-MM').format(m)}', () => monthlyReport(biz.name, m, cash, tx, o));
        }),
      ],
    );
  }
}
