import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app_state.dart';
import '../l10n.dart';

FirebaseFirestore get db => FirebaseFirestore.instance;

// ------------------------------------------------------------------ helpers
int wordCount(String s) {
  final t = s.trim();
  return t.isEmpty ? 0 : t.split(RegExp(r'\s+')).length;
}

String money(num v) => '৳ ${NumberFormat('#,##0.##').format(v)}';
String plainMoney(num v) => 'Tk ${NumberFormat('#,##0.##').format(v)}';
String fmtDate(DateTime d) => DateFormat('dd MMM yyyy').format(d);
String fmtMonth(DateTime d) => DateFormat('MMMM yyyy').format(d);

DateTime toDate(dynamic v) {
  if (v is Timestamp) return v.toDate();
  if (v is DateTime) return v;
  return DateTime.fromMillisecondsSinceEpoch(0);
}

double toNum(dynamic v) => v is num ? v.toDouble() : (double.tryParse('$v') ?? 0);

/// Fields added to every shared record (company / medicine / disease / P&S).
Json stamp(AppState s) => {
      'createdBy': s.uid,
      'createdByName': s.fullName,
      'createdAt': Timestamp.now(),
    };

bool canEdit(BuildContext context, Json data) {
  final s = context.read<AppState>();
  return s.isAdmin || data['createdBy'] == s.uid;
}

void snack(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<bool> confirm(BuildContext context, String message) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(c.tr('Confirm')),
      content: Text(message),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: Text(c.tr('Cancel'))),
        FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: Text(c.tr('Delete'))),
      ],
    ),
  );
  return r ?? false;
}

Future<void> openUrl(BuildContext context, String url) async {
  var u = url.trim();
  if (u.isEmpty) return;
  if (!u.startsWith('http') && !u.startsWith('tel:') && !u.startsWith('sms:')) {
    u = 'https://$u';
  }
  try {
    final ok = await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) snack(context, 'Could not open $u');
  } catch (_) {
    if (context.mounted) snack(context, 'Could not open $u');
  }
}

/// Bangladeshi phone → international digits for wa.me
String waNumber(String phone) {
  var d = phone.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('880')) return d;
  if (d.startsWith('0')) return '88$d';
  return '880$d';
}

// ------------------------------------------------------------- stream wrap
class QueryStream extends StatelessWidget {
  final Query<Json> query;
  final Widget Function(BuildContext, List<QueryDocumentSnapshot<Json>>) builder;
  const QueryStream({super.key, required this.query, required this.builder});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Json>>(
      stream: query.snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(
              child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('${snap.error}', textAlign: TextAlign.center),
          ));
        }
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        return builder(context, snap.data!.docs);
      },
    );
  }
}

class DocStream extends StatelessWidget {
  final DocumentReference<Json> ref;
  final Widget Function(BuildContext, Json data) builder;
  const DocStream({super.key, required this.ref, required this.builder});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: ref.snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return Center(child: Text('${snap.error}'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final d = snap.data!.data();
        if (d == null) {
          return Center(child: Text(context.tr('This item no longer exists.')));
        }
        return builder(context, d);
      },
    );
  }
}

// ----------------------------------------------------------------- widgets
class EmptyState extends StatelessWidget {
  final String message;
  final IconData icon;
  const EmptyState(this.message, {super.key, this.icon = Icons.inbox_outlined});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 56, color: Colors.grey),
            const SizedBox(height: 8),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.grey)),
          ]),
        ),
      );
}

class SearchBox extends StatelessWidget {
  final ValueChanged<String> onChanged;
  final String hint;
  const SearchBox({super.key, required this.onChanged, this.hint = 'Search'});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
        child: TextField(
          onChanged: onChanged,
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search),
            hintText: context.tr(hint),
            isDense: true,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(28)),
          ),
        ),
      );
}

class InfoRow extends StatelessWidget {
  final String label;
  final String? value;
  final Color? valueColor;
  const InfoRow(this.label, this.value, {super.key, this.valueColor});

  @override
  Widget build(BuildContext context) {
    if (value == null || value!.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(context.tr(label),
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.primary)),
        const SizedBox(height: 2),
        SelectableText(value!, style: TextStyle(fontSize: 15, color: valueColor)),
      ]),
    );
  }
}

class TagChip extends StatelessWidget {
  final String text;
  final Color color;
  const TagChip(this.text, this.color, {super.key});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.6)),
        ),
        child: Text(text,
            style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.w600, color: color)),
      );
}

/// "Safe / Unsafe / Not set" chip used for pregnancy & pet fields.
Widget safetyChip(BuildContext context, String? v) {
  if (v == 'safe') return TagChip(context.tr('Safe'), Colors.green.shade700);
  if (v == 'unsafe') return TagChip(context.tr('Unsafe'), Colors.red.shade700);
  return TagChip(context.tr('Not specified'), Colors.grey.shade600);
}

Widget tf(
  TextEditingController c,
  String label, {
  bool required = false,
  TextInputType? keyboard,
  int lines = 1,
  bool obscure = false,
  String? Function(String?)? validator,
  String? suffix,
  Widget? prefixIcon,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Builder(
      builder: (context) => TextFormField(
        controller: c,
        keyboardType: keyboard,
        obscureText: obscure,
        minLines: lines,
        maxLines: obscure ? 1 : (lines == 1 ? 1 : null),
        decoration: InputDecoration(
          labelText: context.tr(label),
          border: const OutlineInputBorder(),
          alignLabelWithHint: lines > 1,
          suffixText: suffix,
          prefixIcon: prefixIcon,
        ),
        validator: validator ??
            (required
                ? (v) => (v == null || v.trim().isEmpty)
                    ? context.tr('Required')
                    : null
                : null),
      ),
    ),
  );
}

/// Multi-line text field with a live "n / max words" counter.
class WordField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final int maxWords;
  final int lines;
  final bool required;
  const WordField({
    super.key,
    required this.controller,
    required this.label,
    required this.maxWords,
    this.lines = 5,
    this.required = false,
  });

  @override
  State<WordField> createState() => _WordFieldState();
}

class _WordFieldState extends State<WordField> {
  int _n = 0;

  @override
  void initState() {
    super.initState();
    _n = wordCount(widget.controller.text);
    widget.controller.addListener(_listen);
  }

  void _listen() {
    final n = wordCount(widget.controller.text);
    if (n != _n) setState(() => _n = n);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_listen);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextFormField(
        controller: widget.controller,
        minLines: widget.lines,
        maxLines: null,
        keyboardType: TextInputType.multiline,
        decoration: InputDecoration(
          labelText: context.tr(widget.label),
          border: const OutlineInputBorder(),
          alignLabelWithHint: true,
          helperText: '$_n / ${widget.maxWords} ${context.tr('words')}',
          helperStyle: TextStyle(
              color: _n > widget.maxWords ? Colors.red : null,
              fontWeight: FontWeight.w600),
        ),
        validator: (v) {
          final n = wordCount(v ?? '');
          if (widget.required && n == 0) return context.tr('Required');
          if (n > widget.maxWords) {
            return '${context.tr('Maximum')} ${widget.maxWords} ${context.tr('words')}';
          }
          return null;
        },
      ),
    );
  }
}

/// Choice chips inside a Form (value -> label).
class ChoiceField extends StatelessWidget {
  final String label;
  final Map<String, String> options;
  final String? value;
  final ValueChanged<String> onChanged;
  final bool required;
  const ChoiceField({
    super.key,
    required this.label,
    required this.options,
    required this.value,
    required this.onChanged,
    this.required = true,
  });

  @override
  Widget build(BuildContext context) {
    return FormField<String>(
      initialValue: value,
      validator: (v) {
        if (!required) return null;
        if (v == null || !options.containsKey(v)) return context.tr('Please choose one');
        return null;
      },
      builder: (f) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(context.tr(label),
              style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Wrap(
            spacing: 8,
            children: options.entries
                .map((e) => ChoiceChip(
                      label: Text(context.tr(e.value)),
                      selected: f.value == e.key,
                      onSelected: (_) {
                        onChanged(e.key);
                        f.didChange(e.key);
                      },
                    ))
                .toList(),
          ),
          if (f.hasError)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(f.errorText!,
                  style: const TextStyle(color: Colors.red, fontSize: 12)),
            ),
        ]),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 14, 4, 6),
        child: Text(context.tr(text),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary)),
      );
}

/// Shows "Added by X" line.
Widget addedBy(BuildContext context, Json d) => Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Text(
        '${context.tr('Added by')}: ${d['createdByName'] ?? '-'}',
        style: const TextStyle(fontSize: 12, color: Colors.grey),
      ),
    );
