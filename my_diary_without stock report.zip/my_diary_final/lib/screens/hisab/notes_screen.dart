import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';

class NotesScreen extends StatelessWidget {
  final Biz biz;
  const NotesScreen({super.key, required this.biz});

  void _edit(BuildContext context, {String? id, Json? existing}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => _NoteEditor(biz: biz, id: id, existing: existing)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Business Notes'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.note_add),
        label: Text(context.tr('New note')),
        onPressed: () => _edit(context),
      ),
      body: QueryStream(
        query: biz.col('notes'),
        builder: (context, docs) {
          final list = [...docs]..sort((a, b) => toDate(b.data()['updatedAt'])
              .compareTo(toDate(a.data()['updatedAt'])));
          if (list.isEmpty) {
            return EmptyState(context.tr('No notes yet. Replace your paper notebook!'),
                icon: Icons.sticky_note_2);
          }
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 80),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final m = list[i].data();
              return Card(
                child: ListTile(
                  title: Text('${m['title']}'.isEmpty ? '(untitled)' : '${m['title']}',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('${m['body'] ?? ''}',
                      maxLines: 3, overflow: TextOverflow.ellipsis),
                  trailing: Text(fmtDate(toDate(m['updatedAt'])),
                      style: const TextStyle(fontSize: 11, color: Colors.grey)),
                  onTap: () => _edit(context, id: list[i].id, existing: m),
                  onLongPress: () async {
                    if (await confirm(context, context.tr('Delete this note?'))) {
                      list[i].reference.delete();
                    }
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _NoteEditor extends StatefulWidget {
  final Biz biz;
  final String? id;
  final Json? existing;
  const _NoteEditor({required this.biz, this.id, this.existing});

  @override
  State<_NoteEditor> createState() => _NoteEditorState();
}

class _NoteEditorState extends State<_NoteEditor> {
  late final _title = TextEditingController(text: widget.existing?['title'] as String?);
  late final _body = TextEditingController(text: widget.existing?['body'] as String?);

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  void _save() {
    if (_title.text.trim().isEmpty && _body.text.trim().isEmpty) {
      Navigator.pop(context);
      return;
    }
    final data = {
      'title': _title.text.trim(),
      'body': _body.text.trim(),
      'updatedAt': Timestamp.now(),
    };
    final col = widget.biz.col('notes');
    if (widget.id == null) {
      col.add(data);
    } else {
      col.doc(widget.id).update(data);
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('Note')),
        actions: [
          IconButton(icon: const Icon(Icons.check), onPressed: _save),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(
            controller: _title,
            decoration: InputDecoration(
                labelText: context.tr('Title'), border: const OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: TextField(
              controller: _body,
              expands: true,
              maxLines: null,
              minLines: null,
              textAlignVertical: TextAlignVertical.top,
              decoration: InputDecoration(
                  hintText: context.tr('Write your note...'),
                  border: const OutlineInputBorder()),
            ),
          ),
        ]),
      ),
    );
  }
}
