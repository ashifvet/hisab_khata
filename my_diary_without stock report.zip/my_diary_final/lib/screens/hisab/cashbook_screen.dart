import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import 'hisab_logic.dart';

class CashbookScreen extends StatefulWidget {
  final Biz biz;
  const CashbookScreen({super.key, required this.biz});

  @override
  State<CashbookScreen> createState() => _CashbookScreenState();
}

class _CashbookScreenState extends State<CashbookScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  String _filter = 'all'; // all | in | out | saving

  void _shift(int d) =>
      setState(() => _month = DateTime(_month.year, _month.month + d));

  @override
  Widget build(BuildContext context) {
    final biz = widget.biz;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Cashbook'))),
      body: QueryStream(
        query: biz.col('entries'),
        builder: (context, docs) {
          final cash = docs.where((d) {
            final t = '${d.data()['type']}';
            return cashInTypes.contains(t) || cashOutTypes.contains(t);
          });
          final inMonth = cash.where((d) {
            final dt = toDate(d.data()['date']);
            return dt.year == _month.year && dt.month == _month.month;
          }).toList();
          final totals = calcTotals(inMonth.map((d) => d.data()));
          final list = inMonth.where((d) {
            final t = '${d.data()['type']}';
            switch (_filter) {
              case 'in':
                return cashInTypes.contains(t);
              case 'out':
                return t == 'expense' || t == 'supplier_payment';
              case 'saving':
                return t == 'saving';
            }
            return true;
          }).toList()
            ..sort((a, b) =>
                toDate(b.data()['date']).compareTo(toDate(a.data()['date'])));
          final overall = calcTotals(cash.map((d) => d.data()));

          return Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(
                  onPressed: () => _shift(-1), icon: const Icon(Icons.chevron_left)),
              Text(fmtMonth(_month),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              IconButton(
                  onPressed: () => _shift(1), icon: const Icon(Icons.chevron_right)),
            ]),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(children: [
                    Row(children: [
                      _sum(context, 'Cash In', totals.cashIn, Colors.green.shade700),
                      _sum(context, 'Cash Out', totals.cashOut - totals.saving,
                          Colors.red.shade700),
                      _sum(context, 'Savings', totals.saving, Colors.blue.shade700),
                    ]),
                    const Divider(),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(context.tr('Total cash balance'),
                              style: const TextStyle(fontWeight: FontWeight.w600)),
                          Text(money(overall.balance),
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  color: overall.balance >= 0
                                      ? Colors.green.shade700
                                      : Colors.red.shade700)),
                        ]),
                  ]),
                ),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(children: [
                for (final f in const {
                  'all': 'All',
                  'in': 'Cash In',
                  'out': 'Cash Out',
                  'saving': 'Savings'
                }.entries)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(context.tr(f.value)),
                      selected: _filter == f.key,
                      onSelected: (_) => setState(() => _filter = f.key),
                    ),
                  ),
              ]),
            ),
            Expanded(
              child: list.isEmpty
                  ? EmptyState(context.tr('No entries this month.'), icon: Icons.menu_book)
                  : ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) {
                        final e = list[i].data();
                        final t = '${e['type']}';
                        final isIn = cashInTypes.contains(t);
                        final who = '${e['partyName'] ?? ''}';
                        final cat = '${e['category'] ?? ''}';
                        final note = '${e['note'] ?? ''}';
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: typeColor(t).withOpacity(0.15),
                            child: Icon(
                                isIn
                                    ? Icons.south_west
                                    : (t == 'saving' ? Icons.savings : Icons.north_east),
                                color: typeColor(t),
                                size: 20),
                          ),
                          title: Text(
                              [
                                if (who.isNotEmpty) who,
                                if (cat.isNotEmpty) context.tr(cat),
                                if (who.isEmpty && cat.isEmpty) context.tr(entryLabel(t)),
                              ].join(' • '),
                              style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text(
                              '${fmtDate(toDate(e['date']))}${note.isEmpty ? '' : '  •  $note'}',
                              style: const TextStyle(fontSize: 12)),
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            Text('${isIn ? '+' : '-'} ${money(toNum(e['amount']))}',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, color: typeColor(t))),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 20),
                              onPressed: () async {
                                if (await confirm(
                                    context, context.tr('Delete this entry?'))) {
                                  list[i].reference.delete();
                                }
                              },
                            ),
                          ]),
                          onTap: () => showEntryDialog(context, biz,
                              type: t,
                              partyId: e['partyId'] as String?,
                              partyName: e['partyName'] as String?,
                              entryId: list[i].id,
                              existing: e),
                        );
                      },
                    ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(children: [
                  Expanded(
                      child: FilledButton(
                    style: FilledButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        minimumSize: const Size.fromHeight(48)),
                    onPressed: () => showEntryDialog(context, biz, type: 'income'),
                    child: Text(context.tr('Cash In')),
                  )),
                  const SizedBox(width: 8),
                  Expanded(
                      child: FilledButton(
                    style: FilledButton.styleFrom(
                        backgroundColor: Colors.red.shade700,
                        minimumSize: const Size.fromHeight(48)),
                    onPressed: () => showEntryDialog(context, biz, type: 'expense'),
                    child: Text(context.tr('Cash Out')),
                  )),
                  const SizedBox(width: 8),
                  Expanded(
                      child: FilledButton(
                    style: FilledButton.styleFrom(
                        backgroundColor: Colors.blue.shade700,
                        minimumSize: const Size.fromHeight(48)),
                    onPressed: () => showEntryDialog(context, biz, type: 'saving'),
                    child: Text(context.tr('Savings')),
                  )),
                ]),
              ),
            ),
          ]);
        },
      ),
    );
  }

  Widget _sum(BuildContext context, String label, double v, Color c) => Expanded(
        child: Column(children: [
          Text(context.tr(label), style: const TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 2),
          FittedBox(
              child: Text(money(v),
                  style: TextStyle(fontWeight: FontWeight.bold, color: c, fontSize: 15))),
        ]),
      );
}
