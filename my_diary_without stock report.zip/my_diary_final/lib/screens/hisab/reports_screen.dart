import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../services/pdf_service.dart';
import '../../widgets/common.dart';
import 'hisab_logic.dart';
import 'parties_screen.dart';

class ReportsScreen extends StatelessWidget {
  final Biz biz;
  final int initialTab;
  const ReportsScreen({super.key, required this.biz, this.initialTab = 0});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      initialIndex: initialTab,
      child: Scaffold(
        appBar: AppBar(
          title: Text(context.tr('Reports')),
          bottom: TabBar(
            labelColor: Theme.of(context).colorScheme.onPrimary,
            unselectedLabelColor:
                Theme.of(context).colorScheme.onPrimary.withOpacity(0.7),
            indicatorColor: Theme.of(context).colorScheme.onPrimary,
            tabs: [
              Tab(text: context.tr('Monthly')),
              Tab(text: context.tr('Customer / Supplier')),
              Tab(text: context.tr('Cost & Savings')),
            ],
          ),
        ),
        body: QueryStream(
          query: biz.col('entries'),
          builder: (context, docs) {
            final entries = docs.map((d) => d.data()).toList();
            return TabBarView(children: [
              _MonthlyTab(biz: biz, entries: entries),
              _PartyReportTab(biz: biz, entries: entries),
              _CostTab(biz: biz, entries: entries),
            ]);
          },
        ),
      ),
    );
  }
}

class _MonthBar extends StatelessWidget {
  final DateTime month;
  final ValueChanged<int> onShift;
  final VoidCallback onPdf;
  const _MonthBar({required this.month, required this.onShift, required this.onPdf});

  @override
  Widget build(BuildContext context) => Row(children: [
        IconButton(onPressed: () => onShift(-1), icon: const Icon(Icons.chevron_left)),
        Expanded(
          child: Text(fmtMonth(month),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ),
        IconButton(onPressed: () => onShift(1), icon: const Icon(Icons.chevron_right)),
        IconButton(
            tooltip: 'PDF',
            onPressed: onPdf,
            icon: const Icon(Icons.picture_as_pdf, color: Colors.red)),
      ]);
}

List<Json> _inMonth(List<Json> all, DateTime m) => all.where((e) {
      final d = toDate(e['date']);
      return d.year == m.year && d.month == m.month;
    }).toList()
      ..sort((a, b) => toDate(a['date']).compareTo(toDate(b['date'])));

class _MonthlyTab extends StatefulWidget {
  final Biz biz;
  final List<Json> entries;
  const _MonthlyTab({required this.biz, required this.entries});

  @override
  State<_MonthlyTab> createState() => _MonthlyTabState();
}

class _MonthlyTabState extends State<_MonthlyTab> {
  DateTime _m = DateTime(DateTime.now().year, DateTime.now().month);

  @override
  Widget build(BuildContext context) {
    final list = _inMonth(widget.entries, _m);
    final t = calcTotals(list);
    double sum(String type) => list
        .where((e) => e['type'] == type)
        .fold(0.0, (a, e) => a + toNum(e['amount']));
    final lines = <List<String>>[
      ['Income (cash in)', money(sum('income'))],
      ['Payments received from customers', money(sum('customer_payment'))],
      ['Expenses', money(sum('expense'))],
      ['Payments made to suppliers', money(sum('supplier_payment'))],
      ['Savings', money(t.saving)],
      ['Credit sales (customers)', money(sum('sale_credit'))],
      ['Credit purchases (suppliers)', money(sum('purchase_credit'))],
    ];
    Future<void> pdf() => showPdfOptions(
          context,
          () => buildPdf(
            title: 'Monthly Report - ${fmtMonth(_m)}',
            subtitle: widget.biz.name,
            summary: [
              ['Total cash in', plainMoney(t.cashIn)],
              ['Total cash out (incl. savings)', plainMoney(t.cashOut)],
              ['Net cash flow', plainMoney(t.balance)],
              ['Savings', plainMoney(t.saving)],
              ['Credit sales', plainMoney(sum('sale_credit'))],
              ['Credit purchases', plainMoney(sum('purchase_credit'))],
            ],
            headers: ['Date', 'Type', 'Party / Category', 'Note', 'Amount'],
            rows: [
              for (final e in list)
                [
                  fmtDate(toDate(e['date'])),
                  entryLabel('${e['type']}'),
                  '${e['partyName'] ?? e['category'] ?? ''}',
                  '${e['note'] ?? ''}',
                  plainMoney(toNum(e['amount'])),
                ]
            ],
            rightAlign: {4},
          ),
          'monthly_report_${_m.year}_${_m.month}.pdf',
        );
    return ListView(padding: const EdgeInsets.all(12), children: [
      _MonthBar(
        month: _m,
        onShift: (d) => setState(() => _m = DateTime(_m.year, _m.month + d)),
        onPdf: pdf,
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(children: [
            Row(children: [
              _big(context, 'Cash In', t.cashIn, Colors.green.shade700),
              _big(context, 'Cash Out', t.cashOut, Colors.red.shade700),
              _big(context, 'Net', t.balance,
                  t.balance >= 0 ? Colors.green.shade700 : Colors.red.shade700),
            ]),
            const Divider(),
            for (final l in lines)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(child: Text(context.tr(l[0]))),
                      Text(l[1], style: const TextStyle(fontWeight: FontWeight.w600)),
                    ]),
              ),
          ]),
        ),
      ),
      const SectionTitle('Transactions'),
      if (list.isEmpty)
        EmptyState(context.tr('No entries this month.'))
      else
        for (final e in list.reversed)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text(
                '${context.tr(entryLabel('${e['type']}'))}${'${e['partyName'] ?? ''}'.isEmpty ? '' : ' • ${e['partyName']}'}'),
            subtitle: Text(
                '${fmtDate(toDate(e['date']))}${'${e['note'] ?? ''}'.isEmpty ? '' : ' • ${e['note']}'}'),
            trailing: Text(money(toNum(e['amount'])),
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: typeColor('${e['type']}'))),
          ),
    ]);
  }

  Widget _big(BuildContext context, String label, double v, Color c) => Expanded(
        child: Column(children: [
          Text(context.tr(label), style: const TextStyle(fontSize: 12, color: Colors.grey)),
          FittedBox(
              child: Text(money(v),
                  style: TextStyle(fontWeight: FontWeight.bold, color: c, fontSize: 16))),
        ]),
      );
}

class _PartyReportTab extends StatefulWidget {
  final Biz biz;
  final List<Json> entries;
  const _PartyReportTab({required this.biz, required this.entries});

  @override
  State<_PartyReportTab> createState() => _PartyReportTabState();
}

class _PartyReportTabState extends State<_PartyReportTab> {
  String _type = 'customer';

  @override
  Widget build(BuildContext context) {
    final bal = partyBalances(widget.entries);
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(10),
        child: SegmentedButton<String>(
          segments: [
            ButtonSegment(value: 'customer', label: Text(context.tr('Customers'))),
            ButtonSegment(value: 'supplier', label: Text(context.tr('Suppliers'))),
          ],
          selected: {_type},
          onSelectionChanged: (s) => setState(() => _type = s.first),
        ),
      ),
      Expanded(
        child: QueryStream(
          query: widget.biz.col('parties').where('type', isEqualTo: _type),
          builder: (context, docs) {
            final list = [...docs]..sort((a, b) =>
                (bal[b.id] ?? 0).abs().compareTo((bal[a.id] ?? 0).abs()));
            if (list.isEmpty) return EmptyState(context.tr('Nothing to show.'));
            var total = 0.0;
            for (final d in list) {
              total += bal[d.id] ?? 0;
            }
            Future<void> pdf() => showPdfOptions(
                  context,
                  () => buildPdf(
                    title: _type == 'customer' ? 'Customer Dues Report' : 'Supplier Payables Report',
                    subtitle: widget.biz.name,
                    summary: [
                      [_type == 'customer' ? "Total you'll get" : "Total you'll give", plainMoney(total)],
                    ],
                    headers: ['Name', 'Phone', 'Balance'],
                    rows: [
                      for (final d in list)
                        [
                          '${d.data()['name']}',
                          '${d.data()['phone'] ?? ''}',
                          plainMoney(bal[d.id] ?? 0),
                        ]
                    ],
                    rightAlign: {2},
                  ),
                  '${_type}_report.pdf',
                );
            return Column(children: [
              ListTile(
                title: Text(
                    context.tr(_type == 'customer' ? "Total you'll get" : "Total you'll give"),
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(context.tr('Tap a name for the full statement')),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(money(total),
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  IconButton(
                      onPressed: pdf,
                      icon: const Icon(Icons.picture_as_pdf, color: Colors.red)),
                ]),
              ),
              const Divider(height: 1),
              Expanded(
                child: ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final b = bal[list[i].id] ?? 0;
                    return ListTile(
                      title: Text('${list[i].data()['name']}'),
                      subtitle: Text('${list[i].data()['phone'] ?? ''}'),
                      trailing: Text(money(b),
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: b > 0
                                  ? (_type == 'customer'
                                      ? Colors.green.shade700
                                      : Colors.red.shade700)
                                  : Colors.grey)),
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => PartyDetail(
                                  biz: widget.biz,
                                  partyId: list[i].id,
                                  type: _type))),
                    );
                  },
                ),
              ),
            ]);
          },
        ),
      ),
    ]);
  }
}

class _CostTab extends StatefulWidget {
  final Biz biz;
  final List<Json> entries;
  const _CostTab({required this.biz, required this.entries});

  @override
  State<_CostTab> createState() => _CostTabState();
}

class _CostTabState extends State<_CostTab> {
  DateTime _m = DateTime(DateTime.now().year, DateTime.now().month);

  @override
  Widget build(BuildContext context) {
    final list = _inMonth(widget.entries, _m);
    final expenses = list.where((e) => e['type'] == 'expense').toList();
    final savings = list.where((e) => e['type'] == 'saving').toList();
    final byCat = <String, double>{};
    for (final e in expenses) {
      final c = '${e['category'] ?? 'Other'}';
      byCat[c] = (byCat[c] ?? 0) + toNum(e['amount']);
    }
    final totalExp = byCat.values.fold(0.0, (a, b) => a + b);
    final totalSave = savings.fold(0.0, (a, e) => a + toNum(e['amount']));
    final allSavings = widget.entries
        .where((e) => e['type'] == 'saving')
        .fold(0.0, (a, e) => a + toNum(e['amount']));
    final income = list
        .where((e) => e['type'] == 'income' || e['type'] == 'customer_payment')
        .fold(0.0, (a, e) => a + toNum(e['amount']));
    final cats = byCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    Future<void> pdf() => showPdfOptions(
          context,
          () => buildPdf(
            title: 'Cost & Savings Report - ${fmtMonth(_m)}',
            subtitle: widget.biz.name,
            summary: [
              ['Cash income this month', plainMoney(income)],
              ['Total cost (expenses)', plainMoney(totalExp)],
              ['Savings this month', plainMoney(totalSave)],
              ['All-time savings', plainMoney(allSavings)],
            ],
            headers: ['Date', 'Category', 'Note', 'Amount'],
            rows: [
              for (final e in [...expenses, ...savings]..sort((a, b) =>
                  toDate(a['date']).compareTo(toDate(b['date']))))
                [
                  fmtDate(toDate(e['date'])),
                  e['type'] == 'saving' ? 'Savings' : '${e['category'] ?? ''}',
                  '${e['note'] ?? ''}',
                  plainMoney(toNum(e['amount'])),
                ]
            ],
            rightAlign: {3},
          ),
          'cost_savings_${_m.year}_${_m.month}.pdf',
        );

    return ListView(padding: const EdgeInsets.all(12), children: [
      _MonthBar(
        month: _m,
        onShift: (d) => setState(() => _m = DateTime(_m.year, _m.month + d)),
        onPdf: pdf,
      ),
      Row(children: [
        Expanded(
            child: _card(context, 'Total cost', totalExp, Colors.red.shade700)),
        const SizedBox(width: 8),
        Expanded(
            child: _card(context, 'Savings (month)', totalSave, Colors.blue.shade700)),
      ]),
      Row(children: [
        Expanded(
            child: _card(context, 'Cash income', income, Colors.green.shade700)),
        const SizedBox(width: 8),
        Expanded(
            child: _card(context, 'All-time savings', allSavings, Colors.teal)),
      ]),
      const SectionTitle('Cost by category'),
      if (cats.isEmpty)
        EmptyState(context.tr('No expenses this month.'))
      else
        for (final c in cats)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(context.tr(c.key)),
                Text('${money(c.value)}  (${(c.value / totalExp * 100).toStringAsFixed(0)}%)',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ]),
              const SizedBox(height: 3),
              LinearProgressIndicator(
                  value: totalExp == 0 ? 0 : c.value / totalExp,
                  minHeight: 8,
                  color: Colors.red.shade400),
            ]),
          ),
      const SectionTitle('Savings entries'),
      if (savings.isEmpty)
        EmptyState(context.tr('No savings this month.'), icon: Icons.savings)
      else
        for (final e in savings.reversed)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.savings, color: Colors.blue),
            title: Text(fmtDate(toDate(e['date']))),
            subtitle: Text('${e['note'] ?? ''}'),
            trailing: Text(money(toNum(e['amount'])),
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.blue.shade700)),
          ),
    ]);
  }

  Widget _card(BuildContext context, String label, double v, Color c) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(context.tr(label), style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 4),
            FittedBox(
                child: Text(money(v),
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: c))),
          ]),
        ),
      );
}
