import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../services/pdf_service.dart';
import '../../widgets/common.dart';
import 'hisab_logic.dart';

/// List of customers or suppliers with their balances.
class PartiesScreen extends StatefulWidget {
  final Biz biz;
  final String type; // customer | supplier
  const PartiesScreen({super.key, required this.biz, required this.type});

  @override
  State<PartiesScreen> createState() => _PartiesScreenState();
}

class _PartiesScreenState extends State<PartiesScreen> {
  String _q = '';
  bool get _isCustomer => widget.type == 'customer';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr(_isCustomer ? 'Customers' : 'Suppliers'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.person_add),
        label: Text(context.tr(_isCustomer ? 'Add Customer' : 'Add Supplier')),
        onPressed: () => showPartyDialog(context, widget.biz, widget.type),
      ),
      body: QueryStream(
        query: widget.biz.col('entries'),
        builder: (context, entryDocs) {
          final bal = partyBalances(entryDocs.map((d) => d.data()));
          return QueryStream(
            query: widget.biz.col('parties').where('type', isEqualTo: widget.type),
            builder: (context, docs) {
              final list = docs
                  .where((d) =>
                      '${d.data()['name']} ${d.data()['phone']}'
                          .toLowerCase()
                          .contains(_q))
                  .toList()
                ..sort((a, b) => '${a.data()['name']}'
                    .toLowerCase()
                    .compareTo('${b.data()['name']}'.toLowerCase()));
              var total = 0.0;
              for (final d in docs) {
                total += bal[d.id] ?? 0;
              }
              return Column(children: [
                Container(
                  width: double.infinity,
                  color: (_isCustomer ? Colors.green : Colors.red).withOpacity(0.10),
                  padding: const EdgeInsets.all(14),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(context.tr(_isCustomer ? "You'll get" : "You'll give"),
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text(money(total),
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: _isCustomer
                                    ? Colors.green.shade700
                                    : Colors.red.shade700)),
                      ]),
                ),
                SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
                Expanded(
                  child: list.isEmpty
                      ? EmptyState(
                          context.tr(_isCustomer
                              ? 'No customers yet.'
                              : 'No suppliers yet.'),
                          icon: Icons.people_outline)
                      : ListView.separated(
                          padding: const EdgeInsets.only(bottom: 80),
                          itemCount: list.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, i) {
                            final d = list[i];
                            final m = d.data();
                            final b = bal[d.id] ?? 0;
                            final good = _isCustomer ? b > 0 : b < 0;
                            String label;
                            Color color;
                            if (b.abs() < 0.005) {
                              label = context.tr('Settled');
                              color = Colors.grey;
                            } else if (_isCustomer) {
                              label = b > 0 ? context.tr("You'll get") : context.tr('Advance');
                              color = b > 0 ? Colors.green.shade700 : Colors.blue.shade700;
                            } else {
                              label = b > 0 ? context.tr("You'll give") : context.tr('Advance');
                              color = b > 0 ? Colors.red.shade700 : Colors.blue.shade700;
                            }
                            if (good) {}
                            return ListTile(
                              leading: CircleAvatar(
                                  child: Text('${m['name'] ?? '?'}'
                                      .characters
                                      .first
                                      .toUpperCase())),
                              title: Text('${m['name']}'),
                              subtitle: Text('${m['phone'] ?? ''}',
                                  style: const TextStyle(fontSize: 12)),
                              trailing: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(money(b.abs()),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: color)),
                                    Text(label,
                                        style: TextStyle(fontSize: 11, color: color)),
                                  ]),
                              onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => PartyDetail(
                                          biz: widget.biz,
                                          partyId: d.id,
                                          type: widget.type))),
                            );
                          },
                        ),
                ),
              ]);
            },
          );
        },
      ),
    );
  }
}

class PartyDetail extends StatelessWidget {
  final Biz biz;
  final String partyId;
  final String type;
  const PartyDetail(
      {super.key, required this.biz, required this.partyId, required this.type});

  bool get _isCustomer => type == 'customer';

  Future<void> _sms(BuildContext context, Json p, double due) async {
    final msg =
        'Dear ${p['name']}, your due balance with ${biz.name} is ${plainMoney(due)}. Please pay soon. Thank you.';
    await openUrl(context, 'sms:${p['phone']}?body=${Uri.encodeComponent(msg)}');
  }

  Future<void> _whatsapp(BuildContext context, Json p, double due) async {
    final msg =
        'Dear ${p['name']}, your due balance with ${biz.name} is ${plainMoney(due)}. Please pay soon. Thank you.';
    await openUrl(context,
        'https://wa.me/${waNumber('${p['phone']}')}?text=${Uri.encodeComponent(msg)}');
  }

  Future<List<List<String>>> _rows(List<Json> entries) async => [
        for (final e in entries)
          [
            fmtDate(toDate(e['date'])),
            '${e['note'] ?? ''}'.isEmpty
                ? entryLabel('${e['type']}')
                : '${entryLabel('${e['type']}')} - ${e['note']}',
            (e['type'] == 'sale_credit' || e['type'] == 'purchase_credit')
                ? plainMoney(toNum(e['amount']))
                : '',
            (e['type'] == 'customer_payment' || e['type'] == 'supplier_payment')
                ? plainMoney(toNum(e['amount']))
                : '',
          ]
      ];

  @override
  Widget build(BuildContext context) {
    final partyRef = biz.col('parties').doc(partyId);
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: partyRef.snapshots(),
      builder: (context, psnap) {
        final p = psnap.data?.data();
        if (p == null) {
          return Scaffold(
              appBar: AppBar(),
              body: const Center(child: CircularProgressIndicator()));
        }
        final firstType = _isCustomer ? 'sale_credit' : 'purchase_credit';
        final secondType = _isCustomer ? 'customer_payment' : 'supplier_payment';
        return QueryStream(
          query: biz.col('entries').where('partyId', isEqualTo: partyId),
          builder: (context, docs) {
            final list = [...docs]..sort((a, b) =>
                toDate(b.data()['date']).compareTo(toDate(a.data()['date'])));
            final b = partyBalances(docs.map((d) => d.data()))[partyId] ?? 0;
            final color = b.abs() < 0.005
                ? Colors.grey
                : (_isCustomer
                    ? (b > 0 ? Colors.green.shade700 : Colors.blue.shade700)
                    : (b > 0 ? Colors.red.shade700 : Colors.blue.shade700));
            final label = b.abs() < 0.005
                ? context.tr('Settled')
                : (b > 0
                    ? context.tr(_isCustomer ? "You'll get" : "You'll give")
                    : context.tr('Advance'));
            return Scaffold(
              appBar: AppBar(
                title: Text('${p['name']}'),
                actions: [
                  IconButton(
                    tooltip: 'PDF',
                    icon: const Icon(Icons.picture_as_pdf),
                    onPressed: () => showPdfOptions(
                      context,
                      () async => buildPdf(
                        title: '${p['name']} - ${_isCustomer ? 'Customer' : 'Supplier'} Statement',
                        subtitle: '${biz.name}   |   ${p['phone'] ?? ''}',
                        summary: [
                          [b > 0 ? (_isCustomer ? "You'll get" : "You'll give") : 'Balance', plainMoney(b.abs())],
                        ],
                        headers: [
                          'Date',
                          'Details',
                          _isCustomer ? 'You gave (credit)' : 'You got (credit)',
                          _isCustomer ? 'You got (paid)' : 'You gave (paid)',
                        ],
                        rows: await _rows(list.reversed.map((d) => d.data()).toList()),
                        rightAlign: {2, 3},
                      ),
                      '${p['name']}_statement.pdf',
                    ),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'edit') {
                        showPartyDialog(context, biz, type,
                            partyId: partyId, existing: p);
                      } else if (v == 'delete') {
                        final nav = Navigator.of(context);
                        if (await confirm(
                            context,
                            context.tr(
                                'Delete this party and all its entries?'))) {
                          final batch = db.batch();
                          for (final d in docs) {
                            batch.delete(d.reference);
                          }
                          batch.delete(partyRef);
                          batch.commit();
                          nav.pop();
                        }
                      } else if (v == 'call') {
                        openUrl(context, 'tel:${p['phone']}');
                      }
                    },
                    itemBuilder: (c) => [
                      PopupMenuItem(value: 'call', child: Text(c.tr('Call'))),
                      PopupMenuItem(value: 'edit', child: Text(c.tr('Edit'))),
                      PopupMenuItem(value: 'delete', child: Text(c.tr('Delete'))),
                    ],
                  ),
                ],
              ),
              body: Column(children: [
                Container(
                  width: double.infinity,
                  color: color.withOpacity(0.10),
                  padding: const EdgeInsets.all(14),
                  child: Column(children: [
                    Text(label, style: TextStyle(color: color)),
                    Text(money(b.abs()),
                        style: TextStyle(
                            fontSize: 28, fontWeight: FontWeight.bold, color: color)),
                    if (_isCustomer &&
                        b > 0 &&
                        '${p['phone'] ?? ''}'.trim().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Wrap(spacing: 8, children: [
                          OutlinedButton.icon(
                              onPressed: () => _sms(context, p, b),
                              icon: const Icon(Icons.sms, size: 18),
                              label: Text(context.tr('SMS reminder'))),
                          OutlinedButton.icon(
                              onPressed: () => _whatsapp(context, p, b),
                              icon: const Icon(Icons.chat, size: 18),
                              label: const Text('WhatsApp')),
                        ]),
                      ),
                  ]),
                ),
                Expanded(
                  child: list.isEmpty
                      ? EmptyState(context.tr('No transactions yet.'),
                          icon: Icons.receipt_long)
                      : ListView.separated(
                          itemCount: list.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, i) {
                            final e = list[i].data();
                            final t = '${e['type']}';
                            return ListTile(
                              title: Text(context.tr(entryLabel(t)),
                                  style: TextStyle(
                                      color: typeColor(t),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14)),
                              subtitle: Text(
                                  '${fmtDate(toDate(e['date']))}${'${e['note'] ?? ''}'.isEmpty ? '' : '  •  ${e['note']}'}',
                                  style: const TextStyle(fontSize: 12)),
                              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                                Text(money(toNum(e['amount'])),
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: typeColor(t))),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline, size: 20),
                                  onPressed: () async {
                                    if (await confirm(context,
                                        context.tr('Delete this entry?'))) {
                                      list[i].reference.delete();
                                    }
                                  },
                                ),
                              ]),
                              onTap: () => showEntryDialog(context, biz,
                                  type: t,
                                  partyId: partyId,
                                  partyName: '${p['name']}',
                                  entryId: list[i].id,
                                  existing: e),
                            );
                          },
                        ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(children: [
                      Expanded(
                        child: FilledButton(
                          style: FilledButton.styleFrom(
                              backgroundColor: _isCustomer
                                  ? Colors.orange.shade800
                                  : Colors.purple.shade600,
                              minimumSize: const Size.fromHeight(48)),
                          onPressed: () => showEntryDialog(context, biz,
                              type: firstType,
                              partyId: partyId,
                              partyName: '${p['name']}'),
                          child: Text(context.tr(_isCustomer
                              ? 'You gave (credit)'
                              : 'You got (credit)')),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton(
                          style: FilledButton.styleFrom(
                              backgroundColor: _isCustomer
                                  ? Colors.green.shade700
                                  : Colors.red.shade700,
                              minimumSize: const Size.fromHeight(48)),
                          onPressed: () => showEntryDialog(context, biz,
                              type: secondType,
                              partyId: partyId,
                              partyName: '${p['name']}'),
                          child: Text(context.tr(
                              _isCustomer ? 'You got (paid)' : 'You gave (paid)')),
                        ),
                      ),
                    ]),
                  ),
                ),
              ]),
            );
          },
        );
      },
    );
  }
}
