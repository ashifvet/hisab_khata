import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import 'hisab_logic.dart';

/// Group messages (batch reminders) for customers who owe money.
class RemindersScreen extends StatefulWidget {
  final Biz biz;
  const RemindersScreen({super.key, required this.biz});

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  late final _msg = TextEditingController(
      text:
          'Dear {name}, your due balance with ${widget.biz.name} is {amount}. Please pay as soon as possible. Thank you.');
  final Set<String> _selected = {};
  List<_Due> _queue = [];
  int _qi = 0;

  @override
  void dispose() {
    _msg.dispose();
    super.dispose();
  }

  String _text(_Due d) =>
      _msg.text.replaceAll('{name}', d.name).replaceAll('{amount}', plainMoney(d.due));

  Future<void> _sendSms(_Due d) =>
      openUrl(context, 'sms:${d.phone}?body=${Uri.encodeComponent(_text(d))}');

  Future<void> _sendWa(_Due d) => openUrl(context,
      'https://wa.me/${waNumber(d.phone)}?text=${Uri.encodeComponent(_text(d))}');

  /// ONE message to MANY people (opens a group SMS in the SMS app).
  Future<void> _groupSms(List<_Due> sel) {
    final numbers = sel.map((d) => d.phone.replaceAll(' ', '')).join(',');
    final text = _msg.text
        .replaceAll('{name}', 'Customer')
        .replaceAll('{amount}', 'the due amount');
    return openUrl(context, 'sms:$numbers?body=${Uri.encodeComponent(text)}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Group Reminder'))),
      body: QueryStream(
        query: widget.biz.col('entries'),
        builder: (context, entryDocs) {
          final bal = partyBalances(entryDocs.map((d) => d.data()));
          return QueryStream(
            query: widget.biz.col('parties').where('type', isEqualTo: 'customer'),
            builder: (context, docs) {
              final dues = <_Due>[
                for (final d in docs)
                  if ((bal[d.id] ?? 0) > 0 && '${d.data()['phone'] ?? ''}'.trim().isNotEmpty)
                    _Due(d.id, '${d.data()['name']}', '${d.data()['phone']}', bal[d.id]!)
              ]..sort((a, b) => b.due.compareTo(a.due));
              final sel = dues.where((d) => _selected.contains(d.id)).toList();
              return Column(children: [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: TextField(
                    controller: _msg,
                    minLines: 3,
                    maxLines: 5,
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      labelText: context.tr('Message'),
                      helperText:
                          context.tr('Use {name} and {amount} — they are replaced for each customer.'),
                      border: const OutlineInputBorder(),
                    ),
                  ),
                ),
                if (dues.isNotEmpty)
                  CheckboxListTile(
                    dense: true,
                    value: sel.length == dues.length,
                    title: Text('${context.tr('Select all')} (${dues.length})'),
                    onChanged: (v) => setState(() {
                      if (v == true) {
                        _selected.addAll(dues.map((d) => d.id));
                      } else {
                        _selected.clear();
                      }
                    }),
                  ),
                Expanded(
                  child: dues.isEmpty
                      ? EmptyState(
                          context.tr('No customers with due balance and phone number.'),
                          icon: Icons.sms)
                      : ListView.separated(
                          itemCount: dues.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, i) {
                            final d = dues[i];
                            return CheckboxListTile(
                              value: _selected.contains(d.id),
                              onChanged: (v) => setState(() {
                                if (v == true) {
                                  _selected.add(d.id);
                                } else {
                                  _selected.remove(d.id);
                                }
                              }),
                              title: Text(d.name),
                              subtitle: Text('${d.phone}  •  ${money(d.due)}'),
                              secondary: Row(mainAxisSize: MainAxisSize.min, children: [
                                IconButton(
                                    icon: const Icon(Icons.sms, color: Colors.blue),
                                    onPressed: () => _sendSms(d)),
                                IconButton(
                                    icon: const Icon(Icons.chat, color: Colors.green),
                                    onPressed: () => _sendWa(d)),
                              ]),
                            );
                          },
                        ),
                ),
                if (_queue.isNotEmpty)
                  Container(
                    color: Colors.teal.withOpacity(0.12),
                    padding: const EdgeInsets.all(10),
                    child: Row(children: [
                      Expanded(
                        child: Text(
                            '${context.tr('Sending')} ${_qi + 1}/${_queue.length}: ${_queue[_qi].name}'),
                      ),
                      FilledButton(
                        onPressed: () async {
                          if (_qi + 1 >= _queue.length) {
                            setState(() => _queue = []);
                          } else {
                            setState(() => _qi++);
                            await _sendSms(_queue[_qi]);
                          }
                        },
                        child: Text(context.tr(_qi + 1 >= _queue.length ? 'Done' : 'Next')),
                      ),
                    ]),
                  ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: sel.isEmpty
                              ? null
                              : () {
                                  setState(() {
                                    _queue = sel;
                                    _qi = 0;
                                  });
                                  _sendSms(sel.first);
                                },
                          icon: const Icon(Icons.format_list_numbered),
                          label: Text(context.tr('One by one'), maxLines: 1),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: sel.isEmpty ? null : () => _groupSms(sel),
                          icon: const Icon(Icons.groups),
                          label: Text('${context.tr('Group SMS')} (${sel.length})',
                              maxLines: 1),
                        ),
                      ),
                    ]),
                  ),
                ),
              ]);
            },
          );
        },
      ),
    );
  }
}

class _Due {
  final String id, name, phone;
  final double due;
  _Due(this.id, this.name, this.phone, this.due);
}
