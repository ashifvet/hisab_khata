import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import 'hisab_logic.dart';

class StockScreen extends StatefulWidget {
  final Biz biz;
  const StockScreen({super.key, required this.biz});

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  String _q = '';

  Future<void> _productDialog({String? id, Json? existing}) async {
    final name = TextEditingController(text: existing?['name'] as String?);
    final unit = TextEditingController(text: (existing?['unit'] as String?) ?? 'pcs');
    final qty = TextEditingController(text: existing == null ? '' : num2s(existing['qty']));
    final buy =
        TextEditingController(text: existing == null ? '' : num2s(existing['buyPrice']));
    final sell =
        TextEditingController(text: existing == null ? '' : num2s(existing['sellPrice']));
    final key = GlobalKey<FormState>();
    const dec = TextInputType.numberWithOptions(decimal: true);
    String? numV(String? v) =>
        (v != null && v.trim().isNotEmpty && double.tryParse(v.trim()) == null)
            ? context.tr('Enter a valid amount')
            : null;
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(c.tr(id == null ? 'Add Product' : 'Edit Product')),
        content: Form(
          key: key,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              tf(name, 'Product name', required: true),
              Row(children: [
                Expanded(child: tf(qty, 'Quantity', keyboard: dec, validator: numV)),
                const SizedBox(width: 8),
                Expanded(child: tf(unit, 'Unit')),
              ]),
              tf(buy, 'Buying price (per unit)', keyboard: dec, validator: numV),
              tf(sell, 'Selling price (per unit)', keyboard: dec, validator: numV),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: Text(c.tr('Cancel'))),
          FilledButton(
            onPressed: () {
              if (!key.currentState!.validate()) return;
              final data = {
                'name': name.text.trim(),
                'unit': unit.text.trim().isEmpty ? 'pcs' : unit.text.trim(),
                'qty': double.tryParse(qty.text.trim()) ?? 0,
                'buyPrice': double.tryParse(buy.text.trim()) ?? 0,
                'sellPrice': double.tryParse(sell.text.trim()) ?? 0,
              };
              final col = widget.biz.col('products');
              if (id == null) {
                col.add({...data, 'createdAt': Timestamp.now()});
              } else {
                col.doc(id).update(data);
              }
              Navigator.pop(c);
            },
            child: Text(c.tr('Save')),
          ),
        ],
      ),
    );
  }

  Future<void> _adjust(DocumentReference<Json> ref, Json p, bool stockIn) async {
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(c.tr(stockIn ? 'Stock In' : 'Stock Out')),
        content: TextField(
          controller: ctl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
              labelText: '${c.tr('Quantity')} (${p['unit']})',
              border: const OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(c.tr('Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(c.tr('Save'))),
        ],
      ),
    );
    final q = double.tryParse(ctl.text.trim());
    if (ok != true || q == null || q <= 0) return;
    if (!stockIn && q > toNum(p['qty'])) {
      if (mounted) snack(context, context.tr('Not enough stock'));
      return;
    }
    ref.update({'qty': FieldValue.increment(stockIn ? q : -q)});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Stock & Inventory'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: Text(context.tr('Add Product')),
        onPressed: () => _productDialog(),
      ),
      body: QueryStream(
        query: widget.biz.col('products'),
        builder: (context, docs) {
          var value = 0.0, saleValue = 0.0;
          for (final d in docs) {
            final m = d.data();
            value += toNum(m['qty']) * toNum(m['buyPrice']);
            saleValue += toNum(m['qty']) * toNum(m['sellPrice']);
          }
          final list = docs
              .where((d) => '${d.data()['name']}'.toLowerCase().contains(_q))
              .toList()
            ..sort((a, b) => '${a.data()['name']}'
                .toLowerCase()
                .compareTo('${b.data()['name']}'.toLowerCase()));
          return Column(children: [
            Container(
              width: double.infinity,
              color: Colors.brown.withOpacity(0.10),
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(context.tr('Stock value (buying price)'),
                      style: const TextStyle(fontSize: 12)),
                  Text(money(value),
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(context.tr('At selling price'), style: const TextStyle(fontSize: 12)),
                  Text(money(saleValue),
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                ]),
              ]),
            ),
            SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
            Expanded(
              child: list.isEmpty
                  ? EmptyState(context.tr('No products yet.'), icon: Icons.inventory_2)
                  : ListView.separated(
                      padding: const EdgeInsets.only(bottom: 80),
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) {
                        final m = list[i].data();
                        final q = toNum(m['qty']);
                        return ListTile(
                          title: Text('${m['name']}'),
                          subtitle: Text(
                              '${context.tr('Buy')}: ${money(toNum(m['buyPrice']))}  •  ${context.tr('Sell')}: ${money(toNum(m['sellPrice']))}',
                              style: const TextStyle(fontSize: 12)),
                          trailing: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text('${num2s(q)} ${m['unit']}',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: q <= 0 ? Colors.red : null)),
                                Text(money(q * toNum(m['buyPrice'])),
                                    style: const TextStyle(fontSize: 11, color: Colors.grey)),
                              ]),
                          onTap: () => showModalBottomSheet<void>(
                            context: context,
                            builder: (c) => SafeArea(
                              child: Column(mainAxisSize: MainAxisSize.min, children: [
                                ListTile(
                                  leading: const Icon(Icons.add_box, color: Colors.green),
                                  title: Text(c.tr('Stock In')),
                                  onTap: () {
                                    Navigator.pop(c);
                                    _adjust(list[i].reference, m, true);
                                  },
                                ),
                                ListTile(
                                  leading: const Icon(Icons.indeterminate_check_box,
                                      color: Colors.red),
                                  title: Text(c.tr('Stock Out')),
                                  onTap: () {
                                    Navigator.pop(c);
                                    _adjust(list[i].reference, m, false);
                                  },
                                ),
                                ListTile(
                                  leading: const Icon(Icons.edit),
                                  title: Text(c.tr('Edit')),
                                  onTap: () {
                                    Navigator.pop(c);
                                    _productDialog(id: list[i].id, existing: m);
                                  },
                                ),
                                ListTile(
                                  leading: const Icon(Icons.delete, color: Colors.red),
                                  title: Text(c.tr('Delete')),
                                  onTap: () async {
                                    Navigator.pop(c);
                                    if (await confirm(
                                        context, context.tr('Delete this product?'))) {
                                      list[i].reference.delete();
                                    }
                                  },
                                ),
                              ]),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ]);
        },
      ),
    );
  }
}
