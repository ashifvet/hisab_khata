import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';

/// Entry types stored in  users/{uid}/businesses/{biz}/entries
///   income            cash in  (sale, consultation fee ...)
///   expense           cash out (cost)
///   saving            cash moved to savings
///   sale_credit       customer owes you more   (You gave)
///   customer_payment  customer paid you        (You got)  - cash in
///   purchase_credit   you owe supplier more    (You got goods)
///   supplier_payment  you paid supplier        (You gave) - cash out
const cashInTypes = {'income', 'customer_payment'};
const cashOutTypes = {'expense', 'supplier_payment', 'saving'};

const expenseCategories = [
  'Purchase of goods',
  'Rent',
  'Salary',
  'Transport',
  'Electricity / Utility',
  'Food',
  'Medicine / Supplies',
  'Marketing',
  'Other',
];

String entryLabel(String type) {
  switch (type) {
    case 'income':
      return 'Cash In (Income)';
    case 'expense':
      return 'Cash Out (Expense)';
    case 'saving':
      return 'Savings';
    case 'sale_credit':
      return 'You gave (Credit sale)';
    case 'customer_payment':
      return 'You got (Payment received)';
    case 'purchase_credit':
      return 'You got (Credit purchase)';
    case 'supplier_payment':
      return 'You gave (Payment made)';
  }
  return type;
}

class Totals {
  double cashIn = 0, cashOut = 0, saving = 0, expense = 0, income = 0;
  double receivable = 0, payable = 0;
  double get balance => cashIn - cashOut;
}

Totals calcTotals(Iterable<Json> entries) {
  final t = Totals();
  for (final e in entries) {
    final type = '${e['type']}';
    final a = toNum(e['amount']);
    if (cashInTypes.contains(type)) t.cashIn += a;
    if (cashOutTypes.contains(type)) t.cashOut += a;
    switch (type) {
      case 'income':
        t.income += a;
        break;
      case 'expense':
        t.expense += a;
        break;
      case 'saving':
        t.saving += a;
        break;
      case 'sale_credit':
        t.receivable += a;
        break;
      case 'customer_payment':
        t.receivable -= a;
        break;
      case 'purchase_credit':
        t.payable += a;
        break;
      case 'supplier_payment':
        t.payable -= a;
        break;
    }
  }
  return t;
}

/// partyId -> balance. Customers: positive = they owe you.
/// Suppliers: positive = you owe them.
Map<String, double> partyBalances(Iterable<Json> entries) {
  final m = <String, double>{};
  for (final e in entries) {
    final id = e['partyId'];
    if (id is! String) continue;
    final a = toNum(e['amount']);
    switch ('${e['type']}') {
      case 'sale_credit':
      case 'purchase_credit':
        m[id] = (m[id] ?? 0) + a;
        break;
      case 'customer_payment':
      case 'supplier_payment':
        m[id] = (m[id] ?? 0) - a;
        break;
    }
  }
  return m;
}

String num2s(dynamic v) {
  final d = toNum(v);
  return d == d.roundToDouble() ? d.toStringAsFixed(0) : d.toString();
}

Color typeColor(String type) {
  if (cashInTypes.contains(type)) return Colors.green.shade700;
  if (type == 'saving') return Colors.blue.shade700;
  if (type == 'sale_credit') return Colors.orange.shade800;
  if (type == 'purchase_credit') return Colors.purple.shade600;
  return Colors.red.shade700;
}

/// Add or edit an entry.
Future<void> showEntryDialog(
  BuildContext context,
  Biz biz, {
  required String type,
  String? partyId,
  String? partyName,
  String? entryId,
  Json? existing,
}) async {
  final amount = TextEditingController(
      text: existing == null ? '' : num2s(existing['amount']));
  final note = TextEditingController(text: existing?['note'] as String?);
  var category = (existing?['category'] as String?) ?? expenseCategories.first;
  if (!expenseCategories.contains(category)) category = 'Other';
  var date = existing == null ? DateTime.now() : toDate(existing['date']);
  final key = GlobalKey<FormState>();

  await showDialog<void>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, setS) => AlertDialog(
        title: Text(c.tr(entryLabel(type))),
        content: Form(
          key: key,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (partyName != null)
                Align(
                    alignment: Alignment.centerLeft,
                    child: Text(partyName,
                        style: const TextStyle(fontWeight: FontWeight.bold))),
              tf(amount, 'Amount (Tk)',
                  keyboard: const TextInputType.numberWithOptions(decimal: true),
                  validator: (v) {
                    final n = double.tryParse((v ?? '').trim());
                    return (n == null || n <= 0) ? c.tr('Enter a valid amount') : null;
                  }),
              if (type == 'expense')
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: DropdownButtonFormField<String>(
                    value: category,
                    isExpanded: true,
                    decoration: InputDecoration(
                        labelText: c.tr('Category'),
                        border: const OutlineInputBorder()),
                    items: [
                      for (final x in expenseCategories)
                        DropdownMenuItem(value: x, child: Text(c.tr(x))),
                    ],
                    onChanged: (v) => setS(() => category = v ?? 'Other'),
                  ),
                ),
              tf(note, 'Note (optional)', lines: 2),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_today),
                title: Text(fmtDate(date)),
                onTap: () async {
                  final p = await showDatePicker(
                    context: c,
                    initialDate: date,
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (p != null) setS(() => date = p);
                },
              ),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: Text(c.tr('Cancel'))),
          FilledButton(
            onPressed: () {
              if (!key.currentState!.validate()) return;
              final data = <String, dynamic>{
                'type': type,
                'amount': double.parse(amount.text.trim()),
                'note': note.text.trim(),
                'date': Timestamp.fromDate(date),
                if (type == 'expense') 'category': category,
                if (type == 'saving') 'category': 'Savings',
                if (partyId != null) 'partyId': partyId,
                if (partyName != null) 'partyName': partyName,
              };
              final col = biz.col('entries');
              if (entryId == null) {
                col.add({...data, 'createdAt': Timestamp.now()});
              } else {
                col.doc(entryId).update(data);
              }
              Navigator.pop(c);
            },
            child: Text(c.tr('Save')),
          ),
        ],
      ),
    ),
  );
}

/// Add / edit a customer or supplier.
Future<void> showPartyDialog(
  BuildContext context,
  Biz biz,
  String type, {
  String? partyId,
  Json? existing,
}) async {
  final name = TextEditingController(text: existing?['name'] as String?);
  final phone = TextEditingController(text: existing?['phone'] as String?);
  final address = TextEditingController(text: existing?['address'] as String?);
  final key = GlobalKey<FormState>();
  await showDialog<void>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(c.tr(partyId == null
          ? (type == 'customer' ? 'Add Customer' : 'Add Supplier')
          : (type == 'customer' ? 'Edit Customer' : 'Edit Supplier'))),
      content: Form(
        key: key,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            tf(name, 'Name', required: true),
            tf(phone, 'Phone number', keyboard: TextInputType.phone),
            tf(address, 'Address (optional)'),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: Text(c.tr('Cancel'))),
        FilledButton(
          onPressed: () {
            if (!key.currentState!.validate()) return;
            final data = {
              'type': type,
              'name': name.text.trim(),
              'phone': phone.text.trim(),
              'address': address.text.trim(),
            };
            final col = biz.col('parties');
            if (partyId == null) {
              col.add({...data, 'createdAt': Timestamp.now()});
            } else {
              col.doc(partyId).update(data);
            }
            Navigator.pop(c);
          },
          child: Text(c.tr('Save')),
        ),
      ],
    ),
  );
}
