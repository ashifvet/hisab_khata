import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import 'cashbook_screen.dart';
import 'hisab_logic.dart';
import 'notes_screen.dart';
import 'parties_screen.dart';
import 'reminders_screen.dart';
import 'reports_screen.dart';
import 'stock_screen.dart';

/// Bottom-bar tab: the logged in user's own current business.
class HisabTab extends StatelessWidget {
  const HisabTab({super.key});

  @override
  Widget build(BuildContext context) {
    final biz = context.watch<AppState>().biz;
    if (biz == null) return const Center(child: CircularProgressIndicator());
    return HisabHome(biz: biz, own: true);
  }
}

class HisabHome extends StatelessWidget {
  final Biz biz;
  final bool own; // own = can switch / add businesses
  const HisabHome({super.key, required this.biz, this.own = false});

  void _push(BuildContext context, Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  void _bizSheet(BuildContext context) {
    final nameCtl = TextEditingController();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (c) => Consumer<AppState>(
        builder: (c, s, _) => Padding(
          padding: EdgeInsets.fromLTRB(
              16, 16, 16, 16 + MediaQuery.of(c).viewInsets.bottom),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(c.tr('My Businesses'),
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            for (final d in s.businesses)
              ListTile(
                leading: Icon(d.id == s.currentBizId
                    ? Icons.radio_button_checked
                    : Icons.radio_button_unchecked),
                title: Text('${d.data()['name']}'),
                trailing: IconButton(
                  icon: const Icon(Icons.edit, size: 20),
                  onPressed: () async {
                    final ctl = TextEditingController(text: '${d.data()['name']}');
                    final ok = await showDialog<bool>(
                      context: c,
                      builder: (x) => AlertDialog(
                        title: Text(x.tr('Rename business')),
                        content: TextField(controller: ctl),
                        actions: [
                          TextButton(
                              onPressed: () => Navigator.pop(x, false),
                              child: Text(x.tr('Cancel'))),
                          FilledButton(
                              onPressed: () => Navigator.pop(x, true),
                              child: Text(x.tr('Save'))),
                        ],
                      ),
                    );
                    if (ok == true && ctl.text.trim().isNotEmpty) {
                      s.renameBusiness(d.id, ctl.text);
                    }
                  },
                ),
                onTap: () {
                  s.setBiz(d.id);
                  Navigator.pop(c);
                },
              ),
            const Divider(),
            if (s.businesses.length < maxBusinesses)
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: nameCtl,
                    decoration: InputDecoration(
                        hintText: c.tr('New business name'),
                        isDense: true,
                        border: const OutlineInputBorder()),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () async {
                    if (nameCtl.text.trim().isEmpty) return;
                    final err = await s.addBusiness(nameCtl.text);
                    if (err != null && c.mounted) {
                      snack(c, err);
                    } else {
                      nameCtl.clear();
                      if (c.mounted) Navigator.pop(c);
                    }
                  },
                  child: Text(c.tr('Add')),
                ),
              ])
            else
              Text(c.tr('Maximum 5 businesses reached'),
                  style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return QueryStream(
      query: biz.col('entries'),
      builder: (context, docs) {
        final entries = docs.map((d) => d.data()).toList();
        final all = calcTotals(entries);
        final now = DateTime.now();
        final today = calcTotals(entries.where((e) {
          final d = toDate(e['date']);
          return d.year == now.year && d.month == now.month && d.day == now.day;
        }));
        final month = calcTotals(entries.where((e) {
          final d = toDate(e['date']);
          return d.year == now.year && d.month == now.month;
        }));

        final tiles = <_Tile>[
          _Tile('Customers', Icons.people, Colors.blue,
              () => _push(context, PartiesScreen(biz: biz, type: 'customer'))),
          _Tile('Suppliers', Icons.local_shipping, Colors.orange,
              () => _push(context, PartiesScreen(biz: biz, type: 'supplier'))),
          _Tile('Cashbook', Icons.menu_book, Colors.green,
              () => _push(context, CashbookScreen(biz: biz))),
          _Tile('Stock', Icons.inventory_2, Colors.brown,
              () => _push(context, StockScreen(biz: biz))),
          _Tile('Reports', Icons.assessment, Colors.purple,
              () => _push(context, ReportsScreen(biz: biz))),
          _Tile('Cost & Savings', Icons.savings, Colors.teal,
              () => _push(context, ReportsScreen(biz: biz, initialTab: 2))),
          _Tile('Group Reminder', Icons.sms, Colors.red,
              () => _push(context, RemindersScreen(biz: biz))),
          _Tile('Notes', Icons.sticky_note_2, Colors.amber.shade800,
              () => _push(context, NotesScreen(biz: biz))),
        ];

        return ListView(padding: const EdgeInsets.all(12), children: [
          InkWell(
            onTap: own ? () => _bizSheet(context) : null,
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
              child: Row(children: [
                const Icon(Icons.store),
                const SizedBox(width: 8),
                Expanded(
                    child: Text(biz.name,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold))),
                if (own) const Icon(Icons.arrow_drop_down),
              ]),
            ),
          ),
          const SizedBox(height: 6),
          Row(children: [
            Expanded(
                child: _StatCard(context.tr("You'll get"), money(all.receivable),
                    Colors.green.shade700, Icons.south_west)),
            const SizedBox(width: 10),
            Expanded(
                child: _StatCard(context.tr("You'll give"), money(all.payable),
                    Colors.red.shade700, Icons.north_east)),
          ]),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(children: [
                Text(context.tr('Cash balance'),
                    style: const TextStyle(color: Colors.grey)),
                Text(money(all.balance),
                    style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: all.balance >= 0
                            ? Colors.green.shade700
                            : Colors.red.shade700)),
                const Divider(),
                _line(context, 'Today', today),
                _line(context, 'This month', month),
                Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('${context.tr('Total savings')}: ${money(all.saving)}',
                          style: TextStyle(color: Colors.blue.shade700)),
                    ]),
              ]),
            ),
          ),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 0.82,
            children: [
              for (final t in tiles)
                InkWell(
                  onTap: t.onTap,
                  borderRadius: BorderRadius.circular(12),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 26,
                          backgroundColor: t.color.withOpacity(0.15),
                          child: Icon(t.icon, color: t.color, size: 28),
                        ),
                        const SizedBox(height: 6),
                        Text(context.tr(t.label),
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            style: const TextStyle(fontSize: 11.5)),
                      ]),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Center(
              child: Text(
                  context.tr('Works offline — data syncs to Firebase when internet is available.'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11, color: Colors.grey))),
        ]);
      },
    );
  }

  Widget _line(BuildContext context, String label, Totals t) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        SizedBox(
            width: 90,
            child: Text(context.tr(label),
                style: const TextStyle(fontWeight: FontWeight.w600))),
        Expanded(
            child: Text('${context.tr('In')}: ${money(t.cashIn)}',
                style: TextStyle(color: Colors.green.shade700, fontSize: 13))),
        Expanded(
            child: Text('${context.tr('Out')}: ${money(t.cashOut)}',
                style: TextStyle(color: Colors.red.shade700, fontSize: 13))),
      ]),
    );
  }
}

class _Tile {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  _Tile(this.label, this.icon, this.color, this.onTap);
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final Color color;
  final IconData icon;
  const _StatCard(this.label, this.value, this.color, this.icon);

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 4),
              Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
            ]),
            const SizedBox(height: 6),
            FittedBox(
              child: Text(value,
                  style: TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold, color: color)),
            ),
          ]),
        ),
      );
}
