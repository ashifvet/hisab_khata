import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import '../medicines/medicine_detail.dart';
import '../medicines/medicine_form.dart';

class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
      Expanded(
        child: QueryStream(
          query: db.collection('companies'),
          builder: (context, docs) {
            return QueryStream(
              query: db.collection('medicines'),
              builder: (context, meds) {
                final counts = <String, int>{};
                for (final m in meds) {
                  final cid = m.data()['companyId'];
                  if (cid is String) counts[cid] = (counts[cid] ?? 0) + 1;
                }
                final list = docs
                    .where((d) =>
                        '${d.data()['name']}'.toLowerCase().contains(_q))
                    .toList()
                  ..sort((a, b) => '${a.data()['name']}'
                      .toLowerCase()
                      .compareTo('${b.data()['name']}'.toLowerCase()));
                if (list.isEmpty) {
                  return EmptyState(context.tr(
                      'No companies yet. Add one from the "Add" tab.'),
                      icon: Icons.business);
                }
                return ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final d = list[i];
                    final m = d.data();
                    final n = counts[d.id] ?? 0;
                    return ListTile(
                      leading: CircleAvatar(
                        child: Text('${m['name'] ?? '?'}'.characters.first.toUpperCase()),
                      ),
                      title: Text('${m['name']}'),
                      subtitle: Text('$n ${context.tr('medicines')}'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => CompanyDetail(id: d.id))),
                    );
                  },
                );
              },
            );
          },
        ),
      ),
    ]);
  }
}

class CompanyDetail extends StatelessWidget {
  final String id;
  const CompanyDetail({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final ref = db.collection('companies').doc(id);
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: ref.snapshots(),
      builder: (context, snap) {
        final data = snap.data?.data();
        return Scaffold(
          appBar: AppBar(
            title: Text(data?['name'] as String? ?? context.tr('Company')),
            actions: [
              if (data != null && canEdit(context, data)) ...[
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => CompanyForm(id: id, existing: data))),
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () async {
                    final nav = Navigator.of(context);
                    if (await confirm(context,
                        context.tr('Delete this company? Its medicines will stay in the Medicines list.'))) {
                      await ref.delete();
                      nav.pop();
                    }
                  },
                ),
              ],
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            icon: const Icon(Icons.add),
            label: Text(context.tr('Add medicine')),
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => MedicineForm(presetCompanyId: id))),
          ),
          body: data == null
              ? const Center(child: CircularProgressIndicator())
              : Column(children: [
                  if ('${data['details'] ?? ''}'.trim().isNotEmpty ||
                      '${data['createdByName'] ?? ''}'.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if ('${data['details'] ?? ''}'.trim().isNotEmpty)
                                Text('${data['details']}'),
                              addedBy(context, data),
                            ]),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                    child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(context.tr('Favourite medicines'),
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Theme.of(context).colorScheme.primary))),
                  ),
                  Expanded(
                    child: QueryStream(
                      query: db
                          .collection('medicines')
                          .where('companyId', isEqualTo: id),
                      builder: (context, docs) {
                        final list = [...docs]..sort((a, b) =>
                            '${a.data()['name']}'.toLowerCase().compareTo(
                                '${b.data()['name']}'.toLowerCase()));
                        if (list.isEmpty) {
                          return EmptyState(context.tr(
                              'No medicines added for this company yet.'));
                        }
                        return ListView.separated(
                          itemCount: list.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, i) {
                            final m = list[i].data();
                            return ListTile(
                              leading: const Icon(Icons.medication),
                              title: Text('${m['name']}'),
                              subtitle: Text('${m['components'] ?? ''}',
                                  maxLines: 1, overflow: TextOverflow.ellipsis),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          MedicineDetail(id: list[i].id))),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ]),
        );
      },
    );
  }
}

class CompanyForm extends StatefulWidget {
  final String? id;
  final Json? existing;
  const CompanyForm({super.key, this.id, this.existing});

  @override
  State<CompanyForm> createState() => _CompanyFormState();
}

class _CompanyFormState extends State<CompanyForm> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.existing?['name'] as String?);
  late final _details =
      TextEditingController(text: widget.existing?['details'] as String?);
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _details.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    try {
      final data = {'name': _name.text.trim(), 'details': _details.text.trim()};
      if (widget.id == null) {
        // Not awaited on purpose: when offline the write is queued and the
        // future only completes after the server confirms.
        db.collection('companies').add({...stamp(s), ...data});
      } else {
        db.collection('companies').doc(widget.id).update(data);
      }
      nav.pop();
    } catch (e) {
      if (mounted) {
        snack(context, '$e');
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(context.tr(widget.id == null ? 'Add Company' : 'Edit Company'))),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          tf(_name, 'Company name', required: true),
          tf(_details, 'Details (optional)', lines: 4),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: const Icon(Icons.save),
            label: Text(context.tr('Save')),
          ),
        ]),
      ),
    );
  }
}
