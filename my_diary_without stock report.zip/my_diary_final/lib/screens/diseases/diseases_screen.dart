import 'package:flutter/material.dart';

import '../../l10n.dart';
import '../../widgets/common.dart';
import 'disease_detail.dart';

class DiseasesScreen extends StatefulWidget {
  const DiseasesScreen({super.key});

  @override
  State<DiseasesScreen> createState() => _DiseasesScreenState();
}

class _DiseasesScreenState extends State<DiseasesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(children: [
        SearchBox(
            hint: 'Search title, owner or phone',
            onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
        TabBar(tabs: [
          Tab(text: context.tr('All')),
          Tab(text: context.tr('Good Prognosis')),
          Tab(text: context.tr('Poor Prognosis')),
        ]),
        Expanded(
          child: TabBarView(children: [
            _DiseaseList(mode: 'all', q: _q),
            _DiseaseList(mode: 'good', q: _q),
            _DiseaseList(mode: 'poor', q: _q),
          ]),
        ),
      ]),
    );
  }
}

class _DiseaseList extends StatelessWidget {
  final String mode;
  final String q;
  const _DiseaseList({required this.mode, required this.q});

  @override
  Widget build(BuildContext context) {
    return QueryStream(
      query: db.collection('diseases'),
      builder: (context, docs) {
        final list = docs.where((d) {
          final m = d.data();
          if (mode != 'all' && m['prognosis'] != mode) return false;
          if (q.isNotEmpty) {
            final hay = '${m['title']} ${m['ownerName']} ${m['phone']}'.toLowerCase();
            if (!hay.contains(q)) return false;
          }
          return true;
        }).toList()
          ..sort((a, b) => toDate(b.data()['createdAt'])
              .compareTo(toDate(a.data()['createdAt'])));
        if (list.isEmpty) {
          return EmptyState(context.tr('No diseases found.'), icon: Icons.sick_outlined);
        }
        return ListView.separated(
          itemCount: list.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final m = list[i].data();
            final prog = m['prognosis'];
            return ListTile(
              title: Text('${m['title']}',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(
                '${m['ownerName'] ?? ''}  •  ${m['phone'] ?? ''}',
                style: const TextStyle(fontSize: 11.5),
              ),
              trailing: prog == null
                  ? null
                  : Icon(
                      prog == 'good' ? Icons.sentiment_satisfied : Icons.sentiment_dissatisfied,
                      color: prog == 'good' ? Colors.green : Colors.red),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => DiseaseDetail(id: list[i].id))),
            );
          },
        );
      },
    );
  }
}
