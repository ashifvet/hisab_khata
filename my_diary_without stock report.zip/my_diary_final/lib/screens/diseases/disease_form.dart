import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';

class DiseaseForm extends StatefulWidget {
  final String? id;
  final Json? existing;
  const DiseaseForm({super.key, this.id, this.existing});

  @override
  State<DiseaseForm> createState() => _DiseaseFormState();
}

class _DiseaseFormState extends State<DiseaseForm> {
  final _form = GlobalKey<FormState>();
  Json get _e => widget.existing ?? {};
  late final _owner = TextEditingController(text: _e['ownerName'] as String?);
  late final _phone = TextEditingController(text: _e['phone'] as String?);
  late final _fee = TextEditingController(
      text: _e['fee'] == null ? '' : '${toNum(_e['fee'])}'.replaceAll(RegExp(r'\.0$'), ''));
  late final _title = TextEditingController(text: _e['title'] as String?);
  late final _temp = TextEditingController(text: _e['temperature'] as String?);
  late final _symptoms = TextEditingController(text: _e['symptoms'] as String?);
  late final _findings = TextEditingController(text: _e['findings'] as String?);
  late final _treatment = TextEditingController(text: _e['treatment'] as String?);
  late String? _location = _e['location'] as String?;
  late String? _skin = _e['skinParasite'] as String?;
  late String? _prognosis = _e['prognosis'] as String?;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_owner, _phone, _fee, _title, _temp, _symptoms, _findings, _treatment]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    try {
      final isPrivate = _location == 'private';
      final fee = isPrivate ? (double.tryParse(_fee.text.trim()) ?? 0) : 0.0;
      final data = <String, dynamic>{
        'ownerName': _owner.text.trim(),
        'phone': _phone.text.trim(),
        'location': _location,
        'fee': fee,
        'title': _title.text.trim(),
        'temperature': _temp.text.trim(),
        'symptoms': _symptoms.text.trim(),
        'findings': _findings.text.trim(),
        'skinParasite': _skin,
        'treatment': _treatment.text.trim(),
        'prognosis': _prognosis,
      };

      final isCreator = widget.id == null || _e['createdBy'] == s.uid;
      final ref = widget.id == null
          ? db.collection('diseases').doc()
          : db.collection('diseases').doc(widget.id);

      // Private fee -> add to the INCOME of the Hisab cashbook (current business).
      if (isCreator && isPrivate && fee > 0) {
        final feeEntryId = _e['feeEntryId'] as String?;
        final feeBizId = _e['feeBizId'] as String?;
        final note = 'Disease: ${_title.text.trim()} (${_owner.text.trim()})';
        if (feeEntryId != null && feeBizId != null) {
          Biz(s.uid, feeBizId, '')
              .col('entries')
              .doc(feeEntryId)
              .update({'amount': fee, 'note': note}).catchError((_) {});
        } else if (s.biz != null) {
          final entry = s.biz!.col('entries').doc();
          entry.set({
            'type': 'income',
            'amount': fee,
            'category': 'Consultation fee',
            'note': note,
            'date': Timestamp.now(),
            'createdAt': Timestamp.now(),
          });
          data['feeEntryId'] = entry.id;
          data['feeBizId'] = s.biz!.id;
        }
      }

      if (widget.id == null) {
        ref.set({...stamp(s), ...data});
      } else {
        ref.update(data);
      }
      nav.pop();
      if (isCreator && isPrivate && fee > 0 && mounted) {
        // (snack shown on the previous screen)
      }
    } catch (e) {
      if (mounted) {
        snack(context, '$e');
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(context.tr(widget.id == null ? 'Add Disease' : 'Edit Disease'))),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          tf(_owner, 'Name of the owner', required: true),
          tf(_phone, 'Phone number', required: true, keyboard: TextInputType.phone),
          ChoiceField(
            label: 'Location',
            options: const {'hospital': 'Hospital', 'private': 'Private'},
            value: _location,
            onChanged: (v) => setState(() => _location = v),
          ),
          if (_location == 'private') ...[
            tf(_fee, 'Fee taken (Tk)',
                keyboard: const TextInputType.numberWithOptions(decimal: true),
                validator: (v) => (double.tryParse((v ?? '').trim()) == null)
                    ? context.tr('Enter a valid amount')
                    : null),
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(
                  context.tr('This fee will be added to Income in the Hisab cashbook.'),
                  style: const TextStyle(fontSize: 12, color: Colors.grey)),
            ),
          ],
          const Divider(height: 24),
          tf(_title, 'Title of the Disease', required: true),
          tf(_temp, 'Temperature',
              keyboard: const TextInputType.numberWithOptions(decimal: true),
              suffix: '°F'),
          WordField(
              controller: _symptoms,
              label: 'Sign & Symptoms told by the owner',
              maxWords: 1000,
              lines: 4),
          WordField(
              controller: _findings,
              label: 'Clinical Findings',
              maxWords: 1000,
              lines: 4),
          ChoiceField(
            label: 'Skin Parasite',
            options: const {'present': 'Present', 'absent': 'Absent'},
            value: _skin,
            onChanged: (v) => _skin = v,
          ),
          WordField(
              controller: _treatment,
              label: 'Treatment',
              maxWords: 1000,
              lines: 6,
              required: true),
          ChoiceField(
            label: 'Prognosis after 10 days of Treatment',
            options: const {'good': 'Good', 'poor': 'Poor'},
            value: _prognosis,
            onChanged: (v) => _prognosis = v,
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: const Icon(Icons.save),
            label: Text(context.tr('Save')),
          ),
        ]),
      ),
    );
  }
}
