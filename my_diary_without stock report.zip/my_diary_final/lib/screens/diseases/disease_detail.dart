import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import 'disease_form.dart';

class DiseaseDetail extends StatelessWidget {
  final String id;
  const DiseaseDetail({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final ref = db.collection('diseases').doc(id);
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: ref.snapshots(),
      builder: (context, snap) {
        final d = snap.data?.data();
        return Scaffold(
          appBar: AppBar(
            title: Text(d?['title'] as String? ?? context.tr('Disease')),
            actions: [
              if (d != null && canEdit(context, d)) ...[
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => DiseaseForm(id: id, existing: d))),
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () async {
                    final nav = Navigator.of(context);
                    if (await confirm(context, context.tr('Delete this record?'))) {
                      await ref.delete();
                      nav.pop();
                    }
                  },
                ),
              ],
            ],
          ),
          body: d == null
              ? const Center(child: CircularProgressIndicator())
              : ListView(padding: const EdgeInsets.all(16), children: [
                  Text('${d['title']}',
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(fmtDate(toDate(d['createdAt'])),
                      style: const TextStyle(color: Colors.grey, fontSize: 12)),
                  const SectionTitle('Owner'),
                  InfoRow('Name of the owner', d['ownerName'] as String?),
                  InfoRow('Phone number', d['phone'] as String?),
                  InfoRow(
                      'Location',
                      d['location'] == 'private'
                          ? '${context.tr('Private')} — ${context.tr('Fee')}: ${money(toNum(d['fee']))}'
                          : context.tr('Hospital')),
                  const SectionTitle('Case'),
                  InfoRow('Temperature',
                      '${d['temperature'] ?? ''}'.isEmpty ? null : '${d['temperature']} °F'),
                  InfoRow('Sign & Symptoms told by the owner', d['symptoms'] as String?),
                  InfoRow('Clinical Findings', d['findings'] as String?),
                  InfoRow(
                      'Skin Parasite',
                      d['skinParasite'] == null
                          ? null
                          : context.tr(d['skinParasite'] == 'present' ? 'Present' : 'Absent')),
                  const SectionTitle('Treatment'),
                  InfoRow('Treatment', d['treatment'] as String?),
                  InfoRow(
                    'Prognosis after 10 days of treatment',
                    d['prognosis'] == null
                        ? null
                        : context.tr(d['prognosis'] == 'good' ? 'Good' : 'Poor'),
                    valueColor: d['prognosis'] == 'good' ? Colors.green : Colors.red,
                  ),
                  addedBy(context, d),
                ]),
        );
      },
    );
  }
}
