import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../services/import_service.dart';
import '../../widgets/common.dart';
import '../companies/companies_screen.dart';
import '../diseases/disease_form.dart';
import '../medicines/medicine_form.dart';
import '../problems/problems_screen.dart';

class AddScreen extends StatefulWidget {
  const AddScreen({super.key});

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  bool _importing = false;
  double _progress = 0;

  void _open(Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  Future<void> _import() async {
    final s = context.read<AppState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(c.tr('Import medicines')),
        content: Text(c.tr(
            'This will add about 450 veterinary medicines and the 13 companies to the shared list for ALL users. It can be done only once. Continue?')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(c.tr('Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(c.tr('Import'))),
        ],
      ),
    );
    if (ok != true) return;
    setState(() {
      _importing = true;
      _progress = 0;
    });
    try {
      final n = await importLocalMedicines(s, (p) {
        if (mounted) setState(() => _progress = p);
      });
      if (mounted) snack(context, '${context.tr('Imported medicines')}: $n');
    } catch (e) {
      if (mounted) snack(context, '$e');
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  Widget _card(IconData icon, String title, String subtitle, VoidCallback onTap,
      {Color? color}) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        leading: CircleAvatar(
            backgroundColor: c.withOpacity(0.15), child: Icon(icon, color: c)),
        title: Text(context.tr(title), style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(context.tr(subtitle), style: const TextStyle(fontSize: 12)),
        trailing: const Icon(Icons.add),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(12), children: [
      _card(Icons.business, 'Company', 'Add a veterinary company',
          () => _open(const CompanyForm()),
          color: Colors.indigo),
      _card(Icons.medication, 'Medicine',
          'Name, components, use, dose, pregnancy & pet safety',
          () => _open(const MedicineForm()),
          color: Colors.teal),
      _card(Icons.sick, 'Disease', 'Owner, symptoms, findings, treatment, prognosis',
          () => _open(const DiseaseForm()),
          color: Colors.red),
      _card(Icons.lightbulb, 'Problems & Solutions', 'Title, problem, solution, prognosis',
          () => _open(const ProblemForm()),
          color: Colors.orange.shade800),
      const SectionTitle('Local medicine database'),
      StreamBuilder<DocumentSnapshot<Json>>(
        stream: db.collection('meta').doc('medicine_import').snapshots(),
        builder: (context, snap) {
          final done = snap.data?.exists == true;
          final d = snap.data?.data();
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(done ? Icons.check_circle : Icons.cloud_download,
                      color: done ? Colors.green : Colors.teal),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                        context.tr(done
                            ? 'Medicines already imported'
                            : 'Import medicines from local database'),
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                  ),
                ]),
                const SizedBox(height: 6),
                Text(
                  done
                      ? '${d?['count'] ?? ''} ${context.tr('medicines')} • ${d?['importedByName'] ?? ''} • ${fmtDate(toDate(d?['at']))}'
                      : context.tr(
                          'Adds the bundled list of veterinary medicines (collected from Arogga.com) and the 13 companies. Safety fields are left "Not specified" — please review.'),
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
                const SizedBox(height: 10),
                if (_importing) LinearProgressIndicator(value: _progress == 0 ? null : _progress),
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    // Disabled for everybody once any user has imported.
                    onPressed: (done || _importing || !snap.hasData) ? null : _import,
                    icon: const Icon(Icons.download),
                    label: Text(context.tr(done ? 'Already imported' : 'Import medicines')),
                  ),
                ),
              ]),
            ),
          );
        },
      ),
    ]);
  }
}
