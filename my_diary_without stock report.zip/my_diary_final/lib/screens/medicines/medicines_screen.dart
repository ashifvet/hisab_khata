import 'package:flutter/material.dart';

import '../../l10n.dart';
import '../../widgets/common.dart';
import 'medicine_detail.dart';

class MedicinesScreen extends StatefulWidget {
  const MedicinesScreen({super.key});

  @override
  State<MedicinesScreen> createState() => _MedicinesScreenState();
}

class _MedicinesScreenState extends State<MedicinesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Column(children: [
        SearchBox(
            hint: 'Search medicine, company or component',
            onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
        TabBar(tabs: [
          Tab(text: context.tr('All Medicines')),
          Tab(text: context.tr('Pregnancy Safe')),
          Tab(text: context.tr('Pet Medicines')),
        ]),
        Expanded(
          child: TabBarView(children: [
            _MedicineList(mode: 'all', q: _q),
            _MedicineList(mode: 'pregnancy', q: _q),
            _MedicineList(mode: 'pet', q: _q),
          ]),
        ),
      ]),
    );
  }
}

class _MedicineList extends StatelessWidget {
  final String mode;
  final String q;
  const _MedicineList({required this.mode, required this.q});

  @override
  Widget build(BuildContext context) {
    return QueryStream(
      query: db.collection('medicines'),
      builder: (context, docs) {
        final list = docs.where((d) {
          final m = d.data();
          if (mode == 'pregnancy' && m['pregnancy'] != 'safe') return false;
          if (mode == 'pet' && m['pet'] != 'safe') return false;
          if (q.isNotEmpty) {
            final hay =
                '${m['name']} ${m['companyName']} ${m['components']} ${m['generic']}'
                    .toLowerCase();
            if (!hay.contains(q)) return false;
          }
          return true;
        }).toList()
          ..sort((a, b) => '${a.data()['name']}'
              .toLowerCase()
              .compareTo('${b.data()['name']}'.toLowerCase()));
        if (list.isEmpty) {
          return EmptyState(
              context.tr(mode == 'all'
                  ? 'No medicines found.'
                  : 'No medicines marked "Safe" yet.'),
              icon: Icons.medication_outlined);
        }
        final items = <Widget>[];
        String? last;
        for (final d in list) {
          final m = d.data();
          final name = '${m['name'] ?? ''}';
          final letter = name.isEmpty ? '#' : name.characters.first.toUpperCase();
          if (mode == 'all' && letter != last) {
            last = letter;
            items.add(Container(
              width: double.infinity,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.10),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Text(letter,
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.primary)),
            ));
          }
          items.add(ListTile(
            title: Text(name),
            subtitle: Text(
              [
                if ('${m['companyName'] ?? ''}'.isNotEmpty) '${m['companyName']}',
                if ('${m['components'] ?? ''}'.isNotEmpty) '${m['components']}',
              ].join(' • '),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => MedicineDetail(id: d.id))),
          ));
        }
        return ListView(children: items);
      },
    );
  }
}
