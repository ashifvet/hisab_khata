import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import 'medicine_form.dart';

class MedicineDetail extends StatelessWidget {
  final String id;
  const MedicineDetail({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final ref = db.collection('medicines').doc(id);
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: ref.snapshots(),
      builder: (context, snap) {
        final d = snap.data?.data();
        return Scaffold(
          appBar: AppBar(
            title: Text(d?['name'] as String? ?? context.tr('Medicine')),
            actions: [
              if (d != null && canEdit(context, d)) ...[
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => MedicineForm(id: id, existing: d))),
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () async {
                    final nav = Navigator.of(context);
                    if (await confirm(
                        context, context.tr('Delete this medicine?'))) {
                      await ref.delete();
                      nav.pop();
                    }
                  },
                ),
              ],
            ],
          ),
          body: d == null
              ? const Center(child: CircularProgressIndicator())
              : ListView(padding: const EdgeInsets.all(16), children: [
                  Text('${d['name']}',
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 4, children: [
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('${context.tr('Pregnancy')}: ',
                          style: const TextStyle(fontSize: 12)),
                      safetyChip(context, d['pregnancy'] as String?),
                    ]),
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('${context.tr('Pet Safety')}: ',
                          style: const TextStyle(fontSize: 12)),
                      safetyChip(context, d['pet'] as String?),
                    ]),
                  ]),
                  const Divider(height: 24),
                  InfoRow('Company', d['companyName'] as String?),
                  InfoRow('Generic / Group', d['generic'] as String?),
                  InfoRow('Components', d['components'] as String?),
                  InfoRow('When to use', d['whenToUse'] as String?),
                  InfoRow('Dose', d['dose'] as String?),
                  InfoRow('Other details', d['details'] as String?),
                  if ((d['source'] ?? '') != '')
                    InfoRow('Source', '${d['source']}'),
                  addedBy(context, d),
                ]),
        );
      },
    );
  }
}
