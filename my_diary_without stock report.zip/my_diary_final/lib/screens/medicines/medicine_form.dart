import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';

class MedicineForm extends StatefulWidget {
  final String? id;
  final Json? existing;
  final String? presetCompanyId;
  const MedicineForm({super.key, this.id, this.existing, this.presetCompanyId});

  @override
  State<MedicineForm> createState() => _MedicineFormState();
}

class _MedicineFormState extends State<MedicineForm> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.existing?['name'] as String?);
  late final _components =
      TextEditingController(text: widget.existing?['components'] as String?);
  late final _when =
      TextEditingController(text: widget.existing?['whenToUse'] as String?);
  late final _dose = TextEditingController(text: widget.existing?['dose'] as String?);
  late final _details =
      TextEditingController(text: widget.existing?['details'] as String?);
  late String? _companyId =
      (widget.existing?['companyId'] as String?) ?? widget.presetCompanyId;
  late String? _pregnancy = widget.existing?['pregnancy'] as String?;
  late String? _pet = widget.existing?['pet'] as String?;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_name, _components, _when, _dose, _details]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save(Map<String, String> companyNames) async {
    if (!_form.currentState!.validate()) return;
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    try {
      final data = <String, dynamic>{
        'name': _name.text.trim(),
        'companyId': _companyId,
        'companyName': _companyId == null ? '' : (companyNames[_companyId] ?? ''),
        'components': _components.text.trim(),
        'whenToUse': _when.text.trim(),
        'dose': _dose.text.trim(),
        'pregnancy': _pregnancy,
        'pet': _pet,
        'details': _details.text.trim(),
      };
      if (widget.id == null) {
        db.collection('medicines').add({...stamp(s), ...data});
      } else {
        db.collection('medicines').doc(widget.id).update(data);
      }
      nav.pop();
    } catch (e) {
      if (mounted) {
        snack(context, '$e');
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(context.tr(widget.id == null ? 'Add Medicine' : 'Edit Medicine'))),
      body: QueryStream(
        query: db.collection('companies'),
        builder: (context, docs) {
          final names = <String, String>{
            for (final d in docs) d.id: '${d.data()['name']}'
          };
          final sorted = names.entries.toList()
            ..sort((a, b) => a.value.toLowerCase().compareTo(b.value.toLowerCase()));
          final valid = _companyId != null && names.containsKey(_companyId);
          return Form(
            key: _form,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: DropdownButtonFormField<String?>(
                  value: valid ? _companyId : null,
                  isExpanded: true,
                  decoration: InputDecoration(
                      labelText: context.tr('Company'),
                      border: const OutlineInputBorder()),
                  items: [
                    DropdownMenuItem<String?>(
                        value: null, child: Text(context.tr('— No company —'))),
                    for (final e in sorted)
                      DropdownMenuItem<String?>(value: e.key, child: Text(e.value)),
                  ],
                  onChanged: (v) => setState(() => _companyId = v),
                ),
              ),
              tf(_name, 'Medicine name', required: true),
              tf(_components, 'Components', lines: 2),
              tf(_when, 'When to use', lines: 3),
              tf(_dose, 'Dose', lines: 3),
              ChoiceField(
                label: 'Pregnancy indication',
                options: const {'safe': 'Safe', 'unsafe': 'Unsafe'},
                value: _pregnancy,
                onChanged: (v) => _pregnancy = v,
              ),
              ChoiceField(
                label: 'Pet Safety',
                options: const {'safe': 'Safe', 'unsafe': 'Unsafe'},
                value: _pet,
                onChanged: (v) => _pet = v,
              ),
              tf(_details, 'Any other details', lines: 4),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _busy ? null : () => _save(names),
                icon: const Icon(Icons.save),
                label: Text(context.tr('Save')),
              ),
            ]),
          );
        },
      ),
    );
  }
}
