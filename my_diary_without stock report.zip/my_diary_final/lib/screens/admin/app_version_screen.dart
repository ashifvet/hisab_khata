import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../l10n.dart';
import '../../widgets/common.dart';

/// Admin only: publish the newest version. Every user's app compares its own
/// version with this document each time it is opened.
class AppVersionScreen extends StatefulWidget {
  const AppVersionScreen({super.key});

  @override
  State<AppVersionScreen> createState() => _AppVersionScreenState();
}

class _AppVersionScreenState extends State<AppVersionScreen> {
  final _latest = TextEditingController();
  final _min = TextEditingController();
  final _url = TextEditingController();
  final _msg = TextEditingController();
  bool _force = false;
  bool _loaded = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    db.collection('app_config').doc('version').get().then((s) {
      final d = s.data();
      if (d != null) {
        _latest.text = '${d['latestVersion'] ?? ''}';
        _min.text = '${d['minVersion'] ?? ''}';
        _url.text = '${d['updateUrl'] ?? ''}';
        _msg.text = '${d['message'] ?? ''}';
        _force = d['forceUpdate'] == true;
      }
      if (mounted) setState(() => _loaded = true);
    }).catchError((_) {
      if (mounted) setState(() => _loaded = true);
    });
  }

  @override
  void dispose() {
    for (final c in [_latest, _min, _url, _msg]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await db.collection('app_config').doc('version').set({
        'latestVersion': _latest.text.trim(),
        'minVersion': _min.text.trim().isEmpty ? '0.0.0' : _min.text.trim(),
        'updateUrl': _url.text.trim(),
        'message': _msg.text.trim(),
        'forceUpdate': _force,
        'updatedAt': Timestamp.now(),
      });
      if (mounted) snack(context, context.tr('Saved'));
    } catch (e) {
      if (mounted) snack(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('App Version (Update)'))),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              tf(_latest, 'Latest version (e.g. 1.0.1)', required: true),
              tf(_min, 'Minimum allowed version (older = blocked)'),
              tf(_url, 'Download / Play Store link', keyboard: TextInputType.url),
              tf(_msg, 'Message to users', lines: 3),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(context.tr('Force update')),
                subtitle: Text(context.tr(
                    'Users on an older version cannot continue until they update.')),
                value: _force,
                onChanged: (v) => setState(() => _force = v),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _busy ? null : _save,
                icon: const Icon(Icons.cloud_upload),
                label: Text(context.tr('Publish')),
              ),
            ]),
    );
  }
}
