import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../l10n.dart';
import '../../widgets/common.dart';

/// Admin only: create dialog-box announcements shown to every user.
class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Announcements'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: Text(context.tr('New announcement')),
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const _AnnouncementForm())),
      ),
      body: QueryStream(
        query: db.collection('announcements'),
        builder: (context, docs) {
          final list = [...docs]..sort((a, b) => toDate(b.data()['createdAt'])
              .compareTo(toDate(a.data()['createdAt'])));
          if (list.isEmpty) {
            return EmptyState(context.tr('No announcements yet.'), icon: Icons.campaign);
          }
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final m = list[i].data();
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(
                          child: Text('${m['title']}',
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold))),
                      Switch(
                        value: m['active'] != false,
                        onChanged: (v) => list[i].reference.update({'active': v}),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () async {
                          if (await confirm(
                              context, context.tr('Delete this announcement?'))) {
                            list[i].reference.delete();
                          }
                        },
                      ),
                    ]),
                    Text('${m['content']}'),
                    const SizedBox(height: 6),
                    Text(
                      '${context.tr('Cancel allowed')}: ${context.tr(m['cancelAllowed'] == true ? 'Yes' : 'No')}  •  '
                      '${context.tr('Shown')}: ${m['maxShows']}x',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _AnnouncementForm extends StatefulWidget {
  const _AnnouncementForm();

  @override
  State<_AnnouncementForm> createState() => _AnnouncementFormState();
}

class _AnnouncementFormState extends State<_AnnouncementForm> {
  final _form = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _content = TextEditingController();
  final _telegram = TextEditingController();
  final _web = TextEditingController();
  final _times = TextEditingController(text: '1');
  bool _cancelAllowed = true;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_title, _content, _telegram, _web, _times]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    try {
      db.collection('announcements').add({
        'title': _title.text.trim(),
        'content': _content.text.trim(),
        'telegramLink': _telegram.text.trim(),
        'webLink': _web.text.trim(),
        'cancelAllowed': _cancelAllowed,
        'maxShows': int.parse(_times.text.trim()),
        'active': true,
        'createdAt': Timestamp.now(),
      });
      nav.pop();
    } catch (e) {
      if (mounted) {
        snack(context, '$e');
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('New announcement'))),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          tf(_title, 'Title of the Dialogbox', required: true),
          tf(_content, 'Content of the Dialogbox', required: true, lines: 4),
          tf(_telegram, 'Telegram Link', keyboard: TextInputType.url),
          tf(_web, 'Website Link', keyboard: TextInputType.url),
          ChoiceField(
            label: 'Cancel allowed',
            options: const {'yes': 'Yes', 'no': 'No'},
            value: _cancelAllowed ? 'yes' : 'no',
            onChanged: (v) => _cancelAllowed = v == 'yes',
          ),
          tf(_times, 'How many times will the user see the Dialogbox?',
              keyboard: TextInputType.number,
              validator: (v) {
                final n = int.tryParse((v ?? '').trim());
                return (n == null || n < 1) ? context.tr('Enter a number (1 or more)') : null;
              }),
          const SizedBox(height: 6),
          Text(
              context.tr(
                  'If "Cancel allowed" is No, the user must tap Join Telegram or Visit Web to continue.'),
              style: const TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: const Icon(Icons.send),
            label: Text(context.tr('Publish')),
          ),
        ]),
      ),
    );
  }
}
