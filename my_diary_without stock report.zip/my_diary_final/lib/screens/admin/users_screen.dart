import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import '../auth/login_screen.dart' show authMessage;
import '../hisab/hisab_home.dart';

/// Admin only: list users, add new admin, promote/demote, view a user's Hisab.
class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  Future<void> _addAdmin(BuildContext context) async {
    final first = TextEditingController();
    final last = TextEditingController();
    final id = TextEditingController();
    final pass = TextEditingController();
    final key = GlobalKey<FormState>();
    await showDialog<void>(
      context: context,
      builder: (c) {
        var busy = false;
        return StatefulBuilder(
          builder: (c, setS) => AlertDialog(
            title: Text(c.tr('Add new admin')),
            content: Form(
              key: key,
              child: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  tf(first, 'First name', required: true),
                  tf(last, 'Last name'),
                  tf(id, 'Email or username',
                      required: true, keyboard: TextInputType.emailAddress),
                  tf(pass, 'Password',
                      obscure: true,
                      validator: (v) => (v == null || v.length < 6)
                          ? c.tr('Password must be at least 6 characters')
                          : null),
                ]),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c), child: Text(c.tr('Cancel'))),
              FilledButton(
                onPressed: busy
                    ? null
                    : () async {
                        if (!key.currentState!.validate()) return;
                        setS(() => busy = true);
                        try {
                          await _createAdmin(
                              first.text, last.text, emailFor(id.text), pass.text);
                          if (c.mounted) Navigator.pop(c);
                          if (context.mounted) {
                            snack(context, context.tr('New admin created'));
                          }
                        } catch (e) {
                          setS(() => busy = false);
                          if (context.mounted) {
                            snack(context, context.tr(authMessage(e)));
                          }
                        }
                      },
                child: Text(c.tr('Create')),
              ),
            ],
          ),
        );
      },
    );
  }

  /// Creates the account on a SECONDARY Firebase app so the current admin
  /// stays logged in.
  Future<void> _createAdmin(
      String first, String last, String email, String password) async {
    FirebaseApp app;
    try {
      app = Firebase.app('secondary');
    } catch (_) {
      app = await Firebase.initializeApp(
          name: 'secondary', options: Firebase.app().options);
    }
    final auth2 = FirebaseAuth.instanceFor(app: app);
    try {
      final c = await auth2.createUserWithEmailAndPassword(
          email: email, password: password);
      await db.collection('users').doc(c.user!.uid).set({
        'firstName': first.trim(),
        'lastName': last.trim(),
        'email': email,
        'phone': '',
        'location': '',
        'role': 'admin',
        'createdAt': Timestamp.now(),
      });
    } finally {
      await auth2.signOut();
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Admins & Users'))),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.person_add),
        label: Text(context.tr('Add new admin')),
        onPressed: () => _addAdmin(context),
      ),
      body: QueryStream(
        query: db.collection('users'),
        builder: (context, docs) {
          final list = [...docs]..sort((a, b) {
              final ra = a.data()['role'] == 'admin' ? 0 : 1;
              final rb = b.data()['role'] == 'admin' ? 0 : 1;
              if (ra != rb) return ra.compareTo(rb);
              return '${a.data()['firstName']}'
                  .toLowerCase()
                  .compareTo('${b.data()['firstName']}'.toLowerCase());
            });
          return ListView.separated(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: list.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final d = list[i];
              final m = d.data();
              final isAdmin = m['role'] == 'admin';
              final name = '${m['firstName'] ?? ''} ${m['lastName'] ?? ''}'.trim();
              final isMe = d.id == me.uid;
              final isRoot = m['email'] == adminEmail;
              return ListTile(
                leading: CircleAvatar(
                    backgroundColor: isAdmin ? Colors.amber.shade700 : null,
                    child: Icon(isAdmin ? Icons.admin_panel_settings : Icons.person)),
                title: Text(name.isEmpty ? '${m['email']}' : name),
                subtitle: Text('${m['email'] ?? ''}  ${m['phone'] ?? ''}'),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'data') {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => _UserData(
                                  uid: d.id, name: name.isEmpty ? '${m['email']}' : name)));
                    } else if (v == 'role') {
                      d.reference.update({'role': isAdmin ? 'user' : 'admin'});
                    }
                  },
                  itemBuilder: (c) => [
                    PopupMenuItem(value: 'data', child: Text(c.tr('View Hisab data'))),
                    if (!isMe && !isRoot)
                      PopupMenuItem(
                          value: 'role',
                          child: Text(c.tr(isAdmin ? 'Remove admin' : 'Make admin'))),
                  ],
                ),
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => _UserData(
                            uid: d.id, name: name.isEmpty ? '${m['email']}' : name))),
              );
            },
          );
        },
      ),
    );
  }
}

/// Admin view of one user's businesses -> their Hisab.
class _UserData extends StatelessWidget {
  final String uid;
  final String name;
  const _UserData({required this.uid, required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(name)),
      body: QueryStream(
        query: db.collection('users').doc(uid).collection('businesses'),
        builder: (context, docs) {
          if (docs.isEmpty) return EmptyState(context.tr('No businesses.'));
          return ListView(children: [
            for (final d in docs)
              ListTile(
                leading: const Icon(Icons.store),
                title: Text('${d.data()['name']}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => Scaffold(
                      appBar: AppBar(title: Text('$name — ${d.data()['name']}')),
                      body: HisabHome(biz: Biz(uid, d.id, '${d.data()['name']}')),
                    ),
                  ),
                ),
              ),
          ]);
        },
      ),
    );
  }
}
