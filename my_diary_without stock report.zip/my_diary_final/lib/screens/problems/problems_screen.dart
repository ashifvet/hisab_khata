import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';

/// "P&S" tab = Problem based Solutions.
class ProblemsScreen extends StatefulWidget {
  const ProblemsScreen({super.key});

  @override
  State<ProblemsScreen> createState() => _ProblemsScreenState();
}

class _ProblemsScreenState extends State<ProblemsScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SearchBox(onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
      Expanded(
        child: QueryStream(
          query: db.collection('problems'),
          builder: (context, docs) {
            final list = docs
                .where((d) =>
                    '${d.data()['title']} ${d.data()['problem']}'.toLowerCase().contains(_q))
                .toList()
              ..sort((a, b) => toDate(b.data()['createdAt'])
                  .compareTo(toDate(a.data()['createdAt'])));
            if (list.isEmpty) {
              return EmptyState(
                  context.tr('No problems & solutions yet. Add one from the "Add" tab.'),
                  icon: Icons.lightbulb_outline);
            }
            return ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final m = list[i].data();
                return ListTile(
                  leading: const Icon(Icons.lightbulb),
                  title: Text('${m['title']}',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('${m['problem'] ?? ''}',
                      maxLines: 2, overflow: TextOverflow.ellipsis),
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => ProblemDetail(id: list[i].id))),
                );
              },
            );
          },
        ),
      ),
    ]);
  }
}

class ProblemDetail extends StatelessWidget {
  final String id;
  const ProblemDetail({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final ref = db.collection('problems').doc(id);
    return StreamBuilder<DocumentSnapshot<Json>>(
      stream: ref.snapshots(),
      builder: (context, snap) {
        final d = snap.data?.data();
        return Scaffold(
          appBar: AppBar(
            title: Text(d?['title'] as String? ?? context.tr('Problem')),
            actions: [
              if (d != null && canEdit(context, d)) ...[
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ProblemForm(id: id, existing: d))),
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () async {
                    final nav = Navigator.of(context);
                    if (await confirm(context, context.tr('Delete this record?'))) {
                      await ref.delete();
                      nav.pop();
                    }
                  },
                ),
              ],
            ],
          ),
          body: d == null
              ? const Center(child: CircularProgressIndicator())
              : ListView(padding: const EdgeInsets.all(16), children: [
                  Text('${d['title']}',
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                  const Divider(height: 24),
                  InfoRow('Problems', d['problem'] as String?),
                  InfoRow('Solutions', d['solution'] as String?),
                  InfoRow('Prognosis', d['prognosis'] as String?),
                  addedBy(context, d),
                ]),
        );
      },
    );
  }
}

class ProblemForm extends StatefulWidget {
  final String? id;
  final Json? existing;
  const ProblemForm({super.key, this.id, this.existing});

  @override
  State<ProblemForm> createState() => _ProblemFormState();
}

class _ProblemFormState extends State<ProblemForm> {
  final _form = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.existing?['title'] as String?);
  late final _problem =
      TextEditingController(text: widget.existing?['problem'] as String?);
  late final _solution =
      TextEditingController(text: widget.existing?['solution'] as String?);
  late final _prognosis =
      TextEditingController(text: widget.existing?['prognosis'] as String?);
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_title, _problem, _solution, _prognosis]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    try {
      final data = {
        'title': _title.text.trim(),
        'problem': _problem.text.trim(),
        'solution': _solution.text.trim(),
        'prognosis': _prognosis.text.trim(),
      };
      if (widget.id == null) {
        db.collection('problems').add({...stamp(s), ...data});
      } else {
        db.collection('problems').doc(widget.id).update(data);
      }
      nav.pop();
    } catch (e) {
      if (mounted) {
        snack(context, '$e');
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(context.tr(widget.id == null
              ? 'Add Problem & Solution'
              : 'Edit Problem & Solution'))),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          tf(_title, 'Title', required: true),
          WordField(
              controller: _problem,
              label: 'Problems',
              maxWords: 1000,
              lines: 5,
              required: true),
          WordField(
              controller: _solution,
              label: 'Solutions',
              maxWords: 2000,
              lines: 7,
              required: true),
          WordField(controller: _prognosis, label: 'Prognosis', maxWords: 300, lines: 3),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: const Icon(Icons.save),
            label: Text(context.tr('Save')),
          ),
        ]),
      ),
    );
  }
}
