import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _first;
  late final TextEditingController _last;
  late final TextEditingController _email;
  late final TextEditingController _phone;
  late final TextEditingController _location;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final p = context.read<AppState>().profile;
    _first = TextEditingController(text: p['firstName'] as String?);
    _last = TextEditingController(text: p['lastName'] as String?);
    _email = TextEditingController(text: p['email'] as String?);
    _phone = TextEditingController(text: p['phone'] as String?);
    _location = TextEditingController(text: p['location'] as String?);
  }

  @override
  void dispose() {
    for (final c in [_first, _last, _email, _phone, _location]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    setState(() => _busy = true);
    try {
      s.updateProfile({
        'firstName': _first.text.trim(),
        'lastName': _last.text.trim(),
        'email': _email.text.trim(),
        'phone': _phone.text.trim(),
        'location': _location.text.trim(),
      });
      nav.pop();
    } catch (e) {
      if (mounted) {
        snack(context, '$e');
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Edit Profile'))),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          tf(_first, 'First name', required: true),
          tf(_last, 'Last name'),
          tf(_email, 'Email', keyboard: TextInputType.emailAddress),
          tf(_phone, 'Phone number', keyboard: TextInputType.phone),
          tf(_location, 'Location'),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: const Icon(Icons.save),
            label: Text(context.tr('Save')),
          ),
        ]),
      ),
    );
  }
}
