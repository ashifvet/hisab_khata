import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';
import '../auth/login_screen.dart' show authMessage;

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _changePassword(BuildContext context) async {
    final cur = TextEditingController();
    final next = TextEditingController();
    final key = GlobalKey<FormState>();
    final s = context.read<AppState>();
    await showDialog<void>(
      context: context,
      builder: (c) {
        var busy = false;
        return StatefulBuilder(
          builder: (c, setS) => AlertDialog(
            title: Text(c.tr('Change password')),
            content: Form(
              key: key,
              child: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  tf(cur, 'Current password', obscure: true, required: true),
                  tf(next, 'New password',
                      obscure: true,
                      validator: (v) => (v == null || v.length < 6)
                          ? c.tr('Password must be at least 6 characters')
                          : null),
                ]),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c), child: Text(c.tr('Cancel'))),
              FilledButton(
                onPressed: busy
                    ? null
                    : () async {
                        if (!key.currentState!.validate()) return;
                        setS(() => busy = true);
                        try {
                          await s.changePassword(cur.text, next.text);
                          if (c.mounted) Navigator.pop(c);
                          if (context.mounted) {
                            snack(context, context.tr('Password changed'));
                          }
                        } catch (e) {
                          setS(() => busy = false);
                          if (context.mounted) {
                            snack(context, context.tr(authMessage(e)));
                          }
                        }
                      },
                child: Text(c.tr('Save')),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Settings'))),
      body: ListView(children: [
        SwitchListTile(
          secondary: const Icon(Icons.dark_mode),
          title: Text(context.tr('Dark mode')),
          value: s.themeMode == ThemeMode.dark,
          onChanged: (v) => s.setDark(v),
        ),
        const Divider(height: 1),
        ListTile(
          leading: const Icon(Icons.lock),
          title: Text(context.tr('Change password')),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _changePassword(context),
        ),
        const Divider(height: 1),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Row(children: [
            const Icon(Icons.language),
            const SizedBox(width: 16),
            Text(context.tr('App language'),
                style: const TextStyle(fontSize: 16)),
          ]),
        ),
        RadioListTile<String>(
          title: const Text('English'),
          value: 'en',
          groupValue: s.locale.languageCode,
          onChanged: (v) => s.setLang(v!),
        ),
        RadioListTile<String>(
          title: const Text('বাংলা'),
          value: 'bn',
          groupValue: s.locale.languageCode,
          onChanged: (v) => s.setLang(v!),
        ),
      ]),
    );
  }
}
