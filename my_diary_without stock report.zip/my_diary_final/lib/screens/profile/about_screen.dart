import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../l10n.dart';
import '../../widgets/common.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    Widget row(IconData icon, String label, String value, {VoidCallback? onTap}) =>
        ListTile(
          leading: Icon(icon, color: scheme.primary),
          title: Text(context.tr(label), style: const TextStyle(fontSize: 12, color: Colors.grey)),
          subtitle: Text(value, style: const TextStyle(fontSize: 16)),
          onTap: onTap,
        );
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('About Developer'))),
      body: ListView(children: [
        const SizedBox(height: 24),
        Center(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.asset('assets/icon.png',
                width: 90,
                height: 90,
                errorBuilder: (_, __, ___) =>
                    Icon(Icons.menu_book, size: 80, color: scheme.primary)),
          ),
        ),
        const SizedBox(height: 8),
        const Center(
            child: Text('My Diary',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        const SizedBox(height: 16),
        const Divider(),
        row(Icons.person, 'Name', 'Dr. MD. ASHIF IQBAL'),
        row(Icons.school, 'Degrees', 'DVM, MSc, BCS'),
        row(Icons.work, 'Designation', 'Veterinary Surgeon, Maheshpur'),
        row(Icons.phone, 'Phone', '01711989236',
            onTap: () => openUrl(context, 'tel:01711989236')),
        row(Icons.home, 'Hometown', 'Kushtia'),
        const Divider(),
        FutureBuilder<PackageInfo>(
          future: PackageInfo.fromPlatform(),
          builder: (c, snap) => row(Icons.info, 'Version Name',
              snap.hasData ? '${snap.data!.version} (${snap.data!.buildNumber})' : '...'),
        ),
      ]),
    );
  }
}
