import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../l10n.dart';
import 'admin/announcements_screen.dart';
import 'admin/app_version_screen.dart';
import 'admin/users_screen.dart';
import 'profile/about_screen.dart';
import 'profile/edit_profile_screen.dart';
import 'profile/settings_screen.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  String _greeting(BuildContext c) {
    final h = DateTime.now().hour;
    if (h < 12) return c.tr('Good morning');
    if (h < 17) return c.tr('Good afternoon');
    if (h < 20) return c.tr('Good evening');
    return c.tr('Good night');
  }

  void _go(BuildContext context, Widget page) {
    Navigator.pop(context); // close drawer
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final scheme = Theme.of(context).colorScheme;
    return Drawer(
      child: Column(children: [
        Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(
              16, MediaQuery.of(context).padding.top + 20, 16, 18),
          color: scheme.primary,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: scheme.onPrimary,
              child: Text(
                s.fullName.isEmpty ? '?' : s.fullName.characters.first.toUpperCase(),
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: scheme.primary),
              ),
            ),
            const SizedBox(height: 12),
            Text('${_greeting(context)},',
                style: TextStyle(color: scheme.onPrimary.withOpacity(0.85))),
            Text(s.fullName,
                style: TextStyle(
                    color: scheme.onPrimary,
                    fontSize: 20,
                    fontWeight: FontWeight.bold)),
            if (s.isAdmin)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(context.tr('Administrator'),
                    style: TextStyle(color: scheme.onPrimary, fontSize: 12)),
              ),
          ]),
        ),
        Expanded(
          child: ListView(padding: EdgeInsets.zero, children: [
            ListTile(
                leading: const Icon(Icons.person),
                title: Text(context.tr('Edit Profile')),
                onTap: () => _go(context, const EditProfileScreen())),
            ListTile(
                leading: const Icon(Icons.settings),
                title: Text(context.tr('Settings')),
                onTap: () => _go(context, const SettingsScreen())),
            ListTile(
                leading: const Icon(Icons.info),
                title: Text(context.tr('About Developer')),
                onTap: () => _go(context, const AboutScreen())),
            if (s.isAdmin) ...[
              const Divider(),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: Text(context.tr('Administrator'),
                    style: const TextStyle(color: Colors.grey, fontSize: 12)),
              ),
              ListTile(
                  leading: const Icon(Icons.campaign),
                  title: Text(context.tr('Announcements')),
                  onTap: () => _go(context, const AnnouncementsScreen())),
              ListTile(
                  leading: const Icon(Icons.admin_panel_settings),
                  title: Text(context.tr('Admins & Users')),
                  onTap: () => _go(context, const UsersScreen())),
              ListTile(
                  leading: const Icon(Icons.system_update),
                  title: Text(context.tr('App Version (Update)')),
                  onTap: () => _go(context, const AppVersionScreen())),
            ],
          ]),
        ),
        const Divider(height: 1),
        FutureBuilder<PackageInfo>(
          future: PackageInfo.fromPlatform(),
          builder: (c, snap) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              '${context.tr('Version')} ${snap.data?.version ?? '...'}',
              style: const TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: Text(context.tr('Logout'), style: const TextStyle(color: Colors.red)),
          onTap: () async {
            Navigator.pop(context);
            await context.read<AppState>().signOut();
          },
        ),
        SizedBox(height: MediaQuery.of(context).padding.bottom),
      ]),
    );
  }
}
