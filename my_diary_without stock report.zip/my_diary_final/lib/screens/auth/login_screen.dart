import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app_state.dart';
import '../../l10n.dart';
import '../../widgets/common.dart';

String authMessage(Object e) {
  if (e is FirebaseAuthException) {
    switch (e.code) {
      case 'invalid-credential':
      case 'wrong-password':
      case 'user-not-found':
      case 'invalid-login-credentials':
        return 'Wrong username/email or password';
      case 'email-already-in-use':
        return 'This email is already registered';
      case 'weak-password':
        return 'Password must be at least 6 characters';
      case 'invalid-email':
        return 'Invalid email address';
      case 'network-request-failed':
        return 'No internet connection. Login needs internet the first time.';
      case 'requires-recent-login':
        return 'Please log in again and retry';
      case 'too-many-requests':
        return 'Too many attempts. Try again later.';
      case 'operation-not-allowed':
        return 'Enable Email/Password sign-in in Firebase Console > Authentication.';
    }
    return e.message ?? e.code;
  }
  return '$e';
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _id = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  bool _register = false;
  bool _busy = false;
  bool _hide = true;

  @override
  void dispose() {
    for (final c in [_id, _pass, _pass2, _first, _last, _email, _phone]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    final s = context.read<AppState>();
    setState(() => _busy = true);
    try {
      if (_register) {
        await s.signUp(
          firstName: _first.text,
          lastName: _last.text,
          email: _email.text,
          phone: _phone.text,
          password: _pass.text,
        );
      } else {
        await s.signIn(_id.text, _pass.text);
      }
    } catch (e) {
      if (mounted) snack(context, context.tr(authMessage(e)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _form,
                child: Column(children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset('assets/icon.png',
                        width: 90,
                        height: 90,
                        errorBuilder: (_, __, ___) => Icon(Icons.menu_book,
                            size: 80, color: Theme.of(context).colorScheme.primary)),
                  ),
                  const SizedBox(height: 12),
                  const Text('My Diary',
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(
                      context.tr(_register ? 'Create your account' : 'Login to continue'),
                      style: const TextStyle(color: Colors.grey)),
                  const SizedBox(height: 20),
                  if (_register) ...[
                    Row(children: [
                      Expanded(child: tf(_first, 'First name', required: true)),
                      const SizedBox(width: 8),
                      Expanded(child: tf(_last, 'Last name', required: true)),
                    ]),
                    tf(_email, 'Email',
                        required: true,
                        keyboard: TextInputType.emailAddress,
                        validator: (v) => (v == null || !v.contains('@'))
                            ? context.tr('Invalid email address')
                            : null),
                    tf(_phone, 'Phone number', keyboard: TextInputType.phone),
                  ] else
                    tf(_id, 'Email or username',
                        required: true, keyboard: TextInputType.emailAddress),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: TextFormField(
                      controller: _pass,
                      obscureText: _hide,
                      decoration: InputDecoration(
                        labelText: context.tr('Password'),
                        border: const OutlineInputBorder(),
                        suffixIcon: IconButton(
                          icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => setState(() => _hide = !_hide),
                        ),
                      ),
                      validator: (v) => (v == null || v.length < 6)
                          ? context.tr('Password must be at least 6 characters')
                          : null,
                    ),
                  ),
                  if (_register)
                    tf(_pass2, 'Confirm password',
                        obscure: true,
                        validator: (v) => v != _pass.text
                            ? context.tr('Passwords do not match')
                            : null),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: FilledButton(
                      onPressed: _busy ? null : _submit,
                      child: _busy
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : Text(context.tr(_register ? 'Register' : 'Login')),
                    ),
                  ),
                  TextButton(
                    onPressed: () => setState(() => _register = !_register),
                    child: Text(context.tr(_register
                        ? 'Already have an account? Login'
                        : 'New user? Create an account')),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
