import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../l10n.dart';
import '../services/app_alerts.dart';
import 'add/add_screen.dart';
import 'app_drawer.dart';
import 'companies/companies_screen.dart';
import 'diseases/diseases_screen.dart';
import 'hisab/hisab_home.dart';
import 'medicines/medicines_screen.dart';
import 'problems/problems_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  bool _checked = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (_checked || !mounted) return;
      _checked = true;
      final state = context.read<AppState>();
      await checkForUpdate(context);
      if (!mounted) return;
      await showAnnouncements(context, state);
    });
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['Hisab', 'Companies', 'Medicines', 'Diseases', 'P&S', 'Add'];
    final pages = <Widget>[
      const HisabTab(),
      const CompaniesScreen(),
      const MedicinesScreen(),
      const DiseasesScreen(),
      const ProblemsScreen(),
      const AddScreen(),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(context.tr(titles[_index]))),
      drawer: const AppDrawer(),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        height: 66,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          NavigationDestination(
              icon: const Icon(Icons.account_balance_wallet_outlined),
              selectedIcon: const Icon(Icons.account_balance_wallet),
              label: context.tr('Hisab')),
          NavigationDestination(
              icon: const Icon(Icons.business_outlined),
              selectedIcon: const Icon(Icons.business),
              label: context.tr('Companies')),
          NavigationDestination(
              icon: const Icon(Icons.medication_outlined),
              selectedIcon: const Icon(Icons.medication),
              label: context.tr('Medicines')),
          NavigationDestination(
              icon: const Icon(Icons.sick_outlined),
              selectedIcon: const Icon(Icons.sick),
              label: context.tr('Diseases')),
          NavigationDestination(
              icon: const Icon(Icons.lightbulb_outline),
              selectedIcon: const Icon(Icons.lightbulb),
              label: context.tr('P&S')),
          NavigationDestination(
              icon: const Icon(Icons.add_circle_outline),
              selectedIcon: const Icon(Icons.add_circle),
              label: context.tr('Add')),
        ],
      ),
    );
  }
}
