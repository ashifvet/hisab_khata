import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app_state.dart';
import '../l10n.dart';
import '../widgets/common.dart';

/// Compare "1.2.3" style versions. Returns <0, 0, >0.
int compareVersions(String a, String b) {
  List<int> parse(String v) => v
      .split('+')
      .first
      .split('.')
      .map((e) => int.tryParse(e.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0)
      .toList();
  final x = parse(a), y = parse(b);
  for (var i = 0; i < 3; i++) {
    final p = i < x.length ? x[i] : 0;
    final q = i < y.length ? y[i] : 0;
    if (p != q) return p.compareTo(q);
  }
  return 0;
}

/// Reads Firestore doc app_config/version and shows an (optionally forced)
/// update dialog. Fields: latestVersion, minVersion, forceUpdate, updateUrl,
/// message.
Future<void> checkForUpdate(BuildContext context) async {
  try {
    final info = await PackageInfo.fromPlatform();
    final snap = await db.collection('app_config').doc('version').get();
    final d = snap.data();
    if (d == null) return;
    final latest = (d['latestVersion'] ?? '0.0.0') as String;
    final min = (d['minVersion'] ?? '0.0.0') as String;
    final force = d['forceUpdate'] == true;
    final url = (d['updateUrl'] ?? '') as String;
    final message = (d['message'] ?? '') as String;
    final cur = info.version;
    final mustUpdate = compareVersions(cur, min) < 0 ||
        (force && compareVersions(cur, latest) < 0);
    final canUpdate = compareVersions(cur, latest) < 0;
    if (!mustUpdate && !canUpdate) return;
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: !mustUpdate,
      builder: (c) => PopScope(
        canPop: !mustUpdate,
        child: AlertDialog(
          title: Row(children: [
            const Icon(Icons.system_update, color: Colors.teal),
            const SizedBox(width: 8),
            Expanded(
                child: Text(c.tr(mustUpdate ? 'Update required' : 'Update available'))),
          ]),
          content: Text(
            '${message.isNotEmpty ? '$message\n\n' : ''}'
            '${c.tr('Your version')}: $cur\n${c.tr('New version')}: $latest',
          ),
          actions: [
            if (!mustUpdate)
              TextButton(
                  onPressed: () => Navigator.pop(c), child: Text(c.tr('Later'))),
            FilledButton(
              onPressed: () {
                if (url.isNotEmpty) openUrl(c, url);
              },
              child: Text(c.tr('Update now')),
            ),
          ],
        ),
      ),
    );
  } catch (_) {
    // offline or not configured – ignore
  }
}

/// Shows admin announcements (dialog boxes) honouring "how many times".
Future<void> showAnnouncements(BuildContext context, AppState state) async {
  try {
    final snap = await db.collection('announcements').get();
    final docs = [...snap.docs];
    docs.sort((a, b) => toDate(a.data()['createdAt'])
        .compareTo(toDate(b.data()['createdAt'])));
    final prefs = await SharedPreferences.getInstance();
    for (final doc in docs) {
      final d = doc.data();
      if (d['active'] == false) continue;
      final maxShows = (d['maxShows'] is num) ? (d['maxShows'] as num).toInt() : 1;
      final key = 'ann_${state.uid}_${doc.id}';
      final shown = prefs.getInt(key) ?? 0;
      if (shown >= maxShows) continue;
      await prefs.setInt(key, shown + 1);
      if (!context.mounted) return;
      await _announcementDialog(context, d);
    }
  } catch (_) {
    // offline & nothing cached – ignore
  }
}

Future<void> _announcementDialog(BuildContext context, Json d) {
  final tg = ((d['telegramLink'] ?? '') as String).trim();
  final web = ((d['webLink'] ?? '') as String).trim();
  final cancelAllowed = d['cancelAllowed'] == true;
  return showDialog<void>(
    context: context,
    barrierDismissible: cancelAllowed,
    builder: (c) => PopScope(
      canPop: cancelAllowed,
      child: AlertDialog(
        title: Text((d['title'] ?? '') as String),
        content: SingleChildScrollView(child: Text((d['content'] ?? '') as String)),
        actionsOverflowButtonSpacing: 4,
        actionsOverflowAlignment: OverflowBarAlignment.end,
        actions: [
          if (tg.isNotEmpty)
            FilledButton.icon(
              icon: const Icon(Icons.send),
              onPressed: () {
                openUrl(c, tg);
                Navigator.pop(c);
              },
              label: Text(c.tr('Join Telegram')),
            ),
          if (web.isNotEmpty)
            FilledButton.tonalIcon(
              icon: const Icon(Icons.public),
              onPressed: () {
                openUrl(c, web);
                Navigator.pop(c);
              },
              label: Text(c.tr('Visit Web')),
            ),
          // Cancel works only when "CancelAllowed" = Yes.
          TextButton(
            onPressed: cancelAllowed
                ? () => Navigator.pop(c)
                : (tg.isEmpty && web.isEmpty ? () => Navigator.pop(c) : null),
            child: Text(c.tr(
                (!cancelAllowed && tg.isEmpty && web.isEmpty) ? 'OK' : 'Cancel')),
          ),
        ],
      ),
    ),
  );
}
