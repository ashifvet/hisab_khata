import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart' show rootBundle;

import '../app_state.dart';
import '../widgets/common.dart';

/// One-time import of the bundled medicine database
/// (assets/data/medicines_seed.json, collected from Arogga.com listings).
///
/// Document ids are deterministic (imp_c_N / imp_m_N) so a retry can never
/// create duplicates. When finished, meta/medicine_import is written - the
/// Add screen watches this document and disables the import button for
/// EVERY user once it exists.
Future<int> importLocalMedicines(
  AppState s,
  void Function(double progress) onProgress,
) async {
  final raw = await rootBundle.loadString('assets/data/medicines_seed.json');
  final j = jsonDecode(raw) as Map<String, dynamic>;
  final companies = (j['companies'] as List).cast<Map<String, dynamic>>();
  final meds = (j['medicines'] as List).cast<Map<String, dynamic>>();

  // Re-use companies that already exist (same name).
  final existing = await db.collection('companies').get();
  final byName = <String, String>{
    for (final d in existing.docs) '${d.data()['name']}'.trim().toLowerCase(): d.id,
  };

  final ops = <void Function(WriteBatch)>[];
  final ids = <String, String>{};
  var ci = 0;
  for (final c in companies) {
    final name = '${c['name']}';
    final found = byName[name.trim().toLowerCase()];
    final String id = found ?? 'imp_c_$ci';
    ci++;
    ids[name] = id;
    if (found == null) {
      ops.add((b) => b.set(db.collection('companies').doc(id), {
            ...stamp(s),
            'name': name,
            'details': '${c['details'] ?? ''}',
            'source': 'import',
          }));
    }
  }

  var mi = 0;
  for (final m in meds) {
    final id = 'imp_m_$mi';
    mi++;
    final cname = '${m['company'] ?? ''}';
    ops.add((b) => b.set(db.collection('medicines').doc(id), {
          ...stamp(s),
          'name': '${m['name']}',
          'companyId': ids[cname],
          'companyName': cname,
          'generic': '${m['generic'] ?? ''}',
          'components': '${m['components'] ?? ''}',
          'whenToUse': '${m['whenToUse'] ?? ''}',
          'dose': '${m['dose'] ?? ''}',
          'pregnancy': 'unknown',
          'pet': 'unknown',
          'details': '${m['details'] ?? ''}',
          'source': 'Imported from ${m['source'] ?? 'local database'}',
          'sourceUrl': '${m['url'] ?? ''}',
        }));
  }

  const chunk = 400;
  for (var i = 0; i < ops.length; i += chunk) {
    final batch = db.batch();
    for (final op in ops.skip(i).take(chunk)) {
      op(batch);
    }
    await batch.commit().timeout(const Duration(seconds: 45),
        onTimeout: () => throw 'Could not reach the server. Check your internet and try again.');
    onProgress(((i + chunk) / ops.length).clamp(0.0, 1.0));
  }

  await db.collection('meta').doc('medicine_import').set({
    'importedBy': s.uid,
    'importedByName': s.fullName,
    'count': meds.length,
    'at': Timestamp.now(),
  });
  return meds.length;
}
