import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Default administrator (created automatically the first time somebody
/// logs in with these credentials). Change the password after first login!
const String adminEmail = 'admin@mydiary.app';
const String defaultAdminUser = 'admin';
const String defaultAdminPass = 'Solution2@';
const int maxBusinesses = 5;

typedef Json = Map<String, dynamic>;

/// Points to one business of one user: users/{uid}/businesses/{id}
class Biz {
  final String uid;
  final String id;
  final String name;
  const Biz(this.uid, this.id, this.name);

  DocumentReference<Json> get ref => FirebaseFirestore.instance
      .collection('users')
      .doc(uid)
      .collection('businesses')
      .doc(id);

  CollectionReference<Json> col(String name) => ref.collection(name);
}

String emailFor(String input) {
  final s = input.trim();
  return s.contains('@') ? s : '${s.toLowerCase()}@mydiary.app';
}

class AppState extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.light;
  Locale locale = const Locale('en');
  SharedPreferences? _prefs;

  bool authReady = false;
  User? user;
  Json profile = {};
  bool profileLoaded = false;
  List<QueryDocumentSnapshot<Json>> businesses = [];
  String? currentBizId;

  StreamSubscription<User?>? _authSub;
  StreamSubscription<DocumentSnapshot<Json>>? _profSub;
  StreamSubscription<QuerySnapshot<Json>>? _bizSub;

  FirebaseFirestore get _fs => FirebaseFirestore.instance;
  DocumentReference<Json> get userDoc => _fs.collection('users').doc(user!.uid);

  // ---------------------------------------------------------------- prefs
  Future<void> loadPrefs() async {
    _prefs = await SharedPreferences.getInstance();
    themeMode =
        (_prefs!.getBool('dark') ?? false) ? ThemeMode.dark : ThemeMode.light;
    locale = Locale(_prefs!.getString('lang') ?? 'en');
  }

  Future<void> setDark(bool v) async {
    themeMode = v ? ThemeMode.dark : ThemeMode.light;
    await _prefs?.setBool('dark', v);
    notifyListeners();
  }

  Future<void> setLang(String code) async {
    locale = Locale(code);
    await _prefs?.setString('lang', code);
    notifyListeners();
  }

  // ----------------------------------------------------------- derived info
  String get uid => user?.uid ?? '';
  bool get isAdmin => profile['role'] == 'admin';
  String get fullName {
    final n =
        '${profile['firstName'] ?? ''} ${profile['lastName'] ?? ''}'.trim();
    if (n.isNotEmpty) return n;
    final e = user?.email ?? '';
    return e.contains('@') ? e.split('@').first : 'User';
  }

  Biz? get biz {
    if (user == null || currentBizId == null) return null;
    for (final d in businesses) {
      if (d.id == currentBizId) {
        return Biz(user!.uid, d.id, (d.data()['name'] ?? 'Business') as String);
      }
    }
    return null;
  }

  // ------------------------------------------------------------ auth stream
  void start() {
    _authSub = FirebaseAuth.instance.authStateChanges().listen(_onAuth);
  }

  void _onAuth(User? u) {
    _profSub?.cancel();
    _bizSub?.cancel();
    user = u;
    profile = {};
    profileLoaded = false;
    businesses = [];
    currentBizId = null;
    authReady = true;
    if (u == null) {
      notifyListeners();
      return;
    }
    _profSub = userDoc.snapshots().listen((s) {
      if (!s.exists && !s.metadata.isFromCache) {
        // Account exists in Firebase Auth but has no profile document yet.
        // (merge + no name fields => can never overwrite the names that the
        // sign-up form writes at the same moment)
        userDoc.set({
          'email': u.email ?? '',
          'role': (u.email == adminEmail) ? 'admin' : 'user',
        }, SetOptions(merge: true)).catchError((_) {});
      }
      profile = s.data() ?? {};
      profileLoaded = true;
      notifyListeners();
    }, onError: (_) {
      profileLoaded = true;
      notifyListeners();
    });
    _bizSub = userDoc.collection('businesses').snapshots().listen(_onBiz,
        onError: (_) {});
    notifyListeners();
  }

  void _onBiz(QuerySnapshot<Json> snap) {
    final docs = [...snap.docs];
    docs.sort((a, b) {
      final ta = a.data()['createdAt'];
      final tb = b.data()['createdAt'];
      if (ta is Timestamp && tb is Timestamp) return ta.compareTo(tb);
      return a.id.compareTo(b.id);
    });
    businesses = docs;
    if (docs.isEmpty && !snap.metadata.isFromCache && user != null) {
      userDoc.collection('businesses').doc('default').set({
        'name': 'My Business',
        'createdAt': Timestamp.now(),
      }).catchError((_) {});
    }
    final saved = _prefs?.getString('biz_${user?.uid}');
    if (saved != null && docs.any((d) => d.id == saved)) {
      currentBizId = saved;
    } else if (docs.isNotEmpty) {
      currentBizId = docs.first.id;
    } else {
      currentBizId = null;
    }
    notifyListeners();
  }

  // --------------------------------------------------------------- business
  Future<void> setBiz(String id) async {
    currentBizId = id;
    await _prefs?.setString('biz_$uid', id);
    notifyListeners();
  }

  Future<String?> addBusiness(String name) async {
    if (businesses.length >= maxBusinesses) {
      return 'Maximum $maxBusinesses businesses allowed';
    }
    final ref = userDoc.collection('businesses').doc();
    await ref.set({'name': name.trim(), 'createdAt': Timestamp.now()});
    await setBiz(ref.id);
    return null;
  }

  Future<void> renameBusiness(String id, String name) =>
      userDoc.collection('businesses').doc(id).update({'name': name.trim()});

  // ------------------------------------------------------------------ auth
  Future<void> signIn(String id, String pass) async {
    final email = emailFor(id);
    final auth = FirebaseAuth.instance;
    try {
      await auth.signInWithEmailAndPassword(email: email, password: pass);
    } on FirebaseAuthException catch (e) {
      final isDefaultAdmin = email == adminEmail && pass == defaultAdminPass;
      final missing = e.code == 'user-not-found' ||
          e.code == 'invalid-credential' ||
          e.code == 'invalid-login-credentials';
      if (isDefaultAdmin && missing) {
        try {
          final c = await auth.createUserWithEmailAndPassword(
              email: email, password: pass);
          await _fs.collection('users').doc(c.user!.uid).set({
            'firstName': 'System',
            'lastName': 'Administrator',
            'email': email,
            'phone': '',
            'location': '',
            'role': 'admin',
            'createdAt': Timestamp.now(),
          });
          return;
        } on FirebaseAuthException catch (e2) {
          if (e2.code != 'email-already-in-use') rethrow;
        }
      }
      rethrow;
    }
  }

  Future<void> signUp({
    required String firstName,
    required String lastName,
    required String email,
    required String phone,
    required String password,
  }) async {
    final c = await FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email.trim(), password: password);
    await _fs.collection('users').doc(c.user!.uid).set({
      'firstName': firstName.trim(),
      'lastName': lastName.trim(),
      'email': email.trim(),
      'phone': phone.trim(),
      'location': '',
      'role': 'user',
      'createdAt': Timestamp.now(),
    });
  }

  Future<void> signOut() => FirebaseAuth.instance.signOut();

  Future<void> updateProfile(Json data) => userDoc.set(data, SetOptions(merge: true));

  Future<void> changePassword(String current, String next) async {
    final u = FirebaseAuth.instance.currentUser!;
    final cred =
        EmailAuthProvider.credential(email: u.email!, password: current);
    await u.reauthenticateWithCredential(cred);
    await u.updatePassword(next);
  }

  @override
  void dispose() {
    _authSub?.cancel();
    _profSub?.cancel();
    _bizSub?.cancel();
    super.dispose();
  }
}
