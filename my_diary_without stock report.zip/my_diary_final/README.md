# My Diary — Flutter app (Veterinary reference + Hisab / business ledger)

Bottom tabs (left → right): **Hisab · Companies · Medicines · Diseases · P&S · Add**

Everything is stored in **Firebase** (Auth + Cloud Firestore). The app works **offline**
(Firestore local cache) and syncs automatically when the internet comes back.

---------------------------------------------------------------------------
## STEP 0 — Install the tools (once)

1. Install Flutter: https://docs.flutter.dev/get-started/install  (then run `flutter doctor`)
2. Install Android Studio (for the Android SDK / emulator) and VS Code (optional).
3. Install Node.js (needed only for the Firebase CLI), then in a terminal:

```
npm install -g firebase-tools
dart pub global activate flutterfire_cli
firebase login
```

---------------------------------------------------------------------------
## STEP 1 — Create the Flutter project

```
flutter create --org com.ashif --project-name my_diary my_diary
cd my_diary
```

---------------------------------------------------------------------------
## STEP 2 — Copy my files into your project (replace everything)

Delete the old `lib/` folder and `test/` folder of the new project, then copy from this
download into your project, **replacing files when asked**:

| This download                                   | Your project                                      |
|-------------------------------------------------|---------------------------------------------------|
| `pubspec.yaml`                                  | `pubspec.yaml`  (replace)                         |
| `lib/` (whole folder)                           | `lib/`  (replace)                                 |
| `assets/` (whole folder, incl. `data/`)         | `assets/`                                         |
| `android/app/src/main/AndroidManifest.xml`      | `android/app/src/main/AndroidManifest.xml` (replace) |
| `firestore.rules`                               | (only used in Firebase console – STEP 3)          |

**Your icon:** put your picture at  `assets/icon.png`  (square PNG, ideally 1024x1024).
(The folder must be called `assets`, with an "s".) A plain placeholder icon is included —
just overwrite it with yours.

Also delete the sample test file if it exists: `test/widget_test.dart`.

---------------------------------------------------------------------------
## STEP 3 — Firebase setup

1. https://console.firebase.google.com → **Add project** (name it "My Diary").
2. **Build → Authentication → Get started → Sign-in method → Email/Password → Enable.**
3. **Build → Firestore Database → Create database** (production mode, choose a nearby region).
4. **Firestore → Rules** → delete everything, paste the content of `firestore.rules` → **Publish**.
5. In your project folder run:

```
flutterfire configure
```
   choose your Firebase project and the platforms (android, ios, web).  It creates
   `lib/firebase_options.dart` (overwrites my placeholder) and `android/app/google-services.json`.

6. Android only: open `android/app/build.gradle.kts` (or `build.gradle` in older projects) and set
   the minimum SDK to 23:

   * `build.gradle.kts`:   `minSdk = 23`      (replace `minSdk = flutter.minSdkVersion`)
   * `build.gradle`:       `minSdkVersion 23`

---------------------------------------------------------------------------
## STEP 4 — Launcher icon + packages + run

```
flutter pub get
dart run flutter_launcher_icons
flutter run
```

---------------------------------------------------------------------------
## STEP 5 — First login

* Username: `admin`   Password: `Solution2@`
  (The very first login with these credentials creates the administrator account in Firebase.)
* **Immediately** go to Drawer → Settings → Change password.
* Other users: "New user? Create an account".

Usernames without "@" are converted to `username@mydiary.app` internally.

---------------------------------------------------------------------------
## STEP 6 — Import the medicine database (once)

Bottom tab **Add → Local medicine database → Import medicines**.
It adds ~450 veterinary products from Arogga.com and the 13 companies, for all users.
After one import the button is disabled for everybody (flag stored at `meta/medicine_import`).
Imported medicines have pregnancy / pet safety = "Not specified" – review and set them.
(Admin can delete the `meta/medicine_import` document in the Firebase console to allow a re-import.)

---------------------------------------------------------------------------
## STEP 7 — Releasing a new version (force update)

1. In `pubspec.yaml` change `version: 1.0.0+1` → e.g. `version: 1.0.1+2`
2. Build: `flutter build apk --release`  (file: `build/app/outputs/flutter-apk/app-release.apk`)
3. Upload the APK (Google Drive / your website / Play Store) and copy the link.
4. In the app (admin): Drawer → **App Version (Update)** → latest version `1.0.1`, link, message,
   switch **Force update** ON if old versions must not be used → **Publish**.
5. Every user who opens the app on an older version sees the update dialog
   (forced = cannot be closed; otherwise "Later" is available).

---------------------------------------------------------------------------
## Admin features (Drawer)

* **Announcements** – dialog box with Title, Content, Telegram link, Website link,
  Cancel allowed (Yes/No) and "how many times". If Cancel is *No* the user must tap
  *Join Telegram* or *Visit Web* to continue.
* **Admins & Users** – add a new admin, promote/demote, open any user's Hisab data.
* **App Version (Update)** – see STEP 7.

## Who can see / edit what

* Companies, Medicines, Diseases, P&S → visible to every user; only the creator or an admin can edit/delete.
* Hisab (customers, suppliers, cashbook, stock, notes, reports) → private per user; admin can see all.

## Hisab features

Up to 5 businesses · unlimited entries · customers & suppliers ledger (you gave / you got) ·
cashbook (cash in / out / savings) · stock & inventory valuation · business notes ·
reports (monthly, customer/supplier, cost & savings) as PDF → Share (WhatsApp, imo …) or Print ·
group reminders (SMS to many customers; one-by-one personalised SMS; WhatsApp per customer).
Private disease fee → automatically added as **Income** (category "Consultation fee") in the
current business cashbook.

## Known limits (please read)

* "Free messages" use the phone's own SMS app (your SIM plan). A real free-SMS service needs a paid SMS gateway.
* Update/announcement alerts appear when the app is opened (in-app dialogs). Background push notifications (FCM) are not included.
* First login/registration needs internet; after that everything works offline.
* PDF with Bangla text downloads a Bangla font once (needs internet the first time); otherwise English font is used.
