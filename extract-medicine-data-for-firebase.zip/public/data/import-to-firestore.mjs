// Import vet_medicines.json into Cloud Firestore using the Firebase Admin SDK.
//
// Setup (in any folder on your computer):
//   npm init -y && npm i firebase-admin
// Run:
//   node import-to-firestore.mjs ./vet_medicines.json ./serviceAccountKey.json [collection] [--dry-run] [--with-companies]
//
// - Document IDs come from the "id" field, so re-running the script UPDATES the same docs
//   (no duplicates).
// - "createdAt" is converted from an ISO string into a real Firestore Timestamp.
// - The "id" field itself is NOT stored inside the document (it is the document ID).

import fs from "node:fs";
import admin from "firebase-admin";

const args = process.argv.slice(2).filter((a) => !a.startsWith("--"));
const flags = new Set(process.argv.slice(2).filter((a) => a.startsWith("--")));

const [dataPath = "./vet_medicines.json", keyPath = "./serviceAccountKey.json", collectionName = "medicines"] = args;
const DRY = flags.has("--dry-run");
const WITH_COMPANIES = flags.has("--with-companies");

const docs = JSON.parse(fs.readFileSync(dataPath, "utf8"));
console.log(`Loaded ${docs.length} medicines from ${dataPath}`);

if (!DRY) {
  admin.initializeApp({ credential: admin.credential.cert(JSON.parse(fs.readFileSync(keyPath, "utf8"))) });
}
const db = DRY ? null : admin.firestore();

async function commitInBatches(items, write) {
  const SIZE = 400; // Firestore limit is 500 writes per batch
  let done = 0;
  for (let i = 0; i < items.length; i += SIZE) {
    const chunk = items.slice(i, i + SIZE);
    if (!DRY) {
      const batch = db.batch();
      chunk.forEach((item) => write(batch, item));
      await batch.commit();
    }
    done += chunk.length;
    console.log(`${DRY ? "[dry-run] " : ""}${done}/${items.length}`);
  }
}

await commitInBatches(docs, (batch, d) => {
  const { id, ...data } = d;
  data.createdAt = admin.firestore.Timestamp.fromDate(new Date(d.createdAt));
  batch.set(db.collection(collectionName).doc(id), data, { merge: true });
});

if (WITH_COMPANIES) {
  const companies = new Map();
  docs.forEach((d) => companies.set(d.companyId, d.companyName));
  const list = [...companies].map(([id, name]) => ({ id, name }));
  await commitInBatches(list, (batch, c) =>
    batch.set(
      db.collection("companies").doc(c.id),
      { name: c.name, createdAt: admin.firestore.Timestamp.now(), createdBy: "system", createdByName: "Imported database" },
      { merge: true }
    )
  );
  console.log(`Upserted ${list.length} companies`);
}

console.log("Done.");
