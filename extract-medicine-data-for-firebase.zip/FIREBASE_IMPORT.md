# Import the veterinary medicine data into Firebase (Firestore)

Files (also downloadable from the web page of this app, or from `public/data/`):

| File | Use |
| --- | --- |
| `vet_medicines.json` | JSON array, one object per medicine, in your document format |
| `vet_medicines.ndjson` | One JSON object per line (handy for scripts) |
| `vet_medicines.csv` | Spreadsheet view for checking / editing |
| `scripts/import-to-firestore.mjs` | Node script that writes everything to Firestore |

## Steps

1. **Service account key**
   Firebase Console → Project settings → *Service accounts* → *Generate new private key*.
   Save as `serviceAccountKey.json`. Keep it private and never commit it to Git.

2. **Prepare a folder**
   ```bash
   mkdir vet-import && cd vet-import
   npm init -y
   npm i firebase-admin
   ```
   Copy `vet_medicines.json`, `import-to-firestore.mjs` and `serviceAccountKey.json` into it.

3. **Dry run** (writes nothing, just checks the file)
   ```bash
   node import-to-firestore.mjs ./vet_medicines.json ./serviceAccountKey.json medicines --dry-run
   ```

4. **Real import**
   ```bash
   node import-to-firestore.mjs ./vet_medicines.json ./serviceAccountKey.json medicines --with-companies
   ```
   * Replace `medicines` with the collection name your app reads.
   * `--with-companies` also creates `companies/{companyId}` docs (e.g. `c_aci_pharmaceuticals`).
     Leave the flag out if your app already has them or uses another structure.

5. **Check** in Firebase Console → Firestore → your collection. `createdAt` should show as a *timestamp*.

## Notes

* Document IDs are stable (`bdnvf_...` / `petzone_...`), so running the import again updates the same documents instead of duplicating them.
* `createdAt` is stored as a real Firestore Timestamp (the JSON has an ISO string; the script converts it).
* Firestore Security Rules do not apply to the Admin SDK, so the import works even if your rules block clients.
* Quota: about 980 writes, well inside the free Spark plan limit (20,000 writes per day).
* No Node? Alternative: Firebase Console has no JSON import for Firestore, so use the script above
  (or a Cloud Function / the `firestore-import-export` community tools).

## Data quality (please read)

* `petSafety` is `unknown` for all items. Neither source states species safety in a structured way.
* `pregnancySafe` is a **text-based guess** from BDNVF contraindication/precaution sentences:
  `unsafe` = the text says do not use or avoid in pregnancy or lactation, `caution` = pregnancy or lactation is mentioned,
  `unknown` = not mentioned. `pregnancy` holds the source sentences. Change the values if your app uses another vocabulary.
* `dose` for BDNVF items is the generic (drug-level) dose text from the formulary, not brand specific.
  Items without it use "Follow the product label / your clinical judgement."
* Prices are market prices taken from BDNVF 2023 (BDT) and petzonebd.com on the extraction date. They change.
* A few vaccine entries in BDNVF have a messy layout and were skipped on purpose.
* Always have a veterinarian review the data before showing it as clinical guidance.
