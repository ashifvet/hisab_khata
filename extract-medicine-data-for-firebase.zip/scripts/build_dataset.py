"""Build Firestore-ready medicine documents from:
  1) /tmp/vet/monos.json  (parsed BDNVF-2023, see parse_bdnvf.py)
  2) /tmp/vet/vet.json    (PetZone BD WooCommerce Store API, category 2824 'veterinary-medicine')
Outputs public/data/vet_medicines.json, vet_medicines.ndjson, vet_medicines.csv
"""
import json, re, html, csv, os, sys, datetime

OUT = sys.argv[1] if len(sys.argv) > 1 else 'public/data'
os.makedirs(OUT, exist_ok=True)
NOW = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')

CHAPTERS = {
    1: 'Antimicrobial Drugs', 2: 'Anthelmintics', 3: 'Analgesics/Antipyretics', 4: 'Corticosteroids',
    5: 'Antihistaminics', 6: 'Expectorants', 7: 'Hormones', 8: 'Anesthetics', 9: 'Euthanasia of Animals',
    10: 'Ophthalmic Preparations', 11: 'Topical Preparations', 12: 'Vitamins', 13: 'Minerals',
    14: 'Liver Tonic', 15: 'Mycotoxin Binder', 16: 'Laxatives and Purgatives', 17: 'Immunomodulator',
    18: 'Vaccines and Immunological Preparations', 19: 'Vaccination Schedule', 20: 'Disinfectants and Antiseptics',
}

# canonical company names (short name in BDNVF -> full name). Only well-known names are expanded.
COMPANY = {
    'acme': 'ACME Laboratories Ltd.', 'techno': 'Techno Drugs Ltd.', 'techno drugs': 'Techno Drugs Ltd.',
    'eskayef': 'Eskayef Pharmaceuticals Ltd.', 'sk+f': 'Eskayef Pharmaceuticals Ltd.',
    'eskayef pharmaceuticals ltd': 'Eskayef Pharmaceuticals Ltd.',
    'square': 'Square Pharmaceuticals Ltd.', 'sq': 'Square Pharmaceuticals Ltd.',
    'renata': 'Renata Limited', 'reneta': 'Renata Limited', 'navana': 'Navana Pharmaceuticals Ltd.',
    'popular': 'Popular Pharmaceuticals Ltd.', 'aci': 'ACI Pharmaceuticals', 'opsonin': 'Opsonin Pharma Ltd.',
    'incepta': 'Incepta Pharmaceuticals Ltd.', 'incepta pharmaceuticals ltd.': 'Incepta Pharmaceuticals Ltd.',
    'beximco': 'Beximco Pharmaceuticals Ltd.', 'aristopharma': 'Aristopharma Ltd.',
    'albion': 'Albion Laboratories Ltd.', 'chemist': 'Chemist Laboratories Ltd.', 'globe': 'Globe Pharmaceuticals Ltd.',
    'advent': 'Advent Pharma Ltd.', 'ethical': 'Ethical Drug Ltd.', 'al-madina': 'Al-Madina Pharmaceuticals Ltd.',
    'al madina': 'Al-Madina Pharmaceuticals Ltd.', 'al-madiana': 'Al-Madina Pharmaceuticals Ltd.',
    'al-medina': 'Al-Madina Pharmaceuticals Ltd.', 'al modina': 'Al-Madina Pharmaceuticals Ltd.',
    'fnf': 'FnF Pharmaceuticals Ltd.', 'shinil': 'Shinil Pharma Ltd.', 'shinil pharma': 'Shinil Pharma Ltd.',
    'shinil pharma ltd': 'Shinil Pharma Ltd.', 'shinil pharma ltd.': 'Shinil Pharma Ltd.',
    'super power': 'Super Power', 'superpower': 'Super Power', 'super powder': 'Super Power', 'super': 'Super Power',
    'super-power': 'Super Power', 'newtec': 'Newtech', 'newtech': 'Newtech', 'rampart': 'Rampart-Power',
    'bengal': 'Bengal Remedies', 'bengal remedies': 'Bengal Remedies', 'one pharma': 'One Pharma',
    'one pharm': 'One Pharma', 'one': 'One Pharma', 'vision': 'Vision', 'vion': 'Vision', 'gurdian': 'Guardian',
    'bridge pharma': 'Bridge', 'rn': 'RN Pharma', 'rn pharmaceuticals': 'RN Pharma', 'medrx': 'MedRx',
    'pharmadesh': 'Pharmadesh', 'pharmadesgh': 'Pharmadesh', 'pharma & firm': 'Pharma & Firm',
}
JUNK_COMPANY = {'including methicillin resistant strains', 'lasota strain', 'b1', 'im', 'in', 'av127', 'av 127', 'ibd',
                'ib', 'fmd', 'h9n2', 'b+, b++', 'respens cvi 988'}

FORMS = {'inj': 'Injection', 'inj.': 'Injection', 'in.': 'Injection', 'injection': 'Injection', 'bol': 'Bolus',
         'bol.': 'Bolus', 'bolus': 'Bolus', 'tab': 'Tablet', 'tab.': 'Tablet', 'tablet': 'Tablet', 'sol': 'Solution',
         'sol.': 'Solution', 'solution': 'Solution', 'pow': 'Powder', 'pow.': 'Powder', 'powder': 'Powder',
         'power': 'Powder', 'wsp': 'WSP (Water Soluble Powder)', 'susp': 'Suspension', 'suspension': 'Suspension',
         'liquid': 'Liquid', 'ointment': 'Ointment', 'infusion': 'Infusion', 'iv infusion': 'IV Infusion',
         'per os': 'Oral', 'per os.': 'Oral', 'oral solution': 'Oral Solution',
         'oral powder': 'Oral Powder', 'oral emulsion': 'Oral Emulsion', 'oral suspension': 'Oral Suspension'}


def slug(s):
    return re.sub(r'[^a-z0-9]+', '_', s.lower()).strip('_')


def norm_company(c):
    c = re.sub(r'\s+', ' ', c).strip()
    if re.search(r'imported\s*by', c, re.I):
        c = re.split(r'imported\s*by', c, flags=re.I)[-1].strip(' ,')
    if ',' in c:
        c = c.split(',')[-1].strip()
    key = c.lower().rstrip('.')
    if re.search(r'\d', c) or key in ('bangladesh', 'b++') or len(c) < 3:
        return None
    if 'square' in key or 'phrmaceuticl' in key:
        return 'Square Pharmaceuticals Ltd.'
    if key.startswith('navana'):
        return 'Navana Pharmaceuticals Ltd.'
    if key in ('advance', 'advanced') or key.startswith('advance animal'):
        return 'Advance Animal Science Co. Ltd.'
    if key == 'eon':
        return 'Eon'
    if key == 'tajarat':
        return 'Tajarat'
    if key in JUNK_COMPANY or key + '.' in JUNK_COMPANY:
        return None
    return COMPANY.get(key) or COMPANY.get(c.lower()) or c


def clean_heading(h, first_sec, chapter):
    h = re.sub(r'\[[A-Za-z]\]', '', h).strip()
    if h.startswith('(') and h.endswith(')'):
        h = h[1:-1]
    h = re.sub(r'^\d+\.\s*', '', h).replace('Proprietary Preperations', '').strip(' :-')
    h = re.sub(r'\s+', ' ', h)
    if len(h) < 4 or h[:1].islower():
        m = re.match(r'^([A-Z][A-Za-z\-]+(?:\s[A-Za-z\-]+){0,3}?)\s+(?:is|are|has|have|acts?)\b', first_sec or '')
        h = m.group(1) if m else ''
    if h.isupper():
        h = h.title()
    return h


def trunc(s, n):
    s = re.sub(r'\s+', ' ', (s or '')).strip()
    if len(s) <= n:
        return s
    cut = s[:n]
    k = max(cut.rfind('. '), cut.rfind('; '))
    return (cut[:k + 1] if k > n * 0.5 else cut.rstrip(' ,;') + '…')


def preg_info(*texts):
    t = ' '.join(x for x in texts if x)
    sents = re.split(r'(?<=[.;])\s+', t)
    hits = [s for s in sents if re.search(r'pregnan|gestation|lactat|nursing|breeding', s, re.I)]
    if not hits:
        return '', 'unknown'
    text = trunc(' '.join(hits), 300)
    if re.search(r"(do not|don't|should not|must not|not be (?:used|given|administered)|avoid|contraindicated|not recommended|not safe)", text, re.I):
        return text, 'unsafe'
    return text, 'caution'


def pretty_form(form):
    f = (form or '').strip()
    # split "Bol. 900mg+600mg" / "pow. 100%" / "inj. 34%"
    m = re.match(r'^([A-Za-z.]+(?:\s[A-Za-z.]+)?)\s*[.:]?\s*(.*)$', f)
    word, extra = (m.group(1), m.group(2)) if m else (f, '')
    key = word.lower().strip()
    if key in FORMS:
        return FORMS[key], extra.strip()
    if key.split(' ')[0] in FORMS and len(key.split(' ')) > 1:
        return FORMS[key.split(' ')[0]], (key.split(' ', 1)[1] + ' ' + extra).strip()
    return f.title() if f else '', ''



def clean_brand(b):
    if ': ' in b and re.search(r'\d', b.rsplit(': ', 1)[0]):
        b = b.rsplit(': ', 1)[1].strip()
    b = re.sub(r'\(Note:[^)]*\)', '', b).strip()
    b = re.sub(r'\s*Tk\.?.*$', '', b).strip()
    if b.count(')') > b.count('('):
        b = b.split(')', 1)[1].strip()
    b = re.sub(r'^\([^)]*\)\s*', '', b).strip()
    b = re.sub(r'^.*\d+\s*(?:mg|gm|ml|g)\s+(?:Bolus|Injection|Powder|Tablet|Suspension)\s+(?=\S)', '', b, flags=re.I).strip()
    b = re.sub(r'^(?:Bol|Inj|Pow|Sol|Tab)\.?\s*[\d.]+\s*(?:mg|gm|ml|g)\s+', '', b, flags=re.I).strip()
    if (len(b) < 3 or len(b) > 50 or b.count('(') != b.count(')') or not b[:1].isalnum() or b[:1].islower()
            or re.match(r'^\d', b) or re.search(r'doses|Strain|Serotype|Virus|Vaccine|\bTk\b', b, re.I)):
        return None
    return b

docs = []
seen = set()

# ---------------- BDNVF ----------------
monos = json.load(open('/tmp/vet/monos.json'))
for m in monos:
    s = m['sections']
    first = next(iter(s.values()), '')
    generic = clean_heading(m['heading'], first, m['chapter'])
    cat = CHAPTERS.get(m['chapter'], 'Veterinary')
    indic = s.get('indication') or s.get('description') or ''
    dose = s.get('dose', '')
    withdrawal = s.get('withdrawal', '')
    preg_text, preg_safe = preg_info(s.get('contra'), s.get('precaution'), s.get('side'))
    for e in m['entries']:
        company = norm_company(e['company'])
        if not company or not e['brand'] or len(e['brand']) < 2:
            continue
        form, extra = pretty_form(e['form'])
        strength = ' '.join(x for x in [extra, e['strength']] if x).strip(' ,')
        brand = re.sub(r'\s+', ' ', e['brand']).strip()
        brand = re.sub(r'^(?:Tk\.?\s*[\d.,]+(?:\s*/\s*[\w .]+)?\s*[;:,]?\s*)+', '', brand).strip(' ,;')
        brand = clean_brand(brand)
        if not brand:
            continue
        name = brand if (form and form.split(' ')[0].lower() in brand.lower()) or not form else f'{brand} {form}'
        key = (name.lower(), company.lower(), strength.lower())
        if key in seen:
            continue
        seen.add(key)
        parts = [f'Category: {cat}']
        if generic:
            parts.append(f'Generic: {generic}')
        if strength:
            parts.append(f'Strength: {strength}')
        if e['price']:
            unit = f" / {e['unit']}" if e['unit'] else ''
            parts.append(f"price (market, may change): MRP Tk {e['price']}{unit}")
        if withdrawal:
            parts.append(f'Withdrawal period: {trunc(withdrawal, 160)}')
        if s.get('side'):
            parts.append(f"Side effects: {trunc(s['side'], 220)}")
        parts.append('Source: Bangladesh National Veterinary Formulary (BDNVF) 2023, DGDA. Verify with the product label before use.')
        docs.append({
            'id': 'bdnvf_' + slug(f'{company}_{name}_{strength}')[:120],
            'companyId': 'c_' + slug(company),
            'companyName': company,
            'components': (generic + (f' {strength}' if strength and len(strength) < 40 else '')).strip() or 'Not listed',
            'createdAt': NOW,
            'createdBy': 'system',
            'createdByName': 'Imported database',
            'details': ' / '.join(parts[:-1]).rstrip('. ') + '. ' + parts[-1],
            'dose': trunc(dose, 700) or 'Follow the product label / your clinical judgement.',
            'indications': (f'Category: {cat}. ' + trunc(indic, 450)).strip(),
            'name': name,
            'petSafety': 'unknown',
            'pregnancy': preg_text,
            'pregnancySafe': preg_safe,
        })

n_bdnvf = len(docs)

# ---------------- PetZone BD ----------------
def clean_html(s):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', s or ''))).strip()

BRAND_FROM_NAME = [(r'^(ACME|Amflor|Fast-Vet|Peravet)', 'ACME Laboratories Ltd.')]
vet = json.load(open('/tmp/vet/vet.json'))
for p in vet:
    pid = p['id']
    raw_name = clean_html(p['name'])
    name = re.split(r'\s+[|–—]\s+', raw_name)[0].strip()          # drop SEO tails
    name = re.sub(r'\s*Price in Bangladesh.*$', '', name, flags=re.I)
    name = re.sub(r'^ACME launched\s+', '', name)
    brand_tags = [clean_html(b['name']) for b in p.get('brands', [])]
    company = None
    if brand_tags:
        company = norm_company(brand_tags[0])
    if not company and re.match(r'^(Fast-Vet|Peravet|Amflor)', name):
        company = 'ACME Laboratories Ltd.'
    cats = [clean_html(c['name']) for c in p['categories']]
    species = [x for x in ['Dog', 'Cat', 'Bird', 'Poultry', 'Cattle'] if any(x.lower() in c.lower() for c in cats)]
    desc = clean_html(p['description'])
    comp = None
    m = re.search(r'Active Ingredients?:?\s*([A-Z][A-Za-z0-9 %\-]+?)(?:\s+[–—-]\s|\.|$)', desc)
    if m:
        comp = m.group(1).strip()
    if not comp:
        m = re.search(r'Generic Name:?\s*([A-Z][A-Za-z0-9 %().\-]+?)(?:\s+Manufacturer|\s+Dosage|\s+Pack|$)', desc)
        if m:
            comp = m.group(1).strip()
    if not comp:
        m = re.search(r'contains ((?:Levofloxacin|Zinc Sulfate|Ivermectin|Albendazole|Cephalexin)[A-Za-z ]*?\d*%?)\s*,', desc)
        if m:
            comp = m.group(1)
    price = int(p['prices']['price']) / (10 ** p['prices']['currency_minor_unit'])
    price_txt = (f'MRP Tk {price:g}' if price > 0 else 'price not listed (check site)')
    intro = re.sub(r'^(Description|Overview)\s*', '', desc)
    parts = ['Category: ' + ', '.join(c for c in cats if c not in ('Pet Pharmacy', 'Pet Medicine', 'Veterinary Medicine')) or 'Veterinary Medicine',
             f'price (market, may change): {price_txt}']
    if species:
        parts.append('Species: ' + ', '.join(species))
    details = ' / '.join(parts) + f". Source: petzonebd.com ({p.get('permalink','')}). Verify with the product label before use."
    company = company or 'Not listed'
    docs.append({
        'id': f'petzone_{pid}',
        'companyId': 'c_' + slug(company) if company != 'Not listed' else 'c_not_listed',
        'companyName': company,
        'components': comp or 'Not listed',
        'createdAt': NOW,
        'createdBy': 'system',
        'createdByName': 'Imported database',
        'details': details,
        'dose': 'Follow the product label / your clinical judgement.',
        'indications': 'Category: ' + (', '.join(c for c in cats if c not in ('Pet Pharmacy', 'Pet Medicine', 'Veterinary Medicine')) or 'Veterinary Medicine'),
        'name': name,
        'petSafety': 'unknown',
        'pregnancy': '',
        'pregnancySafe': 'unknown',
    })

docs.sort(key=lambda d: (d['companyName'].lower(), d['name'].lower()))
json.dump(docs, open(f'{OUT}/vet_medicines.json', 'w'), indent=2, ensure_ascii=False)
with open(f'{OUT}/vet_medicines.ndjson', 'w') as f:
    for d in docs:
        f.write(json.dumps(d, ensure_ascii=False) + '\n')
cols = ['id', 'companyId', 'companyName', 'components', 'createdAt', 'createdBy', 'createdByName', 'details', 'dose',
        'indications', 'name', 'petSafety', 'pregnancy', 'pregnancySafe']
with open(f'{OUT}/vet_medicines.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(docs)
print('BDNVF docs', n_bdnvf, 'PetZone docs', len(docs) - n_bdnvf, 'total', len(docs))
