"""Parse BDNVF-2023 text (extracted with pypdf) into monographs + brand preparations.
Usage: python3 scripts/parse_bdnvf.py /tmp/vet/bdnvf.txt /tmp/vet/monos.json
"""
import re, json, sys

SRC = sys.argv[1] if len(sys.argv) > 1 else '/tmp/vet/bdnvf.txt'
DST = sys.argv[2] if len(sys.argv) > 2 else '/tmp/vet/monos.json'

raw = open(SRC, errors='ignore').read().replace('\x00', '')
lines = raw.split('\n')

LABELS = [
    ('generic', r'Generic\s+Name[^:]*'),
    ('description', r'Description'),
    ('moa', r'Mode\s+of\s+[Aa]ction'),
    ('indication', r'Indications?'),
    ('contra', r'Contra\s?-?\s?indications?'),
    ('side', r'Side\s+effects?|Adverse\s+(?:effects?|reactions?)'),
    ('precaution', r'Precautions?|Cautions?|Warnings?'),
    ('interaction', r'(?:Drug\s+)?Interactions?'),
    ('dose', r'Dos(?:e|age)(?:\s*(?:and|&)\s*[Aa]dministration)?'),
    ('withdrawal', r'Withdrawal\s+[Pp]eriod'),
    ('prep', r'Proprietary\s+Preperations?'),
]
LABEL_RE = [(k, re.compile(r'^\s*(' + p + r')\s*(:?)\s*(.*)$')) for k, p in LABELS]
PAGE_RE = re.compile(r'^=====PAGE \d+=====')
PNUM_RE = re.compile(r'^\s*~\s*[ivxlc\d]+\s*~\s*$')
CHAP_RE = re.compile(r'^Chapter (\d+)\s*$')


def label_of(line):
    s = line.strip()
    for k, rx in LABEL_RE:
        m = rx.match(s)
        if not m:
            continue
        colon, rest = m.group(2), m.group(3)
        if k == 'prep':
            # only a label if the line is exactly the label (block header)
            if not rest and len(s) < 30:
                return k, ''
            continue
        if colon:
            return k, rest
    return None, None


start = next(i for i, l in enumerate(lines) if l.strip() == 'Chapter 1')
end = next(i for i, l in enumerate(lines) if l.strip() == 'Chapter 21' and i > start)

chapter = 1
clean = []
for l in lines[start:end]:
    if PAGE_RE.match(l) or PNUM_RE.match(l):
        continue
    t = l.rstrip()
    if not t.strip():
        continue
    m = CHAP_RE.match(t.strip())
    if m:
        chapter = int(m.group(1))
        continue
    clean.append((chapter, t))


def heading_tail(buf):
    """Take heading line(s) from the tail of previous section buffer. Returns list of lines (to be popped)."""
    def ok(t):
        t = t.strip()
        if not t or len(t) > 60:
            return False
        if 'Tk' in t or t.endswith((',', '.', ':', ';')) or ':' in t:
            return False
        if re.search(r',\s', t) or re.search(r'\d+\s*(mg|ml|gm|g|IU)\b', t, re.I):
            return False
        return True
    heads = []
    if buf and ok(buf[-1]):
        heads.insert(0, buf[-1])
        t = buf[-1].strip()
        # continuation e.g. "(HCG)" or a second heading line
        if len(buf) > 1 and ok(buf[-2]) and (t.startswith('(') or t[:1].islower() or len(t) < 8):
            heads.insert(0, buf[-2])
    return heads


START_LABELS = {'generic', 'description', 'indication'}
monos = []
mono = None
last_label = None
pre_buf = []

for ch, t in clean:
    lab, rest = label_of(t)
    new_start = False
    if lab in START_LABELS:
        if mono is None:
            new_start = True
        else:
            seen = {k for k, _ in mono['sections']}
            if lab in seen:
                new_start = True
            elif last_label in ('prep', 'withdrawal'):
                new_start = True
            elif last_label in ('dose', 'side', 'precaution', 'contra', 'interaction') and lab in ('generic', 'description'):
                new_start = True
    if new_start:
        if mono is not None:
            lastsec = mono['sections'][-1][1]
            heads = heading_tail(lastsec)
            for _ in heads:
                lastsec.pop()
            monos.append(mono)
        else:
            heads = heading_tail(pre_buf)
        mono = {'heading': ' '.join(h.strip() for h in heads), 'chapter': ch, 'sections': []}
        pre_buf = []
    if lab:
        last_label = lab
        if mono is None:
            mono = {'heading': '', 'chapter': ch, 'sections': []}
        mono['sections'].append((lab, [rest] if rest else []))
    else:
        if mono is not None and mono['sections']:
            mono['sections'][-1][1].append(t)
        else:
            pre_buf.append(t)
if mono:
    monos.append(mono)


def txt(sec_lines):
    s = re.sub(r'\s+', ' ', ' '.join(x.strip() for x in sec_lines)).strip()
    return s.replace('Proprietary Preperations', 'preparations').replace('Proprietary Preperation', 'preparation')


PRICE_RE = re.compile(r'Tk\.?\s*([\d][\d,]*(?:\.\d+)?)\s*(?:/\s*([^,;]*))?', re.I)
ENTRY_RE = re.compile(r'([^,]+?)\s*\(([^()]+)\)\s*,')


def parse_preps(text):
    text = re.sub(r'\s+', ' ', text.replace(';', ',')).strip()
    matches = list(ENTRY_RE.finditer(text))
    out = []
    for i, m in enumerate(matches):
        name = m.group(1).strip(' ,.')
        comp = m.group(2).strip()
        rest_end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        rest = text[m.end():rest_end].strip(' ,')
        parts = [p.strip() for p in rest.split(',') if p.strip()]
        form = parts[0] if parts else ''
        pm = PRICE_RE.search(rest)
        price = pm.group(1).replace(',', '') if pm else None
        unit = (pm.group(2) or '').strip() if pm else None
        strength = ', '.join(p for p in parts[1:] if not p.lower().startswith('tk'))
        strength = re.sub(r':?\s*Tk\.?.*$', '', strength).strip(' ,:')
        if name and len(name) < 80:
            out.append({'brand': name, 'company': comp, 'form': form if len(form) < 40 else '',
                        'strength': strength[:160], 'price': price, 'unit': unit})
    return out


result = []
for m in monos:
    secs = {}
    for k, l in m['sections']:
        secs[k] = (secs.get(k, '') + ' ' + txt(l)).strip()
    result.append({'heading': m['heading'], 'chapter': m['chapter'],
                   'sections': {k: v for k, v in secs.items() if k != 'prep'},
                   'entries': parse_preps(secs.get('prep', ''))})

json.dump(result, open(DST, 'w'), indent=1, ensure_ascii=False)
print('monographs', len(result), 'entries', sum(len(r['entries']) for r in result), file=sys.stderr)
