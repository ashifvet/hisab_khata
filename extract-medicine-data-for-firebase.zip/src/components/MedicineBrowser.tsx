"use client";

import { useMemo, useState } from "react";

export type Medicine = {
  id: string;
  companyName: string;
  components: string;
  details: string;
  dose: string;
  indications: string;
  name: string;
  pregnancySafe: string;
};

export default function MedicineBrowser({ items }: { items: Medicine[] }) {
  const [q, setQ] = useState("");
  const [company, setCompany] = useState("");
  const [source, setSource] = useState("");
  const [limit, setLimit] = useState(50);
  const [open, setOpen] = useState<string | null>(null);

  const companies = useMemo(() => Array.from(new Set(items.map((i) => i.companyName))).sort(), [items]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return items.filter((i) => {
      if (company && i.companyName !== company) return false;
      if (source === "bdnvf" && !i.id.startsWith("bdnvf_")) return false;
      if (source === "petzone" && !i.id.startsWith("petzone_")) return false;
      if (!s) return true;
      return (i.name + " " + i.components + " " + i.companyName + " " + i.indications).toLowerCase().includes(s);
    });
  }, [items, q, company, source]);

  const input = "rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-emerald-600";

  return (
    <div>
      <div className="flex flex-wrap gap-3">
        <input
          className={input + " min-w-[240px] flex-1"}
          placeholder="Search name, generic, company, indication…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setLimit(50);
          }}
        />
        <select
          className={input}
          value={company}
          onChange={(e) => {
            setCompany(e.target.value);
            setLimit(50);
          }}
        >
          <option value="">All companies</option>
          {companies.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
        <select
          className={input}
          value={source}
          onChange={(e) => {
            setSource(e.target.value);
            setLimit(50);
          }}
        >
          <option value="">All sources</option>
          <option value="bdnvf">BDNVF 2023 (PDF)</option>
          <option value="petzone">PetZone BD (shop)</option>
        </select>
      </div>

      <p className="mt-3 text-sm text-slate-600">
        {filtered.length} of {items.length} medicines
      </p>

      <ul className="mt-3 divide-y divide-slate-200 overflow-hidden rounded-xl border border-slate-200 bg-white">
        {filtered.slice(0, limit).map((m) => (
          <li key={m.id} className="p-4">
            <button className="flex w-full items-start justify-between gap-4 text-left" onClick={() => setOpen(open === m.id ? null : m.id)}>
              <span>
                <span className="block font-semibold text-slate-900">{m.name}</span>
                <span className="block text-sm text-slate-600">
                  {m.companyName} · {m.components}
                </span>
              </span>
              <span className="shrink-0 rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600">
                {m.id.startsWith("bdnvf_") ? "BDNVF" : "PetZone"}
              </span>
            </button>
            {open === m.id && (
              <dl className="mt-3 space-y-2 text-sm text-slate-700">
                <div>
                  <dt className="font-medium text-slate-900">Details</dt>
                  <dd>{m.details}</dd>
                </div>
                <div>
                  <dt className="font-medium text-slate-900">Indications</dt>
                  <dd>{m.indications}</dd>
                </div>
                <div>
                  <dt className="font-medium text-slate-900">Dose</dt>
                  <dd>{m.dose}</dd>
                </div>
                <div>
                  <dt className="font-medium text-slate-900">Pregnancy ({m.pregnancySafe})</dt>
                </div>
              </dl>
            )}
          </li>
        ))}
        {filtered.length === 0 && <li className="p-6 text-center text-slate-500">No matches.</li>}
      </ul>

      {limit < filtered.length && (
        <button className="mt-4 rounded-lg bg-emerald-700 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-800" onClick={() => setLimit(limit + 100)}>
          Show more
        </button>
      )}
    </div>
  );
}
