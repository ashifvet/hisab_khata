import fs from "node:fs";
import path from "node:path";
import MedicineBrowser, { type Medicine } from "@/components/MedicineBrowser";

export const dynamic = "force-dynamic";

function load(): Medicine[] {
  const file = path.join(process.cwd(), "public", "data", "vet_medicines.json");
  return JSON.parse(fs.readFileSync(file, "utf8")) as Medicine[];
}

const downloads = [
  { href: "/data/vet_medicines.json", label: "JSON (Firestore format)" },
  { href: "/data/vet_medicines.ndjson", label: "NDJSON" },
  { href: "/data/vet_medicines.csv", label: "CSV" },
  { href: "/data/import-to-firestore.mjs", label: "Import script" },
  { href: "/data/FIREBASE_IMPORT.md", label: "Import guide" },
];

export default function HomePage() {
  const items = load();
  return (
    <main className="mx-auto max-w-4xl px-5 py-10">
      <p className="text-sm uppercase tracking-widest text-slate-500">Bangladesh veterinary medicines</p>
      <h1 className="mt-2 text-3xl font-semibold text-slate-950">Medicine data ready for Firebase</h1>
      <p className="mt-3 text-slate-700">
        {items.length} records extracted from the Bangladesh National Veterinary Formulary 2023 (DGDA) and the PetZone BD
        veterinary-medicine category, mapped to your Firestore document fields.
      </p>
      <div className="mt-5 flex flex-wrap gap-2">
        {downloads.map((d) => (
          <a
            key={d.href}
            href={d.href}
            download
            className="rounded-lg border border-emerald-700 px-3 py-1.5 text-sm font-medium text-emerald-800 hover:bg-emerald-50"
          >
            {d.label}
          </a>
        ))}
      </div>
      <div className="mt-8">
        <MedicineBrowser items={items} />
      </div>
    </main>
  );
}
